// ============================================================================
//  BatNXT — Chat Worker (routes: /chat , /generate)
//  Hardened: CORS allowlist + Origin/Referer gate  (+ optional Turnstile)
// ============================================================================

// ── 1) Allowed origins (only these sites may call the worker) ───────────────
//    Add/remove domains here. localhost entries are for local testing only.
const ALLOWED_ORIGINS = [
  'https://batnxt.com',
  'https://www.batnxt.com',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'http://localhost:3000'
];

// ── 2) Turnstile toggle ─────────────────────────────────────────────────────
//    Keep false until you create a Turnstile widget and add TURNSTILE_SECRET
//    as a Worker secret. NOTE for chat: per-message Turnstile is not ideal
//    (tokens are single-use + expire ~300s). Prefer a session token for chat.
const REQUIRE_TURNSTILE = false;

// ── helpers ──────────────────────────────────────────────────────────────────
// Any http://localhost:<port> or http://127.0.0.1:<port> is allowed for local
// dev, regardless of port — the Origin header can't be forged by a real
// browser from a remote site, so this stays safe while covering tools like
// Claude Code's Preview proxy that pick a random local port each run.
function isAllowedOrigin(origin) {
  if (ALLOWED_ORIGINS.includes(origin)) return true;
  try {
    const u = new URL(origin);
    if (u.protocol === 'http:' && (u.hostname === 'localhost' || u.hostname === '127.0.0.1')) {
      return true;
    }
  } catch (_) {}
  return false;
}

function pickOrigin(request) {
  const origin = request.headers.get('Origin') || '';
  if (isAllowedOrigin(origin)) return origin;
  // Fallback: derive from Referer (some browsers omit Origin on same-site GET)
  const ref = request.headers.get('Referer') || '';
  try {
    const refOrigin = new URL(ref).origin;
    if (isAllowedOrigin(refOrigin)) return refOrigin;
  } catch (_) {}
  return null;
}

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Internal-Key',
    'Vary': 'Origin'
  };
}

// ── Internal-key gate ────────────────────────────────────────────────────────
// The Gateway Worker (worker/gateway.js) is now the ONLY legitimate caller of
// this Worker. It forwards a shared secret in the `X-Internal-Key` header. Any
// request missing or mismatching that secret is rejected here — this closes the
// previously wide-open direct-access hole (Origin/Referer headers are NOT a
// security boundary; they are trivially spoofed by a non-browser client).
//
// Transition safety: if INTERNAL_KEY is not yet configured as a Worker secret,
// the gate is SKIPPED (fail-open) so nothing breaks before the secret is set on
// both this Worker and the gateway. Once INTERNAL_KEY is present, enforcement is
// strict. Set it via: Cloudflare Dashboard → this Worker → Settings → Variables
// → add secret `INTERNAL_KEY` (same value on the gateway).
function internalKeyOk(request, env) {
  if (!env.INTERNAL_KEY) {
    console.warn('[SECURITY] INTERNAL_KEY not configured — direct-access gate is OPEN. Set the secret to close it.');
    return true;
  }
  return request.headers.get('X-Internal-Key') === env.INTERNAL_KEY;
}

function deny(status, message, origin) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...(origin ? corsHeaders(origin) : { 'Access-Control-Allow-Origin': 'null' })
    }
  });
}

async function verifyTurnstile(token, secret, ip) {
  if (!token || !secret) return false;
  const form = new FormData();
  form.append('secret', secret);
  form.append('response', token);
  if (ip) form.append('remoteip', ip);
  try {
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      body: form
    });
    const data = await r.json();
    return data.success === true;
  } catch (_) {
    return false;
  }
}

// ============================================================================
//  PERFORMANCE TIMING — measurement only, no behavior/architecture change.
//  Records a timestamp for each named stage and prints one [PERFORMANCE]
//  block per request at the end, so real bottlenecks can be located from
//  the Worker's console logs (Cloudflare dashboard → Logs, or `wrangler tail`).
// ============================================================================
function createPerfTracker(requestId) {
  const t0 = Date.now();
  const marks = [];
  const mark = (label) => {
    marks.push({ label, t: Date.now() - t0 });
  };
  mark('REQUEST_RECEIVED');

  // Rough token estimate — real tokenizers vary, but chars/4 is a standard
  // ballpark for English text and good enough to compare relative sizes.
  const estimateTokens = (text) => Math.ceil((text || '').length / 4);

  const finish = (extra = {}) => {
    mark('RESPONSE_SENT');
    const lines = ['[PERFORMANCE] requestId=' + requestId];
    for (let i = 0; i < marks.length; i++) {
      const prev = i === 0 ? 0 : marks[i - 1].t;
      lines.push(`  ${marks[i].label}: +${marks[i].t - prev}ms (t=${marks[i].t}ms)`);
    }
    if (extra.promptChars != null) {
      lines.push(`  Prompt size: ${extra.promptChars} characters, ~${extra.promptTokens} estimated tokens`);
    }
    if (extra.note) lines.push(`  Note: ${extra.note}`);
    lines.push(`  Total time: ${marks[marks.length - 1].t}ms`);
    console.log(lines.join('\n'));
  };

  return { mark, finish, estimateTokens };
}

// ============================================================================
//  IMAGE PREPROCESSING (Moondream) — Sequential Pipeline
//  This pipeline still runs unconditionally for all 3 chat models (Prime:
//  @cf/moonshotai/kimi-k2.7-code, Core: @cf/openai/gpt-oss-120b,
//  Flash: @cf/meta/llama-4-scout-17b-16e-instruct), even though Kimi and
//  Llama-4-Scout are natively multimodal (gpt-oss is text-only) — mixing a
//  Moondream-derived text description into the prompt is a decision
//  separate from raw vision capability, and switching Prime/Flash to send
//  the image directly to the model is a possible future optimization, not
//  made in this change. When the user attaches an image to a chat message,
//  this helper runs it through a dedicated vision model FIRST and merges its
//  description into the last user message's text as extra context. The
//  main chat model never sees the raw image — only this merged text — and
//  is otherwise completely unaware whether its input was augmented.
//  Degrades gracefully: any single image's failure here just skips that
//  image rather than failing the whole chat turn.
//  Runs all images through Moondream IN PARALLEL (Promise.all) — analysis
//  time stays ~constant regardless of image count, instead of multiplying.
//  Returns an array of booleans (same order/length as imageDataUrls), one
//  per image, used to signal the gateway, via response header, exactly
//  which images were analyzed (for per-image billing + Library persistence).
// ============================================================================
async function analyzeOneImage(env, imageDataUrl) {
  try {
    // Fixed generic English description prompt — decoupled from the user's raw question.
    // Moondream's only job is to describe the image; the main chat model uses that
    // description (plus the user's actual question) to formulate the final answer.
    const question = "Describe this image in detail: objects, people, text, colors, and context.";
    const visionRes = await env.AI.run('@cf/moondream/moondream3.1-9B-A2B', {
      image: imageDataUrl,
      task: 'query',
      question,
      max_tokens: 512,
      stream: false
    });
    // Response shape nests both fields one level deeper, under `result`:
    // visionRes.result.answer and visionRes.result.reasoning.text.
    // `reasoning.text` (the natural-language description) is preferred;
    // `answer` is the fallback.
    const reasoningText = visionRes?.result?.reasoning?.text
      ? String(visionRes.result.reasoning.text).trim()
      : '';
    const answerText = visionRes?.result?.answer ? String(visionRes.result.answer).trim() : '';
    return reasoningText || answerText || '';
  } catch (e) {
    return '';
  }
}

async function applyImagePreprocessing(env, aiMessages, imageDataUrls) {
  if (!Array.isArray(imageDataUrls) || imageDataUrls.length === 0) return [];
  const lastUserIdx = aiMessages.map(m => m.role).lastIndexOf('user');
  if (lastUserIdx === -1) return imageDataUrls.map(() => false);

  const answers = await Promise.all(imageDataUrls.map(url => analyzeOneImage(env, url)));

  const analyzed = answers.map(a => !!a);
  const describedLines = answers
    .map((answer, i) => (answer ? `[Attached image ${i + 1}]: ${answer}` : null))
    .filter(Boolean);
  if (describedLines.length) {
    aiMessages[lastUserIdx].content =
      `${aiMessages[lastUserIdx].content || ''}\n\n${describedLines.join('\n\n')}`;
  }
  return analyzed;
}

// content_filter fallback bank intentionally NOT added yet — deferred until a
// dedicated live test (a deliberately-blocked prompt) shows how Workers AI
// actually surfaces it for these models (exception vs. empty response vs.
// something else). See conversation 2026-07-19 for full rationale.

// Appended to the end of the plain-text stream when a reply is likely
// truncated (see `truncation` below). Streaming means the old non-streaming
// behavior — silently swapping the whole reply for a friendly fallback
// message BEFORE the user sees anything — is no longer possible: by the time
// truncation is known (the last chunk), the user has already watched the
// partial text stream in. The frontend strips this sentinel and shows a
// small "response was cut short" note instead (same spirit as the inline
// `<!-- generation error: ... -->` marker websitegenerator.js already emits
// on stream errors).
const BATNXT_TRUNCATED_SENTINEL = '\n<!--BATNXT_TRUNCATED-->';

// Sentinel tags wrapping the model's real reasoning/chain-of-thought at the
// START of a stream, emitted ONLY when a route opts in via emitReasoning:true
// (currently /chat/core — gpt-oss, the one model that exposes a separate
// `delta.reasoning`/`delta.reasoning_content` channel). The reasoning already
// streams first (before the visible answer) and is already billed via the
// pinned X-Output-Tokens ceiling, so forwarding it costs nothing extra. The
// frontend routes anything inside these tags into the "Thought for Xs" widget
// and strips it from the reply bubble. Backward-safe: a frontend that doesn't
// yet know these tags just sees them stripped like any other control tag, and
// an un-opted route never emits them (current behavior, byte-for-byte).
const BATNXT_REASONING_OPEN  = '<REASONING>';
const BATNXT_REASONING_CLOSE = '</REASONING>';

// ============================================================================
//  SHARED STREAMING RESPONDER for /chat, /chat/flash, /chat/core,
//  /chat/marketing-eco — reuses the SSE-pump pattern already proven in
//  websitegenerator.js (stream:true -> TransformStream -> parse `data:`
//  lines -> write plain text chunks), minus the markdown-fence stripping
//  (chat replies have no code fences to strip) and plus per-route
//  truncation detection:
//    'finish_reason'   — real signal from the model's OpenAI-compatible
//                         stream (same field already read non-streaming
//                         today for /chat/core and /chat/marketing-eco).
//    'token_heuristic' — no finish_reason available (Llama Scout / gpt-oss via
//                         the binding, which returns a plain {response} stream
//                         with no finish_reason): compare accumulated output
//                         chars/4 against maxTokens.
//    'none'            — no truncation handling (Kimi/Prime has none today
//                         either).
// ============================================================================
async function streamChatReply(env, ctx, perf, {
  model, aiOptions, extraAiOpts, truncation, maxTokens,
  promptTokens, imagesAnalyzedHeader, routeLabel, origin,
  outputTokensHeader, emitReasoning
}) {
  let aiStream;
  try {
    perf.mark('AI_REQUEST_START');
    aiStream = await env.AI.run(model, Object.assign({}, aiOptions, { stream: true }), extraAiOpts);
    // Resolves once the ReadableStream handle is back, not once the model has
    // produced output — AI_FIRST_TOKEN_RECEIVED inside the pump below is the
    // real "first useful byte" timing.
    perf.mark('AI_STREAM_HANDLE_RECEIVED');
  } catch (err) {
    perf.finish({ promptTokens, note: `${routeLabel}: AI.run() threw before streaming started: ${err.message}` });
    return deny(500, err.message, origin);
  }

  const { readable, writable } = new TransformStream();
  const writer = writable.getWriter();
  const encoder = new TextEncoder();

  const pump = (async () => {
    const reader = aiStream.getReader();
    const decoder = new TextDecoder();
    let sseBuffer = '';
    let firstTokenSeen = false;
    let outputChars = 0;
    let lastFinishReason = null;
    // Tracks whether a <REASONING> block is currently open (emitReasoning routes
    // only). Opened on the first reasoning delta, closed the moment the first
    // visible-answer delta arrives (reasoning always precedes the answer) or when
    // the stream ends. Stays false forever on non-opted routes.
    let reasoningOpen = false;

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        sseBuffer += decoder.decode(value, { stream: true });
        const lines = sseBuffer.split('\n');
        sseBuffer = lines.pop() ?? '';
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const payload = trimmed.slice(5).trim();
          if (!payload || payload === '[DONE]') continue;
          let delta = '';
          let parsed = null;
          try {
            parsed = JSON.parse(payload);
            // Two streamed shapes, both handled by this one line:
            //  • {response} string   — Kimi/Prime, Llama Scout, Gemma.
            //  • OpenAI choices[].delta — gpt-oss on /chat/core (confirmed
            //    2026-07-21 via a live tail: through the env.AI.run binding it
            //    uses this shape, NOT the Responses-API events its REST endpoint
            //    uses). gpt-oss is a reasoning model and puts its chain-of-
            //    thought in `delta.reasoning`/`delta.reasoning_content` while the
            //    real answer is in `delta.content` — so reading only
            //    `delta.content` here filters the reasoning out for free; it is
            //    never written to the client. `finish_reason` (e.g. 'stop' /
            //    'length') arrives on choices[0] and is read just below.
            delta = parsed?.response ?? parsed?.choices?.[0]?.delta?.content ?? '';
          } catch (_) {}
          if (parsed && parsed.choices?.[0]?.finish_reason) {
            lastFinishReason = parsed.choices[0].finish_reason;
          }
          // Opt-in reasoning passthrough (currently /chat/core only): gpt-oss
          // streams its chain-of-thought in delta.reasoning_content / .reasoning
          // BEFORE any visible answer content. When emitReasoning is on we forward
          // that reasoning wrapped in <REASONING>…</REASONING> so the frontend can
          // route it into the "Thought for Xs" widget. It is NOT counted toward
          // outputChars (billing is pinned via outputTokensHeader for this route)
          // and does NOT flip firstTokenSeen — the answer's first token remains the
          // real "first useful byte" timing, and the widget measures its own span.
          if (emitReasoning) {
            const rDelta = parsed?.choices?.[0]?.delta?.reasoning_content
              ?? parsed?.choices?.[0]?.delta?.reasoning ?? '';
            if (rDelta) {
              if (!reasoningOpen) {
                reasoningOpen = true;
                await writer.write(encoder.encode(BATNXT_REASONING_OPEN));
              }
              await writer.write(encoder.encode(rDelta));
            }
          }
          if (!delta) continue;
          // First visible-answer delta: close any open reasoning block before the
          // answer bytes go out, so the frontend sees a clean <REASONING>…</REASONING>
          // prefix followed by the reply.
          if (reasoningOpen) {
            reasoningOpen = false;
            await writer.write(encoder.encode(BATNXT_REASONING_CLOSE));
          }
          if (!firstTokenSeen) {
            firstTokenSeen = true;
            perf.mark('AI_FIRST_TOKEN_RECEIVED');
          }
          outputChars += delta.length;
          await writer.write(encoder.encode(delta));
        }
      }
      // Reasoning-only stream (no visible answer ever arrived): close the tag so
      // the frontend never sees a dangling <REASONING> with no terminator.
      if (reasoningOpen) {
        reasoningOpen = false;
        try { await writer.write(encoder.encode(BATNXT_REASONING_CLOSE)); } catch (_) {}
      }
      perf.mark('AI_RESPONSE_COMPLETED');

      perf.mark('POST_PROCESSING_START');
      // NOTE (token_heuristic): unlike the real finish_reason signal, this is
      // an estimate — same ballpark chars/4 method used everywhere else in
      // this file — and needs live-traffic confirmation, same as the
      // non-streaming heuristic it replaces (see /chat/flash below).
      const likelyTruncated = truncation === 'finish_reason'
        ? lastFinishReason === 'length'
        : truncation === 'token_heuristic'
          ? Math.ceil(outputChars / 4) >= maxTokens - 1
          : false;
      if (likelyTruncated) {
        await writer.write(encoder.encode(BATNXT_TRUNCATED_SENTINEL));
      }
      perf.mark('POST_PROCESSING_COMPLETED');
      perf.mark('RESPONSE_SENT');
      perf.finish({
        promptTokens, outputChars,
        note: `${routeLabel}: streamed. likely_truncated=${likelyTruncated} last_finish_reason=${lastFinishReason}`
      });
      try { await writer.close(); } catch (_) {}
    } catch (err) {
      if (!firstTokenSeen) perf.mark('AI_FIRST_TOKEN_RECEIVED');
      perf.mark('AI_RESPONSE_COMPLETED');
      if (reasoningOpen) {
        reasoningOpen = false;
        try { await writer.write(encoder.encode(BATNXT_REASONING_CLOSE)); } catch (_) {}
      }
      try { await writer.write(encoder.encode(`\n<!-- generation error: ${err.message} -->\n`)); } catch (_) {}
      perf.finish({ promptTokens, outputChars, note: `${routeLabel}: stream error: ${err.message}` });
      try { await writer.close(); } catch (_) {}
    }
  })();

  ctx.waitUntil(pump);

  // Returned immediately once the ReadableStream exists — headers go out
  // right away, the body streams progressively as `pump` writes to it.
  //
  // X-Output-Tokens: normally omitted for streaming (the true count isn't
  // known until the body finishes) and gateway.js then estimates output from
  // the streamed byte count. But for a REASONING model (gpt-oss on /chat/core)
  // that estimate is unsafe: the reasoning channel is filtered out before it
  // reaches the client, so the streamed bytes only reflect the visible answer
  // while Cloudflare still bills for the (invisible) reasoning tokens. To keep
  // billing safe, such routes pass `outputTokensHeader = maxTokens` (the effort
  // cap, which bounds TOTAL output incl. reasoning), pinning the charge to the
  // per-effort worst case instead of undercounting. Non-reasoning routes leave
  // it undefined and keep the byte-estimate fallback.
  return new Response(readable, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'X-Input-Tokens': String(promptTokens),
      ...(outputTokensHeader != null ? { 'X-Output-Tokens': String(outputTokensHeader) } : {}),
      ...(imagesAnalyzedHeader != null ? { 'X-Images-Analyzed': imagesAnalyzedHeader } : {}),
      ...corsHeaders(origin)
    }
  });
}

// ── /marketing/extract config + SSRF-blocking helper ──────────────────────
// Matches the frontend's own MARKETING_ATTACH_MAX_BYTES / MARKETING_ALLOWED_EXT
// mirror constants in js/x9k2-legacy-shim-t8vn.js — keep in sync.
const MARKETING_EXTRACT_FETCH_TIMEOUT_MS = 10000; // 10s
const MARKETING_EXTRACT_MAX_BYTES = 5 * 1024 * 1024; // 5MB
const MARKETING_EXTRACT_ALLOWED_EXT = ['pdf', 'doc', 'docx', 'html', 'htm', 'csv', 'xlsx', 'odt'];
// env.AI.toMarkdown() expects an explicit MIME type on the Blob it's given
// (Cloudflare's own examples always set one) — without it, internal format
// detection can fail. Mirrors the URL-fetch branch, which already sets
// `type` from the fetched response's own Content-Type header.
const MARKETING_EXTRACT_MIME_TYPES = {
  pdf: 'application/pdf',
  doc: 'application/msword',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  html: 'text/html',
  htm: 'text/html',
  csv: 'text/csv',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  odt: 'application/vnd.oasis.opendocument.text'
};

/**
 * SSRF guard for /marketing/extract's URL-fetch branch. Blocks hostnames that
 * resolve (by literal form — this is a pre-fetch string/IP-literal check, not
 * a DNS-resolution check) to loopback, private, link-local, or cloud-metadata
 * address space, plus bare "localhost". Covers IPv4 (127.0.0.0/8, 10.0.0.0/8,
 * 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16 — the last one covers the
 * common cloud metadata endpoint 169.254.169.254) and IPv6 (::1, fc00::/7
 * unique-local, fe80::/10 link-local, and ::ffff:-mapped IPv4 addresses,
 * checked recursively).
 */
function isPrivateOrLocalHostname(hostname) {
  const host = String(hostname || '').toLowerCase();
  if (!host) return true;
  if (host === 'localhost' || host.endsWith('.localhost')) return true;

  // IPv4 literal?
  const v4 = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (v4) {
    const [a, b] = [parseInt(v4[1], 10), parseInt(v4[2], 10)];
    if (a === 127) return true; // 127.0.0.0/8 loopback
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 169 && b === 254) return true; // 169.254.0.0/16 (incl. cloud metadata)
    if (a === 100 && b >= 64 && b <= 127) return true; // 100.64.0.0/10 (CGNAT)
    if (a === 0) return true; // 0.0.0.0/8
    return false;
  }

  // IPv6 literal (hostname from URL parsing may include brackets stripped already).
  if (host.includes(':')) {
    if (host === '::1' || host === '::') return true;
    if (host.startsWith('fc') || host.startsWith('fd')) return true; // fc00::/7 unique-local
    if (host.startsWith('fe8') || host.startsWith('fe9') || host.startsWith('fea') || host.startsWith('feb')) return true; // fe80::/10 link-local
    const v4mapped = host.match(/^::ffff:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/);
    if (v4mapped) return isPrivateOrLocalHostname(v4mapped[1]);
    return false;
  }

  return false;
}

export default {
  async fetch(request, env, ctx) {
    const perf = createPerfTracker(crypto.randomUUID());
    const origin = pickOrigin(request);

    // ── CORS preflight ──────────────────────────────────────────────────────
    if (request.method === 'OPTIONS') {
      // Only answer preflight for allowed origins
      if (!origin) return new Response(null, { status: 403 });
      return new Response(null, { headers: corsHeaders(origin) });
    }

    // ── Health check (safe, no AI) ──────────────────────────────────────────
    if (request.method === 'GET') {
      return new Response('BatNXT Worker is running!', {
        headers: { 'Content-Type': 'text/plain' }
      });
    }

    if (request.method !== 'POST') {
      return deny(405, 'Method not allowed', origin);
    }

    // ── Internal-key gate: only the gateway may reach the AI routes ─────────
    if (!internalKeyOk(request, env)) {
      return deny(403, 'Forbidden: direct access not allowed', origin);
    }

    // ── Origin gate: block anything not from an allowed site ────────────────
    if (!origin) {
      return deny(403, 'Forbidden: origin not allowed', null);
    }

    // ── Optional Turnstile gate ─────────────────────────────────────────────
    let body;
    try {
      body = await request.json();
    } catch (_) {
      return deny(400, 'Invalid JSON body', origin);
    }

    if (REQUIRE_TURNSTILE) {
      const ok = await verifyTurnstile(
        body.turnstileToken,
        env.TURNSTILE_SECRET,
        request.headers.get('CF-Connecting-IP')
      );
      if (!ok) return deny(403, 'Turnstile verification failed', origin);
    }

    const url  = new URL(request.url);
    const path = url.pathname;

    // ── ROUTE: /generate ────────────────────────────────────────────────────
    if (path === '/' || path === '/generate') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const prompt = body.prompt || 'simple dodge game';
        const promptContent = `You are a hyper-casual HTML5 game generator. Return ONLY a complete working self-contained HTML file, no markdown, no backticks, no explanation. Use vanilla JS + Canvas, dark theme, show score, start screen, game over screen with restart button, touch support. Build this game: ${prompt}`;
        const promptChars = promptContent.length;
        const promptTokens = perf.estimateTokens(promptContent);
        perf.mark('PROMPT_READY');

        // NOTE: this call is NOT streaming (no `stream: true`), so the
        // await below only resolves once GLM has finished generating the
        // ENTIRE response. That means AI_REQUEST_START → AI_RESPONSE_COMPLETED
        // is the single biggest number to look at — there is no separate
        // "first token" moment to measure here, unlike the streaming
        // website generator.
        perf.mark('AI_REQUEST_START');
        const aiRes = await env.AI.run('@cf/zai-org/glm-5.2', {
          max_completion_tokens: 4096,
          messages: [{
            role: 'user',
            content: promptContent
          }]
        });
        perf.mark('AI_FIRST_TOKEN_RECEIVED'); // same instant as completion: non-streaming call
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        const html = aiRes.response || aiRes.choices?.[0]?.message?.content || '';
        const responseBody = JSON.stringify({ html });
        perf.mark('POST_PROCESSING_COMPLETED');

        perf.finish({
          promptChars,
          promptTokens,
          note: 'Not streaming — AI_REQUEST_START to AI_RESPONSE_COMPLETED is the full GLM generation time; the client sees nothing until this whole block finishes.'
        });

        // Report token counts so the gateway can settle at real usage. GLM's
        // non-streaming response carries no usage object, so we estimate from
        // char counts (chars/4) — the same ballpark used everywhere else.
        return new Response(responseBody, {
          headers: {
            'Content-Type': 'application/json',
            'X-Input-Tokens': String(promptTokens),
            'X-Output-Tokens': String(perf.estimateTokens(html)),
            ...corsHeaders(origin)
          }
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /chat ────────────────────────────────────────────────────────
    if (path === '/chat') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const system   = body.system   || '';
        const messages = body.messages || [];

        if (!Array.isArray(messages)) {
          perf.finish({ note: 'messages must be an array' });
          return deny(400, 'messages must be an array', origin);
        }

        const aiMessages = [];
        if (system) aiMessages.push({ role: 'system', content: system });
        aiMessages.push(...messages);
        if (!aiMessages.some(m => m.role === 'user')) {
          aiMessages.push({ role: 'user', content: 'Hello' });
        }

        // Sequential Pipeline: if an image was attached, Moondream analyzes
        // it first and its description is merged into the last user message
        // — the main model below always receives text-only input.
        const imagesAnalyzed = await applyImagePreprocessing(env, aiMessages, body.images);

        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        // Stable per-user id forwarded by the gateway (chat only) so Workers AI
        // can route repeat calls in this conversation to the same model
        // instance and maximize prefix-cache hit rate.
        const sessionAffinity = request.headers.get('X-Session-Affinity') || '';

        // Reasoning-depth tier (Low/Medium/High) selected by the user on the
        // frontend, independent of the Memory toggle. This reasoning_effort
        // logic was written for GLM-5.2's two real levels ('high'/'max').
        // Model swap 2026-07-19: now calling @cf/moonshotai/kimi-k2.7-code
        // instead — NOT YET CONFIRMED whether Kimi accepts/honors the same
        // 'high'/'max' reasoning_effort values the same way GLM-5.2 did;
        // needs live-traffic confirmation. Left unchanged pending that
        // confirmation (out of scope for this batch):
        //   Low    -> explicit 'high' (shallower than the default) + fewer tokens, for lower cost
        //   Medium -> unchanged: no reasoning_effort sent, default max_completion_tokens
        //   High   -> explicit 'max' + more tokens, as a genuine step up from Medium
        const effort = body.effort || 'Medium';
        // Anti-degeneration guard: kimi-k2.7-code is code-tuned and can spiral
        // into repeated characters on casual/emotional non-code messages (e.g.
        // "بحبك" -> "وااااااا..." running up to the token cap). A mild
        // frequency/presence penalty breaks that repetition loop without
        // noticeably affecting normal replies. Unknown params are ignored
        // safely upstream if kimi doesn't honor one of them.
        const aiOptions = {
          messages: aiMessages,
          frequency_penalty: 0.5,
          presence_penalty: 0.3,
        };
        if (effort === 'Low') {
          aiOptions.reasoning_effort = 'high';
          aiOptions.max_completion_tokens = 2048;
        } else if (effort === 'High') {
          aiOptions.reasoning_effort = 'max';
          aiOptions.max_completion_tokens = 16384;
        } else {
          aiOptions.max_completion_tokens = 8192;
        }

        return await streamChatReply(env, ctx, perf, {
          model: '@cf/moonshotai/kimi-k2.7-code',
          aiOptions,
          extraAiOpts: sessionAffinity ? { extraHeaders: { 'x-session-affinity': sessionAffinity } } : undefined,
          truncation: 'none', // Kimi has no truncation-fallback handling non-streaming either
          promptTokens,
          imagesAnalyzedHeader: imagesAnalyzed.map(b => b ? '1' : '0').join(','),
          routeLabel: '/chat',
          origin,
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /chat/flash (bat 1.2 flash — Workers AI, @cf/meta/llama-4-scout-17b-16e-instruct) ──
    if (path === '/chat/flash') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const system   = body.system   || '';
        const messages = body.messages || [];

        if (!Array.isArray(messages)) {
          perf.finish({ note: 'messages must be an array' });
          return deny(400, 'messages must be an array', origin);
        }

        const aiMessages = [];
        if (system) aiMessages.push({ role: 'system', content: system });
        aiMessages.push(...messages);
        if (!aiMessages.some(m => m.role === 'user')) {
          aiMessages.push({ role: 'user', content: 'Hello' });
        }

        // Sequential Pipeline: if an image was attached, Moondream analyzes
        // it first and its description is merged into the last user message
        // — the main model below always receives text-only input.
        const imagesAnalyzed = await applyImagePreprocessing(env, aiMessages, body.images);

        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        // Stable per-user id forwarded by the gateway (chat + chat/flash) so
        // Workers AI can route repeat calls in this conversation to the same
        // model instance and maximize prefix-cache hit rate — same parity as
        // /chat below. NOTE: as of this writing, @cf/meta/llama-4-scout-17b-16e
        // -instruct's own Cloudflare model page lists no discounted cached-input
        // price (unlike kimi-k2.7-code's, which does), so this is not confirmed
        // to yield any cost savings yet — forwarded anyway for consistency, and
        // so the TEMP DIAGNOSTIC usage log below can confirm from real traffic
        // whether Workers AI ever reports cached tokens for this model.
        const sessionAffinity = request.headers.get('X-Session-Affinity') || '';

        // Same Low/Medium/High selector as /chat, mapped onto output-token
        // budget only — Llama Scout is a plain instruct model with no thinking
        // mode, so (unlike /chat/core's gpt-oss, which now maps the selector
        // onto reasoning_effort) we don't send reasoning_effort here and only
        // vary the token budget.
        const effort = body.effort || 'Medium';
        const maxTokens = effort === 'Low' ? 2048 : effort === 'High' ? 16384 : 8192;

        perf.mark('AI_REQUEST_START');
        // llama-4-scout-17b-16e-instruct: per Cloudflare's own docs, this model
        // only documents the `max_tokens` param (default 256) — NOT
        // `max_completion_tokens` (unlike kimi-k2.7-code/nemotron-3-120b-a12b
        // above/below). Using max_completion_tokens here would silently be
        // ignored and every response would truncate at the 256-token default,
        // so max_tokens is used deliberately, not interchangeably. Plain
        // instruct model, no built-in thinking/reasoning mode, so no
        // reasoning_effort/enable_thinking param is needed or sent.
        // finish_reason confirmed NOT present anywhere in this model's actual
        // response shape ({response, tool_calls, usage} — no choices[], no
        // top-level finish_reason; confirmed 2026-07-19 via a one-time raw
        // response dump), so streamChatReply falls back to the same
        // chars/4-vs-maxTokens heuristic the old non-streaming path used
        // (via `truncation: 'token_heuristic'`).
        // content_filter is NOT handled here — no reliable signal exists to
        // tell it apart from a short-but-complete answer with this response
        // shape; deferred until a dedicated live test (a deliberately blocked
        // prompt) shows how Workers AI actually surfaces it for this model.
        return await streamChatReply(env, ctx, perf, {
          model: '@cf/meta/llama-4-scout-17b-16e-instruct',
          aiOptions: { messages: aiMessages, max_tokens: maxTokens },
          extraAiOpts: sessionAffinity ? { extraHeaders: { 'x-session-affinity': sessionAffinity } } : undefined,
          truncation: 'token_heuristic',
          maxTokens,
          promptTokens,
          imagesAnalyzedHeader: imagesAnalyzed.map(b => b ? '1' : '0').join(','),
          routeLabel: '/chat/flash',
          origin,
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /chat/core (bat 1.2 core — Workers AI, @cf/openai/gpt-oss-120b) ──
    if (path === '/chat/core') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const system   = body.system   || '';
        const messages = body.messages || [];

        if (!Array.isArray(messages)) {
          perf.finish({ note: 'messages must be an array' });
          return deny(400, 'messages must be an array', origin);
        }

        const aiMessages = [];
        if (system) aiMessages.push({ role: 'system', content: system });
        aiMessages.push(...messages);
        if (!aiMessages.some(m => m.role === 'user')) {
          aiMessages.push({ role: 'user', content: 'Hello' });
        }

        // Sequential Pipeline: if an image was attached, Moondream analyzes
        // it first and its description is merged into the last user message
        // — the main model below always receives text-only input.
        const imagesAnalyzed = await applyImagePreprocessing(env, aiMessages, body.images);

        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        // gpt-oss-120b, called through the env.AI.run binding, takes the SAME
        // OpenAI chat-completions shape as the other chat routes here — NOT the
        // Responses API (`input`/`instructions`/`reasoning`) its REST endpoint
        // uses. Confirmed 2026-07-21: sending `input`/`instructions` made the
        // binding silently ignore them (usage.input_tokens === 0, empty
        // response). So it takes:
        //   • `messages`         — conversation incl. the role:'system' item.
        //   • `max_tokens`       — output cap (default 256 per the model's docs,
        //                          so it MUST be sent). Kept at the same
        //                          1024/2048/4096 budget as before
        //                          (SERVICE_LIMITS.chat_core.maxOutput in
        //                          gateway.js is still 4096).
        //   • `reasoning_effort` — best-effort control of thinking depth; the
        //                          same Low/Medium/High selector maps onto
        //                          low/medium/high. If the binding ignores it
        //                          (as it did the Responses-API params) it's a
        //                          harmless no-op.
        // gpt-oss is a reasoning model, and through the binding it DOES expose
        // reasoning as a separate channel: the chain-of-thought streams in
        // `delta.reasoning`/`delta.reasoning_content` while the final answer is
        // in `delta.content`. streamChatReply reads only `delta.content`, so the
        // reasoning is filtered out and never reaches the user (confirmed via a
        // live tail 2026-07-21).
        const effort = body.effort || 'Medium';
        const reasoningEffort = effort === 'Low' ? 'low' : effort === 'High' ? 'high' : 'medium';
        const maxTokens = effort === 'Low' ? 1024 : effort === 'High' ? 4096 : 2048;

        // truncation: 'finish_reason' — through the binding gpt-oss uses the
        // OpenAI choices[].delta shape and DOES emit a real finish_reason on
        // choices[0] ('stop' when complete, 'length' when cut off at max_tokens;
        // confirmed 2026-07-21 via a live tail), so cut-off is detected from the
        // model's own signal rather than a byte heuristic — and the heuristic
        // would be unreliable here anyway since it only sees the visible answer
        // chars, not the (filtered) reasoning that also counts toward max_tokens.
        return await streamChatReply(env, ctx, perf, {
          model: '@cf/openai/gpt-oss-120b',
          aiOptions: { messages: aiMessages, max_tokens: maxTokens, reasoning_effort: reasoningEffort },
          truncation: 'finish_reason',
          maxTokens,
          promptTokens,
          imagesAnalyzedHeader: imagesAnalyzed.map(b => b ? '1' : '0').join(','),
          routeLabel: '/chat/core',
          origin,
          // Pin the billed output-token count to the effort cap (maxTokens),
          // which bounds TOTAL output incl. the filtered reasoning channel, so
          // the flat-tier charge (chatCoreTierCredits) can't be undercut by a
          // short visible answer that hid a large reasoning burn. Yields a safe
          // per-effort charge: Low=4 / Medium=5 / High=6 credits (see gateway.js
          // CHAT_CORE_TIER_CONFIG). NOTE: assumes max_tokens caps reasoning+
          // answer, not just the answer — confirm from the tail `usage` data.
          outputTokensHeader: maxTokens,
          // Forward gpt-oss's real reasoning channel wrapped in <REASONING>…
          // </REASONING> at the head of the stream (see BATNXT_REASONING_OPEN).
          // /chat/core is the only route that opts in — it's the one model that
          // exposes a separate reasoning delta. Costs nothing extra (already
          // billed via outputTokensHeader) and is backward-safe (a frontend that
          // doesn't parse the tag just strips it).
          emitReasoning: true,
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /chat/marketing-eco (bat 2.2 — Workers AI, @cf/google/gemma-4-26b-a4b-it) ──
    // Backs the "Marketing" tool's economic model tier (see js/x9k2-legacy-
    // shim-4471v.js's Marketing view). Same request/response shape as /chat,
    // /chat/flash, /chat/core above — system+messages in, {content:[{text}]}
    // out — so it drops straight into gateway.js's existing handleGenerate()
    // proxy/billing pipeline with zero changes there beyond service routing.
    if (path === '/chat/marketing-eco') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const system   = body.system   || '';
        const messages = body.messages || [];

        if (!Array.isArray(messages)) {
          perf.finish({ note: 'messages must be an array' });
          return deny(400, 'messages must be an array', origin);
        }

        const aiMessages = [];
        if (system) aiMessages.push({ role: 'system', content: system });
        aiMessages.push(...messages);
        if (!aiMessages.some(m => m.role === 'user')) {
          aiMessages.push({ role: 'user', content: 'Hello' });
        }

        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        perf.mark('AI_REQUEST_START');
        // gemma-4-26b-a4b-it: per its own Workers AI docs page, accepts
        // max_completion_tokens (like kimi-k2.7-code/nemotron-3-120b-a12b
        // above, NOT llama-4-scout's max_tokens-only shape) and a
        // reasoning_effort param (built-in thinking mode). No
        // reasoning_effort is sent here — deliberately left at the model's
        // default, same as /chat's own "Medium" behavior — since the only
        // confirmed live-traffic issue with this model's thinking mode
        // (worker.js:~707 above, on the short-budget /status-hint route) was
        // it consuming the ENTIRE completion budget on internal reasoning;
        // this route's budget (SERVICE_LIMITS.chat_marketing_eco.maxOutput =
        // 16384 in gateway.js) is generous specifically to give reasoning
        // room without starving the actual answer. Recalibrate
        // (reasoning_effort and/or the token budget) if live traffic shows
        // otherwise.
        // gemma-4-26b-a4b-it exposes a real finish_reason like Nemotron
        // (/chat/core above), so streamChatReply watches for it directly.
        return await streamChatReply(env, ctx, perf, {
          model: '@cf/google/gemma-4-26b-a4b-it',
          aiOptions: { messages: aiMessages, max_completion_tokens: 16384 },
          truncation: 'finish_reason',
          promptTokens,
          routeLabel: '/chat/marketing-eco',
          origin,
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /status-hint (short AI-generated "what's happening" sentence,
    // used to replace the generic rotating "BatNXT is thinking..." status
    // text with something reflecting the user's actual request) ──────────
    if (path === '/status-hint') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const userPrompt = (body.prompt || '').toString().slice(0, 2000);
        const context = body.context === 'build' ? 'build' : 'chat';
        const hasImage = body.hasImage === true;
        // Unified, content-aware system prompt: the model classifies the
        // message itself (build request vs. technical question vs. general
        // conversation/greeting) instead of relying solely on the external
        // `context` flag, which previously forced a build-sentence template
        // even for plain greetings (e.g. "كيفك" -> hallucinated build
        // sentence). `context` is now embedded as a supplementary hint in
        // the user message content below, not used to pick between templates.
        // `hasImage` (from an attached-image indicator, not a guess) is
        // embedded the same way so the model can describe image analysis
        // specifically instead of a generic/build sentence.
        const systemPrompt = 'You write a single short status sentence (max 8 words), in present-continuous ' +
          'tense, describing what is currently happening in response to the user\'s ' +
          'message below. First classify the message, then respond accordingly:\n' +
          '- If it is a clear request to build/create a website, game, app, or tool, ' +
          'describe that build, e.g. "Building your dodge game...".\n' +
          '- If it is a technical question or bug report, describe that work, e.g. ' +
          '"Analyzing your login bug...".\n' +
          '- If the message includes an image attachment (marked with ' +
          '[attachment: image]), describe that you are analyzing/reading the image, ' +
          'e.g. "Analyzing your image..." or "Reading your image...", regardless of ' +
          'any accompanying text.\n' +
          '- If it is a greeting, small talk, or general conversation with no specific ' +
          'task (e.g. "hi", "how are you"), use a general phrase like "Thinking about ' +
          'your message..." or "Replying to you..." — do NOT invent a build or ' +
          'technical task that was not actually requested.\n' +
          'Output ONLY the sentence. No quotes, no markdown, no explanation.';

        const attachmentTag = hasImage ? ' [attachment: image]' : '';
        const aiMessages = [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `[context: ${context}]${attachmentTag} ${userPrompt || 'a request'}` },
        ];
        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        perf.mark('AI_REQUEST_START');
        // llama-3.1-8b-instruct-fast: plain instruct model, no built-in
        // thinking/reasoning mode (unlike GLM-4.7-Flash and Gemma-4-26b-a4b-it,
        // both of which were confirmed via live logs to consume the entire
        // completion-token budget on internal reasoning for this route) — so
        // no reasoning_effort/enable_thinking param is needed or sent.
        const aiRes = await env.AI.run('@cf/meta/llama-3.1-8b-instruct-fast', {
          messages: aiMessages,
          max_completion_tokens: 200
        });
        perf.mark('AI_FIRST_TOKEN_RECEIVED'); // same instant as completion: non-streaming call
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        let text = (aiRes.response || aiRes.choices?.[0]?.message?.content || '').toString().trim();
        text = text.replace(/^["']|["']$/g, '').slice(0, 120);
        const responseBody = JSON.stringify({ text });
        perf.mark('POST_PROCESSING_COMPLETED');

        perf.finish({
          promptChars,
          promptTokens,
          note: `Not streaming — status-hint short call. completion_tokens=${aiRes.usage?.completion_tokens} prompt_tokens=${aiRes.usage?.prompt_tokens}`
        });

        return new Response(responseBody, {
          headers: {
            'Content-Type': 'application/json',
            'X-Input-Tokens': String(promptTokens),
            'X-Output-Tokens': String(perf.estimateTokens(text)),
            ...corsHeaders(origin)
          }
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /chat/title (short, non-streaming: name a conversation) ──
    // Mirrors /status-hint: one cheap fp8 call that reads the first user +
    // first assistant turn and returns a clean 2–8 word title as {title} JSON.
    if (path === '/chat/title') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        // Strip CLARIFY / IMPROVED_PROMPT control blocks from assistant content
        // so a vague first turn (which yields a clarify question) still produces
        // a topic-based title rather than echoing the markup.
        const stripControl = (s) => (s || '')
          .replace(/<CLARIFY>[\s\S]*?<\/CLARIFY>/gi, '')
          .replace(/<IMPROVED_PROMPT>[\s\S]*?<\/IMPROVED_PROMPT>/gi, '')
          .trim();
        const src = Array.isArray(body.messages) ? body.messages : [];
        const firstUser = src.find(m => m && m.role === 'user');
        const firstAssistant = src.find(m => m && m.role === 'assistant');
        const userContent = (firstUser?.content || '').toString().slice(0, 600);
        const aiContent = stripControl((firstAssistant?.content || '').toString()).slice(0, 600);

        const systemPrompt = 'You are a conversation title generator. Reply with ONLY a ' +
          'concise title of 2–8 words in the same language as the conversation. No ' +
          'quotes, no punctuation at the end, no explanation.';
        const aiMessages = [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: 'User message: ' + (userContent || 'a request') +
            (aiContent ? '\n\nAI reply: ' + aiContent : '') +
            '\n\nWrite a 2-8 word title for this conversation.' },
        ];
        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        perf.mark('AI_REQUEST_START');
        // llama-3.1-8b-instruct-fp8: plain instruct model, no thinking/reasoning
        // mode — same rationale as /status-hint's -fast variant.
        const aiRes = await env.AI.run('@cf/meta/llama-3.1-8b-instruct-fp8', {
          messages: aiMessages,
          max_completion_tokens: 32
        });
        perf.mark('AI_FIRST_TOKEN_RECEIVED'); // same instant as completion: non-streaming call
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        let title = (aiRes.response || aiRes.choices?.[0]?.message?.content || '').toString().trim();
        title = title.replace(/^["'“”‘’]+|["'“”‘’]+$/g, '').replace(/[.!?]+$/, '').replace(/\s+/g, ' ').trim();
        title = title.split(' ').slice(0, 8).join(' ').slice(0, 60);
        const responseBody = JSON.stringify({ title });
        perf.mark('POST_PROCESSING_COMPLETED');

        perf.finish({
          promptChars,
          promptTokens,
          note: `Not streaming — chat-title short call. completion_tokens=${aiRes.usage?.completion_tokens} prompt_tokens=${aiRes.usage?.prompt_tokens}`
        });

        return new Response(responseBody, {
          headers: {
            'Content-Type': 'application/json',
            'X-Input-Tokens': String(promptTokens),
            'X-Output-Tokens': String(perf.estimateTokens(title)),
            ...corsHeaders(origin)
          }
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /chat/reason (short, non-streaming: real background reasoning) ──
    // Powers the "Thought for Xs" widget for every model EXCEPT bat 1.2 Core
    // (gpt-oss), which surfaces its own real reasoning inline via <REASONING>
    // (see /chat/core + emitReasoning). The other chat models (Kimi/Prime,
    // Llama Scout, Gemma) expose no reasoning channel, so rather than fabricate
    // "thinking" text (which would be dishonest) the frontend makes ONE cheap
    // real call here: a lightweight model genuinely reasons about how it would
    // approach the request and returns that trace as {reason} JSON. Billed
    // flat-0 in gateway.js (service 'chat_reason') — a cosmetic UX nicety that
    // must never feel like a second charge on top of the real reply. Mirrors
    // /chat/title's shape (cheap -fast model, single non-streaming call).
    if (path === '/chat/reason') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        // Accept either a single {prompt} string or a short {messages} recap;
        // strip control blocks so a clarify/improve turn doesn't pollute the
        // reasoning. Cap hard — this is a tiny best-effort call.
        const stripControl = (s) => (s || '')
          .replace(/<CLARIFY>[\s\S]*?<\/CLARIFY>/gi, '')
          .replace(/<IMPROVED_PROMPT>[\s\S]*?<\/IMPROVED_PROMPT>/gi, '')
          .replace(/<STEPS>[\s\S]*?<\/STEPS>/gi, '')
          .replace(/<MKT_SCORES>[\s\S]*?<\/MKT_SCORES>/gi, '')
          .trim();
        let userText = '';
        if (typeof body.prompt === 'string' && body.prompt.trim()) {
          userText = stripControl(body.prompt).slice(0, 1200);
        } else if (Array.isArray(body.messages)) {
          const lastUser = [...body.messages].reverse().find(m => m && m.role === 'user');
          userText = stripControl((lastUser?.content || '').toString()).slice(0, 1200);
        }
        if (!userText) {
          perf.finish({ note: 'chat_reason: no prompt/messages' });
          return deny(400, 'prompt or messages is required', origin);
        }

        // First-person, real planning trace — NOT an answer. Kept short so the
        // widget shows a tight "thinking" summary, and same-language so it reads
        // naturally for ar/en users.
        // uiLangName is client-supplied — sanitize to a short plain-word label only,
        // never interpolate it as free-form instruction text.
        const uiLangNameRaw = typeof body.uiLangName === 'string' ? body.uiLangName : '';
        const uiLangName = uiLangNameRaw.replace(/[^A-Za-z\u0600-\u06FF\s]/g, '').trim().slice(0, 30);
        const langClause = uiLangName
          ? ' The user interface language is ' + uiLangName + ' — think in ' + uiLangName +
            ' by default, unless the request is clearly written in a different language, in which case reason in that language instead.'
          : '';
        const systemPrompt = 'You are the internal reasoning module of an AI assistant. ' +
          'Given the user request, briefly think through HOW you would approach it: the goal, ' +
          'key considerations, and the concrete steps or angle you would take. Write a short ' +
          'first-person reasoning trace of 3-6 sentences in the SAME language as the request. ' +
          'Do NOT answer or solve the request itself — only reason about the approach. ' +
          'No preamble, no headings, no quotes.' + langClause;
        const aiMessages = [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userText },
        ];
        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        perf.mark('AI_REQUEST_START');
        // llama-3.1-8b-instruct-fast: plain instruct model, no thinking mode —
        // same cheap family as /status-hint and /chat/export.
        const aiRes = await env.AI.run('@cf/meta/llama-3.1-8b-instruct-fast', {
          messages: aiMessages,
          max_completion_tokens: 256
        });
        perf.mark('AI_FIRST_TOKEN_RECEIVED'); // same instant as completion: non-streaming call
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        let reason = (aiRes.response || aiRes.choices?.[0]?.message?.content || '').toString().trim();
        reason = reason.replace(/\s+\n/g, '\n').slice(0, 1200);
        const responseBody = JSON.stringify({ reason });
        perf.mark('POST_PROCESSING_COMPLETED');

        perf.finish({
          promptChars,
          promptTokens,
          note: `Not streaming — chat-reason short call. completion_tokens=${aiRes.usage?.completion_tokens} prompt_tokens=${aiRes.usage?.prompt_tokens}`
        });

        return new Response(responseBody, {
          headers: {
            'Content-Type': 'application/json',
            'X-Input-Tokens': String(promptTokens),
            'X-Output-Tokens': String(perf.estimateTokens(reason)),
            ...corsHeaders(origin)
          }
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /build-steps (AI-selected build-progress checklist labels) ──
    // Powers the "Building..." checklist shown while a website/game/tool/mobile
    // streams in (see BUILD_STEP_DETECTORS in the frontend shim). Rather than
    // always showing all 8 generic structural steps, this route asks a small
    // model to pick which of those 8 fixed categories are actually relevant to
    // THIS specific request and phrase a short custom label for each — the
    // underlying regex "done" detection stays on the existing 8 proven
    // categories (never AI-invented), only the SELECTION and LABEL TEXT are
    // AI-generated. Billed flat-0 in gateway.js (service 'build_steps') — same
    // cosmetic-UX-nicety pattern as /chat/reason above; the frontend always
    // falls back to the full static 8-step list on any failure/timeout/empty
    // response (see hcmCreateBuildWidget/createWorkspaceBuildProgress).
    if (path === '/build-steps') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const userPrompt = (body.prompt || '').toString().slice(0, 1200);
        const genType = ['website', 'game', 'tool', 'mobile'].includes(body.type) ? body.type : 'website';
        const langName = typeof body.lang === 'string' ? body.lang.slice(0, 20) : 'en';

        const CATEGORY_LIST = ['head', 'style', 'body', 'nav', 'main', 'form', 'footer', 'script'];
        const systemPrompt = 'You select which build-progress checklist items apply to a ' +
          genType + ' generation request, and write a short custom label for each.\n' +
          'You MUST choose ONLY from these exact category ids: ' + CATEGORY_LIST.join(', ') + '.\n' +
          'Pick only the categories genuinely relevant to the specific request — as few as 1 if ' +
          'the request is narrow (e.g. a simple text/rename change), up to all 8 for a full new ' +
          'build (skip categories that clearly do not apply, e.g. skip "nav" for a single-section ' +
          'landing page with no navigation bar, skip "form" if nothing is submitted).\n' +
          'For each chosen category, write a short label (max 6 words) in language code "' + langName + '" ' +
          'describing that specific build step for THIS request (e.g. for a portfolio site\'s ' +
          '"main" category: "Building project gallery" instead of the generic "Building sections").\n' +
          'Output ONLY strict JSON, no markdown, no explanation, in exactly this shape:\n' +
          '{"steps":[{"category":"head","label":"..."},...]}';

        const aiMessages = [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt || ('a new ' + genType) },
        ];
        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        perf.mark('AI_REQUEST_START');
        // granite-4.0-h-micro: confirmed via live testing (2026-07-25, 4 real
        // calls via the Workers AI REST API) to have no reasoning-budget-
        // consumption issue on this kind of short structured-output task
        // (finish_reason: "stop", reasoning_content: null on every call) —
        // unlike glm-4.7-flash/Gemma, which were confirmed (see /status-hint's
        // comment above) to consume the entire completion-token budget on
        // internal reasoning for a similarly small route.
        const aiRes = await env.AI.run('@cf/ibm-granite/granite-4.0-h-micro', {
          messages: aiMessages,
          max_completion_tokens: 300
        });
        perf.mark('AI_FIRST_TOKEN_RECEIVED'); // same instant as completion: non-streaming call
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        let raw = (aiRes.response || aiRes.choices?.[0]?.message?.content || '').toString().trim();
        // Strip stray markdown fences the model might add despite instructions.
        raw = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();
        let steps = [];
        try {
          const match = raw.match(/\{[\s\S]*\}/);
          const parsed = JSON.parse(match ? match[0] : raw);
          if (Array.isArray(parsed.steps)) {
            const seen = new Set();
            for (const s of parsed.steps) {
              const cat = s && typeof s.category === 'string' ? s.category.trim().toLowerCase() : '';
              const label = s && typeof s.label === 'string' ? s.label.trim().slice(0, 80) : '';
              if (CATEGORY_LIST.includes(cat) && label && !seen.has(cat)) {
                seen.add(cat);
                steps.push({ category: cat, label });
              }
            }
            // Keep the canonical BUILD_STEP_DETECTORS display order, cap at 8.
            steps.sort((a, b) => CATEGORY_LIST.indexOf(a.category) - CATEGORY_LIST.indexOf(b.category));
            steps = steps.slice(0, 8);
          }
        } catch (_) {
          steps = []; // empty array -> frontend falls back to the full static list
        }

        const responseBody = JSON.stringify({ steps });
        perf.mark('POST_PROCESSING_COMPLETED');

        perf.finish({
          promptChars,
          promptTokens,
          note: `Not streaming — build-steps short call. steps=${steps.length} completion_tokens=${aiRes.usage?.completion_tokens} prompt_tokens=${aiRes.usage?.prompt_tokens}`
        });

        return new Response(responseBody, {
          headers: {
            'Content-Type': 'application/json',
            'X-Input-Tokens': String(promptTokens),
            'X-Output-Tokens': String(perf.estimateTokens(raw)),
            ...corsHeaders(origin)
          }
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /chat/export (non-streaming: summarize a conversation to markdown) ──
    // Same cheap model family as /status-hint (-fast, no reasoning overhead).
    // Unlike /chat/title, this accepts a caller-supplied system prompt and the
    // full message history as-is (no server-side truncation — same as /chat,
    // /chat/flash, etc.), since the caller (buildExportSystemPrompt()) already
    // encodes the noise-filtering/summary-vs-transcript instructions.
    if (path === '/chat/export') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const system = typeof body.system === 'string' ? body.system : '';
        const messages = Array.isArray(body.messages) ? body.messages : [];
        if (!system || !messages.length) {
          perf.finish({ note: 'missing system or messages' });
          return deny(400, 'system and messages are required', origin);
        }
        const aiMessages = [{ role: 'system', content: system }]
          .concat(messages.map(m => ({ role: m.role, content: (m.content || '').toString() })));
        const promptChars = aiMessages.reduce((sum, m) => sum + (m.content || '').length, 0);
        const promptTokens = perf.estimateTokens(aiMessages.map(m => m.content || '').join('\n'));
        perf.mark('PROMPT_READY');

        perf.mark('AI_REQUEST_START');
        // llama-3.1-8b-instruct-fast: plain instruct model, no thinking/reasoning
        // mode — same rationale as /status-hint.
        const aiRes = await env.AI.run('@cf/meta/llama-3.1-8b-instruct-fast', {
          messages: aiMessages,
          max_completion_tokens: 1536
        });
        perf.mark('AI_FIRST_TOKEN_RECEIVED'); // same instant as completion: non-streaming call
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        const markdown = (aiRes.response || aiRes.choices?.[0]?.message?.content || '').toString().trim();
        const responseBody = JSON.stringify({ markdown });
        perf.mark('POST_PROCESSING_COMPLETED');

        perf.finish({
          promptChars,
          promptTokens,
          note: `Not streaming — chat-export summarization call. completion_tokens=${aiRes.usage?.completion_tokens} prompt_tokens=${aiRes.usage?.prompt_tokens}`
        });

        return new Response(responseBody, {
          headers: {
            'Content-Type': 'application/json',
            'X-Input-Tokens': String(promptTokens),
            'X-Output-Tokens': String(perf.estimateTokens(markdown)),
            ...corsHeaders(origin)
          }
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── ROUTE: /marketing/extract (URL fetch, or uploaded file, → markdown via env.AI.toMarkdown()) ──
    if (path === '/marketing/extract') {
      try {
        perf.mark('PROMPT_PREPARATION_START');
        const reqUrl = typeof body.url === 'string' ? body.url.trim() : '';
        const fileBase64 = typeof body.fileBase64 === 'string' ? body.fileBase64 : '';
        const fileName = typeof body.fileName === 'string' ? body.fileName : '';

        if (!reqUrl && !fileBase64) {
          perf.finish({ note: 'no url or fileBase64 provided' });
          return deny(400, 'Provide either url or fileBase64+fileName', origin);
        }

        let name, blob;

        if (reqUrl) {
          // ── SSRF protections ────────────────────────────────────────────
          let parsed;
          try {
            parsed = new URL(reqUrl);
          } catch (_) {
            perf.finish({ note: 'invalid url' });
            return deny(400, 'Invalid URL', origin);
          }
          if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
            perf.finish({ note: `blocked protocol: ${parsed.protocol}` });
            return deny(400, 'Only http/https URLs are allowed', origin);
          }
          if (isPrivateOrLocalHostname(parsed.hostname)) {
            perf.finish({ note: `blocked private/local host: ${parsed.hostname}` });
            return deny(400, 'This URL cannot be fetched', origin);
          }

          perf.mark('EXTRACT_FETCH_START');
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), MARKETING_EXTRACT_FETCH_TIMEOUT_MS);
          let upstreamRes;
          try {
            upstreamRes = await fetch(parsed.toString(), {
              signal: controller.signal,
              // Never auto-follow redirects: a redirect could point at a
              // private/local address that only fails the hostname check
              // above if we resolve it — refusing redirects entirely closes
              // that bypass instead of trying to re-validate each hop.
              redirect: 'manual',
              headers: { 'User-Agent': 'Mozilla/5.0 (compatible; BatNXTMarketingBot/1.0)' },
            });
          } catch (e) {
            const timedOut = e && e.name === 'AbortError';
            perf.finish({ note: timedOut ? 'fetch timed out' : `fetch failed: ${e.message}` });
            return deny(502, timedOut ? 'The URL took too long to respond' : 'Could not fetch that URL', origin);
          } finally {
            clearTimeout(timeoutId);
          }

          if (upstreamRes.status >= 300 && upstreamRes.status < 400) {
            perf.finish({ note: `blocked redirect: status=${upstreamRes.status}` });
            return deny(400, 'That URL redirects elsewhere and cannot be fetched directly', origin);
          }
          if (!upstreamRes.ok) {
            perf.finish({ note: `upstream status=${upstreamRes.status}` });
            return deny(502, `The URL returned an error (status ${upstreamRes.status})`, origin);
          }

          // Read the body ourselves with a hard size cap, instead of trusting
          // Content-Length (which the server can simply omit or lie about).
          const reader = upstreamRes.body ? upstreamRes.body.getReader() : null;
          const chunks = [];
          let totalBytes = 0;
          if (reader) {
            for (;;) {
              const { done, value } = await reader.read();
              if (done) break;
              totalBytes += value.byteLength;
              if (totalBytes > MARKETING_EXTRACT_MAX_BYTES) {
                perf.finish({ note: 'response too large' });
                return deny(413, 'That page is too large to analyze', origin);
              }
              chunks.push(value);
            }
          }
          perf.mark('EXTRACT_FETCH_COMPLETED');

          const contentType = upstreamRes.headers.get('Content-Type') || 'text/html';
          name = 'page.html';
          blob = new Blob(chunks, { type: contentType });
        } else {
          // ── Uploaded-file branch ────────────────────────────────────────
          const ext = (fileName.split('.').pop() || '').toLowerCase();
          if (!MARKETING_EXTRACT_ALLOWED_EXT.includes(ext)) {
            perf.finish({ note: `blocked file extension: ${ext}` });
            return deny(400, 'Unsupported file type', origin);
          }

          let bytes;
          try {
            const binary = atob(fileBase64);
            bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          } catch (_) {
            perf.finish({ note: 'invalid base64' });
            return deny(400, 'Invalid file data', origin);
          }
          if (bytes.byteLength > MARKETING_EXTRACT_MAX_BYTES) {
            perf.finish({ note: 'file too large' });
            return deny(413, 'That file is too large', origin);
          }

          name = fileName;
          blob = new Blob([bytes], { type: MARKETING_EXTRACT_MIME_TYPES[ext] || 'application/octet-stream' });
        }

        perf.mark('AI_REQUEST_START');
        const result = await env.AI.toMarkdown({ name, blob });
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        if (!result || result.format === 'error') {
          perf.finish({ note: `toMarkdown error: ${result && result.error}` });
          return deny(422, 'Could not extract content from that source', origin);
        }
        const markdown = result.data || '';
        const responseBody = JSON.stringify({ markdown });
        perf.mark('POST_PROCESSING_COMPLETED');

        const promptTokens = perf.estimateTokens(name);
        const outputTokens = result.tokens || perf.estimateTokens(markdown);
        perf.finish({
          note: `Not streaming — /marketing/extract. source=${reqUrl ? 'url' : 'file'} bytes=${blob.size} output_tokens=${outputTokens}`
        });

        // Report token counts so the gateway's flat-charge log entry
        // (MARKETING_EXTRACT_FLAT_CREDITS in gateway.js) carries a non-zero
        // input/output for observability, even though billing here is flat
        // rather than token-based.
        return new Response(responseBody, {
          headers: {
            'Content-Type': 'application/json',
            'X-Input-Tokens': String(promptTokens),
            'X-Output-Tokens': String(outputTokens),
            ...corsHeaders(origin)
          }
        });
      } catch (e) {
        perf.finish({ note: `Error: ${e.message}` });
        return deny(500, e.message, origin);
      }
    }

    // ── 404 ─────────────────────────────────────────────────────────────────
    perf.finish({ note: `Route not found: ${path}` });
    return deny(404, 'Route not found. Use /generate, /chat, /chat/flash, /chat/core, /chat/marketing-eco, /status-hint, /chat/title, /chat/export, /build-steps, or /marketing/extract', origin);
  }
}
