// ============================================================================
//  BatNXT — Alerts Cron Worker
// ----------------------------------------------------------------------------
//  A tiny, standalone Cloudflare Cron Trigger Worker. It does NOT touch any
//  Durable Object and shares no code with the gateway — its ONLY job is to run
//  the background cost-alert checks on a schedule so that alerts fire even when
//  no admin is looking at the dashboard.
//
//  It calls one Postgres function, public.cron_check_cost_alerts() (defined in
//  db/schema.sql), which:
//    (a) flags any service whose rolling-24h API cost exceeds 80% of its credit
//        revenue, and
//    (b) flags any active usage window that burned >50% of its allocation in
//        under an hour,
//  inserting idempotently into public.cost_alerts (re-runs never duplicate an
//  open alert). The function returns the count of NEW alerts inserted.
//
//  DEPLOYMENT (manual, via the Cloudflare Dashboard — consistent with the rest
//  of this project's single-file, no-wrangler-config convention):
//    1. Create a new Worker, paste this file.
//    2. Settings → Variables → add secrets:
//         SUPABASE_URL                (e.g. https://xxxx.supabase.co)
//         SUPABASE_SERVICE_ROLE_KEY   (service-role key — Worker-only, secret)
//    3. Settings → Triggers → Cron Triggers → add a schedule, e.g.
//         */10 * * * *     (every 10 minutes — recommended 5–15 min range)
//
//  There is no HTTP surface: an optional fetch() handler is included only so a
//  manual GET can trigger the same check on demand while testing. It is NOT
//  required for the cron to work.
// ============================================================================

/**
 * @typedef {Object} Env
 * @property {string} SUPABASE_URL
 * @property {string} SUPABASE_SERVICE_ROLE_KEY
 */

/**
 * Invoke the idempotent alert-check RPC using the service-role key.
 * @param {Env} env
 * @returns {Promise<{ ok: boolean, status: number, inserted: number|null, detail?: any }>}
 */
async function runAlertCheck(env) {
  if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
    console.error('[alerts-cron] SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured — skipping.');
    return { ok: false, status: 500, inserted: null, detail: 'not_configured' };
  }
  const base = env.SUPABASE_URL.replace(/\/+$/, '');
  try {
    const res = await fetch(`${base}/rest/v1/rpc/cron_check_cost_alerts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        apikey: env.SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
      },
      body: '{}',
    });
    const text = await res.text();
    let data = null;
    if (text) { try { data = JSON.parse(text); } catch (_) { data = text; } }
    if (!res.ok) {
      console.error(`[alerts-cron] RPC failed ${res.status}:`, data);
      return { ok: false, status: res.status, inserted: null, detail: data };
    }
    // The RPC returns a bare integer (count of new alerts).
    const inserted = typeof data === 'number' ? data : Number(data);
    console.log(`[alerts-cron] check complete — ${Number.isFinite(inserted) ? inserted : 0} new alert(s).`);
    return { ok: true, status: 200, inserted: Number.isFinite(inserted) ? inserted : 0 };
  } catch (err) {
    console.error('[alerts-cron] threw', err);
    return { ok: false, status: 500, inserted: null, detail: String(err) };
  }
}

export default {
  /**
   * Cron Trigger entrypoint — fired by the schedule configured in the Dashboard.
   * @param {ScheduledController} _event
   * @param {Env} env
   * @param {ExecutionContext} ctx
   */
  async scheduled(_event, env, ctx) {
    ctx.waitUntil(runAlertCheck(env));
  },

  /**
   * Optional on-demand trigger for manual testing only. Returns the RPC result.
   * @param {Request} _request
   * @param {Env} env
   */
  async fetch(_request, env) {
    const result = await runAlertCheck(env);
    return new Response(JSON.stringify(result), {
      status: result.ok ? 200 : result.status,
      headers: { 'Content-Type': 'application/json' },
    });
  },
};
