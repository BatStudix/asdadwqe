// ============================================================================
//  BatNXT - Gateway Worker  (v2 subscription / usage-window / cost-protection)
// ============================================================================
//
//  WHAT THIS FILE IS
//  -----------------
//  A single, self-contained Cloudflare Worker that sits IN FRONT of the three
//  existing generation Workers (worker.js = chat, batlab-x-api.js = game/tool/
//  mobile, websitegenerator.js = website). Every generation request from the
//  browser now goes here first. This Worker:
//
//    1. verifies the caller's Supabase JWT (real server-side identity)
//    2. reserves credits atomically in a per-user Durable Object
//    3. admits the request through a tier-priority concurrency gate
//    4. proxies to the real generation Worker (with a shared secret header)
//    5. settles the reservation at the ACTUAL token cost afterwards
//
//  It also serves the Recharge-Now purchase stubs and the Admin API.
//
//  WHY EVERYTHING IS IN ONE FILE
//  -----------------------------
//  Durable Objects must be defined in the SAME script that binds them. Unlike
//  the three plain generation Workers (which are copy-pasted into the Cloudflare
//  Dashboard), a DO-backed Worker needs its classes co-located. Keeping the
//  three DO classes + the gateway handler in this one file preserves the
//  project's "paste one file into the Dashboard" deploy convention.
//
//  DASHBOARD DEPLOY NOTES (no wrangler required)
//  ---------------------------------------------
//    • Create a new Worker, paste this whole file.
//    • Settings → Variables:
//        SUPABASE_URL                = https://<project>.supabase.co
//        SUPABASE_JWT_ISSUER         = https://<project>.supabase.co/auth/v1
//        (Secrets)
//        SUPABASE_SERVICE_ROLE_KEY   = <service_role key - NEVER shipped to browser>
//        INTERNAL_KEY                = <random shared secret, also set on the 3 workers>
//        CHAT_WORKER_URL             = https://weathered-rain-34fa.<acct>.workers.dev
//        GAME_WORKER_URL             = https://batlab-x-api.<acct>.workers.dev
//        WEBSITE_WORKER_URL          = https://websitegenerator.<acct>.workers.dev
//    • Settings → Durable Objects: add three bindings pointing at the classes
//        USER_ACCOUNT  → UserAccountDO
//        CONC_GATE     → ConcurrencyGateDO
//        IP_GUARD      → IpGuardDO
//      (the Dashboard prompts to create the migration for new classes on save)
//
//  All new logic is plain JS + JSDoc types (the project has no build step).
// ============================================================================

import { DurableObject } from 'cloudflare:workers';

// ============================================================================
//  SECTION 1 - PLAN / TIER CONFIGURATION
// ----------------------------------------------------------------------------
//  These numbers are DERIVED, not arbitrary (see plan doc §1). Summary:
//    Credits_Month  = floor( Price × (1 − 0.60) / $0.01 )        // 40% is API budget
//    Credits_Window = Credits_Month / (Windows_per_month × 0.60) // 60% engagement
//  Free is a fixed acquisition budget (no revenue to margin against).
//  Max is deliberately overridden to 7.5× Pro's monthly credits (not linear to
//  its 3.4× price) to make it the irresistible upsell anchor the spec asks for.
//
//  1 credit === $0.01 of internal API-cost budget (reference only, NOT a sale
//  price). Charges always round UP (Math.ceil) so rounding favors the platform.
// ============================================================================

/**
 * @typedef {'free'|'starter'|'pro'|'max'} Tier
 * @typedef {'chat'|'website'|'game'|'tool'|'mobile'} Service
 */

// ── LOCKED: "Usage Windows – Option A" ──────────────────────────────────────
// Applied 2026-07-16, creditsPerWindow revised 2026-07-27. The windowHours
// values below are the finalized "Option A" window lengths (unchanged since
// 2026-07-16 confirmation). creditsPerWindow was intentionally increased on
// 2026-07-27 (Starter 100→150, Pro 160→300, Max 800→1200; Free untouched) —
// a deliberate allocation bump, not a recompute of the original Option A
// spec. WEEKLY_CAP_CREDITS below is derived from PLAN_PRICE, not from
// creditsPerWindow, so it was intentionally left unchanged alongside this.
// creditsPerWindow derivation/rationale: see the SECTION 1 header comment
// above (Credits_Month / Credits_Window formulas, plan doc §1). The
// windowHours choice per tier is not re-derived from that formula in-repo;
// treat it as part of the locked Option A decision rather than something to
// recompute. Do not change windowHours, or creditsPerWindow again, without
// re-confirming against the Option A spec first.
/** Per-tier plan config: window length, per-window credit allocation, rate limits, queue rank. */
const PLANS = /** @type {const} */ ({
  free:    { windowHours: 24, creditsPerWindow: 200,  rpm: 6,  burst: 30,  tierRank: 3 },
  starter: { windowHours: 9,  creditsPerWindow: 150,  rpm: 10, burst: 50,  tierRank: 2 },
  pro:     { windowHours: 6,  creditsPerWindow: 300,  rpm: 20, burst: 100, tierRank: 1 },
  max:     { windowHours: 6,  creditsPerWindow: 1200, rpm: 40, burst: 200, tierRank: 0 },
});

/** Fallback when a tier string is unknown/missing - treat as the most restricted tier. */
function planFor(tier) {
  return PLANS[tier] || PLANS.free;
}

/**
 * Free-Plan Lifetime Credit Cap: on top of the existing, unchanged per-window
 * allocation (200 credits/24h - see PLANS.free above), free-tier accounts
 * accumulate a lifetime, NEVER-resetting total (UserAccountDO.lifetimeUsed,
 * mirrored async to users.lifetime_credits_used for admin/audit only - see
 * db/schema_lifetime_free_cap.sql). Once the cap is reached, reserve() hard-
 * blocks new reservations with 'lifetime_cap_reached' until the user
 * upgrades - unlike the per-window/weekly counters, there is no periodic
 * reset of any kind.
 *   - Never subscribed (subscription_started_at is null): LIFETIME_FREE_CAP_NEW.
 *   - Ever subscribed at least once, even if since canceled/lapsed
 *     (subscription_started_at is non-null - that column is never cleared on
 *     cancellation): LIFETIME_FREE_CAP_RETURNING. Closes the
 *     subscribe→consume→cancel→re-signup-style abuse loop.
 * Neither cap ever renews on a later subscribe/cancel cycle - both are a
 * single, whole-account-lifetime allowance. Replaces the old
 * TRIAL_PERIOD_DAYS-based extended-trial system.
 */
const LIFETIME_FREE_CAP_NEW = 1000;
const LIFETIME_FREE_CAP_RETURNING = 100;

/**
 * Weekly Usage Cap: a global (same-for-all-users), UTC-Monday-00:00-resetting
 * ceiling on top of the existing per-window credit system. Free has no cap
 * (unlimited weekly usage, still bound by its per-window allocation). Paid
 * tiers get a fixed weekly credit ceiling; at >= WEEKLY_CAP_WARNING_RATIO of
 * that ceiling the frontend shows a warning banner + "Reset Usage" purchase
 * upsell, and at 100% the tier is hard-blocked from new reservations until
 * either the automatic Monday 00:00 UTC rollover or a paid Weekly Reset
 * purchase (handleWeeklyReset()) immediately zeroes the counter. No purchase
 * cooldown applies to Weekly Reset (unlike Recharge Now's RECHARGE_COOLDOWN_DAYS).
 *
 * starter/pro recalibrated 2026-07-19 alongside the 12%-margin chat tier
 * tables (see CHAT_TIER_CONFIG etc.): sized so the aggregate monthly margin
 * lands around a 15% target even under worst-case (tightest-tier) Prime
 * usage, via weekly_cap = PLAN_PRICE / (1.15 x worst_cost_per_credit) /
 * 4.348 (avg weeks/month), using Prime's tightest tier (maxOutput=5000,
 * 29 credits, cost_per_credit ~= $0.0008861 - its lowest-margin tier at
 * ~12.86%). max is left untouched (not part of this recalibration).
 */
const WEEKLY_CAP_CREDITS = { free: null, starter: 2032, pro: 4967, max: 15000 };
const WEEKLY_CAP_WARNING_RATIO = 0.8;
/** Weekly Reset purchase prices (USD). Free is not sold a reset (no cap to reset). */
const WEEKLY_RESET_USD = { starter: 2.99, pro: 5.99, max: 19.99 };

// ============================================================================
//  SECTION 2 - COST CALCULATOR  (the "safety margin" logic - heavily commented)
// ----------------------------------------------------------------------------
//  Real cost basis: Cloudflare Workers AI, model @cf/zai-org/glm-5.2, billed at
//  $0.011 / 1,000 neurons. In token terms that model works out to roughly:
//      input  ≈ $1.40 per 1,000,000 tokens
//      output ≈ $4.40 per 1,000,000 tokens
//  These live in model_pricing (Postgres) so they can change without touching
//  any plan definition. The gateway reads the current row, caches it briefly,
//  and passes it into reserve()/settle() as `pricing`. DEFAULT_MODEL_COST below
//  is only the fallback if the DB read hasn't populated yet.
//
//  TWO NUMBERS MATTER PER OPERATION:
//    • worstCaseCredits() - charged-on-RESERVE. Uses each service's MAX possible
//      output (its max_completion_tokens ceiling) so we can never over-commit
//      the user's balance. This is the "safety margin": we hold the maximum a
//      request could ever cost BEFORE running it, then refund the difference.
//    • actualCredits()    - charged-on-SETTLE. Uses the REAL token counts the
//      upstream Worker reports, so the user is ultimately billed for what they
//      actually consumed (still Math.ceil'd, still + margin).
// ============================================================================

const CREDIT_USD = 0.001; // 1 credit === $0.001 of budget (was $0.01; credit *counts* were rescaled ×10, same real $ cost/margin)

/** Fallback token pricing (USD per 1,000,000 tokens), mirrors model_pricing seed. */
const DEFAULT_MODEL_COST = {
  // ── ACTIVE (2026-07-19 model swap) ──────────────────────────────────────
  // bat 1.2 prime - Workers AI, called directly (no AI Gateway, no BYOK).
  '@cf/moonshotai/kimi-k2.7-code': { inputPer1M: 0.95, outputPer1M: 4.00 },
  // bat 1.2 core - Workers AI, called directly (no AI Gateway, no BYOK).
  // Swapped 2026-07-21 to gpt-oss-120b (cheaper + faster + reasoning-effort).
  '@cf/openai/gpt-oss-120b': { inputPer1M: 0.35, outputPer1M: 0.75 },
  // bat 1.2 flash - Workers AI, called directly (no AI Gateway, no BYOK).
  '@cf/meta/llama-4-scout-17b-16e-instruct': { inputPer1M: 0.27, outputPer1M: 0.85 },
  // bat 2.2 (Marketing eco, /chat/marketing-eco) - Workers AI, called
  // directly (no AI Gateway, no BYOK). Confirmed via the model's own live
  // Workers AI docs page: $0.10/1M input, $0.30/1M output.
  '@cf/google/gemma-4-26b-a4b-it': { inputPer1M: 0.10, outputPer1M: 0.30 },
  // ── HISTORICAL (superseded 2026-07-19, kept for reference only - not
  //    reachable via MODEL/MODEL_CORE/MODEL_FLASH anymore) ────────────────
  '@cf/zai-org/glm-5.2': { inputPer1M: 1.40, outputPer1M: 4.40 },
  // bat 1.2 flash - Workers AI, called directly (no AI Gateway, no BYOK).
  '@cf/zai-org/glm-4.7-flash': { inputPer1M: 0.06, outputPer1M: 0.40 },
  // bat 1.2 core - Workers AI, called directly (no AI Gateway, no BYOK).
  // NOTE: invocation slug has no "@cf/" prefix (confirmed exact format).
  'minimax/m3': { inputPer1M: 0.30, outputPer1M: 1.20 },
  // Chat image-preprocessing (Moondream) - not billed via actualCredits()/
  // worstCaseCredits() (see MOONDREAM_FLAT_SURCHARGE_CREDITS, a flat surcharge
  // instead); listed here for completeness/reference and to recalibrate the
  // flat surcharge later from real Workers AI pricing + observed usage.
  '@cf/moondream/moondream3.1-9B-A2B': { inputPer1M: 0.30, outputPer1M: 1.00 },
  // /status-hint model - not billed via actualCredits()/worstCaseCredits()
  // (status_hint is a flat STATUS_HINT_FLAT_CREDITS charge regardless of
  // model/tokens, see below); listed here for internal documentation only.
  // NOTE: Cloudflare's official pricing page has no exact-match row for
  // "@cf/meta/llama-3.1-8b-instruct-fast" (the plain, non-fp8 "fast" model
  // ID confirmed on its own docs page). The closest documented row is the
  // separate "@cf/meta/llama-3.1-8b-instruct-fp8-fast" variant, used here
  // as the best available proxy - recalibrate if Cloudflare publishes an
  // exact-match price for the non-fp8 "fast" model.
  '@cf/meta/llama-3.1-8b-instruct-fast': { inputPer1M: 0.045, outputPer1M: 0.384 },
  // bat 1.2 flash - Workers AI direct (no AI Gateway, no BYOK). Plain instruct
  // model (no reasoning/thinking mode per Cloudflare docs), confirmed exact
  // model ID via its own live Workers AI docs page (unlike the similarly
  // named "-fp8-fast" variant, which appears in the pricing table but has
  // no live model page - not used here for that reason).
  '@cf/meta/llama-3.1-8b-instruct-fp8': { inputPer1M: 0.152, outputPer1M: 0.287 },
};

/**
 * Per-service safety ceilings + margin band (mid-range of the mandated bands).
 *   maxInput  - generous upper bound on prompt size for that service
 *   maxOutput - the service Worker's own max_completion_tokens ceiling
 *   margin    - profit margin applied on top of raw API cost
 * Worst-case credits (with DEFAULT pricing) come out to: chat 6, website 10,
 * game/tool/mobile 6 - matching the plan doc.
 */
const SERVICE_LIMITS = {
  chat:        { maxInput: 6000, maxOutput: 16384, margin: 0.20  },
  chat_flash:  { maxInput: 6000, maxOutput: 16384, margin: 0.20  },
  // bat 2.2 (Marketing eco, @cf/google/gemma-4-26b-a4b-it) - same shape as
  // chat_flash (long-form analysis, generous output ceiling).
  chat_marketing_eco: { maxInput: 6000, maxOutput: 16384, margin: 0.20 },
  // bat 1.2 core (@cf/openai/gpt-oss-120b) - 4096 here is an intentional
  // product/design cap, NOT a hard model ceiling. For gpt-oss this cap is the
  // effort ceiling passed as max_tokens and bounds TOTAL output (reasoning +
  // answer). Kept at 4096 for now; raising it is a separate future decision.
  chat_core:   { maxInput: 6000, maxOutput: 4096,  margin: 0.20  },
  website:     { maxInput: 3000, maxOutput: 16000, margin: 0.275 },
  game:        { maxInput: 2000, maxOutput: 8192,  margin: 0.35  },
  tool:        { maxInput: 2000, maxOutput: 8192,  margin: 0.35  },
  mobile:      { maxInput: 2000, maxOutput: 8192,  margin: 0.35  },
  // Informational only (logging/margin-reporting) - status_hint is billed at
  // a flat STATUS_HINT_FLAT_CREDITS amount, not via worstCaseCredits/actualCredits.
  status_hint: { maxInput: 500,  maxOutput: 200,   margin: 0.20  },
  // Informational only (logging/margin-reporting) - marketing_extract is
  // billed at a flat MARKETING_EXTRACT_FLAT_CREDITS amount, not via
  // worstCaseCredits/actualCredits (see /marketing/extract).
  marketing_extract: { maxInput: 0, maxOutput: 0, margin: 0.20 },
  // Informational only (logging/margin-reporting) - chat_title is billed at a
  // flat CHAT_TITLE_FLAT_CREDITS amount (0), not via worstCaseCredits/actualCredits.
  chat_title:  { maxInput: 800,  maxOutput: 40,    margin: 0.20  },
  // Informational only (logging/margin-reporting) - chat_reason is billed at a
  // flat CHAT_REASON_FLAT_CREDITS amount (0), not via worstCaseCredits/actualCredits.
  chat_reason: { maxInput: 1400, maxOutput: 300,   margin: 0.20  },
  // Informational only (logging/margin-reporting) - chat_export is billed at a
  // flat CHAT_EXPORT_FLAT_CREDITS amount, not via worstCaseCredits/actualCredits.
  // maxInput mirrors chat's budget (a full conversation must fit); maxOutput
  // is sized for a multi-section markdown summary (not a full transcript).
  chat_export: { maxInput: 6000, maxOutput: 1536,  margin: 0.20  },
  // Informational only (logging/margin-reporting) - build_steps is billed at
  // a flat BUILD_STEPS_FLAT_CREDITS amount (0), not via worstCaseCredits/
  // actualCredits (see /build-steps).
  build_steps: { maxInput: 1200, maxOutput: 300,   margin: 0.20  },
};

function serviceLimits(service) {
  return SERVICE_LIMITS[service] || SERVICE_LIMITS.game;
}

/**
 * Raw API cost in USD for a given token usage.
 * @param {number} inTok
 * @param {number} outTok
 * @param {string} model
 * @param {Record<string,{inputPer1M:number,outputPer1M:number}>} [pricing]
 */
function costUsd(inTok, outTok, model, pricing) {
  const p =
    (pricing && pricing[model]) ||
    DEFAULT_MODEL_COST[model] ||
    DEFAULT_MODEL_COST['@cf/moonshotai/kimi-k2.7-code'];
  return inTok * (p.inputPer1M / 1e6) + outTok * (p.outputPer1M / 1e6);
}

/**
 * Convert a USD cost into whole credits, applying margin and ALWAYS rounding up
 * (Math.ceil) so every rounding decision favors the platform (spec requirement).
 * @param {number} usd
 * @param {number} margin  e.g. 0.20 for 20%
 */
function creditsFromUsd(usd, margin) {
  return Math.ceil((usd * (1 + margin)) / CREDIT_USD);
}

/** Max credits a single op of this service could ever cost (reserve-time hold). */
function worstCaseCredits(service, model, pricing) {
  const lim = serviceLimits(service);
  return creditsFromUsd(costUsd(lim.maxInput, lim.maxOutput, model, pricing), lim.margin);
}

/** Real credits to charge given the token counts the upstream Worker reported. */
function actualCredits(inTok, outTok, service, model, pricing) {
  const lim = serviceLimits(service);
  return creditsFromUsd(costUsd(inTok, outTok, model, pricing), lim.margin);
}

/**
 * Chat credit-tier config (Phase 4). Single source of truth for the flat
 * output-token tiers plus the dynamic formula used above the top tier.
 * Mirrored for display purposes in js/creditConfig.js - keep both in sync.
 *
 * Fixed tiers: charge a flat credit amount once real output tokens are known,
 * bucketed by an exclusive upper bound (outputTokens < maxOutput -> credits).
 * Recalibrated 2026-07-19 to a 12% margin target (down from the prior 20%),
 * a deliberate economics decision to close the gap between the ~139-224%
 * aggregate margin the 20% tables were producing and the 10-15% aggregate
 * target - for @cf/moonshotai/kimi-k2.7-code ($0.95/$4.00 per 1M in/out).
 * Every tier verified against the TRUE worst case: worst-case input =
 * SERVICE_LIMITS.chat.maxInput = 6000 tok + output just under the tier's
 * upper bound, default pricing. Real achieved floor is ~12.86% (tier
 * maxOutput=5000, the tightest one - Math.ceil rounding keeps every other
 * tier slightly above the 12% nominal target, never below it).
 *
 * Dynamic tier: for outputTokens >= the last tier's maxOutput (8000), flat
 * tiers no longer scale safely with true cost, so charge is instead computed
 * directly from actual cost: ceil(costUsd * safetyMultiplier / creditValueUsd).
 */
const CHAT_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 7  },
    { maxOutput: 300,  credits: 8  },
    { maxOutput: 700,  credits: 10 },
    { maxOutput: 1500, credits: 14 },
    { maxOutput: 3000, credits: 20 },
    { maxOutput: 5000, credits: 29 },
    { maxOutput: 8000, credits: 43 },
  ],
  safetyMultiplier: 1.4,
  creditValueUsd: CREDIT_USD,
};

/** Flat tiered (+ dynamic overflow) credit cost for chat, based on real output
 *  tokens. See CHAT_TIER_CONFIG for the tier table and dynamic-formula constants. */
function chatTierCredits(outputTokens, inputTokens, model, pricing) {
  for (const tier of CHAT_TIER_CONFIG.tiers) {
    if (outputTokens < tier.maxOutput) return tier.credits;
  }
  // outputTokens >= top tier's maxOutput (8000): dynamic cost-based charge.
  const cost = costUsd(inputTokens || 0, outputTokens, model, pricing);
  return Math.ceil((cost * CHAT_TIER_CONFIG.safetyMultiplier) / CHAT_TIER_CONFIG.creditValueUsd);
}

/**
 * bat 1.2 flash credit-tier config. Same shape/mechanics as CHAT_TIER_CONFIG
 * (flat tiers by real output tokens + dynamic overflow above the top tier),
 * priced against @cf/meta/llama-4-scout-17b-16e-instruct's per-token cost
 * (input $0.27/1M, output $0.85/1M; Workers AI, called directly).
 * Recalibrated 2026-07-19 to the same 12% margin target as CHAT_TIER_CONFIG
 * (worst-case input = SERVICE_LIMITS.chat_flash.maxInput = 6000 tok, output
 * just under the tier's upper bound). NOTE (transparent, intentional):
 * because Flash's dollar cost per message is so small, CREDIT_USD's fixed
 * $0.001 granularity forces Math.ceil() to round every tier well past the
 * 12% nominal target - the real achieved floor here is ~17.36% (tier
 * maxOutput=100), not 12%. This was reviewed and accepted as-is: no further
 * adjustment to force it down to exactly 12%.
 */
const CHAT_FLASH_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 2  },
    { maxOutput: 300,  credits: 3  },
    { maxOutput: 700,  credits: 3  },
    { maxOutput: 1500, credits: 4  },
    { maxOutput: 3000, credits: 5  },
    { maxOutput: 5000, credits: 7  },
    { maxOutput: 8000, credits: 10 },
  ],
  safetyMultiplier: 1.4,
  creditValueUsd: CREDIT_USD,
};

/** Flat tiered (+ dynamic overflow) credit cost for bat 1.2 flash. See
 *  CHAT_FLASH_TIER_CONFIG for the tier table and dynamic-formula constants. */
function chatFlashTierCredits(outputTokens, inputTokens, model, pricing) {
  for (const tier of CHAT_FLASH_TIER_CONFIG.tiers) {
    if (outputTokens < tier.maxOutput) return tier.credits;
  }
  // outputTokens >= top tier's maxOutput (8000): dynamic cost-based charge.
  const cost = costUsd(inputTokens || 0, outputTokens, model, pricing);
  return Math.ceil((cost * CHAT_FLASH_TIER_CONFIG.safetyMultiplier) / CHAT_FLASH_TIER_CONFIG.creditValueUsd);
}

/**
 * bat 2.2 (Marketing eco) credit-tier config. Same shape/mechanics as
 * CHAT_FLASH_TIER_CONFIG (flat tiers by real output tokens + dynamic
 * overflow above the top tier), priced against
 * @cf/google/gemma-4-26b-a4b-it's per-token cost (input $0.10/1M, output
 * $0.30/1M; Workers AI, called directly). Same 12% margin target /
 * worst-case-input methodology as CHAT_TIER_CONFIG/CHAT_FLASH_TIER_CONFIG
 * (worst-case input = SERVICE_LIMITS.chat_marketing_eco.maxInput = 6000 tok,
 * output just under the tier's upper bound):
 *   credits = ceil(costUsd(6000, tier.maxOutput, gemma) * 1.12 / CREDIT_USD)
 * Because Gemma is even cheaper than Flash, several low tiers round to the
 * same 1-credit floor under Math.ceil - this is expected, not a bug.
 */
const CHAT_MARKETING_ECO_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 1 },
    { maxOutput: 300,  credits: 1 },
    { maxOutput: 700,  credits: 1 },
    { maxOutput: 1500, credits: 2 },
    { maxOutput: 3000, credits: 2 },
    { maxOutput: 5000, credits: 3 },
    { maxOutput: 8000, credits: 4 },
  ],
  safetyMultiplier: 1.4,
  creditValueUsd: CREDIT_USD,
};

/** Flat tiered (+ dynamic overflow) credit cost for bat 2.2 (Marketing eco).
 *  See CHAT_MARKETING_ECO_TIER_CONFIG for the tier table and dynamic-formula constants. */
function chatMarketingEcoTierCredits(outputTokens, inputTokens, model, pricing) {
  for (const tier of CHAT_MARKETING_ECO_TIER_CONFIG.tiers) {
    if (outputTokens < tier.maxOutput) return tier.credits;
  }
  // outputTokens >= top tier's maxOutput (8000): dynamic cost-based charge.
  const cost = costUsd(inputTokens || 0, outputTokens, model, pricing);
  return Math.ceil((cost * CHAT_MARKETING_ECO_TIER_CONFIG.safetyMultiplier) / CHAT_MARKETING_ECO_TIER_CONFIG.creditValueUsd);
}

/**
 * bat 1.2 core credit-tier config. RECALIBRATED 2026-07-21 for the model swap
 * from nemotron-3-120b-a12b ($0.50/$1.50 per 1M in/out) to @cf/openai/gpt-oss-
 * 120b ($0.35/$0.75 per 1M in/out). Same methodology as before and as CHAT_
 * TIER_CONFIG/CHAT_FLASH_TIER_CONFIG:
 *   credits(tier) = ceil( costUsd(6000 in, maxOutput out, $0.35/$0.75) × 1.12
 *                         / CREDIT_USD )
 * i.e. worst-case input = SERVICE_LIMITS.chat_core.maxInput = 6000 tok, 12%
 * margin target, inclusive output boundary (see chatCoreTierCredits() below).
 * Worked example, terminal tier: (6000·0.35/1e6 + 4096·0.75/1e6)×1.12/0.001 =
 * (0.0021 + 0.003072)×1.12/0.001 = 5.79 → 6. The whole table drops from the
 * old [4,4,5,6,9,11] to [3,3,3,4,5,6] because gpt-oss output is half the price.
 *
 * REASONING-TOKEN SAFETY: gpt-oss is a reasoning model whose reasoning channel
 * is filtered out before it reaches the client, so the gateway's byte-based
 * output estimate would only see the visible answer while Cloudflare still
 * bills the (invisible) reasoning tokens — a short answer that hid a big
 * reasoning burn would be undercharged, possibly below cost. To close that
 * gap WITHOUT guessing a reasoning multiplier, the /chat/core worker route
 * sends X-Output-Tokens = maxTokens (the effort cap, which bounds TOTAL output
 * incl. reasoning). So in practice outTok here is always the effort ceiling
 * (1024/2048/4096), and this table resolves to a safe flat per-effort charge:
 *   Low(1024) → tier 1500 → 4cr,  Medium(2048) → tier 3000 → 5cr,
 *   High(4096) → tier 4096 → 6cr.
 * The sub-1024 tiers are only a fallback (e.g. if the header is ever absent).
 *
 * UNLIKE chat/chat_flash, this table has NO dynamic/overflow tier: 4096 is
 * kept as a fixed output ceiling for this service (SERVICE_LIMITS.chat_core
 * .maxOutput), so output can never exceed it here - the top tier is a true
 * terminal bucket.
 */
const CHAT_CORE_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 3  },
    { maxOutput: 300,  credits: 3  },
    { maxOutput: 700,  credits: 3  },
    { maxOutput: 1500, credits: 4  }, // effective "Low" effort charge (1024-tok cap lands here)
    { maxOutput: 3000, credits: 5  }, // effective "Medium" effort charge (2048-tok cap lands here)
    { maxOutput: 4096, credits: 6  }, // effective "High" effort charge; terminal tier (SERVICE_LIMITS.chat_core.maxOutput)
  ],
};

/**
 * Flat tiered credit cost for bat 1.2 core (@cf/openai/gpt-oss-120b).
 * See CHAT_CORE_TIER_CONFIG for the tier table.
 *
 * NOTE the boundary is inclusive (outputTokens <= tier.maxOutput), NOT the
 * exclusive "<" used by chatTierCredits()/chatFlashTierCredits() above. This
 * is intentional and SAFELY ISOLATED to Core only: chatTierCredits() and
 * chatFlashTierCredits() are fully independent functions/configs (not a
 * shared helper), so this "<=" change cannot affect Prime's or Flash's
 * tiering in any way. It exists here because 4096 is this service's fixed
 * output ceiling (SERVICE_LIMITS.chat_core.maxOutput) - an exact-4096-token
 * completion must still land in the top (and only terminal) tier rather
 * than falling through to undefined behaviour, and the top tier being a
 * real ceiling (not a generous/arbitrary bound like 8000 for chat/
 * chat_flash) makes "<=" the correct semantics here specifically.
 */
function chatCoreTierCredits(outputTokens) {
  for (const tier of CHAT_CORE_TIER_CONFIG.tiers) {
    if (outputTokens <= tier.maxOutput) return tier.credits;
  }
  // Unreachable in practice (4096 is this service's output ceiling) - safety fallback.
  return CHAT_CORE_TIER_CONFIG.tiers[CHAT_CORE_TIER_CONFIG.tiers.length - 1].credits;
}

/** Flat per-message credit charge for the status-hint helper call (Task D).
 *  Same flat amount for every tier and for both chat and build contexts -
 *  bypasses worstCaseCredits()/actualCredits()/chatTierCredits() entirely. */
const STATUS_HINT_FLAT_CREDITS = 1;

/** Flat per-call credit charge for the /chat/title conversation-namer helper.
 *  Zero: auto-titling is a free cosmetic nicety, billed like status_hint but at
 *  0 credits (hold = min(0, available) = 0, so nothing is reserved or settled). */
const CHAT_TITLE_FLAT_CREDITS = 0;

/** Flat per-call credit charge for the /chat/reason background-reasoning helper
 *  (powers the "Thought for Xs" widget for non-Core models). Zero: it's a
 *  cosmetic UX nicety layered on top of the real reply — the user must never
 *  feel double-charged (once for the reasoning card, once for the answer). Same
 *  flat-charge pattern as CHAT_TITLE_FLAT_CREDITS above (hold = min(0, available)
 *  = 0, so nothing is reserved or settled). */
const CHAT_REASON_FLAT_CREDITS = 0;

/** Flat per-call credit charge for the /build-steps checklist-labeling helper
 *  (powers the AI-selected "Building..." step labels). Zero: same cosmetic
 *  UX-nicety reasoning as CHAT_REASON_FLAT_CREDITS above — this only picks
 *  which of the existing 8 fixed checklist items to show and phrases their
 *  labels, it never changes what the user is actually billed for the real
 *  generation itself (hold = min(0, available) = 0, so nothing is reserved
 *  or settled). */
const BUILD_STEPS_FLAT_CREDITS = 0;

/** Flat per-call credit charge for /marketing/extract (server-side URL fetch
 *  + env.AI.toMarkdown(), or uploaded-file + env.AI.toMarkdown()) - not
 *  token-based, same flat-charge pattern as STATUS_HINT_FLAT_CREDITS above.
 *  Starting value mirrors MOONDREAM_FLAT_SURCHARGE_CREDITS as a conservative
 *  baseline; recalibrate once real toMarkdown() usage/cost data is available. */
const MARKETING_EXTRACT_FLAT_CREDITS = 5;

/** Flat per-call credit charge for /chat/export (AI-generated conversation
 *  summary → downloadable markdown/PDF). Not token-based - same flat-charge
 *  pattern as STATUS_HINT_FLAT_CREDITS/CHAT_TITLE_FLAT_CREDITS above, but
 *  non-zero since this produces a real downloadable artifact (unlike the free
 *  cosmetic auto-titling). */
const CHAT_EXPORT_FLAT_CREDITS = 3;

/** Flat additive surcharge charged on top of the normal chat/chat_flash/
 *  chat_core tier charge PER IMAGE actually analyzed by Moondream (see
 *  applyImagePreprocessing() in worker.js and the X-Images-Analyzed response
 *  header — a comma-separated per-image bitmap — read in handleGenerate()
 *  below). Linear scaling: total surcharge = this constant × the number of
 *  images that were actually analyzed (not merely attached) in the message,
 *  up to the 10-image-per-message hard cap enforced in handleGenerate().
 *  Conservative worst-case estimate PER IMAGE: ~4000 input tokens for a
 *  500KB image (ATTACH_MAX_IMAGE cap) + Moondream's own max_tokens capped at
 *  512 -> cost ~= 4000*0.30/1e6 + 512*1.00/1e6 ~= $0.00172 -> credits =
 *  ceil(0.00172 * 1.4 / 0.001) = 3, rounded up to 5 for headroom until real
 *  production Moondream `usage` data is available to recalibrate this. */
const MOONDREAM_FLAT_SURCHARGE_CREDITS = 5;

/** Hard cap on images per chat message, enforced server-side in
 *  handleGenerate() as defense-in-depth (the frontend already blocks
 *  attaching more than this before the request is ever sent). */
const MAX_IMAGES_PER_MESSAGE = 10;

/** Hard per-image and combined-payload byte caps for chat attachments
 *  (`payload.images`, sent to /chat, /chat/flash, /chat/core), enforced
 *  server-side in handleGenerate() as defense-in-depth - mirrors
 *  ATTACH_MAX_IMAGE / ATTACH_MAX_TOTAL in js/x9k2-legacy-shim-t8vn.js,
 *  which already blocks this client-side before the request is ever sent,
 *  but a direct API call bypasses that (2026-07-26 audit). Images arrive
 *  here as base64 data-URL strings, not raw bytes, so the true byte size is
 *  estimated from the encoded string length (~4/3 inflation over the raw
 *  file) - the same estimation the frontend itself uses for its screenshot
 *  attachments (see homeAttachScreenshot's `dataUrl.length * 0.75`). */
const ATTACH_MAX_IMAGE_BYTES = 500 * 1024;
const ATTACH_MAX_TOTAL_BYTES = 1200 * 1024;

/** Hard cap on baseHTML (the current site being edited) sent to the website
 *  generator, mirrored from worker/websitegenerator.js's own defensive
 *  check. ~75% of the 16,000-token output ceiling (chars/4 heuristic),
 *  leaving headroom for GLM to actually finish rewriting the file. */
const BASE_HTML_CHAR_CAP = 48000;

/** Hard cap on the full `.prompt` string sent to /generate (website/game/
 *  tool/mobile), enforced server-side in handleGenerate() as defense-in-
 *  depth (2026-07-26 audit, part 2). Unlike /chat*, attachments on the
 *  Build pipeline are NOT sent as a separate `images` array - text AND
 *  image (base64 data-URL) attachments are both merged directly into this
 *  one string by buildAttachContext() (js/x9k2-legacy-shim-t8vn.js), so the
 *  ATTACH_MAX_IMAGE_BYTES/ATTACH_MAX_TOTAL_BYTES per-field checks above
 *  cannot apply here - there's no separate field left to check.
 *
 *  A single flat length cap on the whole string (matching the existing
 *  BASE_HTML_CHAR_CAP philosophy) was chosen over trying to parse out and
 *  re-check each embedded attachment individually, because precise parsing
 *  would depend on buildAttachContext()'s exact "[Image \"name\"] ... \n"/
 *  "[File \"name\"] ... \n" marker text - a convention a direct API call
 *  has no obligation to follow, so it could simply omit the markers and
 *  still smuggle an oversized blob through undetected. A flat cap has no
 *  such bypass: it's format-agnostic and always measures the true worst
 *  case regardless of what's inside the string.
 *
 *  Sizing: worst-case legitimate content = ATTACH_MAX_TOTAL_BYTES (1.2MB)
 *  of attachments, inflated up to ~4/3 if that entire budget is images
 *  (base64 encoding) = ~1,638,400 chars, + buildConvRecap()'s own bounded
 *  ~4.5KB (max 8 turns x 500 chars), + generous headroom for the user's own
 *  typed prompt text itself (currently uncapped client-side) and the small
 *  fixed prefix/latinRule/SEO-rule text. Rounded up to a clean 2,000,000
 *  chars (~2MB) - comfortably above any legitimate request, far below
 *  Cloudflare's platform body-size limit (100MB+) and the ~128MB per-
 *  isolate memory ceiling, so it actually bounds abusive payloads instead
 *  of just formalizing the status quo. */
const GENERATE_PROMPT_CHAR_CAP = 2000000;

/**
 * Post-generation sanity check for website/game/tool/mobile HTML output.
 * Catches the "coherent-looking success, garbage content" failure mode
 * (see: audited garbage-output-on-edit bug) that a bare `!html` check
 * misses entirely. Applied to gateway-side billing decisions for all four
 * HTML-generating services (website streams raw HTML; game/tool/mobile
 * return a non-streamed `{ html }` JSON envelope whose `.html` field is
 * extracted before this check runs — see handleGenerate()).
 */
function isValidWebsiteOutput(html) {
  if (!html || html.length < 20) return { valid: false, reason: 'empty_or_too_short' };

  const head = html.slice(0, 500).toLowerCase();
  if (!/<!doctype|<html|<body/.test(head)) {
    return { valid: false, reason: 'no_html_structure_near_start' };
  }

  const tagChars = (html.match(/[<>]/g) || []).length;
  if (tagChars < html.length / 300) {
    return { valid: false, reason: 'low_tag_density' };
  }

  // The generation prompt always forbids non-Latin scripts (see `latinRule`
  // in the frontend), so any significant presence of these ranges in real
  // output is a reliable failure signal, not a false-positive risk.
  const nonLatinMatches = html.match(/[\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF\u0400-\u04FF\u0600-\u06FF\u0750-\u077F]/g) || [];
  if (nonLatinMatches.length > 30 && nonLatinMatches.length / html.length > 0.003) {
    return { valid: false, reason: 'unexpected_language_mixing' };
  }

  return { valid: true, reason: 'ok' };
}

// ============================================================================
//  SECTION 3 - SMALL HELPERS
// ============================================================================

const CORS_ALLOW_HEADERS = 'Content-Type, Authorization, X-Internal-Key';

/** JSON Response with permissive-but-explicit CORS (origin echoed by caller). */
function json(body, status = 200, origin = '*', extraHeaders = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, GET, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': CORS_ALLOW_HEADERS,
      'Vary': 'Origin',
      ...extraHeaders,
    },
  });
}

function nowMs() {
  return Date.now();
}

function isoFrom(ms) {
  return new Date(ms).toISOString();
}

function uuid() {
  return crypto.randomUUID();
}

/**
 * Per-request timing instrumentation, mirroring worker.js's createPerfTracker()
 * exactly. mark(label) records elapsed ms since creation; finish(extra) auto-marks
 * 'RESPONSE_SENT' and logs a formatted [PERFORMANCE] block via console.log.
 */
function createPerfTracker(requestId) {
  const t0 = Date.now();
  const marks = [];
  const mark = (label) => {
    marks.push({ label, t: Date.now() - t0 });
  };
  mark('REQUEST_RECEIVED');

  const estimateTokens = (text) => Math.ceil((text || '').length / 4);

  const finish = (extra = {}) => {
    mark('RESPONSE_SENT');
    const lines = ['[PERFORMANCE] requestId=' + requestId];
    for (let i = 0; i < marks.length; i++) {
      const prev = i === 0 ? 0 : marks[i - 1].t;
      lines.push(`  ${marks[i].label}: +${marks[i].t - prev}ms (t=${marks[i].t}ms)`);
    }
    if (extra.promptChars != null) {
      lines.push(`  Prompt size: ${extra.promptChars} characters, ~${extra.promptTokens} estimated tokens`);
    }
    if (extra.note) lines.push(`  Note: ${extra.note}`);
    lines.push(`  Total time: ${marks[marks.length - 1].t}ms`);
    console.log(lines.join('\n'));
  };

  return { mark, finish, estimateTokens };
}

// ============================================================================
//  SECTION 4 - POSTGRES MIRROR (async, non-blocking audit trail)
// ----------------------------------------------------------------------------
//  The Durable Object is the authoritative source of truth in the hot path.
//  Postgres is only a mirror for the admin dashboard / audit trail, so it must
//  NEVER be awaited on the request path. DO methods therefore RETURN a list of
//  "side effects" (rows to insert); the Gateway flushes them via
//  ctx.waitUntil(), and the DO's own alarm handler flushes them directly.
// ============================================================================

/** @typedef {{ table: string, rows: object[] }} SideEffect */

/**
 * Best-effort insert of mirror rows into Supabase via PostgREST using the
 * service-role key (Worker-only; never exposed to the browser). Failures are
 * swallowed + logged: a missed mirror row must never break a paid generation.
 * @param {any} env
 * @param {SideEffect[]} effects
 */
async function flushToSupabase(env, effects) {
  if (!effects || !effects.length) return;
  if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) return;
  const base = env.SUPABASE_URL.replace(/\/+$/, '');
  await Promise.all(
    effects
      .filter((e) => e && e.rows && e.rows.length)
      .map(async (e) => {
        try {
          const res = await fetch(`${base}/rest/v1/${e.table}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              apikey: env.SUPABASE_SERVICE_ROLE_KEY,
              Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
              Prefer: 'return=minimal,resolution=merge-duplicates',
            },
            body: JSON.stringify(e.rows),
          });
          if (!res.ok) {
            console.error(`[mirror] ${e.table} ${res.status}: ${await res.text()}`);
          }
        } catch (err) {
          console.error(`[mirror] ${e.table} threw`, err);
        }
      })
  );
}

// ============================================================================
//  SECTION 5 - UserAccountDO   (usage-window + credits + rate-limit + bans)
// ----------------------------------------------------------------------------
//  ONE INSTANCE PER USER, keyed by the Supabase user id. Because a Durable
//  Object runs single-threaded per id, every reserve()/settle() is naturally
//  atomic - no locks, no double-spend, even under concurrent generations from
//  the same user. This is the source of truth for the request path; Postgres
//  is mirrored asynchronously (Section 4).
//
//  STATE (persisted via ctx.storage KV; cached in memory after first load):
//    window       - the single ACTIVE usage window, or null. Shape:
//                   { id, windowStart, windowEnd, creditsAllocated, creditsUsed,
//                     status:'active', tier }
//    reservations - map { [resId]: { credits, service, model, createdAt,
//                                    upstreamDone, actualCredits } }
//                   credits held for in-flight generations (worst-case).
//    rlHits       - number[] of recent request timestamps (ms) for rate limiting
//    ban          - { strikeCount, firstStrikeAt, bannedUntil }
//
//  USAGE WINDOW LOGIC (heavily commented - spec requirement)
//  ---------------------------------------------------------
//   • A window opens on the user's FIRST request when they have no active
//     window (NOT clock-aligned to midnight/week). ensureWindow() handles this
//     lazily on every reserve - no cron needed for expiry.
//   • While active, the balance is fixed to THAT window's allocation. If it is
//     exhausted, there is NO refill until window_end - the user waits, upgrades,
//     or uses Recharge Now.
//   • On natural expiry (now >= windowEnd) the next request opens a brand-new
//     window with a full fresh allocation. The expired window is mirrored to
//     Postgres as its own immutable row (audit trail - never a mutated counter).
// ============================================================================

const ORPHAN_TTL_MS = 3 * 60 * 1000;      // reservations older than this are swept
const STRIKE_WINDOW_MS = 60 * 60 * 1000;  // strikes roll off after 1h of good behaviour

/**
 * Escalating-ban ladder (spec §6). strike N (within the rolling 1h) → action.
 * strike 1 is a soft warning (no ban recorded); 4th+ also flags an admin alert.
 */
const BAN_LADDER = [
  { banMs: 0,                  retryAfter: 30    }, // strike 1 - soft warning
  { banMs: 5 * 60 * 1000,      retryAfter: 300   }, // strike 2 - 5 min
  { banMs: 30 * 60 * 1000,     retryAfter: 1800  }, // strike 3 - 30 min
  { banMs: 24 * 60 * 60 * 1000, retryAfter: 86400 }, // strike 4+ - 24h + alert
];

/**
 * Fixed, tier-independent budget for the background helper lane (memory
 * extraction + chat-title generation). At most 2 of these fire per real user
 * message (never more), so this comfortably covers even Max-tier bursts of
 * real chat messages without ever being reachable through normal product
 * usage - it exists only so a genuinely automated abuser can't use the
 * "background" flag as an unbounded free-for-all lane.
 */
const BG_LANE_LIMIT = { rpm: 20, burst: 10 };

export class UserAccountDO extends DurableObject {
  /**
   * @param {DurableObjectState} ctx
   * @param {any} env
   */
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
    /** @type {any} */ this.window = null;
    /** @type {Record<string, any>} */ this.reservations = {};
    /** @type {number[]} */ this.rlHits = [];
    /** @type {{strikeCount:number, firstStrikeAt:number, bannedUntil:number}} */
    this.ban = { strikeCount: 0, firstStrikeAt: 0, bannedUntil: 0 };
    // Separate "background" lane (memory extraction, chat-title generation -
    // fire-and-forget helper calls the frontend fires alongside a single real
    // chat message). These are still billed for real tokens at settle-time,
    // but they must NOT share the user-visible chat lane's rate-limit/ban
    // counters, otherwise 1 visible message (which silently fans out into up
    // to 3 gateway requests) can burn through the tier's rpm/burst budget and
    // ban the user out of their OWN real conversation after only a couple of
    // messages. Kept as fully independent state so it has its own bounded
    // budget instead of an unlimited bypass.
    /** @type {number[]} */ this.rlHitsBg = [];
    /** @type {{strikeCount:number, firstStrikeAt:number, bannedUntil:number}} */
    this.banBg = { strikeCount: 0, firstStrikeAt: 0, bannedUntil: 0 };
    this.userId = ''; // set on first call (DO ids are opaque; caller passes it in)
    // Weekly Usage Cap state (independent of the per-window `this.window`
    // allocation above). `periodStart` is the ms timestamp of the most recent
    // UTC-Monday-00:00 boundary (or of the last paid Weekly Reset purchase,
    // whichever is more recent) - see _ensureWeeklyPeriod(). `usage` is the
    // running credit total settled within that period; compared against
    // WEEKLY_CAP_CREDITS[tier] by reserve(). Free tier never populates a cap
    // (WEEKLY_CAP_CREDITS.free is null) so this simply accumulates unused.
    /** @type {{periodStart: number, usage: number}} */
    this.weekly = { periodStart: 0, usage: 0 };
    // Free-Plan Lifetime Credit Cap running total (see LIFETIME_FREE_CAP_NEW/
    // _RETURNING above). Unlike `this.weekly`, this has NO periodStart / no
    // periodic reset of any kind - it only ever grows, for the lifetime of
    // the account, and is only ever incremented while the reservation being
    // settled was placed under tier === 'free' (see settle()/alarm()).
    /** @type {number} */
    this.lifetimeUsed = 0;
    // Set by applyUpgrade() when a tier change happens: credits/weekly reset
    // immediately, but this flag keeps getState() from lazily auto-opening a
    // fresh window on the next /me poll. Cleared by reserve() the moment the
    // user sends their first real message post-upgrade, which is what
    // actually opens the new window (see getState()/reserve() below).
    /** @type {boolean} */ this.windowPendingReset = false;
    // Last tier this DO has observed for this user, independent of the
    // window lifecycle (this.window gets nulled by applyUpgrade(), so it
    // can't double as a "last known tier" baseline). Used by
    // _syncTierAndDetectUpgrade() to auto-detect tier changes made through
    // ANY path (admin renew endpoint, direct DB edit, future checkout flow)
    // by comparing against the fresh tier passed into every getState()/
    // reserve() call. `null` means "never observed" - the first observation
    // just records the tier without firing an upgrade, so this feature can't
    // falsely fire for every existing user the moment it's deployed.
    /** @type {string|null} */ this.lastSeenTier = null;

    // Load persisted state once, before any request is served. The 10 reads
    // are independent keys, so fire them concurrently instead of serially -
    // same defaults/fallbacks as before, just parallelized.
    ctx.blockConcurrencyWhile(async () => {
      const [window_, reservations, rlHits, ban, rlHitsBg, banBg, userId, weekly, windowPendingReset, lastSeenTier, lifetimeUsed] = await Promise.all([
        ctx.storage.get('window'),
        ctx.storage.get('reservations'),
        ctx.storage.get('rlHits'),
        ctx.storage.get('ban'),
        ctx.storage.get('rlHitsBg'),
        ctx.storage.get('banBg'),
        ctx.storage.get('userId'),
        ctx.storage.get('weekly'),
        ctx.storage.get('windowPendingReset'),
        ctx.storage.get('lastSeenTier'),
        ctx.storage.get('lifetimeUsed'),
      ]);
      this.window = window_ ?? null;
      this.reservations = reservations ?? {};
      this.rlHits = rlHits ?? [];
      this.ban = ban ?? { strikeCount: 0, firstStrikeAt: 0, bannedUntil: 0 };
      this.rlHitsBg = rlHitsBg ?? [];
      this.banBg = banBg ?? { strikeCount: 0, firstStrikeAt: 0, bannedUntil: 0 };
      this.userId = /** @type {string} */ (userId ?? '');
      this.weekly = weekly ?? { periodStart: 0, usage: 0 };
      this.windowPendingReset = windowPendingReset ?? false;
      this.lastSeenTier = lastSeenTier ?? null;
      this.lifetimeUsed = lifetimeUsed ?? 0;
    });
  }

  // ── persistence helpers (persist FIRST, then trust the in-memory copy) ──────
  async _saveWindow() { await this.ctx.storage.put('window', this.window); }
  async _saveReservations() { await this.ctx.storage.put('reservations', this.reservations); }
  async _saveRl() { await this.ctx.storage.put('rlHits', this.rlHits); }
  async _saveBan() { await this.ctx.storage.put('ban', this.ban); }
  async _saveRlBg() { await this.ctx.storage.put('rlHitsBg', this.rlHitsBg); }
  async _saveBanBg() { await this.ctx.storage.put('banBg', this.banBg); }
  async _saveWeekly() { await this.ctx.storage.put('weekly', this.weekly); }
  async _saveWindowPendingReset() { await this.ctx.storage.put('windowPendingReset', this.windowPendingReset); }
  async _saveLastSeenTier() { await this.ctx.storage.put('lastSeenTier', this.lastSeenTier); }
  async _saveLifetimeUsed() { await this.ctx.storage.put('lifetimeUsed', this.lifetimeUsed); }

  /** ms timestamp of the most recent UTC Monday 00:00 boundary at or before `t`. */
  _mostRecentUtcMondayMs(t) {
    const DAY_MS = 24 * 60 * 60 * 1000;
    const d = new Date(t);
    const dayStartMs = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
    // getUTCDay(): 0=Sun, 1=Mon, ... 6=Sat. Days since the most recent Monday:
    const dow = new Date(dayStartMs).getUTCDay();
    const daysSinceMonday = (dow + 6) % 7; // Mon->0, Tue->1, ..., Sun->6
    return dayStartMs - daysSinceMonday * DAY_MS;
  }

  /**
   * Lazily roll the weekly usage counter over to the current UTC-week period
   * if the last-known period has ended. Mirrors the lazy-reset pattern used
   * by _ensureWindow() for the per-window allocation, but on a fixed
   * Monday-00:00-UTC cadence rather than a rolling `windowHours` duration.
   * Returns true if a rollover happened (caller should persist `this.weekly`).
   */
  _ensureWeeklyPeriod() {
    const currentPeriodStart = this._mostRecentUtcMondayMs(nowMs());
    if (this.weekly.periodStart !== currentPeriodStart) {
      this.weekly = { periodStart: currentPeriodStart, usage: 0 };
      return true;
    }
    return false;
  }

  /** Sum of credits currently held by open (unsettled) reservations. */
  _reservedTotal() {
    let sum = 0;
    for (const id in this.reservations) sum += this.reservations[id].credits;
    return sum;
  }

  /** Remember the caller's real user id (for mirror rows) once we learn it. */
  async _rememberUser(userId) {
    if (userId && this.userId !== userId) {
      this.userId = userId;
      await this.ctx.storage.put('userId', userId);
    }
  }

  // ── USAGE WINDOW ────────────────────────────────────────────────────────────
  /**
   * Lazily expire the current window and/or open a fresh one. Returns any
   * side-effect rows produced (expired-window update + new-window insert +
   * window_refill transaction) for the caller to mirror to Postgres.
   *
   * Each new window always opens with exactly the plan's base allocation
   * (no rollover/carryover from a previous window) — unused credits are
   * simply forfeited when a window expires, so a user's balance can never
   * exceed the plan's advertised per-window cap.
   *
   * Async (reads admin-editable plan overrides via `getAppConfig()`, a 5-min
   * cached Supabase read) - this is the ONE place in the whole reserve/settle
   * pipeline that consults `app_config`; every other cost calculation
   * (SERVICE_LIMITS, margins, worstCaseCredits/actualCredits) stays on the
   * hardcoded constants, untouched.
   * @param {Tier} tier
   * @returns {Promise<SideEffect[]>}
   */
  async _ensureWindow(tier) {
    const t = nowMs();
    /** @type {SideEffect[]} */ const fx = [];

    // Expire a window that has run past its end.
    if (this.window && t >= this.window.windowEnd) {
      fx.push({
        table: 'usage_windows',
        rows: [{
          id: this.window.id,
          status: 'expired',
          credits_used: this.window.creditsUsed,
        }],
      });
      this.window = null;
    }

    // Open a brand-new full-allocation window on first request after none active.
    if (!this.window) {
      const appConfig = await getAppConfig(this.env);
      const plan = effectivePlan(planFor(tier), appConfig[tier]);
      const creditsPerWindow = plan.creditsPerWindow;
      const start = t;
      const end = start + plan.windowHours * 60 * 60 * 1000;
      this.window = {
        id: uuid(),
        windowStart: start,
        windowEnd: end,
        creditsAllocated: creditsPerWindow,
        creditsUsed: 0,
        status: 'active',
        tier,
      };
      fx.push({
        table: 'usage_windows',
        rows: [{
          id: this.window.id,
          user_id: this.userId || null,
          window_start: isoFrom(start),
          window_end: isoFrom(end),
          credits_allocated: this.window.creditsAllocated,
          credits_used: 0,
          status: 'active',
        }],
      });
      fx.push({
        table: 'credit_transactions',
        rows: [{
          id: uuid(),
          user_id: this.userId || null,
          window_id: this.window.id,
          amount: creditsPerWindow,
          type: 'window_refill',
          balance_after: this.window.creditsAllocated,
          created_at: isoFrom(start),
        }],
      });
    }
    return fx;
  }

  // ── RATE LIMIT + ESCALATING BANS ─────────────────────────────────────────────
  /**
   * Sliding-window anti-spam check (NOT total-consumption control - the usage
   * window already bounds total spend). Returns null if allowed, or a 429
   * descriptor if the request must be rejected. Registers an escalating strike
   * on violation.
   *
   * @param {Tier} tier
   * @param {'main'|'bg'} [lane='main'] - 'bg' is the separate, independent
   *        budget used for fire-and-forget background helper calls (memory
   *        extraction, chat-title generation) so they can never eat into or
   *        trip a ban on the user's own real chat rate limit (see the fields'
   *        doc comment in the constructor for why this lane exists).
   * @returns {{status:429, error:string, retryAfter:number, alert?:boolean}|null}
   */
  _checkRateLimit(tier, lane = 'main') {
    const t = nowMs();
    const isBg = lane === 'bg';
    const hits = isBg ? this.rlHitsBg : this.rlHits;
    const ban = isBg ? this.banBg : this.ban;

    // Already serving a ban?
    if (ban.bannedUntil > t) {
      return { status: 429, error: 'banned', retryAfter: Math.ceil((ban.bannedUntil - t) / 1000) };
    }

    // The background lane isn't tier-priced (it's not a real generation the
    // user chose to spend a tier's worth of throughput on) - a single fixed,
    // still-bounded budget applies to every tier so it can never be used to
    // exceed a tier's real intended throughput.
    const plan = isBg ? BG_LANE_LIMIT : planFor(tier);
    // Prune hits older than 60s; count 60s + 10s buckets.
    const pruned = hits.filter((ts) => t - ts < 60_000);
    const inLastMin = pruned.length;
    const inLast10s = pruned.filter((ts) => t - ts < 10_000).length;
    if (isBg) this.rlHitsBg = pruned; else this.rlHits = pruned;

    if (inLastMin >= plan.rpm || inLast10s >= plan.burst) {
      return this._registerStrike(t, lane);
    }

    // Allowed - record the hit.
    pruned.push(t);
    return null;
  }

  /**
   * Escalate a violation into the ban ladder and return the 429 descriptor.
   * @param {'main'|'bg'} [lane='main']
   * @returns {{status:429, error:string, retryAfter:number, alert?:boolean}}
   */
  _registerStrike(t, lane = 'main') {
    const isBg = lane === 'bg';
    const ban = isBg ? this.banBg : this.ban;

    // Reset the strike counter if the last strike was more than 1h ago.
    if (t - ban.firstStrikeAt > STRIKE_WINDOW_MS) {
      ban.strikeCount = 0;
      ban.firstStrikeAt = t;
    }
    ban.strikeCount += 1;
    if (ban.strikeCount === 1) ban.firstStrikeAt = t;

    const rung = BAN_LADDER[Math.min(ban.strikeCount, BAN_LADDER.length) - 1];
    ban.bannedUntil = rung.banMs > 0 ? t + rung.banMs : 0;

    return {
      status: 429,
      error: ban.strikeCount === 1 ? 'rate_limited' : 'banned',
      retryAfter: rung.retryAfter,
      alert: ban.strikeCount >= 4, // 4th+ → admin cost_alerts row
    };
  }

  // ── RPC: reserve ──────────────────────────────────────────────────────────────
  /**
   * Reserve worst-case credits for one generation. Atomic: because the DO is
   * single-threaded, no two concurrent reserves can double-spend the balance.
   *
   * @param {{ userId:string, tier:Tier, service:Service, model:string,
   *           pricing?:object, background?:boolean, freeLifetimeCap?:number|null }} p
   * @returns {Promise<{ ok:boolean, status?:number, error?:string,
   *           reservationId?:string, reservedCredits?:number, warning?:string|null,
   *           retryAfter?:number, windowEndsAt?:string, balance?:object,
   *           weeklyUsage?:number, weeklyCap?:number|null, weeklyResetAt?:string,
   *           lifetimeUsed?:number, lifetimeCap?:number|null,
   *           sideEffects:SideEffect[] }>}
   */
  async reserve(p) {
    /** @type {SideEffect[]} */ const sideEffects = [];
    await this._rememberUser(p.userId);

    // 0) Auto-detect a tier change (any source: admin renew, direct DB edit,
    //    future self-serve checkout) by comparing against the last tier this
    //    DO has observed. Must run here too (not just in getState()) because
    //    request order between /me polling and sending a message isn't
    //    guaranteed for any given user.
    sideEffects.push(...(await this._syncTierAndDetectUpgrade(p.tier)));

    // 1) Rate limit / ban gate (cheap, before touching credits). Background
    //    helper calls (memory extraction, chat-title generation) use their
    //    own independent lane (see BG_LANE_LIMIT) so they can never trip a
    //    ban on the user's real, visible chat usage.
    const lane = p.background ? 'bg' : 'main';
    const rl = this._checkRateLimit(p.tier, lane);
    await (lane === 'bg' ? this._saveRlBg() : this._saveRl());
    if (rl) {
      await (lane === 'bg' ? this._saveBanBg() : this._saveBan());
      if (rl.alert) {
        sideEffects.push({
          table: 'cost_alerts',
          rows: [{
            id: uuid(),
            type: 'rate_limit_ban',
            severity: 'high',
            message: `User ${this.userId} hit a 24h ban (repeated rate-limit violations)`,
            metadata: { userId: this.userId, tier: p.tier },
            resolved: false,
            created_at: isoFrom(nowMs()),
          }],
        });
      }
      {
        const hits = lane === 'bg' ? this.rlHitsBg : this.rlHits;
        const ban = lane === 'bg' ? this.banBg : this.ban;
        sideEffects.push({
          table: 'rate_limit_logs',
          rows: [{
            id: uuid(),
            user_id: this.userId || null,
            requests_count: hits.length,
            window_start: isoFrom(nowMs()),
            blocked_until: ban.bannedUntil ? isoFrom(ban.bannedUntil) : null,
          }],
        });
      }
      return { ok: false, status: rl.status, error: rl.error, retryAfter: rl.retryAfter, sideEffects };
    }

    // 2) Ensure an active window exists (lazy expiry + fresh allocation).
    //    Clear any post-upgrade pending flag first - this real message is
    //    exactly the "first use" event that should (re)open the new window.
    if (this.windowPendingReset) { this.windowPendingReset = false; await this._saveWindowPendingReset(); }
    sideEffects.push(...(await this._ensureWindow(p.tier)));
    await this._saveWindow();

    // 2.5) Weekly Usage Cap gate - a global, UTC-Monday-00:00-resetting
    //    ceiling on top of the per-window allocation above (see
    //    WEEKLY_CAP_CREDITS). Free tier has no cap (WEEKLY_CAP_CREDITS.free
    //    is null) so this is a no-op for it. Checked independently of the
    //    balance check below: a user can still have per-window balance left
    //    but be hard-blocked here once their weekly total is exhausted.
    if (this._ensureWeeklyPeriod()) await this._saveWeekly();
    const weeklyCap = WEEKLY_CAP_CREDITS[p.tier];
    if (weeklyCap != null && this.weekly.usage >= weeklyCap) {
      return {
        ok: false,
        status: 402,
        error: 'weekly_cap_reached',
        weeklyUsage: this.weekly.usage,
        weeklyCap,
        weeklyResetAt: isoFrom(this.weekly.periodStart + 7 * 24 * 60 * 60 * 1000),
        sideEffects,
      };
    }

    // 2.6) Free-Plan Lifetime Credit Cap gate (see LIFETIME_FREE_CAP_NEW/
    //    _RETURNING above) - a one-time, NEVER-resetting ceiling that only
    //    ever applies to the free tier. `p.freeLifetimeCap` is computed by
    //    authenticate() (null for paid tiers) and passed in per-request,
    //    since it depends on subscription_started_at, not just tier. Once
    //    reached, the account is hard-blocked from new reservations - unlike
    //    the weekly gate above, there is no reset/rollover of any kind here.
    if (p.tier === 'free' && p.freeLifetimeCap != null && this.lifetimeUsed >= p.freeLifetimeCap) {
      return {
        ok: false,
        status: 402,
        error: 'lifetime_cap_reached',
        lifetimeUsed: this.lifetimeUsed,
        lifetimeCap: p.freeLifetimeCap,
        sideEffects,
      };
    }

    // 3) Balance check. We only hard-block once the balance is fully
    //    exhausted (available <= 0). If some balance remains but it's less
    //    than the service's worst-case ceiling, we still admit the request
    //    and cap the hold at whatever is left (`hold`) instead of the full
    //    worst-case amount - this lets a user's balance be spent all the way
    //    down to exactly 0 rather than getting permanently "stranded" below
    //    the worst-case threshold (e.g. 5 credits left but chat's worst-case
    //    is 6 → previously blocked forever until the window refilled).
    //    settle() still charges the REAL usage afterwards (Math.ceil'd, same
    //    as before) - real usage is bounded by the same worst-case ceiling,
    //    so this can only let the balance dip slightly negative in rare
    //    max-output cases, never beyond the worst-case ceiling itself.
    const worst = p.service === 'status_hint'
      ? STATUS_HINT_FLAT_CREDITS
      : p.service === 'chat_title'
      ? CHAT_TITLE_FLAT_CREDITS
      : p.service === 'chat_reason'
      ? CHAT_REASON_FLAT_CREDITS
      : p.service === 'build_steps'
      ? BUILD_STEPS_FLAT_CREDITS
      : p.service === 'marketing_extract'
      ? MARKETING_EXTRACT_FLAT_CREDITS
      : p.service === 'chat_export'
      ? CHAT_EXPORT_FLAT_CREDITS
      : worstCaseCredits(p.service, p.model, p.pricing);
    const available = this.window.creditsAllocated - this.window.creditsUsed - this._reservedTotal();
    if (available <= 0) {
      return {
        ok: false,
        status: 402,
        error: 'insufficient_credits',
        windowEndsAt: isoFrom(this.window.windowEnd),
        balance: {
          allocated: this.window.creditsAllocated,
          used: this.window.creditsUsed,
          reserved: this._reservedTotal(),
          available,
        },
        sideEffects,
      };
    }
    const hold = Math.min(worst, available);

    // 4) Place the reservation.
    const reservationId = uuid();
    this.reservations[reservationId] = {
      credits: hold,
      service: p.service,
      model: p.model,
      // Captured at reserve()-time so settle()/alarm() can gate the Free
      // Lifetime Cap accumulation on the tier this reservation was actually
      // placed under (not whatever tier the account happens to be on by the
      // time it settles - see settle()'s "Free Lifetime Cap" comment).
      tier: p.tier,
      createdAt: nowMs(),
      upstreamDone: false,
      actualCredits: null,
    };
    await this._saveReservations();

    // 5) Schedule the orphan-sweep alarm if not already pending.
    const existing = await this.ctx.storage.getAlarm();
    if (existing == null) {
      await this.ctx.storage.setAlarm(nowMs() + ORPHAN_TTL_MS);
    }

    // 6) Soft-limit warning (informative, non-blocking) based on committed load.
    const committed = this.window.creditsUsed + this._reservedTotal();
    const ratio = committed / this.window.creditsAllocated;
    const warning = ratio >= 0.9 ? 'soft_90' : ratio >= 0.8 ? 'soft_80' : null;

    return {
      ok: true,
      reservationId,
      // Worst-case hold placed for THIS specific request (not the
      // account-wide `balance.reserved` total below). Exposed so the gateway
      // can surface an instant, non-final "X-Credits-Charged" estimate to the
      // client right away - the real/final charge is only known later, once
      // settle() runs (see settle() RPC + settleAndRelease() in gateway.js).
      reservedCredits: hold,
      warning,
      windowEndsAt: isoFrom(this.window.windowEnd),
      balance: {
        allocated: this.window.creditsAllocated,
        used: this.window.creditsUsed,
        reserved: this._reservedTotal(),
        available: this.window.creditsAllocated - committed,
      },
      sideEffects,
    };
  }

  // ── RPC: settle ────────────────────────────────────────────────────────────────
  /**
   * Close a reservation at the ACTUAL cost once the upstream Worker has
   * responded. `outcome` decides the charge:
   *   'success' + tokens → charge actualCredits() (real usage, Math.ceil'd)
   *   'failed'           → charge 0 (release the hold; user got nothing)
   *   'unknown'          → charge the full worst-case hold (protect platform)
   *
   * @param {{ reservationId:string, outcome:'success'|'failed'|'unknown',
   *           inputTokens?:number, outputTokens?:number, pricing?:object,
   *           analyzedImageCount?:number }} p
   */
  async settle(p) {
    /** @type {SideEffect[]} */ const sideEffects = [];
    const res = this.reservations[p.reservationId];
    if (!res) {
      // Already settled (e.g. by the orphan sweep) - idempotent no-op.
      return { ok: true, alreadySettled: true, sideEffects };
    }

    let charge;
    let logStatus = 'ok';
    let inTok = p.inputTokens || 0;
    let outTok = p.outputTokens || 0;
    if (p.outcome === 'success' && (inTok || outTok)) {
      // Chat (and bat 1.2 flash/core) use a flat tiered schedule based on
      // real output tokens (see chatTierCredits()/chatFlashTierCredits()/
      // chatCoreTierCredits()); other services keep the proportional
      // actual-cost charge.
      const tierCharge = res.service === 'status_hint'
        ? STATUS_HINT_FLAT_CREDITS
        : res.service === 'chat_title'
        ? CHAT_TITLE_FLAT_CREDITS
        : res.service === 'chat_reason'
        ? CHAT_REASON_FLAT_CREDITS
        : res.service === 'build_steps'
        ? BUILD_STEPS_FLAT_CREDITS
        : res.service === 'marketing_extract'
        ? MARKETING_EXTRACT_FLAT_CREDITS
        : res.service === 'chat_export'
        ? CHAT_EXPORT_FLAT_CREDITS
        : res.service === 'chat'
        ? chatTierCredits(outTok, inTok, res.model, p.pricing)
        : res.service === 'chat_flash'
        ? chatFlashTierCredits(outTok, inTok, res.model, p.pricing)
        : res.service === 'chat_core'
        ? chatCoreTierCredits(outTok)
        : res.service === 'chat_marketing_eco'
        ? chatMarketingEcoTierCredits(outTok, inTok, res.model, p.pricing)
        : actualCredits(inTok, outTok, res.service, res.model, p.pricing);
      charge = tierCharge;

      // Moondream image-preprocessing surcharge: flat additive credits PER
      // IMAGE actually analyzed, on top of the tier charge above, applied
      // only when the upstream chat route signaled analyzed images (see
      // applyImagePreprocessing() in worker.js / X-Images-Analyzed header,
      // forwarded here as p.analyzedImageCount by handleGenerate()). Zero
      // analyzed images = no surcharge; existing chat/chat_flash/chat_core
      // billing above is completely unaffected either way.
      if (p.analyzedImageCount > 0 &&
          (res.service === 'chat' || res.service === 'chat_flash' || res.service === 'chat_core')) {
        charge += MOONDREAM_FLAT_SURCHARGE_CREDITS * p.analyzedImageCount;
      }
    } else if (p.outcome === 'failed') {
      charge = 0; // full release, no charge - nothing was produced
    } else {
      charge = res.credits; // unknown → keep the worst-case hold
      logStatus = 'orphaned_reservation';
    }

    // Apply the charge to the current window (single-threaded ⇒ atomic).
    if (this.window) {
      this.window.creditsUsed += charge;
      await this._saveWindow();
    }
    // Mirror the same charge into the Weekly Usage Cap counter (independent
    // ceiling on top of the per-window balance above; see WEEKLY_CAP_CREDITS
    // and reserve()'s gate). Re-check the period first in case a long-delayed
    // settle (e.g. via the orphan-sweep alarm) crosses a Monday 00:00 UTC
    // boundary between reserve() and settle().
    if (charge > 0) {
      this._ensureWeeklyPeriod();
      this.weekly.usage += charge;
      await this._saveWeekly();
    }
    // Mirror the same charge into the Free-Plan Lifetime Credit Cap counter
    // (see LIFETIME_FREE_CAP_NEW/_RETURNING above), but ONLY for reservations
    // placed while the account was on the free tier (res.tier, captured at
    // reserve()-time) - paid-tier usage must never count against it, and
    // this counter never resets (unlike this.weekly.usage above).
    if (charge > 0 && res.tier === 'free') {
      this.lifetimeUsed += charge;
      await this._saveLifetimeUsed();
      if (this.userId) {
        sideEffects.push({
          table: 'users',
          rows: [{ id: this.userId, lifetime_credits_used: this.lifetimeUsed }],
        });
      }
    }
    delete this.reservations[p.reservationId];
    await this._saveReservations();

    const balanceAfter = this.window
      ? this.window.creditsAllocated - this.window.creditsUsed - this._reservedTotal()
      : 0;

    if (charge > 0) {
      sideEffects.push({
        table: 'credit_transactions',
        rows: [{
          id: uuid(),
          user_id: this.userId || null,
          window_id: this.window ? this.window.id : null,
          amount: -charge,
          type: 'charge',
          service: res.service,
          balance_after: balanceAfter,
          reference: p.reservationId,
          created_at: isoFrom(nowMs()),
        }],
      });
      // Mirror the updated running total into the window's own Supabase row
      // too (not just the ledger above) - the DO's own storage is already
      // authoritative and up to date (see "_saveWindow()" above); without
      // this, usage_windows.credits_used silently freezes at its
      // window-creation value in Postgres for the window's entire life,
      // even though real charges keep landing in credit_transactions. That
      // gap breaks admin_user_detail()'s dashboard figures and lets
      // cron_check_cost_alerts()'s fast-drain abuse check (which reads
      // credits_used straight off this table) never fire.
      if (this.window) {
        sideEffects.push({
          table: 'usage_windows',
          rows: [{ id: this.window.id, credits_used: this.window.creditsUsed }],
        });
      }
    }
    sideEffects.push({
      table: 'api_usage_logs',
      rows: [{
        id: uuid(),
        user_id: this.userId || null,
        window_id: this.window ? this.window.id : null,
        service: res.service,
        model: res.model,
        input_tokens: inTok,
        output_tokens: outTok,
        actual_cost_usd: costUsd(inTok, outTok, res.model, p.pricing),
        margin_pct: serviceLimits(res.service).margin,
        credits_charged: charge,
        status: logStatus,
        created_at: isoFrom(nowMs()),
      }],
    });

    return { ok: true, charged: charge, balanceAfter, sideEffects };
  }

  // ── ALARM: orphaned-reservation sweep ────────────────────────────────────────
  /**
   * Fires ORPHAN_TTL_MS after a reservation is placed. Any reservation still
   * open past the TTL is settled defensively:
   *   • if the upstream call was known to complete (usage captured but the async
   *     settle write itself was lost) → charge the ACTUAL captured cost
   *   • if the outcome is unknown / never completed → charge the worst-case hold
   * Either way it is logged as status='orphaned_reservation' for admin review.
   * The alarm writes to Postgres directly (no request context for waitUntil).
   */
  async alarm() {
    const t = nowMs();
    /** @type {SideEffect[]} */ const sideEffects = [];
    let mutated = false;

    for (const id in this.reservations) {
      const res = this.reservations[id];
      if (t - res.createdAt <= ORPHAN_TTL_MS) continue;

      const charge = res.upstreamDone && res.actualCredits != null ? res.actualCredits : res.credits;
      if (this.window) this.window.creditsUsed += charge;
      // Mirror into the Weekly Usage Cap counter, same as settle() does
      // (see settle()'s "Mirror the same charge" step above) - otherwise an
      // orphaned reservation (settle() never runs for it; this alarm sweep
      // is the ONLY place it gets charged) would silently bypass the weekly
      // cap entirely, letting a user who repeatedly triggers orphan sweeps
      // never hit weekly_cap_reached. No double-counting risk: this branch
      // and settle()'s mirroring are mutually exclusive per reservation -
      // once deleted here, settle() finds it missing and no-ops
      // (`alreadySettled`), so it can never also be mirrored there.
      if (charge > 0) {
        this._ensureWeeklyPeriod();
        this.weekly.usage += charge;
      }
      // Same Free Lifetime Cap mirroring as settle() (see its comment) -
      // an orphaned reservation never goes through settle(), so this alarm
      // sweep is the only place it gets charged.
      if (charge > 0 && res.tier === 'free') {
        this.lifetimeUsed += charge;
      }
      delete this.reservations[id];
      mutated = true;

      const balanceAfter = this.window
        ? this.window.creditsAllocated - this.window.creditsUsed - this._reservedTotal()
        : 0;
      sideEffects.push({
        table: 'credit_transactions',
        rows: [{
          id: uuid(),
          user_id: this.userId || null,
          window_id: this.window ? this.window.id : null,
          amount: -charge,
          type: 'charge',
          service: res.service,
          balance_after: balanceAfter,
          reference: id,
          created_at: isoFrom(t),
        }],
      });
      sideEffects.push({
        table: 'api_usage_logs',
        rows: [{
          id: uuid(),
          user_id: this.userId || null,
          window_id: this.window ? this.window.id : null,
          service: res.service,
          model: res.model,
          input_tokens: 0,
          output_tokens: 0,
          actual_cost_usd: 0,
          margin_pct: serviceLimits(res.service).margin,
          credits_charged: charge,
          status: 'orphaned_reservation',
          created_at: isoFrom(t),
        }],
      });
    }

    if (mutated) {
      await this._saveWindow();
      await this._saveReservations();
      await this._saveWeekly();
      await this._saveLifetimeUsed();
      // Same usage_windows mirror as settle() (see its comment) - one
      // combined write for the window's final creditsUsed after the sweep,
      // rather than per-reservation, since this loop can charge several
      // orphaned reservations against the same window in one pass.
      if (this.window) {
        sideEffects.push({
          table: 'usage_windows',
          rows: [{ id: this.window.id, credits_used: this.window.creditsUsed }],
        });
      }
      if (this.userId) {
        sideEffects.push({
          table: 'users',
          rows: [{ id: this.userId, lifetime_credits_used: this.lifetimeUsed }],
        });
      }
      await flushToSupabase(this.env, sideEffects);
    }

    // Reschedule if any reservations remain open.
    if (Object.keys(this.reservations).length > 0) {
      await this.ctx.storage.setAlarm(nowMs() + ORPHAN_TTL_MS);
    }
  }

  // ── RPC: reads + admin/recharge mutations ────────────────────────────────────
  /**
   * Current window + balance snapshot for the frontend / admin detail view.
   * Read-only with respect to `this.window` - it never opens a new window.
   * A brand-new signup (or any user between windows) sees `window: null`
   * here, and the frontend shows the plan's full allocation with no
   * countdown until the user's actual first message. Only `reserve()` (the
   * real consumption point) is allowed to open a window - see reserve(),
   * which clears windowPendingReset and calls _ensureWindow().
   * @param {Tier} [tier]
   * @param {number|null} [freeLifetimeCap] - the caller's current Free
   *   Lifetime Cap (see LIFETIME_FREE_CAP_NEW/_RETURNING above), computed by
   *   authenticate() from subscription_started_at. null/undefined for paid
   *   tiers or when unknown.
   */
  async getState(tier, freeLifetimeCap) {
    /** @type {SideEffect[]} */ let sideEffects = [];
    // Auto-detect a tier change (any source: admin renew, direct DB edit,
    // future self-serve checkout) so an upgrade discovered via a /me poll
    // (not just via reserve()) still expires the old window / arms
    // windowPendingReset immediately.
    sideEffects.push(...(await this._syncTierAndDetectUpgrade(tier)));
    if (this._ensureWeeklyPeriod()) await this._saveWeekly();
    const weeklyCap = tier ? WEEKLY_CAP_CREDITS[tier] : null;
    return {
      window: this.window,
      reserved: this._reservedTotal(),
      openReservations: Object.keys(this.reservations).length,
      ban: this.ban,
      weekly: {
        usage: this.weekly.usage,
        cap: weeklyCap, // null → tier has no weekly cap (e.g. free)
        periodStart: isoFrom(this.weekly.periodStart),
        resetAt: isoFrom(this.weekly.periodStart + 7 * 24 * 60 * 60 * 1000),
        warningRatio: WEEKLY_CAP_WARNING_RATIO,
      },
      lifetime: {
        used: this.lifetimeUsed,
        cap: tier === 'free' ? (freeLifetimeCap ?? null) : null, // null → not applicable (paid tier)
      },
      sideEffects,
    };
  }

  /**
   * Grant credits to the current window (admin adjustment OR a Recharge-Now
   * purchase). If there is no active window, one is opened first so the credits
   * have somewhere to land. `mode`:
   *   'add'     → increase the current window's allocation (extra credits/window)
   *   'refill'  → reset usage to 0 (Instant Refill: top back up to full now)
   * If the grant leaves creditsUsed at 0 (always true for 'refill'; possible
   * but rare for 'add' landing on an untouched window), the window is
   * expired and windowPendingReset is armed - the exact same treatment
   * _applyUpgradeEffects() uses - so the OLD windowEnd from before the grant
   * doesn't keep ticking down over a now fully-available balance. A fresh,
   * full-duration window only opens on the user's next real message via
   * reserve(). If creditsUsed stays above 0 after the grant (the common
   * 'add' case), the window is left running as-is since real usage already
   * happened in it.
   * @param {{ userId:string, tier:Tier, credits?:number, mode:'add'|'refill',
   *           txType:string, reference?:string }} p
   */
  async grant(p) {
    /** @type {SideEffect[]} */ const sideEffects = [];
    await this._rememberUser(p.userId);
    sideEffects.push(...(await this._ensureWindow(p.tier)));

    if (p.mode === 'refill') {
      this.window.creditsUsed = 0;
    } else {
      this.window.creditsAllocated += p.credits || 0;
    }

    const windowId = this.window.id;
    const balanceAfter = this.window.creditsAllocated - this.window.creditsUsed - this._reservedTotal();

    if (this.window.creditsUsed === 0) {
      sideEffects.push({ table: 'usage_windows', rows: [{ id: windowId, status: 'expired', credits_used: 0 }] });
      this.window = null;
      this.windowPendingReset = true;
      await this._saveWindow();
      await this._saveWindowPendingReset();
    } else {
      await this._saveWindow();
      sideEffects.push({ table: 'usage_windows', rows: [{ id: windowId, credits_allocated: this.window.creditsAllocated, credits_used: this.window.creditsUsed }] });
    }

    sideEffects.push({ table: 'credit_transactions', rows: [{
      id: uuid(),
      user_id: this.userId || null,
      window_id: windowId,
      amount: p.mode === 'refill' ? 0 : (p.credits || 0),
      type: p.txType,
      balance_after: balanceAfter,
      reference: p.reference || null,
      created_at: isoFrom(nowMs()),
    }]});

    return { ok: true, balanceAfter, windowEndsAt: this.window ? isoFrom(this.window.windowEnd) : null, sideEffects };
  }

  /**
   * Force-open a fresh window (admin/support "reset window" action). Routed
   * through the same window-open path so it stays atomic + auditable.
   * @param {{ userId:string, tier:Tier }} p
   */
  async resetWindow(p) {
    await this._rememberUser(p.userId);
    /** @type {SideEffect[]} */ const sideEffects = [];
    // Force expiry of any current window, then open a new one.
    if (this.window) {
      sideEffects.push({ table: 'usage_windows', rows: [{ id: this.window.id, status: 'expired', credits_used: this.window.creditsUsed }] });
      this.window = null;
    }
    sideEffects.push(...(await this._ensureWindow(p.tier)));
    await this._saveWindow();
    return { ok: true, windowEndsAt: isoFrom(this.window.windowEnd), sideEffects };
  }

  /**
   * Shared core of a tier upgrade: expires the current window (if any),
   * arms windowPendingReset so getState() won't lazily reopen a window
   * until the user's next real message (reserve() clears the flag), and
   * resets the weekly cap immediately (calendar-anchored, no "wait for
   * first use" concept). Extracted so both the manual admin-endpoint path
   * (applyUpgrade()) and the automatic path (_syncTierAndDetectUpgrade())
   * share identical logic instead of duplicating/drifting.
   * @returns {Promise<SideEffect[]>}
   */
  async _applyUpgradeEffects() {
    /** @type {SideEffect[]} */ const sideEffects = [];
    if (this.window) {
      sideEffects.push({ table: 'usage_windows', rows: [{ id: this.window.id, status: 'expired', credits_used: this.window.creditsUsed }] });
      this.window = null;
    }
    this.windowPendingReset = true;
    await this._saveWindow();
    await this._saveWindowPendingReset();
    this.weekly = { periodStart: this._mostRecentUtcMondayMs(nowMs()), usage: 0 };
    await this._saveWeekly();
    return sideEffects;
  }

  /**
   * Auto-detects a tier change made through ANY path - the admin renew
   * endpoint, a direct Supabase edit, or a future self-serve checkout - by
   * comparing the fresh `tier` passed into every getState()/reserve() call
   * against the last tier this DO has observed (`this.lastSeenTier`, which
   * is independent of `this.window` since that gets nulled by an upgrade).
   * Applies the same reset as the manual applyUpgrade() RPC on ANY detected
   * change, upgrade OR downgrade (business decision, 2026-07-26: a prior
   * "lazy on downgrade" behavior left the old tier's stale window/weekly
   * numbers visible until natural expiry - e.g. a Max->Pro change kept
   * showing Max's 800-credit window and Max-era weekly usage under the Pro
   * label. Resetting unconditionally keeps this path's behavior identical
   * to the official renew path's applyUpgrade(), which has never branched
   * on direction). Note this only fixes the "never resets on downgrade"
   * half of the staleness window - the up-to-60s detection delay for
   * direct/out-of-band Supabase edits (see TIER_CACHE, Section 9) is a
   * separate, still-present limitation: this DO instance cannot reach into
   * the Worker-isolate's TIER_CACHE Map to invalidate it (Durable Objects
   * run in their own isolate/global scope, so it isn't the same Map
   * instance even though defined in the same source file) - see the note
   * above TIER_CACHE's definition for why this remains bounded-but-present
   * specifically for manual DB edits (the official renew endpoint doesn't
   * have this delay at all, since it calls TIER_CACHE.delete() itself from
   * within the Worker isolate before invoking applyUpgrade()).
   * @param {Tier} [tier]
   * @returns {Promise<SideEffect[]>}
   */
  async _syncTierAndDetectUpgrade(tier) {
    if (!tier) return [];
    if (!this.lastSeenTier) {
      // First time this DO has ever observed a tier for this user - just
      // record it. Firing a reset here would falsely trigger for every
      // pre-existing user the moment this feature is deployed.
      this.lastSeenTier = tier;
      await this._saveLastSeenTier();
      return [];
    }
    if (tier === this.lastSeenTier) return [];
    this.lastSeenTier = tier;
    await this._saveLastSeenTier();
    return await this._applyUpgradeEffects();
  }

  /**
   * Apply a tier upgrade (called from /admin/user/{uid}/renew): credits show
   * full immediately, but the rolling window does NOT resume counting down
   * until the user's next real message (reserve()) reopens it - see the
   * windowPendingReset bypass in getState() and the clear in reserve().
   * Weekly usage resets immediately since it's a calendar-anchored cap, not
   * a countdown that needs to "wait" for first use.
   * @param {{ userId:string, tier?:Tier }} p
   */
  async applyUpgrade(p) {
    await this._rememberUser(p.userId);
    const sideEffects = await this._applyUpgradeEffects();
    if (p.tier) {
      // Record the new tier immediately so _syncTierAndDetectUpgrade()
      // doesn't redundantly re-fire on the very next getState()/reserve()
      // call for this same, already-handled upgrade.
      this.lastSeenTier = p.tier;
      await this._saveLastSeenTier();
    }
    return { ok: true, sideEffects };
  }

  /**
   * One-time maintenance action for the grant() window-invalidation bug fix:
   * if the account's current window shows creditsUsed === 0 (i.e. it's
   * sitting on a fully-available balance but still has an old window ticking
   * down from a refill/add that happened before the grant() fix landed),
   * apply the exact same treatment _applyUpgradeEffects() uses - expire the
   * window, null it, arm windowPendingReset - WITHOUT touching the weekly
   * cap or lastSeenTier (this is a stale-window correction, not a real
   * upgrade). Re-validates its own persisted state before mutating, so it's
   * safe to call from a batch script built off a possibly-stale Supabase
   * snapshot: no-ops harmlessly if the window no longer qualifies.
   * @param {{ userId:string }} p
   */
  async invalidateIfFullyRefilled(p) {
    await this._rememberUser(p.userId);
    if (!this.window || this.window.creditsUsed !== 0) {
      return { ok: true, changed: false, reason: !this.window ? 'no_active_window' : 'window_has_usage' };
    }
    /** @type {SideEffect[]} */ const sideEffects = [];
    sideEffects.push({ table: 'usage_windows', rows: [{ id: this.window.id, status: 'expired', credits_used: 0 }] });
    this.window = null;
    this.windowPendingReset = true;
    await this._saveWindow();
    await this._saveWindowPendingReset();
    return { ok: true, changed: true, sideEffects };
  }

  /**
   * Paid "Weekly Reset" purchase (handleWeeklyReset() in gateway.js's router
   * section) - immediately zeroes the Weekly Usage Cap counter, independent
   * of (and without touching) the per-window balance/allocation above. Does
   * NOT reuse grant()/resetWindow(), which operate on the per-window system;
   * this is a distinct RPC for the distinct weekly-cap system. No purchase
   * cooldown (unlike Recharge Now) - a user can buy this again immediately
   * if they somehow re-exhaust the cap before the next Monday.
   * @param {{ userId:string, tier:Tier, reference?:string }} p
   */
  async resetWeekly(p) {
    await this._rememberUser(p.userId);
    // Re-anchor to the current Monday-boundary period (so a stale/rolled-over
    // period is never mistaken for "already reset") then zero usage.
    this._ensureWeeklyPeriod();
    this.weekly.usage = 0;
    await this._saveWeekly();
    const resetAtIso = isoFrom(nowMs());
    /** @type {SideEffect[]} */ const sideEffects = [{
      table: 'credit_transactions',
      rows: [{
        id: uuid(),
        user_id: this.userId || null,
        window_id: this.window ? this.window.id : null,
        amount: 0,
        type: 'weekly_reset_purchase',
        balance_after: this.window ? this.window.creditsAllocated - this.window.creditsUsed - this._reservedTotal() : null,
        reference: p.reference || null,
        created_at: resetAtIso,
      }],
    }];
    return {
      ok: true,
      weeklyUsage: this.weekly.usage,
      weeklyPeriodStart: resetAtIso, // mirror-only "last zeroed at" marker (see schema_weekly_usage_cap.sql design notes)
      sideEffects,
    };
  }
}

// ============================================================================
//  SECTION 6 - ConcurrencyGateDO   (tier-priority admission control)
// ----------------------------------------------------------------------------
//  PURPOSE (heavily commented - spec requirement)
//  ----------------------------------------------
//  Under load we want paid tiers to be served ahead of free ones, but we do NOT
//  want a heavyweight always-on queue that adds latency in the common (uncon-
//  tended) case. This DO does ADMISSION CONTROL, not long-lived queuing:
//
//    • It tracks an in-flight counter per shard against a ceiling.
//    • Below the ceiling → admit IMMEDIATELY (near-zero overhead - the 99% path).
//    • At/above the ceiling → the caller waits briefly (bounded, MAX_WAIT_MS) in
//      an internal list ordered by (tierRank, enqueueTime). Max(0) jumps ahead
//      of Pro(1), Pro ahead of Starter(2), Starter ahead of Free(3). Within a
//      tier it is first-come-first-served.
//    • If a slot doesn't free up within the bound → 429 with a tier-based
//      Retry-After (paid tiers get a shorter retry).
//
//  WHY A DURABLE OBJECT (vs. plain Worker / Cloudflare Queues)?
//    • A plain Worker is stateless - there is no shared in-flight counter across
//      its many isolated invocations, so it cannot coordinate admission.
//    • Cloudflare Queues are async/pull-based - the wrong shape for a synchronous
//      request/response with preemption. We need a live gatekeeper.
//
//  SHARDING: the gateway spreads load across SHARD_COUNT instances per service
//  (id = `${service}:${shard}`) so a single DO is never the global bottleneck.
//
//  STATE IS IN-MEMORY ONLY (no storage): an in-flight counter must not survive
//  eviction - if the DO is evicted, all its in-flight requests are already gone
//  too, so resetting to 0 is the correct, safe behaviour (never leaks capacity).
//
//  INITIAL CEILING is deliberately high (near no-op). Tighten it only once real
//  contention is observed - avoids over-engineering against load that may never
//  materialise (spec: don't optimise a problem you don't have yet).
// ============================================================================

const GATE_CEILING = 100;         // max concurrent in-flight per shard (start high)
const GATE_MAX_WAIT_MS = 18_000;  // longest a queued request will wait for a slot

/** Retry-After (seconds) handed back on admission timeout, by tier rank. */
const GATE_RETRY_AFTER = { 0: 2, 1: 5, 2: 10, 3: 15 };

export class ConcurrencyGateDO extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
    this.inFlight = 0;
    /** @type {Array<{tierRank:number, enqueueTime:number, ticket:string, resolve:Function}>} */
    this.waiters = [];
  }

  /** Pull the highest-priority waiter (lowest tierRank, then earliest enqueue). */
  _dequeueBest() {
    if (!this.waiters.length) return null;
    let bestIdx = 0;
    for (let i = 1; i < this.waiters.length; i++) {
      const a = this.waiters[i];
      const b = this.waiters[bestIdx];
      if (a.tierRank < b.tierRank || (a.tierRank === b.tierRank && a.enqueueTime < b.enqueueTime)) {
        bestIdx = i;
      }
    }
    return this.waiters.splice(bestIdx, 1)[0];
  }

  /**
   * Request admission. Resolves immediately when below the ceiling, otherwise
   * waits (priority-ordered) up to GATE_MAX_WAIT_MS. Returns a ticket the caller
   * MUST pass back to release() in a finally block.
   * @param {{ tierRank:number }} p
   * @returns {Promise<{admitted:true, ticket:string} | {admitted:false, status:429, retryAfter:number}>}
   */
  async admit(p) {
    const tierRank = typeof p.tierRank === 'number' ? p.tierRank : 3;

    // Debug/diagnostic: log queue pressure on every admit() call so we can
    // confirm from real traffic whether this gate is actually the bottleneck
    // (temporary instrumentation - not gated behind a flag, remove once the
    // real bottleneck is confirmed/ruled out).
    console.log(`[GATE_STATS] inFlight=${this.inFlight} waiting=${this.waiters.length} ceiling=${GATE_CEILING} tierRank=${tierRank}`);

    // Fast path: capacity available.
    if (this.inFlight < GATE_CEILING) {
      this.inFlight += 1;
      return { admitted: true, ticket: uuid() };
    }

    // Slow path: wait for a slot, ordered by priority.
    const ticket = uuid();
    const enqueueTime = nowMs();
    console.log(`[GATE_STATS] QUEUED tierRank=${tierRank} inFlight=${this.inFlight} waiting=${this.waiters.length + 1}`);
    return await new Promise((resolve) => {
      const waiter = { tierRank, enqueueTime, ticket, resolve };
      this.waiters.push(waiter);

      const timer = setTimeout(() => {
        // Remove ourselves from the queue and reject with a tier-based retry.
        const idx = this.waiters.indexOf(waiter);
        if (idx !== -1) this.waiters.splice(idx, 1);
        console.log(`[GATE_STATS] TIMEOUT tierRank=${tierRank} waitedMs=${nowMs() - enqueueTime}`);
        resolve({ admitted: false, status: 429, retryAfter: GATE_RETRY_AFTER[tierRank] ?? 15 });
      }, GATE_MAX_WAIT_MS);

      // Stash the resolver so release() can wake us and cancel the timer.
      waiter.resolve = (val) => {
        clearTimeout(timer);
        if (val && val.admitted) {
          console.log(`[GATE_STATS] ADMITTED_FROM_QUEUE tierRank=${tierRank} waitedMs=${nowMs() - enqueueTime}`);
        }
        resolve(val);
      };
    });
  }

  /**
   * Release a previously-admitted slot. Wakes the next highest-priority waiter
   * if any are queued; otherwise decrements the in-flight counter. Idempotent-ish
   * (a stray release just frees a slot - bounded by the ceiling logic).
   */
  async release() {
    const next = this._dequeueBest();
    if (next) {
      // Hand the just-freed slot directly to the next waiter (in-flight count
      // is unchanged - one out, one in).
      next.resolve({ admitted: true, ticket: next.ticket });
      return { ok: true };
    }
    if (this.inFlight > 0) this.inFlight -= 1;
    return { ok: true };
  }

  /** Debug/admin snapshot of current pressure on this shard. */
  async stats() {
    return { inFlight: this.inFlight, waiting: this.waiters.length, ceiling: GATE_CEILING };
  }
}

// ============================================================================
//  SECTION 7 - IpGuardDO   (secondary per-IP anti-abuse limiter)
// ----------------------------------------------------------------------------
//  A second, tier-independent rate limiter keyed by a HASH of the client IP.
//  This catches abuse that the per-user limiter can't - e.g. one bad actor
//  spraying requests across many freshly-created free accounts from a single
//  IP. It is intentionally simple: a sliding-window counter with a short cool-
//  down ban. The per-user UserAccountDO limiter remains the primary control;
//  this is the safety net for unauthenticated / multi-account abuse.
//
//  Limits (spec §6): 15 req/min, burst 75 per 10s, all tiers. Violation → a
//  short 60s cooldown (kept mild - a shared corporate/NAT IP may be many
//  legitimate users).
// ============================================================================

const IP_RPM = 15;
const IP_BURST = 75;
const IP_COOLDOWN_MS = 60_000;

export class IpGuardDO extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.ctx = ctx;
    this.env = env;
    /** @type {number[]} */ this.hits = [];
    this.blockedUntil = 0;
  }

  /**
   * @returns {Promise<{allowed:true} | {allowed:false, retryAfter:number}>}
   */
  async check() {
    const t = nowMs();
    if (this.blockedUntil > t) {
      return { allowed: false, retryAfter: Math.ceil((this.blockedUntil - t) / 1000) };
    }
    this.hits = this.hits.filter((ts) => t - ts < 60_000);
    const inMin = this.hits.length;
    const in10s = this.hits.filter((ts) => t - ts < 10_000).length;
    if (inMin >= IP_RPM || in10s >= IP_BURST) {
      this.blockedUntil = t + IP_COOLDOWN_MS;
      return { allowed: false, retryAfter: Math.ceil(IP_COOLDOWN_MS / 1000) };
    }
    this.hits.push(t);
    return { allowed: true };
  }
}

// ============================================================================
//  SECTION 8 - JWT VERIFICATION  (real server-side identity)
// ----------------------------------------------------------------------------
//  Origin/Referer headers are NOT a security boundary (trivially spoofed). The
//  gateway's real gate is a verified Supabase JWT. We support both signing
//  schemes Supabase uses:
//    • ES256 / RS256 - asymmetric, verified against the project's public JWKS
//      (newer projects; keys fetched from /auth/v1/.well-known/jwks.json).
//    • HS256         - symmetric, verified with SUPABASE_JWT_SECRET (older
//      projects; only used if that secret env var is present).
//  All verification uses WebCrypto (crypto.subtle) - no external libs.
// ============================================================================

/** base64url → Uint8Array. */
function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  const pad = s.length % 4 ? 4 - (s.length % 4) : 0;
  s += '='.repeat(pad);
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/** base64url → UTF-8 string. */
function b64urlToStr(s) {
  return new TextDecoder().decode(b64urlToBytes(s));
}

// Per-isolate JWKS cache (public keys rotate rarely - 1h is safe).
let JWKS_CACHE = { keys: null, exp: 0 };
const JWKS_TTL_MS = 60 * 60 * 1000;

async function getJwks(env) {
  if (JWKS_CACHE.keys && JWKS_CACHE.exp > nowMs()) return JWKS_CACHE.keys;
  const base = (env.SUPABASE_URL || '').replace(/\/+$/, '');
  const url = `${base}/auth/v1/.well-known/jwks.json`;
  const res = await fetch(url, {
    headers: env.SUPABASE_SERVICE_ROLE_KEY ? { apikey: env.SUPABASE_SERVICE_ROLE_KEY } : {},
  });
  if (!res.ok) throw new Error(`jwks fetch ${res.status}`);
  const data = await res.json();
  JWKS_CACHE = { keys: data.keys || [], exp: nowMs() + JWKS_TTL_MS };
  return JWKS_CACHE.keys;
}

/**
 * Verify a Supabase JWT and return its identity claims.
 * @param {string} token
 * @param {any} env
 * @returns {Promise<{userId:string, email:string, payload:any}>}
 */
async function verifyJwt(token, env) {
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('malformed token');
  const [h, p, sig] = parts;
  const header = JSON.parse(b64urlToStr(h));
  const payload = JSON.parse(b64urlToStr(p));

  // Cheap claim checks first.
  if (payload.exp && nowMs() / 1000 > payload.exp) throw new Error('token expired');

  const signingInput = new TextEncoder().encode(`${h}.${p}`);
  const signature = b64urlToBytes(sig);
  const alg = header.alg;

  if (alg === 'HS256') {
    const secret = env.SUPABASE_JWT_SECRET;
    if (!secret) throw new Error('HS256 token but SUPABASE_JWT_SECRET not configured');
    const key = await crypto.subtle.importKey(
      'raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']
    );
    const ok = await crypto.subtle.verify('HMAC', key, signature, signingInput);
    if (!ok) throw new Error('bad signature');
  } else if (alg === 'ES256' || alg === 'RS256') {
    const jwks = await getJwks(env);
    const jwk = jwks.find((k) => k.kid === header.kid) || jwks[0];
    if (!jwk) throw new Error('no matching JWK');
    let key, verifyAlg;
    if (alg === 'ES256') {
      key = await crypto.subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
      verifyAlg = { name: 'ECDSA', hash: 'SHA-256' };
    } else {
      key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
      verifyAlg = { name: 'RSASSA-PKCS1-v1_5' };
    }
    const ok = await crypto.subtle.verify(verifyAlg, key, signature, signingInput);
    if (!ok) throw new Error('bad signature');
  } else {
    throw new Error(`unsupported alg ${alg}`);
  }

  if (!payload.sub) throw new Error('no subject claim');
  return { userId: payload.sub, email: payload.email || '', payload };
}

/**
 * Verify the Authorization header + resolve the caller's tier/block/admin state.
 * @returns {Promise<{ok:true, userId:string, email:string, tier:Tier, isAdmin:boolean,
 *                     freeLifetimeCap:number|null}
 *                   | {ok:false, status:number, error:string, detail?:string,
 *                      reason?:string, bannedAt?:string|null}>}
 */
async function authenticate(request, env) {
  const authz = request.headers.get('Authorization') || '';
  const m = authz.match(/^Bearer\s+(.+)$/i);
  if (!m) return { ok: false, status: 401, error: 'missing_token' };
  try {
    const v = await verifyJwt(m[1], env);
    const row = await getUserRow(env, v.userId);
    if (row.is_banned) {
      return { ok: false, status: 403, error: 'banned', reason: row.ban_reason || '', bannedAt: row.banned_at || null };
    }
    const blocked =
      row.is_blocked && (!row.blocked_until || new Date(row.blocked_until).getTime() > nowMs());
    if (blocked) return { ok: false, status: 403, error: 'account_blocked' };
    const tier = row.tier || 'free';
    // Free-Plan Lifetime Credit Cap (see LIFETIME_FREE_CAP_NEW/_RETURNING
    // above): which of the two applies depends solely on whether this
    // account has EVER subscribed (subscription_started_at is non-null and
    // never gets cleared on cancellation - see getUserRow()). null for paid
    // tiers, where the lifetime cap doesn't apply.
    const freeLifetimeCap = tier === 'free'
      ? (row.subscription_started_at ? LIFETIME_FREE_CAP_RETURNING : LIFETIME_FREE_CAP_NEW)
      : null;
    const nextRechargeAt = nextRechargeAllowedAt(row);
    return { ok: true, userId: v.userId, email: v.email, tier, isAdmin: !!row.is_admin, freeLifetimeCap, nextRechargeAt };
  } catch (err) {
    return { ok: false, status: 401, error: 'invalid_token', detail: String((err && err.message) || err) };
  }
}

// ============================================================================
//  SECTION 9 - PER-ISOLATE CACHES  (keep Postgres off the hot path)
// ----------------------------------------------------------------------------
//  The DO is the source of truth for balances. But two small pieces of state
//  live in Postgres and are read on the request path: the user's TIER and the
//  MODEL PRICING. Both change rarely, so we cache them per-isolate with short
//  TTLs - a cache miss just costs one Supabase read, and staleness is bounded.
//
//  Known limitation (2026-07-26 tier-sync audit): this Map lives in the
//  Worker-fetch-handling isolate's module scope. UserAccountDO instances run
//  in their OWN separate isolate/global scope (a Durable Object re-executes
//  this module's top level independently), so a DO method can never reach
//  into and invalidate THIS Map instance - only code that runs as part of a
//  Worker fetch handler can (see TIER_CACHE.delete() in the
//  /admin/user/{uid}/renew handler). This means a direct/out-of-band tier
//  edit in Supabase (bypassing that endpoint) is invisible to authenticate()
//  for up to TIER_TTL_MS - there's no way to shrink that window from inside
//  the DO. The DO-side fix (_syncTierAndDetectUpgrade() resetting on ANY
//  tier change, not just upgrades) only removes the SECOND half of the
//  staleness bug - once the new tier is observed, window/weekly reset
//  immediately instead of lingering until natural expiry.
// ============================================================================

const TIER_CACHE = new Map(); // userId -> { row, exp }
const TIER_TTL_MS = 60 * 1000;

/** Read (cached) the caller's tier + block/admin flags from the `users` table. */
async function getUserRow(env, userId) {
  const hit = TIER_CACHE.get(userId);
  if (hit && hit.exp > nowMs()) return hit.row;

  let row = {
    tier: 'free', is_blocked: false, blocked_until: null, is_admin: false,
    is_banned: false, ban_reason: null, banned_at: null,
    created_at: null, subscription_started_at: null, last_recharge_at: null,
  };
  try {
    if (env.SUPABASE_URL && env.SUPABASE_SERVICE_ROLE_KEY) {
      const base = env.SUPABASE_URL.replace(/\/+$/, '');
      const url = `${base}/rest/v1/users?id=eq.${encodeURIComponent(userId)}` +
                  `&select=tier,is_blocked,blocked_until,is_admin,is_banned,ban_reason,banned_at,created_at,subscription_started_at,last_recharge_at&limit=1`;
      const res = await fetch(url, {
        headers: {
          apikey: env.SUPABASE_SERVICE_ROLE_KEY,
          Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
        },
      });
      if (res.ok) {
        const arr = await res.json();
        if (Array.isArray(arr) && arr[0]) {
          row = {
            tier: arr[0].tier || 'free',
            is_blocked: !!arr[0].is_blocked,
            blocked_until: arr[0].blocked_until || null,
            is_admin: !!arr[0].is_admin,
            is_banned: !!arr[0].is_banned,
            ban_reason: arr[0].ban_reason || null,
            banned_at: arr[0].banned_at || null,
            created_at: arr[0].created_at || null,
            subscription_started_at: arr[0].subscription_started_at || null,
            last_recharge_at: arr[0].last_recharge_at || null,
          };
        }
      } else {
        const body = await res.text().catch(() => '');
        console.error('[getUserRow] Supabase query failed', res.status, body.slice(0, 300));
      }
    }
  } catch (err) {
    console.error('[getUserRow]', err);
  }
  TIER_CACHE.set(userId, { row, exp: nowMs() + TIER_TTL_MS });
  return row;
}

let PRICING_CACHE = { map: null, exp: 0 };
const PRICING_TTL_MS = 5 * 60 * 1000;

/** Read (cached) model_pricing as { [model]: {inputPer1M, outputPer1M} }. */
async function getPricing(env) {
  if (PRICING_CACHE.map && PRICING_CACHE.exp > nowMs()) return PRICING_CACHE.map;

  /** @type {Record<string, {inputPer1M:number, outputPer1M:number}>} */
  let map = { ...DEFAULT_MODEL_COST };
  try {
    if (env.SUPABASE_URL && env.SUPABASE_SERVICE_ROLE_KEY) {
      const base = env.SUPABASE_URL.replace(/\/+$/, '');
      const url = `${base}/rest/v1/model_pricing?select=model,input_cost_per_1m,output_cost_per_1m`;
      const res = await fetch(url, {
        headers: {
          apikey: env.SUPABASE_SERVICE_ROLE_KEY,
          Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
        },
      });
      if (res.ok) {
        const arr = await res.json();
        if (Array.isArray(arr) && arr.length) {
          /** @type {Record<string, {inputPer1M:number, outputPer1M:number}>} */
          const m = {};
          for (const r of arr) {
            if (r.model) m[r.model] = { inputPer1M: Number(r.input_cost_per_1m), outputPer1M: Number(r.output_cost_per_1m) };
          }
          if (Object.keys(m).length) map = m;
        }
      }
    }
  } catch (err) {
    console.error('[getPricing]', err);
  }
  PRICING_CACHE = { map, exp: nowMs() + PRICING_TTL_MS };
  return map;
}

let APP_CONFIG_CACHE = { plans: null, exp: 0 };
const APP_CONFIG_TTL_MS = 5 * 60 * 1000;

/**
 * Read (cached) admin-editable plan overrides from `public.app_config.plans`,
 * shaped like { [tier]: { creditsPerWindow, windowHours } }. Falls back to `{}`
 * (i.e. every tier uses the hardcoded `PLANS` default via `effectivePlan()`)
 * if the table/row/column is missing, empty, or unreadable - so this can only
 * ever ADD an override on top of the hardcoded plan, never break billing.
 * Scoped read-through: used ONLY by `UserAccountDO._ensureWindow()` to size a
 * newly-opened window's allocation. All other cost math (SERVICE_LIMITS,
 * margins, worstCaseCredits/actualCredits) is untouched by this and remains
 * governed solely by the hardcoded constants above.
 */
async function getAppConfig(env) {
  if (APP_CONFIG_CACHE.plans && APP_CONFIG_CACHE.exp > nowMs()) return APP_CONFIG_CACHE.plans;

  let plans = {};
  try {
    const r = await sbGet(env, 'app_config', 'id=eq.1&select=plans');
    if (r.ok && Array.isArray(r.data) && r.data[0] && r.data[0].plans && typeof r.data[0].plans === 'object') {
      plans = r.data[0].plans;
    }
  } catch (err) {
    console.error('[getAppConfig]', err);
  }
  APP_CONFIG_CACHE = { plans, exp: nowMs() + APP_CONFIG_TTL_MS };
  return plans;
}

/**
 * Merge an admin override (from `getAppConfig()`) on top of a hardcoded
 * `PLANS[tier]` entry. Any override field that's missing or not a positive
 * finite number is ignored (base value wins) - a partially-filled or
 * malformed override can never zero-out or corrupt a plan's allocation.
 */
/**
 * ISO timestamp of when this user may next successfully call
 * `/recharge/:type`, or `null` if they're not on cooldown right now (either
 * never recharged, or RECHARGE_COOLDOWN_DAYS has already elapsed since
 * `last_recharge_at`). Uniform across every recharge type and tier - there is
 * intentionally no tier-upgrade exception (see db/schema_recharge_cooldown.sql).
 * @param {{ last_recharge_at:string|null }} row
 */
function nextRechargeAllowedAt(row) {
  if (!row.last_recharge_at) return null; // never recharged -> no cooldown
  const lastMs = new Date(row.last_recharge_at).getTime();
  if (!Number.isFinite(lastMs)) return null;
  const allowedAtMs = lastMs + RECHARGE_COOLDOWN_DAYS * 24 * 60 * 60 * 1000;
  return allowedAtMs > nowMs() ? isoFrom(allowedAtMs) : null;
}

function effectivePlan(basePlan, override) {
  if (!override) return basePlan;
  const creditsPerWindow = Number(override.creditsPerWindow);
  const windowHours = Number(override.windowHours);
  return {
    ...basePlan,
    creditsPerWindow: Number.isFinite(creditsPerWindow) && creditsPerWindow > 0 ? creditsPerWindow : basePlan.creditsPerWindow,
    windowHours: Number.isFinite(windowHours) && windowHours > 0 ? windowHours : basePlan.windowHours,
  };
}

// ============================================================================
//  SECTION 10 - ROUTING HELPERS
// ============================================================================

// Model swap (2026-07-19): GLM-5.2 / minimax/m3 / llama-3.1-8b-instruct-fp8
// replaced by Kimi K2.7-Code / Nemotron-3-120B-A12B / Llama-4-Scout across
// all 3 chat tiers. Old entries kept in DEFAULT_MODEL_COST below as historical
// reference, same pattern as every prior model swap.
const MODEL = '@cf/moonshotai/kimi-k2.7-code'; // bat 1.2 prime, Workers AI direct (no AI Gateway, no BYOK)
const MODEL_FLASH = '@cf/meta/llama-4-scout-17b-16e-instruct'; // bat 1.2 flash, Workers AI direct (no AI Gateway, no BYOK)
// bat 1.2 core, Workers AI direct (no AI Gateway, no BYOK). Swapped from
// nemotron-3-120b-a12b to gpt-oss-120b (2026-07-21): cheaper ($0.35/$0.75 vs
// $0.50/$1.50), faster per-token (~5B active vs 12B), and it exposes real
// reasoning-effort control (wired to the Low/Medium/High selector). Uses the
// Responses API shape upstream — see the /chat/core route in worker.js.
const MODEL_CORE = '@cf/openai/gpt-oss-120b';
// bat 2.2 (Marketing eco, /chat/marketing-eco), Workers AI direct (no AI Gateway, no BYOK).
const MODEL_MARKETING_ECO = '@cf/google/gemma-4-26b-a4b-it';
const SHARD_COUNT = 6; // ConcurrencyGate shards per service (avoid a single bottleneck)

/** Normalise a client-supplied service string into one of the known services. */
function normalizeService(s) {
  const v = String(s || '').toLowerCase();
  if (v === 'website' || v === 'web' || v === 'site') return 'website';
  if (v === 'game') return 'game';
  if (v === 'tool') return 'tool';
  if (v === 'mobile' || v === 'app') return 'mobile';
  if (v === 'chat_flash' || v === 'chatflash') return 'chat_flash';
  if (v === 'chat_core' || v === 'chatcore') return 'chat_core';
  if (v === 'chat_marketing_eco' || v === 'chatmarketingeco') return 'chat_marketing_eco';
  if (v === 'chat') return 'chat';
  if (v === 'status_hint' || v === 'statushint') return 'status_hint';
  if (v === 'chat_title' || v === 'chattitle') return 'chat_title';
  if (v === 'chat_reason' || v === 'chatreason') return 'chat_reason';
  if (v === 'chat_export' || v === 'chatexport') return 'chat_export';
  if (v === 'marketing_extract' || v === 'marketingextract') return 'marketing_extract';
  if (v === 'build_steps' || v === 'buildsteps') return 'build_steps';
  return 'game'; // game/tool/mobile share one upstream + margin band; safe default
}

/**
 * Map a service to its upstream generation Worker's Service Binding + route.
 * game/tool/mobile all share batlab-x-api; website uses websitegenerator;
 * chat uses worker.js. Service Bindings (not raw fetch() to the public
 * *.workers.dev URL) are required here - gateway and the 3 generation
 * Workers share one zone, and Cloudflare blocks same-zone Worker-to-Worker
 * fetch() as a loop-prevention measure (error 1042). The binding's .fetch()
 * routes directly, off the public network, so this is unaffected.
 */
function upstreamFor(env, service) {
  switch (service) {
    case 'chat':                return { fetcher: env.CHAT_WORKER, path: '/chat' };
    case 'chat_flash':          return { fetcher: env.CHAT_WORKER, path: '/chat/flash' };
    case 'chat_core':           return { fetcher: env.CHAT_WORKER, path: '/chat/core' };
    case 'chat_marketing_eco':  return { fetcher: env.CHAT_WORKER, path: '/chat/marketing-eco' };
    case 'status_hint':         return { fetcher: env.CHAT_WORKER, path: '/status-hint' };
    case 'chat_title':          return { fetcher: env.CHAT_WORKER, path: '/chat/title' };
    case 'chat_reason':         return { fetcher: env.CHAT_WORKER, path: '/chat/reason' };
    case 'chat_export':         return { fetcher: env.CHAT_WORKER, path: '/chat/export' };
    case 'marketing_extract':   return { fetcher: env.CHAT_WORKER, path: '/marketing/extract' };
    case 'build_steps':         return { fetcher: env.CHAT_WORKER, path: '/build-steps' };
    case 'website':             return { fetcher: env.WEBSITE_WORKER, path: '/' };
    case 'game':
    case 'tool':
    case 'mobile':
    default:           return { fetcher: env.GAME_WORKER, path: '/generate' };
  }
}

/** Pick a ConcurrencyGate shard id for a service (round-robin by random shard). */
function gateName(service) {
  return `${service}:${Math.floor(Math.random() * SHARD_COUNT)}`;
}

/** SHA-256 the client IP → first 32 hex chars (never store/route on the raw IP). */
async function hashIp(ip) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(ip));
  const bytes = new Uint8Array(digest);
  let hex = '';
  for (let i = 0; i < 16; i++) hex += bytes[i].toString(16).padStart(2, '0');
  return hex;
}

// ============================================================================
//  SECTION 11 - RECHARGE-NOW PRICING  (spec §4; ≈2× blended $/credit)
// ----------------------------------------------------------------------------
//  Instant, no-commitment top-ups, collapsed to 2 options:
//    - full_refill:   top the current window back up to full (per-tier price,
//                      since window sizes/costs differ by tier)
//    - custom_amount: user-chosen credit amount, priced flat per credit,
//                      independent of tier
//  Priced above worst-case API cost and high enough not to cannibalise tier
//  upgrades, but cheaper than the frustration of waiting out the window.
// ============================================================================

const RECHARGE_FULL_REFILL_USD = { free: 1.49, starter: 2.49, pro: 3.49, max: 12.99 };

const CUSTOM_AMOUNT_USD_PER_CREDIT = 0.003;
const CUSTOM_AMOUNT_MIN_CREDITS = 100;
const CUSTOM_AMOUNT_MAX_CREDITS = 2000;
const CUSTOM_AMOUNT_STEP_CREDITS = 50;

// Uniform cooldown between successful "Recharge Now" purchases, across ALL
// recharge types and ALL tiers, anchored to `users.last_recharge_at`
// (db/schema_recharge_cooldown.sql). No exception for tier upgrades - see
// nextRechargeAllowedAt() below.
const RECHARGE_COOLDOWN_DAYS = 5;

// ============================================================================
//  SECTION 12 - GENERATION PIPELINE  (reserve → admit → proxy → settle)
// ----------------------------------------------------------------------------
//  This is the 5-step hot path from plan §11. Credits are RESERVED at worst-case
//  before the upstream call, the request is ADMITTED through the tier-priority
//  gate, PROXIED to the real Worker with the shared internal key, and finally
//  SETTLED at the real token cost via ctx.waitUntil (never blocking the client).
//  Output tokens are metered by tee-ing the upstream body so streaming responses
//  (websitegenerator) still stream straight through untouched.
// ============================================================================

async function handleGenerate(request, env, ctx, origin, service, payload, auth, perf, pricingPromise) {
  // Server-side defense-in-depth: the frontend already caps attachments at
  // MAX_IMAGES_PER_MESSAGE before ever sending the request, but this must
  // also be rejected here in case that client-side check is bypassed.
  if (Array.isArray(payload && payload.images) && payload.images.length > MAX_IMAGES_PER_MESSAGE) {
    if (perf) perf.finish({ note: 'too_many_images' });
    return json({ error: 'too_many_images' }, 400, origin);
  }

  // Server-side defense-in-depth: the frontend already caps each attached
  // image at ATTACH_MAX_IMAGE (500KB) and the combined attachment payload at
  // ATTACH_MAX_TOTAL (~1.2MB) before ever sending the request, but a direct
  // API call bypasses that (2026-07-26 audit - same frontend-only-check
  // pattern as the tier-sync bug fixed earlier). Images arrive as base64
  // data-URL strings; byte size is estimated from the encoded string length
  // once any "data:...;base64," prefix is stripped off.
  if (Array.isArray(payload && payload.images) && payload.images.length) {
    let attachTotalBytes = 0;
    for (const img of payload.images) {
      if (typeof img !== 'string') continue;
      const commaIdx = img.indexOf(',');
      const b64 = commaIdx >= 0 ? img.slice(commaIdx + 1) : img;
      const bytes = Math.floor(b64.length * 0.75);
      if (bytes > ATTACH_MAX_IMAGE_BYTES) {
        if (perf) perf.finish({ note: 'image_too_large' });
        return json({ error: 'image_too_large', limit: ATTACH_MAX_IMAGE_BYTES }, 413, origin);
      }
      attachTotalBytes += bytes;
    }
    if (attachTotalBytes > ATTACH_MAX_TOTAL_BYTES) {
      if (perf) perf.finish({ note: 'attachments_too_large' });
      return json({ error: 'attachments_too_large', limit: ATTACH_MAX_TOTAL_BYTES }, 413, origin);
    }
  }

  // Server-side defense-in-depth: the frontend already blocks an oversized
  // baseHTML edit before sending, and websitegenerator.js/batlab-x-api.js
  // re-check it too; this third check protects the credit-reservation step
  // itself from ever running for a request that's going to be rejected
  // downstream anyway. Scoped to the four HTML-generating services.
  const isHtmlGenService = service === 'website' || service === 'game' || service === 'tool' || service === 'mobile';
  if (isHtmlGenService && typeof payload?.baseHTML === 'string' && payload.baseHTML.length > BASE_HTML_CHAR_CAP) {
    if (perf) perf.finish({ note: 'base_html_too_large' });
    return json({ error: 'base_html_too_large', limit: BASE_HTML_CHAR_CAP }, 413, origin);
  }

  // Server-side defense-in-depth (2026-07-26 audit, part 2): /generate's
  // `.prompt` field is where BOTH text-file AND image attachments actually
  // end up (buildAttachContext() merges them directly into this string
  // client-side) - unlike /chat*, there's no separate `images` field here
  // to check per-attachment, so this is a flat cap on the whole string. See
  // GENERATE_PROMPT_CHAR_CAP's own comment for why a flat cap was chosen
  // over parsing out individual embedded attachments.
  if (typeof payload?.prompt === 'string' && payload.prompt.length > GENERATE_PROMPT_CHAR_CAP) {
    if (perf) perf.finish({ note: 'prompt_too_large' });
    return json({ error: 'prompt_too_large', limit: GENERATE_PROMPT_CHAR_CAP }, 413, origin);
  }

  const pricing = pricingPromise ? await pricingPromise : await getPricing(env);
  if (perf) perf.mark('post-getPricing');
  const tier = auth.tier;

  const userStub = env.USER_ACCOUNT.getByName(auth.userId);
  const model = service === 'chat_flash' ? MODEL_FLASH
    : service === 'chat_core' ? MODEL_CORE
    : service === 'chat_marketing_eco' ? MODEL_MARKETING_ECO
    : MODEL;

  // 1) Reserve worst-case credits atomically in the per-user DO.
  // Background helper calls (memory extraction / chat-title generation) are
  // flagged by the frontend with `background: true` in the request body.
  // They still get billed for their real token usage like any other
  // generation - this flag ONLY steers them onto the separate BG_LANE_LIMIT
  // rate-limit lane (see UserAccountDO) so they can't trip a ban on the
  // user's own real, visible chat usage. It is not a credit/billing bypass.
  const background = payload && payload.background === true;
  const reservation = await userStub.reserve({ userId: auth.userId, tier, service, model, pricing, background, freeLifetimeCap: auth.freeLifetimeCap });
  if (perf) perf.mark('post-reserve');
  if (reservation.sideEffects && reservation.sideEffects.length) {
    ctx.waitUntil(flushToSupabase(env, reservation.sideEffects));
  }
  if (!reservation.ok) {
    const extra = reservation.retryAfter ? { 'Retry-After': String(reservation.retryAfter) } : {};
    if (perf) perf.finish({ note: `reservation_failed: ${reservation.error}` });
    return json({
      error: reservation.error,               // 'insufficient_credits' | 'rate_limited' | 'banned'
      windowEndsAt: reservation.windowEndsAt,  // ISO - client renders the countdown
      balance: reservation.balance,
      retryAfter: reservation.retryAfter,
      upgradeUrl: '/upgrade.html',
    }, reservation.status, origin, extra);
  }

  // 2) Admission control (Max > Pro > Starter > Free under load).
  const gateStub = env.CONC_GATE.getByName(gateName(service));
  const admit = await gateStub.admit({ tierRank: planFor(tier).tierRank });
  if (perf) perf.mark('post-admit');
  if (!admit.admitted) {
    // Couldn't get a slot in time → release the hold (no charge) and 429.
    ctx.waitUntil((async () => {
      const s = await userStub.settle({ reservationId: reservation.reservationId, outcome: 'failed' });
      if (s.sideEffects && s.sideEffects.length) await flushToSupabase(env, s.sideEffects);
    })());
    if (perf) perf.finish({ note: 'admission_denied: server_busy' });
    return json({ error: 'server_busy', retryAfter: admit.retryAfter }, admit.status || 429, origin,
      { 'Retry-After': String(admit.retryAfter) });
  }

  // Helper: settle the reservation + free the gate slot exactly once.
  // `analyzedImageCount` (chat routes only) signals settle() to add the flat
  // Moondream image-preprocessing surcharge, multiplied by that count, on
  // top of the tier charge.
  const settleAndRelease = async (inTok, outTok, outcome, analyzedImageCount = 0) => {
    try {
      const s = await userStub.settle({
        reservationId: reservation.reservationId, outcome,
        inputTokens: inTok, outputTokens: outTok, pricing, analyzedImageCount,
      });
      if (s.sideEffects && s.sideEffects.length) await flushToSupabase(env, s.sideEffects);
    } finally {
      await gateStub.release();
    }
  };

  // 3) Proxy to the real generation Worker with the shared internal key, via
  //    its Service Binding (see upstreamFor's comment for why not raw fetch()).
  try {
    const { fetcher, path } = upstreamFor(env, service);
    const upstream = await fetcher.fetch(`https://internal${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Internal-Key': env.INTERNAL_KEY || '',
        // Forward the real browser origin so the upstream's Origin gate passes.
        'Origin': origin && origin !== '*' ? origin : 'https://batnxt.com',
        // Chat + Chat Flash only: stable per-user id so Workers AI can route
        // repeat calls to the same model instance and maximize prefix-cache
        // hit rate. See
        // https://developers.cloudflare.com/workers-ai/features/prompt-caching/
        ...((service === 'chat' || service === 'chat_flash') && auth.userId ? { 'X-Session-Affinity': auth.userId } : {}),
      },
      body: JSON.stringify(payload),
    });
    if (perf) perf.mark('post-Service-Binding-fetch');

    if (!upstream.ok) {
      const detail = (await upstream.text()).slice(0, 500);
      ctx.waitUntil(settleAndRelease(0, 0, 'failed')); // nothing produced → no charge
      if (perf) perf.finish({ note: `upstream_error: status=${upstream.status}` });
      return json({ error: 'upstream_error', status: upstream.status, detail }, 502, origin);
    }

    // Prefer exact token counts from upstream headers (added in todo #6); else
    // estimate: input from the prompt chars, output from streamed byte count.
    const inTokHeader = Number(upstream.headers.get('X-Input-Tokens')) || 0;
    const outTokHeader = Number(upstream.headers.get('X-Output-Tokens')) || 0;
    const inTok = inTokHeader || Math.ceil(JSON.stringify(payload).length / 4);
    // Chat routes only: which attached images did worker.js actually run
    // through Moondream? Comma-separated per-image bitmap, same order as
    // payload.images (e.g. "1,1,0"). Drives the per-image
    // MOONDREAM_FLAT_SURCHARGE_CREDITS surcharge in settle() and which
    // images get persisted to the Library below.
    const imagesAnalyzedHeader = upstream.headers.get('X-Images-Analyzed') || '';
    const imagesAnalyzed = imagesAnalyzedHeader ? imagesAnalyzedHeader.split(',').map(v => v === '1') : [];
    const analyzedImageCount = imagesAnalyzed.filter(Boolean).length;
    // Settings > Library: fire-and-forget persistence of the analyzed
    // images only, never awaited so it can't add latency or affect the
    // chat response.
    if (analyzedImageCount > 0 && payload && Array.isArray(payload.images)) {
      const analyzedImages = payload.images.filter((_, i) => imagesAnalyzed[i]);
      // Parallel array of original filenames (same order as payload.images),
      // filtered by the same analyzed bitmap so names stay index-aligned with
      // the images actually persisted. Absent/older clients send none → NULL.
      const analyzedNames = Array.isArray(payload.imageNames)
        ? payload.imageNames.filter((_, i) => imagesAnalyzed[i])
        : [];
      ctx.waitUntil(persistLibraryImages(env, auth.userId, auth.tier, analyzedImages, analyzedNames));
    }

    const respHeaders = {
      'Content-Type': upstream.headers.get('Content-Type') || 'application/json',
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Headers': CORS_ALLOW_HEADERS,
      'Vary': 'Origin',
      'X-Window-Ends-At': reservation.windowEndsAt || '',
      // Best-effort, non-final estimate = the worst-case hold reserve() placed
      // for this request. Lets the client optimistically decrement its local
      // credit display immediately, without waiting a full round trip for
      // settle() (which only runs later, inside ctx.waitUntil() below, once
      // the true output-token count is known). The client's next
      // refreshAccountState() call reconciles this with the real, settled
      // balance - so this header can only ever be a few ms stale, never wrong.
      'X-Credits-Charged': String(reservation.reservedCredits || 0),
    };
    if (reservation.warning) respHeaders['X-Credit-Warning'] = reservation.warning; // soft_80 | soft_90

    if (upstream.body) {
      // tee: one branch streams to the client, the other counts output bytes
      // (and, for HTML-generating services, validates the accumulated text).
      const [toClient, toMeter] = upstream.body.tee();
      const validateOutput = isHtmlGenService;
      ctx.waitUntil((async () => {
        let bytes = 0;
        let text = '';
        let decoder = validateOutput ? new TextDecoder() : null;
        try {
          const reader = toMeter.getReader();
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            if (value) {
              bytes += value.byteLength;
              if (validateOutput) text += decoder.decode(value, { stream: true });
            }
          }
        } catch (_) { /* metering must never break billing */ }
        const outTok = outTokHeader || Math.ceil(bytes / 4);
        // website streams raw HTML as plain text, so `text` IS the HTML.
        // game/tool/mobile return a non-streamed `{ html }` JSON envelope,
        // so the JSON must be parsed and the html field extracted before
        // running the same structural/language check on it.
        let htmlForValidation = text;
        if (validateOutput && service !== 'website') {
          try {
            const parsed = JSON.parse(text);
            htmlForValidation = (parsed && typeof parsed.html === 'string') ? parsed.html : '';
          } catch (_) {
            htmlForValidation = '';
          }
        }
        // A validation-failed generation delivered no usable output, so it's
        // billed exactly like an upstream error (outcome:'failed' → 0
        // credits charged) — this is a system-side generation bug, not user
        // error, and the frontend's own retry is already bounded to one
        // extra attempt.
        const outcome = (validateOutput && !isValidWebsiteOutput(htmlForValidation).valid) ? 'failed' : 'success';
        await settleAndRelease(inTok, outTok, outcome, analyzedImageCount);
      })());
      if (perf) {
        const promptChars = JSON.stringify(payload).length;
        perf.finish({ promptChars, promptTokens: perf.estimateTokens(JSON.stringify(payload)) });
      }
      return new Response(toClient, { status: 200, headers: respHeaders });
    }

    // No body (unexpected) - settle at header/estimate and return empty.
    ctx.waitUntil(settleAndRelease(inTok, outTokHeader, 'success', analyzedImageCount));
    if (perf) perf.finish({ note: 'no_upstream_body' });
    return new Response(null, { status: 200, headers: respHeaders });
  } catch (err) {
    ctx.waitUntil(settleAndRelease(0, 0, 'failed'));
    if (perf) perf.finish({ note: `Error: ${(err && err.message) || err}` });
    return json({ error: 'gateway_exception', detail: String((err && err.message) || err) }, 502, origin);
  }
}

// ============================================================================
//  SECTION 13 - RECHARGE-NOW  (instant top-up; NO payment gateway yet)
// ----------------------------------------------------------------------------
//  Scoping decision (a): no gateway is wired. We grant credits immediately and
//  record a completed purchase so the feature is demonstrable end-to-end. The
//  PAYMENT GATEWAY BOUNDARY comment below marks the exact spot to gate this
//  behind a real webhook (Stripe/Paddle/etc.) later.
// ============================================================================

async function handleRecharge(request, env, ctx, origin, type, auth) {
  const valid = ['full_refill', 'custom_amount'];
  if (!valid.includes(type)) return json({ error: 'unknown_recharge_type' }, 400, origin);

  // Uniform 5-day cooldown across all recharge types/tiers, no tier-upgrade
  // exception - see nextRechargeAllowedAt()/db/schema_recharge_cooldown.sql.
  if (auth.nextRechargeAt) {
    return json({
      error: 'recharge_on_cooldown',
      nextRechargeAt: auth.nextRechargeAt,
      cooldownDays: RECHARGE_COOLDOWN_DAYS,
    }, 429, origin);
  }

  const tier = auth.tier;
  const purchaseId = uuid();
  const userStub = env.USER_ACCOUNT.getByName(auth.userId);

  let creditsToGrant = null; // null → 'refill' mode (top window back up to full)
  let amountUsd;

  if (type === 'full_refill') {
    amountUsd = RECHARGE_FULL_REFILL_USD[tier] ?? RECHARGE_FULL_REFILL_USD.free;
  } else {
    // custom_amount: user picks a credit amount, validated server-side
    // regardless of whatever the client displayed.
    let body = {};
    try { body = await request.json(); } catch (_) { /* validated below */ }
    const credits = Number(body.credits);
    if (
      !Number.isFinite(credits) ||
      credits < CUSTOM_AMOUNT_MIN_CREDITS ||
      credits > CUSTOM_AMOUNT_MAX_CREDITS ||
      credits % CUSTOM_AMOUNT_STEP_CREDITS !== 0
    ) {
      return json({
        error: 'invalid_credits_amount',
        minCredits: CUSTOM_AMOUNT_MIN_CREDITS,
        maxCredits: CUSTOM_AMOUNT_MAX_CREDITS,
        step: CUSTOM_AMOUNT_STEP_CREDITS,
      }, 400, origin);
    }
    creditsToGrant = credits;
    amountUsd = Math.round(credits * CUSTOM_AMOUNT_USD_PER_CREDIT * 100) / 100;
  }

  // ── PAYMENT GATEWAY BOUNDARY ────────────────────────────────────────────────
  // TO GATE BEHIND REAL PAYMENT LATER: insert the recharge_purchases row as
  // status:'pending_payment', return `paymentIntentStub`, and move the grant()
  // below into the webhook that flips the row to status:'completed'.
  let grantRes;
  if (type === 'full_refill') {
    grantRes = await userStub.grant({ userId: auth.userId, tier, mode: 'refill', txType: 'recharge_purchase', reference: purchaseId });
  } else {
    grantRes = await userStub.grant({ userId: auth.userId, tier, credits: creditsToGrant, mode: 'add', txType: 'recharge_purchase', reference: purchaseId });
  }

  const effects = grantRes.sideEffects || [];
  effects.push({
    table: 'recharge_purchases',
    rows: [{
      id: purchaseId,
      user_id: auth.userId,
      type,
      amount_usd: amountUsd,
      credits_granted: type === 'full_refill' ? null : creditsToGrant,
      status: 'completed', // ← change to 'pending_payment' once a gateway is added
      created_at: isoFrom(nowMs()),
    }],
  });
  ctx.waitUntil(flushToSupabase(env, effects));

  // Start the cooldown: persist last_recharge_at and invalidate the cached
  // users row so the very next authenticate()/getUserRow() call sees it.
  const rechargedAtIso = isoFrom(nowMs());
  await sbPatch(env, 'users', `id=eq.${auth.userId}`, { last_recharge_at: rechargedAtIso });
  TIER_CACHE.delete(auth.userId);

  return json({
    ok: true,
    purchaseId,
    type,
    amountUsd,
    creditsGranted: type === 'full_refill' ? 'refill' : creditsToGrant,
    balanceAfter: grantRes.balanceAfter,
    windowEndsAt: grantRes.windowEndsAt,
    nextRechargeAt: nextRechargeAllowedAt({ last_recharge_at: rechargedAtIso }),
    paymentIntentStub: { status: 'no_gateway_configured', purchaseId },
  }, 200, origin);
}

/**
 * Paid "Weekly Reset" purchase - immediately zeroes the caller's Weekly
 * Usage Cap counter (see WEEKLY_CAP_CREDITS / UserAccountDO.resetWeekly()).
 * Mirrors handleRecharge()'s stub-payment structure exactly, but is a fully
 * separate system: no purchase cooldown (unlike Recharge Now's
 * RECHARGE_COOLDOWN_DAYS), and it never touches the per-window
 * balance/allocation - only the independent weekly counter. Free tier has no
 * weekly cap (WEEKLY_RESET_USD has no `free` entry) so there's nothing to
 * sell it a reset for.
 */
async function handleWeeklyReset(request, env, ctx, origin, auth) {
  const tier = auth.tier;
  const amountUsd = WEEKLY_RESET_USD[tier];
  if (amountUsd == null) {
    return json({ error: 'weekly_reset_not_available', reason: 'tier_has_no_weekly_cap' }, 400, origin);
  }

  const purchaseId = uuid();
  const userStub = env.USER_ACCOUNT.getByName(auth.userId);

  // ── PAYMENT GATEWAY BOUNDARY ────────────────────────────────────────────────
  // TO GATE BEHIND REAL PAYMENT LATER: hold off calling resetWeekly() below
  // until a webhook confirms payment; return `paymentIntentStub` in the
  // meantime, same boundary pattern as handleRecharge() above.
  const resetRes = await userStub.resetWeekly({ userId: auth.userId, tier, reference: purchaseId });

  ctx.waitUntil(flushToSupabase(env, resetRes.sideEffects || []));

  // Postgres mirror only (admin dashboard / audit visibility) - the DO's own
  // storage remains the source of truth and is never read back to drive
  // billing decisions. See db/schema_weekly_usage_cap.sql design notes.
  await sbPatch(env, 'users', `id=eq.${auth.userId}`, {
    weekly_usage_credits: resetRes.weeklyUsage,
    weekly_period_start: resetRes.weeklyPeriodStart,
  });

  return json({
    ok: true,
    purchaseId,
    amountUsd,
    weeklyUsage: resetRes.weeklyUsage,
    weeklyCap: WEEKLY_CAP_CREDITS[tier],
    paymentIntentStub: { status: 'no_gateway_configured', purchaseId },
  }, 200, origin);
}

// ============================================================================
//  SECTION 14 - ADMIN API
// ----------------------------------------------------------------------------
//  Identity + is_admin are already verified by authenticate() before this runs,
//  so the service-role key is only ever reached for a confirmed admin. Covers
//  analytics (overview / cost-trend / usage-by-model / recharge-stats), user
//  management (list / detail / add-credits / reset-window / renew / block /
//  unblock / delete), conversation + share management (sessions / shares list
//  + delete + revoke), and cost alerts (list / resolve). Backs admin.html.
// ============================================================================

// ── Supabase REST helpers (service-role; Worker-only) ───────────────────────
//  All admin reads/writes go through the service-role key, which bypasses RLS.
//  This key is NEVER sent to the browser. Each helper returns a uniform
//  { ok, status, data } shape so the router can branch without try/catch noise.

/** @returns {{apikey:string, Authorization:string}} */
function sbAuthHeaders(env) {
  return {
    apikey: env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
  };
}

/**
 * Low-level Supabase REST call. `pathAndQuery` is everything after /rest/v1/.
 * @returns {Promise<{ok:boolean, status:number, data:any}>}
 */
async function sbFetch(env, pathAndQuery, init = {}) {
  if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
    return { ok: false, status: 500, data: { error: 'supabase_not_configured' } };
  }
  const base = env.SUPABASE_URL.replace(/\/+$/, '');
  const res = await fetch(`${base}/rest/v1/${pathAndQuery}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...sbAuthHeaders(env),
      ...(init.headers || {}),
    },
  });
  let data = null;
  const text = await res.text();
  if (text) { try { data = JSON.parse(text); } catch (_) { data = text; } }
  return { ok: res.ok, status: res.status, data };
}

/** GET rows from a table (query is a PostgREST query string, sans leading ?). */
function sbGet(env, table, query) {
  return sbFetch(env, `${table}?${query}`, { method: 'GET' });
}

/**
 * Maintenance query for the grant() window-invalidation bug: finds accounts
 * whose active usage_windows row shows credits_used = 0 (full balance) with
 * window_end still in the future, where that fill came from a full-refill
 * recharge (credit_transactions.type='recharge_purchase' AND amount=0) -
 * i.e. accounts currently exhibiting the "full credits + running countdown"
 * anomaly the grant() fix prevents going forward. Uses PostgREST's !inner
 * embed (same pattern as the /admin/users listing) so only usage_windows
 * rows with a matching recharge_purchase transaction are returned.
 */
async function findStaleRefillWindows(env, limit = 200) {
  const nowIso = encodeURIComponent(isoFrom(nowMs()));
  const query =
    `select=id,user_id,window_start,window_end,credits_allocated,credits_used,status,` +
    `credit_transactions!inner(id,type,amount,created_at)` +
    `&status=eq.active` +
    `&credits_used=eq.0` +
    `&window_end=gt.${nowIso}` +
    `&credit_transactions.type=eq.recharge_purchase` +
    `&credit_transactions.amount=eq.0` +
    `&order=window_end.asc` +
    `&limit=${limit}`;
  const r = await sbGet(env, 'usage_windows', query);
  if (!r.ok) return { ok: false, error: r.data };
  const seen = new Set();
  const rows = [];
  for (const row of (r.data || [])) {
    if (seen.has(row.id)) continue; // !inner can duplicate a window row per matching transaction
    seen.add(row.id);
    rows.push({
      windowId: row.id,
      userId: row.user_id,
      windowStart: row.window_start,
      windowEnd: row.window_end,
      creditsAllocated: row.credits_allocated,
      creditsUsed: row.credits_used,
    });
  }
  return { ok: true, rows };
}

/** Call a Postgres RPC function (POST /rpc/:fn). */
function sbRpc(env, fn, args = {}) {
  return sbFetch(env, `rpc/${fn}`, { method: 'POST', body: JSON.stringify(args) });
}

/** PATCH rows matching `query`; returns the updated representation. */
function sbPatch(env, table, query, body) {
  return sbFetch(env, `${table}?${query}`, {
    method: 'PATCH',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(body),
  });
}

/** INSERT rows; returns the inserted representation. */
function sbInsert(env, table, rows) {
  return sbFetch(env, table, {
    method: 'POST',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(rows),
  });
}

// ── Settings > Library — persist analyzed chat/build image attachments ───────
// See db/schema_library_images.sql + worker/wrangler.jsonc (LIBRARY_IMAGES R2
// binding). Write path is wired into handleGenerate(); read path is the
// GET /library/image/:id route below.

/** Mirrors the frontend's ATTACH_MAX_IMAGE safety net (js/x9k2-legacy-shim-t8vn.js). */
const LIBRARY_MAX_IMAGE_BYTES = 500 * 1024;

/** Total Library storage allowed per user, tiered same as PLAN_MAX/WEEKLY_CAP_CREDITS elsewhere. */
const GB = 1024 * 1024 * 1024;
const LIBRARY_STORAGE_QUOTA_BY_TIER = { free: 1 * GB, starter: 5 * GB, pro: 20 * GB, max: 50 * GB };

const LIBRARY_EXT_BY_MIME = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'video/mp4': 'mp4',
  'video/webm': 'webm',
  'video/quicktime': 'mov',
};

/**
 * Parse a `data:<mime>;base64,<data>` string into raw bytes.
 * Returns null if the input isn't a well-formed base64 data URL.
 */
function dataUrlToBytes(dataUrl) {
  if (typeof dataUrl !== 'string') return null;
  const m = /^data:([^;,]+)(?:;charset=[^;,]+)?;base64,(.+)$/s.exec(dataUrl);
  if (!m) return null;
  const contentType = m[1].toLowerCase();
  try {
    const binary = atob(m[2]);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const ext = LIBRARY_EXT_BY_MIME[contentType] || 'bin';
    return { bytes, contentType, ext };
  } catch (_) {
    return null;
  }
}

/**
 * Fire-and-forget: store an analyzed image attachment in R2 + record its
 * metadata in Postgres. Must never throw into the caller — any failure is
 * logged and swallowed so it can't affect the chat response or billing.
 * `tier` drives the per-plan storage quota (LIBRARY_STORAGE_QUOTA_BY_TIER) —
 * over quota means the new image is silently skipped, same as an oversized
 * image. The client learns about "over quota" out-of-band via the /me
 * endpoint's `storage` field (see handleGenerate()'s ctx.waitUntil() call
 * site — this runs fire-and-forget with no response threaded back).
 */
async function persistLibraryImage(env, userId, tier, imageDataUrl, fileName) {
  try {
    if (!env.LIBRARY_IMAGES || !userId || !imageDataUrl) return;
    const parsed = dataUrlToBytes(imageDataUrl);
    if (!parsed) return;
    const { bytes, contentType, ext } = parsed;
    if (bytes.byteLength > LIBRARY_MAX_IMAGE_BYTES) return;

    const quota = LIBRARY_STORAGE_QUOTA_BY_TIER[tier] ?? LIBRARY_STORAGE_QUOTA_BY_TIER.free;
    const usedR = await sbRpc(env, 'user_library_storage_bytes', { p_uid: userId });
    const used = usedR.ok ? Number(usedR.data) || 0 : 0;
    if (used + bytes.byteLength > quota) return;

    const key = `${userId}/${crypto.randomUUID()}.${ext}`;
    await env.LIBRARY_IMAGES.put(key, bytes, { httpMetadata: { contentType } });

    // Original filename (forward-only): trim, strip control chars, clamp so a
    // hostile/oversized name can't bloat the row. NULL when absent — the client
    // synthesizes a display name for those older rows.
    const cleanName = (typeof fileName === 'string' && fileName.trim())
      ? fileName.trim().replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 120)
      : null;

    const ins = await sbInsert(env, 'library_images', [{
      user_id: userId,
      r2_key: key,
      content_type: contentType,
      size_bytes: bytes.byteLength,
      file_name: cleanName,
    }]);
    if (!ins.ok) {
      console.log('[library] sbInsert failed:', ins.status, JSON.stringify(ins.data));
    }
  } catch (e) {
    console.log('[library] persistLibraryImage error:', e && e.message);
  }
}

/**
 * Fire-and-forget: persist multiple analyzed image attachments (multi-image
 * chat messages), one at a time via persistLibraryImage() above. Sequential
 * (not Promise.all) is deliberate: each call re-checks the user's live storage
 * usage via user_library_storage_bytes(), so running them in parallel would
 * let several images race past the same quota snapshot instead of correctly
 * stopping once the quota fills partway through the batch.
 */
async function persistLibraryImages(env, userId, tier, imageDataUrls, fileNames) {
  if (!Array.isArray(imageDataUrls)) return;
  const names = Array.isArray(fileNames) ? fileNames : [];
  for (let i = 0; i < imageDataUrls.length; i++) {
    await persistLibraryImage(env, userId, tier, imageDataUrls[i], names[i]);
  }
}

/**
 * POST /library/upload — direct user-initiated upload (drag & drop / click to
 * upload in the Library page). Unlike persistLibraryImage() (fire-and-forget,
 * called from handleGenerate()), this responds synchronously so the frontend
 * can show real success/error feedback (including the storage-full toast).
 * Reuses the exact same size cap, quota check, R2 key scheme, and Postgres
 * insert as persistLibraryImage() for consistency. Never returns `r2_key` to
 * the client, matching the convention documented in db/schema_library_images.sql.
 */
async function handleLibraryUpload(request, env, origin, auth) {
  if (!env.LIBRARY_IMAGES) return json({ error: 'library_not_configured' }, 500, origin);

  let form;
  try {
    form = await request.formData();
  } catch (_) {
    return json({ error: 'invalid_form_data' }, 400, origin);
  }

  const file = form.get('file');
  if (!file || typeof file.arrayBuffer !== 'function') {
    return json({ error: 'missing_file' }, 400, origin);
  }

  const contentType = (file.type || '').toLowerCase();
  const ext = LIBRARY_EXT_BY_MIME[contentType];
  if (!ext || !(contentType.startsWith('image/') || contentType.startsWith('video/'))) {
    return json({ error: 'unsupported_type' }, 400, origin);
  }

  if (file.size > LIBRARY_MAX_IMAGE_BYTES) {
    return json({ error: 'file_too_large', maxBytes: LIBRARY_MAX_IMAGE_BYTES }, 413, origin);
  }

  const quota = LIBRARY_STORAGE_QUOTA_BY_TIER[auth.tier] ?? LIBRARY_STORAGE_QUOTA_BY_TIER.free;
  const usedR = await sbRpc(env, 'user_library_storage_bytes', { p_uid: auth.userId });
  const used = usedR.ok ? Number(usedR.data) || 0 : 0;
  if (used + file.size > quota) {
    return json({ error: 'quota_exceeded', usedBytes: used, quotaBytes: quota }, 413, origin);
  }

  const bytes = new Uint8Array(await file.arrayBuffer());
  const key = `${auth.userId}/${crypto.randomUUID()}.${ext}`;
  await env.LIBRARY_IMAGES.put(key, bytes, { httpMetadata: { contentType } });

  const cleanName = (typeof file.name === 'string' && file.name.trim())
    ? file.name.trim().replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 120)
    : null;

  const ins = await sbInsert(env, 'library_images', [{
    user_id: auth.userId,
    r2_key: key,
    content_type: contentType,
    size_bytes: bytes.byteLength,
    file_name: cleanName,
  }]);
  if (!ins.ok) {
    console.log('[library] upload sbInsert failed:', ins.status, JSON.stringify(ins.data));
    return json({ error: 'insert_failed' }, 502, origin);
  }

  const row = Array.isArray(ins.data) ? ins.data[0] : null;
  return json({ ok: true, id: row && row.id }, 200, origin);
}

/**
 * Delete every R2 object owned by `userId`'s library_images rows. Must be
 * called BEFORE the Postgres cascade-delete removes those rows (auth.users
 * -> public.users -> library_images), since r2_key is only recoverable from
 * them. Fail-silent per image: one failed R2 delete must not stop the loop
 * or block the rest of the account-deletion flow.
 */
async function deleteLibraryImagesForUser(env, userId) {
  try {
    if (!env.LIBRARY_IMAGES) return;
    const r = await sbGet(env, 'library_images', `select=r2_key&user_id=eq.${userId}`);
    if (!r.ok || !Array.isArray(r.data)) return;
    for (const row of r.data) {
      try {
        await env.LIBRARY_IMAGES.delete(row.r2_key);
      } catch (e) {
        console.log('[library] r2 delete failed:', row.r2_key, e && e.message);
      }
    }
  } catch (e) {
    console.log('[library] deleteLibraryImagesForUser error:', e && e.message);
  }
}

// ── Plan prices (inline - plan definitions in Section 1 carry credit math, not
//  dollar prices; renew/subscription rows need the $ amount). Keep in sync with
//  upgrade.html and §1 of the plan.
const PLAN_PRICE = { free: 0, starter: 9, pro: 22, max: 75 };

/**
 * Confirm a user exists (getUserRow can't - it defaults unknown ids to a free
 * row) and return their tier. @returns {Promise<{tier:string}|null>}
 */
async function adminLoadUser(env, uid) {
  const r = await sbGet(env, 'users', `select=id,tier&id=eq.${uid}&limit=1`);
  if (!r.ok || !Array.isArray(r.data) || r.data.length === 0) return null;
  return { tier: r.data[0].tier || 'free' };
}

/** Parses optional ?from=&to= ISO date-time query params shared by the admin
 *  overview/cost-trend routes. Either may be omitted for "all time" on that
 *  side. Returns { error } if a provided value isn't a valid date. */
function parseAdminRange(url) {
  const rawFrom = url.searchParams.get('from');
  const rawTo = url.searchParams.get('to');
  const from = rawFrom ? new Date(rawFrom) : null;
  const to = rawTo ? new Date(rawTo) : null;
  if ((from && isNaN(from.getTime())) || (to && isNaN(to.getTime()))) return { error: 'invalid_date_range' };
  return { from: from ? from.toISOString() : null, to: to ? to.toISOString() : null };
}

/**
 * Admin API router. Identity + is_admin are verified by authenticate() in the
 * entrypoint BEFORE this runs, and every route here uses the service-role key,
 * so the service role is only ever reached for a confirmed admin.
 *
 * Routes:
 *   GET  /admin/overview?from=&to=
 *   GET  /admin/cost-trend?from=&to=
 *   GET  /admin/usage-by-model
 *   GET  /admin/recharge-stats
 *   GET  /admin/users?limit=&offset=
 *   GET  /admin/alerts?resolved=true|false
 *   POST /admin/alerts/:id/resolve
 *   GET  /admin/user/:id
 *   POST /admin/user/:id/add-credits   { credits, reason }
 *   POST /admin/user/:id/reset-window
 *   POST /admin/user/:id/renew         { plan?, price?, months? }
 *   GET  /admin/maintenance/stale-refill-windows?limit=       (dry-run)
 *   POST /admin/maintenance/stale-refill-windows/fix?limit=   { confirm: true }
 *   POST /admin/user/:id/block         { until? }
 *   POST /admin/user/:id/unblock
 *   POST /admin/user/:id/ban           { reason? }  (permanent, no auto-expiry)
 *   POST /admin/user/:id/unban
 *   POST /admin/user/:id/delete
 *   GET  /admin/sessions?user_id=&q=&limit=&offset=
 *   POST /admin/session/:id/delete
 *   GET  /admin/shares?session_id=&user_id=&limit=&offset=
 *   POST /admin/share/:id/revoke
 */
async function handleAdmin(request, env, ctx, origin, path, auth) {
  if (!auth || !auth.isAdmin) return json({ error: 'forbidden' }, 403, origin);

  const url = new URL(request.url);
  const method = request.method;
  const UUID = '[0-9a-fA-F-]{36}';

  // ── Aggregation reads (RPC-backed) ────────────────────────────────────────
  if (method === 'GET' && path === '/admin/overview') {
    const { from, to, error } = parseAdminRange(url);
    if (error) return json({ error }, 400, origin);
    const r = await sbRpc(env, 'admin_overview', { p_from: from, p_to: to });
    return json(r.ok ? r.data : { error: 'query_failed', detail: r.data }, r.ok ? 200 : 502, origin);
  }

  if (method === 'GET' && path === '/admin/cost-trend') {
    const { from, to, error } = parseAdminRange(url);
    if (error) return json({ error }, 400, origin);
    const r = await sbRpc(env, 'admin_cost_trend', { p_from: from, p_to: to });
    return json(r.ok ? { from, to, trend: r.data } : { error: 'query_failed', detail: r.data }, r.ok ? 200 : 502, origin);
  }

  if (method === 'GET' && path === '/admin/usage-by-model') {
    const r = await sbRpc(env, 'admin_usage_by_model');
    return json(r.ok ? { models: r.data } : { error: 'query_failed', detail: r.data }, r.ok ? 200 : 502, origin);
  }

  if (method === 'GET' && path === '/admin/recharge-stats') {
    const r = await sbRpc(env, 'admin_recharge_stats');
    return json(r.ok ? { recharge: r.data } : { error: 'query_failed', detail: r.data }, r.ok ? 200 : 502, origin);
  }

  // ── Users list (paginated; embeds each user's ACTIVE window) ───────────────
  if (method === 'GET' && path === '/admin/users') {
    const limit = Math.min(Math.max(parseInt(url.searchParams.get('limit') || '50', 10) || 50, 1), 200);
    const offset = Math.max(parseInt(url.searchParams.get('offset') || '0', 10) || 0, 0);
    const select = [
      'id', 'email', 'tier', 'subscription_status', 'subscription_renews_at',
      'rate_limit_tier', 'is_blocked', 'blocked_until', 'is_admin', 'created_at',
      'is_banned', 'ban_reason', 'banned_at',
      'usage_windows(id,window_start,window_end,credits_allocated,credits_used,status)',
    ].join(',');
    const query =
      `select=${select}&usage_windows.status=eq.active` +
      `&order=created_at.desc&limit=${limit}&offset=${offset}`;
    const r = await sbGet(env, 'users', query);
    return json(r.ok ? { users: r.data, limit, offset } : { error: 'query_failed', detail: r.data },
      r.ok ? 200 : 502, origin);
  }

  // ── Alerts list + resolve ─────────────────────────────────────────────────
  if (method === 'GET' && path === '/admin/alerts') {
    const resolvedParam = url.searchParams.get('resolved');
    let query = 'select=id,type,message,metadata,resolved,created_at&order=created_at.desc&limit=200';
    if (resolvedParam === 'true' || resolvedParam === 'false') query += `&resolved=eq.${resolvedParam}`;
    const r = await sbGet(env, 'cost_alerts', query);
    return json(r.ok ? { alerts: r.data } : { error: 'query_failed', detail: r.data }, r.ok ? 200 : 502, origin);
  }

  const alertResolve = path.match(new RegExp(`^/admin/alerts/(${UUID})/resolve$`));
  if (alertResolve) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    const r = await sbPatch(env, 'cost_alerts', `id=eq.${alertResolve[1]}`, { resolved: true });
    if (!r.ok) return json({ error: 'update_failed', detail: r.data }, 502, origin);
    if (!Array.isArray(r.data) || r.data.length === 0) return json({ error: 'alert_not_found' }, 404, origin);
    return json({ ok: true, alert: r.data[0] }, 200, origin);
  }

  // ── Per-user routes ───────────────────────────────────────────────────────
  const userDetail = path.match(new RegExp(`^/admin/user/(${UUID})$`));
  if (userDetail && method === 'GET') {
    const r = await sbRpc(env, 'admin_user_detail', { p_uid: userDetail[1] });
    if (!r.ok) return json({ error: 'query_failed', detail: r.data }, 502, origin);
    if (!r.data || !r.data.user) return json({ error: 'user_not_found' }, 404, origin);
    return json(r.data, 200, origin);
  }

  const addCredits = path.match(new RegExp(`^/admin/user/(${UUID})/add-credits$`));
  if (addCredits) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    let body;
    try { body = await request.json(); } catch (_) { return json({ error: 'invalid_json' }, 400, origin); }
    const uid = addCredits[1];
    const credits = Math.trunc(Number(body.credits));
    const reason = (body.reason || '').toString().trim();
    if (!Number.isFinite(credits) || credits === 0) return json({ error: 'credits_must_be_nonzero_integer' }, 400, origin);
    if (!reason) return json({ error: 'reason_required' }, 400, origin);

    // Need the user's tier so the DO can open a fresh window if none is active.
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);

    const res = await env.USER_ACCOUNT.getByName(uid).grant({
      userId: uid,
      tier: urow.tier,
      credits,
      mode: 'add',
      txType: 'admin_adjustment',
      reference: `admin:${auth.userId} ${reason}`,
    });
    if (res && res.sideEffects) ctx.waitUntil(flushToSupabase(env, res.sideEffects));
    return json({ ok: !!(res && res.ok), balanceAfter: res && res.balanceAfter, windowEndsAt: res && res.windowEndsAt },
      200, origin);
  }

  const resetWindow = path.match(new RegExp(`^/admin/user/(${UUID})/reset-window$`));
  if (resetWindow) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    const uid = resetWindow[1];
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);
    const res = await env.USER_ACCOUNT.getByName(uid).resetWindow({ userId: uid, tier: urow.tier });
    if (res && res.sideEffects) ctx.waitUntil(flushToSupabase(env, res.sideEffects));
    return json({ ok: !!(res && res.ok), windowEndsAt: res && res.windowEndsAt }, 200, origin);
  }

  const renew = path.match(new RegExp(`^/admin/user/(${UUID})/renew$`));
  if (renew) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    let body = {};
    try { body = await request.json(); } catch (_) { /* renew accepts an empty body */ }
    const uid = renew[1];
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);

    const plan = (body.plan || urow.tier || 'free').toString();
    if (!(plan in PLAN_PRICE)) return json({ error: 'unknown_plan', plan }, 400, origin);
    const price = body.price != null ? Number(body.price) : PLAN_PRICE[plan];
    const months = Math.min(Math.max(parseInt(body.months, 10) || 1, 1), 24);

    const startedMs = nowMs();
    const renewsMs = startedMs + months * 30 * 24 * 60 * 60 * 1000;
    const startedIso = isoFrom(startedMs);
    const renewsIso = isoFrom(renewsMs);

    // 1) Update the users row (tier + subscription lifecycle fields).
    const upd = await sbPatch(env, 'users', `id=eq.${uid}`, {
      tier: plan,
      rate_limit_tier: plan,
      subscription_status: 'active',
      subscription_started_at: startedIso,
      subscription_renews_at: renewsIso,
      updated_at: startedIso,
    });
    if (!upd.ok) return json({ error: 'update_failed', detail: upd.data }, 502, origin);

    // 2) Record a subscriptions row for history.
    const sub = await sbInsert(env, 'subscriptions', [{
      user_id: uid, plan, price, started_at: startedIso, renews_at: renewsIso, status: 'active',
    }]);
    if (!sub.ok) return json({ error: 'subscription_insert_failed', detail: sub.data }, 502, origin);

    // 3) Invalidate the per-isolate tier cache so the new tier takes effect.
    TIER_CACHE.delete(uid);

    // 4) Apply the upgrade to the DO: credits show full under the new tier
    //    immediately, but the rolling window stays inactive until the
    //    user's first message post-upgrade reopens it (see applyUpgrade()).
    const upgradeRes = await env.USER_ACCOUNT.getByName(uid).applyUpgrade({ userId: uid, tier: plan });
    if (upgradeRes && upgradeRes.sideEffects) ctx.waitUntil(flushToSupabase(env, upgradeRes.sideEffects));

    return json({ ok: true, plan, price, renewsAt: renewsIso, user: Array.isArray(upd.data) ? upd.data[0] : upd.data },
      200, origin);
  }

  // ---- Dry-run: list accounts currently affected by the stale-refill-window
  //      bug (full balance + a still-running countdown from a window that
  //      predates the grant() fix). Read-only - makes no changes. ----
  if (method === 'GET' && path === '/admin/maintenance/stale-refill-windows') {
    const limit = Math.min(Math.max(parseInt(url.searchParams.get('limit') || '200', 10) || 200, 1), 500);
    const r = await findStaleRefillWindows(env, limit);
    if (!r.ok) return json({ error: 'query_failed', detail: r.error }, 502, origin);
    return json({ ok: true, count: r.rows.length, accounts: r.rows }, 200, origin);
  }

  // ---- Execute: apply the invalidateIfFullyRefilled() fix to every account
  //      currently matching the same criteria. Requires an explicit
  //      { confirm: true } body - re-queries fresh (rather than trusting a
  //      client-supplied list) and each DO call re-validates its own state
  //      before mutating, so this is safe to run more than once. ----
  if (method === 'POST' && path === '/admin/maintenance/stale-refill-windows/fix') {
    let body = {};
    try { body = await request.json(); } catch (_) {}
    if (body.confirm !== true) {
      return json({ error: 'confirmation_required', detail: 'POST { "confirm": true } to execute the fix.' }, 400, origin);
    }
    const limit = Math.min(Math.max(parseInt(url.searchParams.get('limit') || '200', 10) || 200, 1), 500);
    const r = await findStaleRefillWindows(env, limit);
    if (!r.ok) return json({ error: 'query_failed', detail: r.error }, 502, origin);

    const results = [];
    for (const acc of r.rows) {
      const res = await env.USER_ACCOUNT.getByName(acc.userId).invalidateIfFullyRefilled({ userId: acc.userId });
      if (res && res.sideEffects) ctx.waitUntil(flushToSupabase(env, res.sideEffects));
      results.push({ userId: acc.userId, windowId: acc.windowId, changed: !!(res && res.changed), reason: res && res.reason });
    }
    const fixedCount = results.filter(x => x.changed).length;
    return json({ ok: true, scanned: r.rows.length, fixed: fixedCount, results }, 200, origin);
  }

  const block = path.match(new RegExp(`^/admin/user/(${UUID})/block$`));
  if (block) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    let body = {};
    try { body = await request.json(); } catch (_) { /* until is optional */ }
    const uid = block[1];
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);
    const r = await sbPatch(env, 'users', `id=eq.${uid}`, {
      is_blocked: true,
      blocked_until: body.until || null,
    });
    if (!r.ok) return json({ error: 'update_failed', detail: r.data }, 502, origin);
    TIER_CACHE.delete(uid);
    return json({ ok: true, user: Array.isArray(r.data) ? r.data[0] : r.data }, 200, origin);
  }

  const unblock = path.match(new RegExp(`^/admin/user/(${UUID})/unblock$`));
  if (unblock) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    const uid = unblock[1];
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);
    const r = await sbPatch(env, 'users', `id=eq.${uid}`, {
      is_blocked: false,
      blocked_until: null,
    });
    if (!r.ok) return json({ error: 'update_failed', detail: r.data }, 502, origin);
    TIER_CACHE.delete(uid);
    return json({ ok: true, user: Array.isArray(r.data) ? r.data[0] : r.data }, 200, origin);
  }

  // ── Permanent ban (distinct from the temporary block above; no auto-expiry,
  //    fully locks the account out of chat/generation until an admin unbans). ──
  const ban = path.match(new RegExp(`^/admin/user/(${UUID})/ban$`));
  if (ban) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    let body = {};
    try { body = await request.json(); } catch (_) { /* reason is optional */ }
    const uid = ban[1];
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);
    const r = await sbPatch(env, 'users', `id=eq.${uid}`, {
      is_banned: true,
      ban_reason: (body.reason || '').toString().trim() || null,
      banned_at: isoFrom(nowMs()),
    });
    if (!r.ok) return json({ error: 'update_failed', detail: r.data }, 502, origin);
    TIER_CACHE.delete(uid);
    return json({ ok: true, user: Array.isArray(r.data) ? r.data[0] : r.data }, 200, origin);
  }

  const unban = path.match(new RegExp(`^/admin/user/(${UUID})/unban$`));
  if (unban) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    const uid = unban[1];
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);
    const r = await sbPatch(env, 'users', `id=eq.${uid}`, {
      is_banned: false,
      ban_reason: null,
      banned_at: null,
    });
    if (!r.ok) return json({ error: 'update_failed', detail: r.data }, 502, origin);
    TIER_CACHE.delete(uid);
    return json({ ok: true, user: Array.isArray(r.data) ? r.data[0] : r.data }, 200, origin);
  }

  const deleteUser = path.match(new RegExp(`^/admin/user/(${UUID})/delete$`));
  if (deleteUser) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    const uid = deleteUser[1];
    const urow = await adminLoadUser(env, uid);
    if (!urow) return json({ error: 'user_not_found' }, 404, origin);

    // 0) Clean up R2 objects for this user's Library images BEFORE the
    //    Postgres cascade below removes their library_images rows (the only
    //    place r2_key is recorded). Fail-silent per image - see
    //    deleteLibraryImagesForUser().
    await deleteLibraryImagesForUser(env, uid);

    // 1) Remove the user's conversations first (cascades to conversation_shares
    //    via the confirmed FK - see db/schema_conversation_sharing.sql).
    const delSessions = await sbFetch(env, `chat_sessions?user_id=eq.${uid}`, { method: 'DELETE' });
    if (!delSessions.ok) return json({ error: 'sessions_delete_failed', detail: delSessions.data }, 502, origin);

    // 2) Delete the auth.users row via the Supabase Auth Admin API (service-role
    //    only; not reachable through sbFetch since it targets /auth/v1/, not
    //    /rest/v1/). Cascades to public.users (confirmed on delete cascade).
    if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) {
      return json({ error: 'supabase_not_configured' }, 500, origin);
    }
    const base = env.SUPABASE_URL.replace(/\/+$/, '');
    const authRes = await fetch(`${base}/auth/v1/admin/users/${uid}`, {
      method: 'DELETE',
      headers: sbAuthHeaders(env),
    });
    if (!authRes.ok) {
      const detail = await authRes.text().catch(() => '');
      return json({ error: 'auth_user_delete_failed', status: authRes.status, detail }, 502, origin);
    }

    TIER_CACHE.delete(uid);
    return json({ ok: true }, 200, origin);
  }

  // ── App config (admin-editable plan credits / window-reset hours only —
  //    see db/schema_app_config.sql + getAppConfig()/effectivePlan() above.
  //    Scoped deliberately: does NOT cover SERVICE_LIMITS/margins/model
  //    pricing, which stay hardcoded/DB-seeded and are deferred to a
  //    follow-up since they sit on the reserve/settle hot path. ──────────────
  if (method === 'GET' && path === '/admin/config') {
    const overrides = await getAppConfig(env);
    // Return both the raw saved overrides (possibly partial/empty) and the
    // effective (merged-with-hardcoded-defaults) values, so the admin UI can
    // prefill inputs with what's actually in effect right now.
    const effective = {};
    for (const tier of Object.keys(PLANS)) {
      effective[tier] = effectivePlan(PLANS[tier], overrides[tier]);
    }
    return json({ ok: true, plans: overrides, effective }, 200, origin);
  }

  if (method === 'PATCH' && path === '/admin/config') {
    let body = {};
    try { body = await request.json(); } catch (_) { /* noop */ }
    const inPlans = body && typeof body.plans === 'object' && body.plans ? body.plans : {};

    // Validate + sanitize: only known tiers, only positive-finite numeric
    // fields survive. A malformed/partial payload can never corrupt the
    // stored blob or, downstream, zero-out a plan (effectivePlan() re-checks
    // this too, but reject garbage at the write site as well).
    const plans = {};
    for (const tier of Object.keys(PLANS)) {
      const src = inPlans[tier];
      if (!src || typeof src !== 'object') continue;
      const entry = {};
      const credits = Number(src.creditsPerWindow);
      const hours = Number(src.windowHours);
      if (Number.isFinite(credits) && credits > 0) entry.creditsPerWindow = credits;
      if (Number.isFinite(hours) && hours > 0) entry.windowHours = hours;
      if (Object.keys(entry).length) plans[tier] = entry;
    }

    const r = await sbPatch(env, 'app_config', 'id=eq.1', {
      plans,
      updated_at: isoFrom(nowMs()),
    });
    if (!r.ok) return json({ error: 'update_failed', detail: r.data }, 502, origin);

    // Reset the in-Worker cache so the new config is picked up immediately,
    // instead of waiting out the normal 5-min TTL - important for an admin
    // who just saved a change and expects it to apply right away.
    APP_CONFIG_CACHE = { plans: null, exp: 0 };

    return json({ ok: true, plans }, 200, origin);
  }

  // ── Conversation (session) management ───────────────────────────────────
  if (method === 'GET' && path === '/admin/sessions') {
    const limit = Math.min(Math.max(parseInt(url.searchParams.get('limit') || '50', 10) || 50, 1), 200);
    const offset = Math.max(parseInt(url.searchParams.get('offset') || '0', 10) || 0, 0);
    const userId = url.searchParams.get('user_id');
    const q = url.searchParams.get('q');
    let query = `select=id,user_id,title,code,updated_at&order=updated_at.desc&limit=${limit}&offset=${offset}`;
    if (userId) query += `&user_id=eq.${encodeURIComponent(userId)}`;
    if (q) query += `&title=ilike.*${encodeURIComponent(q)}*`;
    const r = await sbGet(env, 'chat_sessions', query);
    return json(r.ok ? { sessions: r.data, limit, offset } : { error: 'query_failed', detail: r.data },
      r.ok ? 200 : 502, origin);
  }

  const deleteSession = path.match(new RegExp(`^/admin/session/([^/]+)/delete$`));
  if (deleteSession) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    const sessionId = deleteSession[1];
    const r = await sbFetch(env, `chat_sessions?id=eq.${encodeURIComponent(sessionId)}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=representation' },
    });
    if (!r.ok) return json({ error: 'delete_failed', detail: r.data }, 502, origin);
    if (!Array.isArray(r.data) || r.data.length === 0) return json({ error: 'session_not_found' }, 404, origin);
    return json({ ok: true }, 200, origin);
  }

  // ── Share management ──────────────────────────────────────────────────────
  if (method === 'GET' && path === '/admin/shares') {
    const limit = Math.min(Math.max(parseInt(url.searchParams.get('limit') || '50', 10) || 50, 1), 200);
    const offset = Math.max(parseInt(url.searchParams.get('offset') || '0', 10) || 0, 0);
    const sessionId = url.searchParams.get('session_id');
    const userId = url.searchParams.get('user_id');
    let query =
      `select=id,session_id,user_id,is_active,created_at,chat_sessions(title)&order=created_at.desc&limit=${limit}&offset=${offset}`;
    if (sessionId) query += `&session_id=eq.${encodeURIComponent(sessionId)}`;
    if (userId) query += `&user_id=eq.${encodeURIComponent(userId)}`;
    const r = await sbGet(env, 'conversation_shares', query);
    return json(r.ok ? { shares: r.data, limit, offset } : { error: 'query_failed', detail: r.data },
      r.ok ? 200 : 502, origin);
  }

  const revokeShare = path.match(new RegExp(`^/admin/share/(${UUID})/revoke$`));
  if (revokeShare) {
    if (method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
    const r = await sbPatch(env, 'conversation_shares', `id=eq.${revokeShare[1]}`, {
      is_active: false,
      revoked_at: isoFrom(nowMs()),
    });
    if (!r.ok) return json({ error: 'update_failed', detail: r.data }, 502, origin);
    if (!Array.isArray(r.data) || r.data.length === 0) return json({ error: 'share_not_found' }, 404, origin);
    return json({ ok: true, share: r.data[0] }, 200, origin);
  }

  return json({ error: 'not_found', note: 'Unknown admin route', path }, 404, origin);
}

// ============================================================================
//  SECTION 15 - WORKER ENTRYPOINT  (router)
// ----------------------------------------------------------------------------
//  Order: CORS preflight → health → authenticate (JWT) → per-IP guard →
//  /admin/* → /me → /recharge/:type → /chat | /generate → 404.
// ============================================================================

export default {
  async fetch(request, env, ctx) {
    const origin = request.headers.get('Origin') || '*';
    const url = new URL(request.url);
    const path = url.pathname;

    // CORS preflight - the gateway is the new front door for the browser.
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        headers: {
          'Access-Control-Allow-Origin': origin,
          'Access-Control-Allow-Methods': 'POST, GET, PATCH, OPTIONS',
          'Access-Control-Allow-Headers': CORS_ALLOW_HEADERS,
          'Access-Control-Max-Age': '86400',
          'Vary': 'Origin',
        },
      });
    }

    // Unauthenticated health check.
    if (request.method === 'GET' && (path === '/' || path === '/health')) {
      return new Response('BatNXT Gateway is running!', {
        headers: { 'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': origin },
      });
    }

    // Generation routes only: same condition used by the dispatch below.
    // Kept in sync deliberately - duplicated here (rather than computed once
    // and reused below) only because body-parsing must stay right before the
    // dispatch; the route-matching predicate itself is identical.
    const isGenRoute = request.method === 'POST' && (path === '/chat' || path === '/chat/flash' || path === '/chat/core' || path === '/chat/marketing-eco' || path === '/status-hint' || path === '/chat/title' || path === '/chat/reason' || path === '/chat/export' || path === '/marketing/extract' || path === '/build-steps' || path === '/generate');
    const perf = isGenRoute ? createPerfTracker(uuid()) : null;
    // Pricing lookup is logically independent of auth - kick it off now so it
    // overlaps with authenticate() instead of waiting until inside handleGenerate().
    const pricingPromise = isGenRoute ? getPricing(env) : null;

    // Everything past here requires a verified identity.
    const auth = await authenticate(request, env);
    if (perf) perf.mark('post-authenticate');
    if (auth.ok === false) {
      if (perf) perf.finish({ note: `auth_failed: ${auth.error}` });
      return json({ error: auth.error, detail: auth.detail, reason: auth.reason, bannedAt: auth.bannedAt },
        auth.status, origin);
    }

    // Secondary per-IP anti-abuse guard (hashed IP; never routes on raw IP).
    const ip = request.headers.get('CF-Connecting-IP') || '';
    if (ip) {
      const ipCheck = await env.IP_GUARD.getByName(await hashIp(ip)).check();
      if (!ipCheck.allowed) {
        if (perf) perf.finish({ note: 'ip_rate_limited' });
        return json({ error: 'ip_rate_limited', retryAfter: ipCheck.retryAfter }, 429, origin,
          { 'Retry-After': String(ipCheck.retryAfter) });
      }
    }
    if (perf) perf.mark('post-IP_GUARD');

    // Admin API.
    if (path.startsWith('/admin')) return handleAdmin(request, env, ctx, origin, path, auth);

    // Account + window status (no generation) - used by the frontend to render
    // the live balance / countdown without spending a credit.
    if (path === '/me') {
      const st = await env.USER_ACCOUNT.getByName(auth.userId).getState(auth.tier, auth.freeLifetimeCap);
      if (st.sideEffects && st.sideEffects.length) ctx.waitUntil(flushToSupabase(env, st.sideEffects));
      const quotaBytes = LIBRARY_STORAGE_QUOTA_BY_TIER[auth.tier] ?? LIBRARY_STORAGE_QUOTA_BY_TIER.free;
      const usedR = await sbRpc(env, 'user_library_storage_bytes', { p_uid: auth.userId });
      const usedBytes = usedR.ok ? Number(usedR.data) || 0 : 0;
      return json({
        tier: auth.tier,
        email: auth.email,
        isAdmin: auth.isAdmin,
        window: st.window,
        reserved: st.reserved,
        openReservations: st.openReservations,
        ban: st.ban,
        nextRechargeAt: auth.nextRechargeAt,
        weekly: st.weekly,
        lifetime: st.lifetime,
        storage: { usedBytes, quotaBytes },
      }, 200, origin);
    }

    // Today's Usage — per-service credit breakdown since start of UTC day.
    // Powers the Settings > Billing "Today's Usage" dashboard card.
    if (path === '/me/usage-today' && request.method === 'GET') {
      const startOfDay = new Date();
      startOfDay.setUTCHours(0, 0, 0, 0);
      const r = await sbGet(env, 'api_usage_logs',
        `select=service,credits_charged&user_id=eq.${auth.userId}` +
        `&created_at=gte.${startOfDay.toISOString()}&status=eq.ok`);
      if (!r.ok) return json({ error: 'query_failed', detail: r.data }, 502, origin);
      const byService = {};
      for (const row of (r.data || [])) {
        const svc = row.service || 'unknown';
        byService[svc] = (byService[svc] || 0) + (row.credits_charged || 0);
      }
      return json({ byService }, 200, origin);
    }

    // Usage History — paginated log of individual API operations (chat
    // calls, generations, etc), most-recent-first. Reads from
    // api_usage_logs (one row per settled request) rather than the
    // credit_transactions ledger, so each entry reflects one real API
    // operation with its service + model, not a generic balance movement.
    // Only cost/margin-internal fields (actual_cost_usd, margin_pct) are
    // deliberately excluded from the select — never exposed to end users.
    // Powers the "Recent Activity" list.
    if (path === '/me/usage-history' && request.method === 'GET') {
      const limit = Math.min(Math.max(parseInt(url.searchParams.get('limit') || '50', 10) || 50, 1), 100);
      const offset = Math.max(parseInt(url.searchParams.get('offset') || '0', 10) || 0, 0);
      const r = await sbGet(env, 'api_usage_logs',
        `select=id,service,model,credits_charged,created_at&user_id=eq.${auth.userId}` +
        `&status=eq.ok&order=created_at.desc&limit=${limit}&offset=${offset}`);
      if (!r.ok) return json({ error: 'query_failed', detail: r.data }, 502, origin);
      return json({ items: r.data || [] }, 200, origin);
    }

    // Recharge Now.
    const rechargeMatch = path.match(/^\/recharge\/([a-z_]+)$/);
    if (rechargeMatch) {
      if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
      return handleRecharge(request, env, ctx, origin, rechargeMatch[1], auth);
    }

    // Weekly Reset (paid, immediately zeroes the Weekly Usage Cap counter).
    if (path === '/weekly-reset') {
      if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
      return handleWeeklyReset(request, env, ctx, origin, auth);
    }

    // Settings > Library — stream back one stored image after an ownership
    // check (the row only comes back if user_id matches the caller; RLS on
    // the table gives a second layer of defense for direct client reads).
    const libImgMatch = path.match(/^\/library\/image\/([0-9a-f-]{36})$/);
    if (libImgMatch) {
      if (request.method !== 'GET') return json({ error: 'method_not_allowed' }, 405, origin);
      if (!env.LIBRARY_IMAGES) return json({ error: 'library_not_configured' }, 500, origin);
      const row = await sbGet(
        env,
        'library_images',
        `select=r2_key,content_type&id=eq.${libImgMatch[1]}&user_id=eq.${auth.userId}&limit=1`
      );
      const rec = row.ok && Array.isArray(row.data) ? row.data[0] : null;
      if (!rec) return json({ error: 'not_found' }, 404, origin);
      const obj = await env.LIBRARY_IMAGES.get(rec.r2_key);
      if (!obj) return json({ error: 'not_found' }, 404, origin);
      return new Response(obj.body, {
        headers: {
          'Content-Type': rec.content_type || 'application/octet-stream',
          'Cache-Control': 'private, max-age=86400',
          'Access-Control-Allow-Origin': origin,
          'Vary': 'Origin',
        },
      });
    }

    // Settings > Library — direct user upload (drag & drop / click to upload).
    if (path === '/library/upload') {
      if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405, origin);
      return handleLibraryUpload(request, env, origin, auth);
    }

    // Generation.
    if (request.method === 'POST' && (path === '/chat' || path === '/chat/flash' || path === '/chat/core' || path === '/chat/marketing-eco' || path === '/status-hint' || path === '/chat/title' || path === '/chat/reason' || path === '/chat/export' || path === '/marketing/extract' || path === '/build-steps' || path === '/generate')) {
      let body;
      try { body = await request.json(); } catch (_) {
        if (perf) perf.finish({ note: 'invalid_json' });
        return json({ error: 'invalid_json' }, 400, origin);
      }
      const service = path === '/chat' ? 'chat'
        : path === '/chat/flash' ? 'chat_flash'
        : path === '/chat/core' ? 'chat_core'
        : path === '/chat/marketing-eco' ? 'chat_marketing_eco'
        : path === '/status-hint' ? 'status_hint'
        : path === '/chat/title' ? 'chat_title'
        : path === '/chat/reason' ? 'chat_reason'
        : path === '/chat/export' ? 'chat_export'
        : path === '/marketing/extract' ? 'marketing_extract'
        : path === '/build-steps' ? 'build_steps'
        : normalizeService(body.service || body.kind || body.type);

      // BAT 5 Prime is Pro/Max only (2026-07-19). Free/Starter - including
      // both the Trial and post-Trial states, since both simply resolve to
      // tier === 'free' via authenticate() - are rejected here, before any
      // credit reservation/settlement logic runs. This is a pure access gate
      // layered in front of the unchanged billing pipeline (Core/Flash are
      // untouched, and existing Pro/Max users are unaffected). Admins bypass
      // this check entirely for internal testing; the bypass is marked in
      // the per-request [PERFORMANCE] log (not the response body) so admin
      // test traffic can be told apart from real user usage during review.
      if (service === 'chat' && PLANS[auth.tier].tierRank > PLANS.pro.tierRank) {
        if (auth.isAdmin) {
          if (perf) perf.mark('ADMIN_BYPASS_PLAN_GATE');
        } else {
          if (perf) perf.finish({ note: `plan_restricted: chat requires pro/max, got tier=${auth.tier}` });
          return json({
            error: 'plan_restricted',
            service: 'chat',
            message: 'BAT 5 Prime is available on Pro and Max plans only.',
            requiredPlans: ['pro', 'max'],
            currentTier: auth.tier,
            upgradeUrl: '/upgrade.html',
          }, 403, origin);
        }
      }

      // bat 2.2 (Marketing eco) & /marketing/extract are open to every plan,
      // including Free, per product decision 2026-07-21. BAT 2.2 Prime (the
      // Kimi-backed strong model inside Marketing) reuses the existing
      // 'chat' service/route, so it still stays behind the Pro/Max gate
      // directly above with zero extra code needed here.

      return handleGenerate(request, env, ctx, origin, service, body, auth, perf, pricingPromise);
    }

    return json({ error: 'not_found', note: 'Use /chat, /chat/flash, /chat/core, /chat/marketing-eco, /status-hint, /chat/title, /chat/export, /marketing/extract, /build-steps, /generate, /recharge/:type, /weekly-reset, /me, or /admin/*' }, 404, origin);
  },
};
