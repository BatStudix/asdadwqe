// ============================================================================
//  BatNXT — Game / Tool / Mobile Generator Worker
//  Hardened: CORS allowlist + Origin/Referer gate + optional Turnstile
// ============================================================================

const ALLOWED_ORIGINS = [
  'https://batnxt.com',
  'https://www.batnxt.com',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'http://localhost:3000'
];

// One-shot generation → Turnstile fits perfectly here.
// Flip to true after you create the widget + add TURNSTILE_SECRET.
const REQUIRE_TURNSTILE = false;

// Any http://localhost:<port> or http://127.0.0.1:<port> is allowed for local
// dev, regardless of port — the Origin header can't be forged by a real
// browser from a remote site, so this stays safe while covering tools like
// Claude Code's Preview proxy that pick a random local port each run.
function isAllowedOrigin(origin) {
  if (ALLOWED_ORIGINS.includes(origin)) return true;
  try {
    const u = new URL(origin);
    if (u.protocol === 'http:' && (u.hostname === 'localhost' || u.hostname === '127.0.0.1')) {
      return true;
    }
  } catch (_) {}
  return false;
}

function pickOrigin(request) {
  const origin = request.headers.get('Origin') || '';
  if (isAllowedOrigin(origin)) return origin;
  const ref = request.headers.get('Referer') || '';
  try {
    const refOrigin = new URL(ref).origin;
    if (isAllowedOrigin(refOrigin)) return refOrigin;
  } catch (_) {}
  return null;
}

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Internal-Key',
    'Vary': 'Origin'
  };
}

// ── Internal-key gate ────────────────────────────────────────────────────────
// The Gateway Worker (worker/gateway.js) is now the ONLY legitimate caller of
// this Worker. It forwards a shared secret in the `X-Internal-Key` header. Any
// request missing or mismatching that secret is rejected — this closes the
// previously wide-open direct-access hole (Origin/Referer headers are NOT a
// security boundary; they are trivially spoofed by a non-browser client).
//
// Transition safety: if INTERNAL_KEY is not yet configured as a Worker secret,
// the gate is SKIPPED (fail-open) so nothing breaks before the secret is set on
// both this Worker and the gateway. Once INTERNAL_KEY is present, enforcement is
// strict. Set it via: Cloudflare Dashboard → this Worker → Settings → Variables
// → add secret `INTERNAL_KEY` (same value on the gateway).
function internalKeyOk(request, env) {
  if (!env.INTERNAL_KEY) {
    console.warn('[SECURITY] INTERNAL_KEY not configured — direct-access gate is OPEN. Set the secret to close it.');
    return true;
  }
  return request.headers.get('X-Internal-Key') === env.INTERNAL_KEY;
}

function deny(status, message, origin) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...(origin ? corsHeaders(origin) : { 'Access-Control-Allow-Origin': 'null' })
    }
  });
}

async function verifyTurnstile(token, secret, ip) {
  if (!token || !secret) return false;
  const form = new FormData();
  form.append('secret', secret);
  form.append('response', token);
  if (ip) form.append('remoteip', ip);
  try {
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST', body: form
    });
    const data = await r.json();
    return data.success === true;
  } catch (_) { return false; }
}

// ============================================================================
//  PERFORMANCE TIMING — measurement only, no behavior/architecture change.
//  Records a timestamp for each named stage and prints one [PERFORMANCE]
//  block per request at the end, so real bottlenecks can be located from
//  the Worker's console logs (Cloudflare dashboard → Logs, or `wrangler tail`).
// ============================================================================
function createPerfTracker(requestId) {
  const t0 = Date.now();
  const marks = [];
  const mark = (label) => {
    marks.push({ label, t: Date.now() - t0 });
  };
  mark('REQUEST_RECEIVED');

  // Rough token estimate — real tokenizers vary, but chars/4 is a standard
  // ballpark for English text and good enough to compare relative sizes.
  const estimateTokens = (text) => Math.ceil((text || '').length / 4);

  const finish = (extra = {}) => {
    mark('RESPONSE_SENT');
    const lines = ['[PERFORMANCE] requestId=' + requestId];
    for (let i = 0; i < marks.length; i++) {
      const prev = i === 0 ? 0 : marks[i - 1].t;
      lines.push(`  ${marks[i].label}: +${marks[i].t - prev}ms (t=${marks[i].t}ms)`);
    }
    if (extra.promptChars != null) {
      lines.push(`  Prompt size: ${extra.promptChars} characters, ~${extra.promptTokens} estimated tokens`);
    }
    if (extra.outputChars != null) {
      lines.push(`  Output size: ${extra.outputChars} characters (~${Math.ceil(extra.outputChars / 4)} estimated tokens)`);
    }
    if (extra.note) lines.push(`  Note: ${extra.note}`);
    lines.push(`  Total time: ${marks[marks.length - 1].t}ms`);
    console.log(lines.join('\n'));
  };

  return { mark, finish, estimateTokens };
}

export default {
  async fetch(request, env) {
    const perf = createPerfTracker(crypto.randomUUID());
    const origin = pickOrigin(request);

    if (request.method === 'OPTIONS') {
      if (!origin) return new Response(null, { status: 403 });
      return new Response(null, { headers: corsHeaders(origin) });
    }

    if (request.method !== 'POST') {
      return new Response('Worker is running!', {
        headers: { 'Content-Type': 'text/plain' }
      });
    }

    // ── Internal-key gate: only the gateway may reach the AI route ──────────
    if (!internalKeyOk(request, env)) {
      return deny(403, 'Forbidden: direct access not allowed', origin);
    }

    if (!origin) return deny(403, 'Forbidden: origin not allowed', null);

    let body;
    try { body = await request.json(); }
    catch (_) { return deny(400, 'Invalid JSON body', origin); }

    if (REQUIRE_TURNSTILE) {
      const ok = await verifyTurnstile(
        body.turnstileToken,
        env.TURNSTILE_SECRET,
        request.headers.get('CF-Connecting-IP')
      );
      if (!ok) return deny(403, 'Turnstile verification failed', origin);
    }

    // Hard cap on baseHTML (the current file being edited), mirrored from
    // worker/websitegenerator.js and worker/gateway.js's own defensive
    // checks. ~75% of the 16,000-token output ceiling (chars/4 heuristic),
    // leaving headroom for the model to actually finish rewriting the file.
    // This is the third, innermost layer of defense-in-depth (frontend +
    // gateway already check this before a request ever reaches here).
    const BASE_HTML_CHAR_CAP = 48000;
    if (typeof body.baseHTML === 'string' && body.baseHTML.length > BASE_HTML_CHAR_CAP) {
      perf.finish({ note: 'base_html_too_large' });
      return deny(413, 'base_html_too_large', origin);
    }

    // Type-aware, edit-aware system prompts. Each of game/tool/mobile has
    // its own framing so the model isn't pulled toward game vocabulary
    // (Canvas, score, game-over/restart) when building a tool or a mobile
    // app. The 'edit' variant is used whenever body.baseHTML is present, so
    // the model is told explicitly it's modifying an existing file instead
    // of being handed the whole file wrapped inside a "build new" prompt.
    const SYSTEM_PROMPTS = {
      game: {
        build: `You are an expert HTML5 game developer. When given a description, you generate a complete, playable, self-contained hyper-casual browser game as a single HTML file.
RULES:
- Return ONLY raw HTML code, nothing else — no markdown, no backticks, no explanation
- Everything inline: CSS + JS inside the HTML file, vanilla JavaScript only (no external libraries or CDNs)
- Use HTML5 Canvas for rendering the game
- Dark theme UI
- Include a start screen, a visible score, and a game-over screen with a restart button
- Full touch support (tap/swipe) alongside keyboard/mouse controls
- Start directly with <!DOCTYPE html>`,
        edit: `You are an expert HTML5 game developer editing an EXISTING single-file HTML5 browser game. You will be given the CURRENT complete HTML file and a requested change.
RULES:
- Apply ONLY the requested change and preserve everything else exactly — game logic, art, controls, and difficulty stay untouched unless the change explicitly targets them
- Return ONLY the FULL updated, self-contained HTML file — no markdown, no backticks, no explanation
- Everything stays inline: CSS + JS inside the HTML file, vanilla JavaScript only
- Start directly with <!DOCTYPE html>`,
      },
      tool: {
        build: `You are an expert front-end developer. When given a description, you generate a complete, genuinely functional productivity tool or UI component — such as a calculator, converter, generator, dashboard, form, or data-visualization widget — as a single self-contained HTML file.
RULES:
- Return ONLY raw HTML code, nothing else — no markdown, no backticks, no explanation
- Everything inline: CSS + JS inside the HTML file, vanilla JavaScript only (no external libraries or CDNs)
- The tool must actually work: real logic, calculations, and interactivity — not a static mockup
- Clean, modern, professional UI — no game framing (no Canvas, no score, no "game over"/"restart"/"start screen" language)
- Fully responsive layout
- Start directly with <!DOCTYPE html>`,
        edit: `You are an expert front-end developer editing an EXISTING single-file HTML tool. You will be given the CURRENT complete HTML file and a requested change.
RULES:
- Apply ONLY the requested change and preserve everything else exactly, including the tool's existing logic and calculations
- Return ONLY the FULL updated, self-contained HTML file — no markdown, no backticks, no explanation
- Everything stays inline: CSS + JS inside the HTML file, vanilla JavaScript only
- Start directly with <!DOCTYPE html>`,
      },
      mobile: {
        build: `You are an expert mobile UI/UX developer. When given a description, you generate a complete, self-contained mobile app interface as a single HTML file, designed mobile-first so it feels like a native app screen — not a desktop website squeezed into a phone frame.
RULES:
- Return ONLY raw HTML code, nothing else — no markdown, no backticks, no explanation
- Everything inline: CSS + JS inside the HTML file, vanilla JavaScript only (no external libraries or CDNs)
- Design for a phone-sized viewport: touch-friendly tap targets, a bottom nav bar or top app bar where appropriate, swipe/touch gestures where they make sense
- App-like visual language: rounded cards, clear hierarchy, native-feeling components (lists, tabs, modals, buttons) — avoid generic website patterns like large hero banners or footer link columns
- No game framing (no Canvas, no score, no "game over"/"restart" language)
- Start directly with <!DOCTYPE html>`,
        edit: `You are an expert mobile UI/UX developer editing an EXISTING single-file HTML mobile app interface. You will be given the CURRENT complete HTML file and a requested change.
RULES:
- Apply ONLY the requested change and preserve everything else exactly, including the existing mobile-first layout and navigation
- Return ONLY the FULL updated, self-contained HTML file — no markdown, no backticks, no explanation
- Everything stays inline: CSS + JS inside the HTML file, vanilla JavaScript only
- Start directly with <!DOCTYPE html>`,
      },
    };

    try {
      perf.mark('PROMPT_PREPARATION_START');
      const prompt = body.prompt || 'simple dodge game';
      const type = SYSTEM_PROMPTS[body.type] ? body.type : 'game';
      const isEdit = typeof body.baseHTML === 'string' && body.baseHTML.length > 0;
      const systemContent = SYSTEM_PROMPTS[type][isEdit ? 'edit' : 'build'];
      const userContent = isEdit
        ? `=== CURRENT COMPLETE HTML FILE ===\n${body.baseHTML}\n=== END CURRENT FILE ===\n\nRequested change: ${prompt}`
        : `Build this ${type}: ${prompt}`;
      const promptChars = systemContent.length + userContent.length;
      const promptTokens = perf.estimateTokens(systemContent + userContent);
      perf.mark('PROMPT_READY');

      perf.mark('AI_REQUEST_START');
      const stream = await env.AI.run('@cf/zai-org/glm-5.2', {
        max_completion_tokens: 16000,
        stream: true,
        frequency_penalty: 0.5,
        presence_penalty: 0.3,
        messages: [
          { role: 'system', content: systemContent },
          { role: 'user', content: userContent }
        ]
      });
      // `env.AI.run()` resolving here only means the ReadableStream handle
      // exists — GLM has not necessarily produced anything yet.
      perf.mark('AI_STREAM_HANDLE_RECEIVED');

      let html = '';
      let firstTokenSeen = false;
      const reader = stream.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const payload = trimmed.slice(5).trim();
          if (!payload || payload === '[DONE]') continue;
          try {
            const parsed = JSON.parse(payload);
            const delta = parsed?.response ?? parsed?.choices?.[0]?.delta?.content ?? '';
            if (delta) {
              if (!firstTokenSeen) {
                firstTokenSeen = true;
                perf.mark('AI_FIRST_TOKEN_RECEIVED');
              }
              html += delta;
            }
          } catch (_) {}
        }
      }
      perf.mark('AI_RESPONSE_COMPLETED');

      perf.mark('POST_PROCESSING_START');
      const responseBody = JSON.stringify({ html });
      perf.mark('POST_PROCESSING_COMPLETED');

      perf.finish({
        promptChars,
        promptTokens,
        outputChars: html.length,
        // IMPORTANT FINDING: this worker requests `stream: true` from GLM and
        // pays the cost of parsing SSE chunks, but it buffers every chunk
        // into `html` and only responds once the reader loop is fully done.
        // The client gets ZERO benefit from streaming here — it waits the
        // full AI_REQUEST_START → AI_RESPONSE_COMPLETED duration either way,
        // same as a non-streaming call would, but with extra SSE-parsing
        // overhead on top. AI_FIRST_TOKEN_RECEIVED vs AI_RESPONSE_COMPLETED
        // shows how much latency is being thrown away here.
        note: 'stream:true requested from GLM but buffered fully server-side before responding — client sees no streaming benefit.'
      });

      // Report token counts so the gateway can settle at real usage. GLM's
      // stream is buffered fully above, so we estimate from char counts
      // (chars/4) — the same ballpark used everywhere else.
      return new Response(responseBody, {
        headers: {
          'Content-Type': 'application/json',
          'X-Input-Tokens': String(promptTokens),
          'X-Output-Tokens': String(perf.estimateTokens(html)),
          ...corsHeaders(origin)
        }
      });

    } catch (e) {
      perf.finish({ note: `Error: ${e.message}` });
      return deny(500, e.message, origin);
    }
  }
}
