// ============================================================================
//  BatNXT — Website Generator Worker
//  Hardened: CORS allowlist + Origin/Referer gate + optional Turnstile
// ============================================================================

const ALLOWED_ORIGINS = [
  'https://batnxt.com',
  'https://www.batnxt.com',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'http://localhost:3000'
];

// One-shot generation → Turnstile fits perfectly here.
const REQUIRE_TURNSTILE = false;

// Any http://localhost:<port> or http://127.0.0.1:<port> is allowed for local
// dev, regardless of port — the Origin header can't be forged by a real
// browser from a remote site, so this stays safe while covering tools like
// Claude Code's Preview proxy that pick a random local port each run.
function isAllowedOrigin(origin) {
  if (ALLOWED_ORIGINS.includes(origin)) return true;
  try {
    const u = new URL(origin);
    if (u.protocol === 'http:' && (u.hostname === 'localhost' || u.hostname === '127.0.0.1')) {
      return true;
    }
  } catch (_) {}
  return false;
}

function pickOrigin(request) {
  const origin = request.headers.get('Origin') || '';
  if (isAllowedOrigin(origin)) return origin;
  const ref = request.headers.get('Referer') || '';
  try {
    const refOrigin = new URL(ref).origin;
    if (isAllowedOrigin(refOrigin)) return refOrigin;
  } catch (_) {}
  return null;
}

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Internal-Key',
    'Vary': 'Origin'
  };
}

// ── Internal-key gate ────────────────────────────────────────────────────────
// The Gateway Worker (worker/gateway.js) is now the ONLY legitimate caller of
// this Worker. It forwards a shared secret in the `X-Internal-Key` header. Any
// request missing or mismatching that secret is rejected — this closes the
// previously wide-open direct-access hole (Origin/Referer headers are NOT a
// security boundary; they are trivially spoofed by a non-browser client).
//
// Transition safety: if INTERNAL_KEY is not yet configured as a Worker secret,
// the gate is SKIPPED (fail-open) so nothing breaks before the secret is set on
// both this Worker and the gateway. Once INTERNAL_KEY is present, enforcement is
// strict. Set it via: Cloudflare Dashboard → this Worker → Settings → Variables
// → add secret `INTERNAL_KEY` (same value on the gateway).
function internalKeyOk(request, env) {
  if (!env.INTERNAL_KEY) {
    console.warn('[SECURITY] INTERNAL_KEY not configured — direct-access gate is OPEN. Set the secret to close it.');
    return true;
  }
  return request.headers.get('X-Internal-Key') === env.INTERNAL_KEY;
}

function deny(status, message, origin) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...(origin ? corsHeaders(origin) : { 'Access-Control-Allow-Origin': 'null' })
    }
  });
}

async function verifyTurnstile(token, secret, ip) {
  if (!token || !secret) return false;
  const form = new FormData();
  form.append('secret', secret);
  form.append('response', token);
  if (ip) form.append('remoteip', ip);
  try {
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST', body: form
    });
    const data = await r.json();
    return data.success === true;
  } catch (_) { return false; }
}

// ============================================================================
//  PERFORMANCE TIMING — measurement only, no behavior/architecture change.
//  Records a timestamp for each named stage and prints a [PERFORMANCE] block
//  once the whole stream has finished, so real bottlenecks (queueing before
//  the AI call vs. GLM's own generation time vs. chunk relaying) can be read
//  straight from the Worker's console logs (Cloudflare dashboard → Logs, or
//  `wrangler tail`).
// ============================================================================
function createPerfTracker(requestId) {
  const t0 = Date.now();
  const marks = [];
  const mark = (label) => {
    marks.push({ label, t: Date.now() - t0 });
  };
  mark('REQUEST_RECEIVED');

  // Rough token estimate — real tokenizers vary, but chars/4 is a standard
  // ballpark for English text and good enough to compare relative sizes.
  const estimateTokens = (text) => Math.ceil((text || '').length / 4);

  const finish = (extra = {}) => {
    const lines = ['[PERFORMANCE] requestId=' + requestId];
    for (let i = 0; i < marks.length; i++) {
      const prev = i === 0 ? 0 : marks[i - 1].t;
      lines.push(`  ${marks[i].label}: +${marks[i].t - prev}ms (t=${marks[i].t}ms)`);
    }
    if (extra.promptChars != null) {
      lines.push(`  Prompt size: ${extra.promptChars} characters, ~${extra.promptTokens} estimated tokens`);
    }
    if (extra.outputChars != null) {
      lines.push(`  Output size: ${extra.outputChars} characters (~${Math.ceil(extra.outputChars / 4)} estimated tokens)`);
    }
    if (extra.note) lines.push(`  Note: ${extra.note}`);
    lines.push(`  Total time: ${marks[marks.length - 1].t}ms`);
    console.log(lines.join('\n'));
  };

  return { mark, finish, estimateTokens };
}

export default {
  async fetch(request, env, ctx) {
    const perf = createPerfTracker(crypto.randomUUID());
    const origin = pickOrigin(request);

    if (request.method === 'OPTIONS') {
      if (!origin) return new Response(null, { status: 403 });
      return new Response(null, { headers: corsHeaders(origin) });
    }

    if (request.method !== 'POST') {
      return new Response('🚀 BatLab Website Generator Worker is running!', {
        status: 200,
        headers: { 'Content-Type': 'text/plain' }
      });
    }

    // ── Internal-key gate: only the gateway may reach the AI route ──────────
    if (!internalKeyOk(request, env)) {
      return deny(403, 'Forbidden: direct access not allowed', origin);
    }

    if (!origin) return deny(403, 'Forbidden: origin not allowed', null);

    let body;
    try { body = await request.json(); }
    catch (_) { return deny(400, 'Invalid JSON body', origin); }

    const { prompt, baseHTML } = body;
    if (!prompt) return deny(400, 'Prompt is required', origin);

    // Defensive duplicate of the frontend's size guard (defense-in-depth,
    // mirrors the image-count check in gateway.js) — the frontend already
    // stops an oversized edit before it gets here, but no other caller must
    // be able to send a baseHTML too large for GLM to realistically finish
    // rewriting within the fixed output budget.
    const BASE_HTML_CHAR_CAP = 48000;
    if (baseHTML && baseHTML.length > BASE_HTML_CHAR_CAP) {
      return deny(413, `Current site is too large to edit as a whole (${baseHTML.length} chars, limit ${BASE_HTML_CHAR_CAP}). Try a smaller/more targeted change.`, origin);
    }

    if (REQUIRE_TURNSTILE) {
      const ok = await verifyTurnstile(
        body.turnstileToken,
        env.TURNSTILE_SECRET,
        request.headers.get('CF-Connecting-IP')
      );
      if (!ok) return deny(403, 'Turnstile verification failed', origin);
    }

    perf.mark('PROMPT_PREPARATION_START');
    // Editing an existing site needs a genuinely different system prompt —
    // the model must know it's revising a file, not writing one from a
    // short description, otherwise the huge embedded current-file text
    // contradicts a "generate new from description" framing and the model's
    // output coherence can collapse (see: audited garbage-output bug).
    const systemContent = baseHTML
      ? `You are an expert web developer editing an EXISTING single-file HTML website. You will be given the CURRENT complete HTML file and a requested change.
RULES:
- Apply ONLY the requested change and preserve everything else exactly
- Return ONLY the FULL updated, self-contained HTML file — no markdown, no backticks, no explanation
- Everything stays inline: CSS + JS inside the HTML file
- Start directly with <!DOCTYPE html>`
      : `You are an expert web developer. When given a description, you generate a complete, beautiful, modern, single-file HTML website.
RULES:
- Return ONLY raw HTML code, nothing else
- No markdown, no backticks, no explanation
- Everything inline: CSS + JS inside the HTML file
- Modern design: gradients, animations, clean style
- Fully mobile responsive
- Professional color scheme
- Start directly with <!DOCTYPE html>`;
    const userContent = baseHTML
      ? `=== CURRENT COMPLETE HTML FILE ===\n${baseHTML}\n=== END CURRENT FILE ===\n\nRequested change: ${prompt}`
      : `Build a complete website for: "${prompt}"`;
    const promptChars = systemContent.length + userContent.length;
    const promptTokens = perf.estimateTokens(systemContent + userContent);
    perf.mark('PROMPT_READY');

    let aiStream;
    try {
      perf.mark('AI_REQUEST_START');
      aiStream = await env.AI.run('@cf/zai-org/glm-5.2', {
        max_completion_tokens: 16000,
        stream: true,
        // Anti-degeneration guard, matching /chat's existing precedent —
        // discourages the model from spiraling into repeated/garbage output.
        frequency_penalty: 0.5,
        presence_penalty: 0.3,
        messages: [
          {
            role: 'system',
            content: systemContent
          },
          {
            role: 'user',
            content: userContent
          }
        ]
      });
      // For a streaming call this await only resolves once the ReadableStream
      // itself is handed back — it does NOT mean GLM has produced output yet.
      // The real "how long before anything useful happens" number is
      // AI_FIRST_TOKEN_RECEIVED below, measured inside the pump loop.
      perf.mark('AI_STREAM_HANDLE_RECEIVED');
    } catch (err) {
      perf.finish({ promptChars, promptTokens, note: `AI.run() threw before streaming started: ${err.message}` });
      return deny(500, err.message, origin);
    }

    // Stream the generated HTML straight through to the client as plain text,
    // instead of buffering the whole ~16k-token response before responding.
    // A small tail buffer is held back so a trailing ``` fence can still be
    // stripped once the stream ends, and a leading ```html fence (if any) is
    // stripped from the first chunk(s) before anything is written out.
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();
    const encoder = new TextEncoder();
    const TAIL_LEN = 12;

    const pump = (async () => {
      const reader = aiStream.getReader();
      const decoder = new TextDecoder();
      let sseBuffer = '';
      let leadingChecked = false;
      let leadingBuffer = '';
      let tail = '';
      let firstTokenSeen = false;
      let outputChars = 0;

      const emit = async (text) => {
        if (!text) return;
        const combined = tail + text;
        if (combined.length > TAIL_LEN) {
          const toSend = combined.slice(0, combined.length - TAIL_LEN);
          tail = combined.slice(combined.length - TAIL_LEN);
          outputChars += toSend.length;
          await writer.write(encoder.encode(toSend));
        } else {
          tail = combined;
        }
      };

      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          sseBuffer += decoder.decode(value, { stream: true });
          const lines = sseBuffer.split('\n');
          sseBuffer = lines.pop() ?? '';
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data:')) continue;
            const payload = trimmed.slice(5).trim();
            if (!payload || payload === '[DONE]') continue;
            let delta = '';
            try {
              const parsed = JSON.parse(payload);
              delta = parsed?.response ?? parsed?.choices?.[0]?.delta?.content ?? '';
            } catch (_) {}
            if (!delta) continue;

            if (!firstTokenSeen) {
              firstTokenSeen = true;
              perf.mark('AI_FIRST_TOKEN_RECEIVED');
            }

            if (!leadingChecked) {
              leadingBuffer += delta;
              // The longest possible fence is "```html\n" (8 chars). Keep
              // buffering only while what we have so far could still grow
              // into that full fence — otherwise we risk cutting a fence
              // short (e.g. deciding on "```" when "```html\n" was actually
              // on its way in the next chunk).
              const MAX_FENCE_LEN = 8;
              const stillMightBeFence =
                leadingBuffer.length < MAX_FENCE_LEN &&
                '```html\n'.startsWith(leadingBuffer.toLowerCase());
              if (stillMightBeFence) continue;

              const fenceMatch = leadingBuffer.match(/^```(?:html)?\n?/i);
              if (fenceMatch) leadingBuffer = leadingBuffer.slice(fenceMatch[0].length);
              leadingChecked = true;
              await emit(leadingBuffer);
              leadingBuffer = '';
            } else {
              await emit(delta);
            }
          }
        }
        perf.mark('AI_RESPONSE_COMPLETED');

        perf.mark('POST_PROCESSING_START');
        if (!leadingChecked && leadingBuffer) {
          leadingBuffer = leadingBuffer.replace(/^```(?:html)?\n?/i, '');
          await emit(leadingBuffer);
        }

        const finalTail = tail.replace(/\n?```\s*$/, '');
        if (finalTail) {
          outputChars += finalTail.length;
          await writer.write(encoder.encode(finalTail));
        }
        perf.mark('POST_PROCESSING_COMPLETED');
      } catch (err) {
        if (!firstTokenSeen) perf.mark('AI_FIRST_TOKEN_RECEIVED');
        perf.mark('AI_RESPONSE_COMPLETED');
        try {
          await writer.write(encoder.encode(`\n<!-- generation error: ${err.message} -->\n`));
        } catch (_) {}
        perf.finish({ promptChars, promptTokens, outputChars, note: `Stream error: ${err.message}` });
        try { await writer.close(); } catch (_) {}
        return;
      }

      perf.mark('RESPONSE_SENT');
      perf.finish({ promptChars, promptTokens, outputChars });
      try { await writer.close(); } catch (_) {}
    })();

    ctx.waitUntil(pump);

    // NOTE: this Response is returned immediately once the ReadableStream
    // exists — HTTP headers go out right away. The client then receives the
    // body progressively as `pump` writes to it. The [PERFORMANCE] summary
    // above (logged from inside `pump`) is what tells you how long the
    // headers-to-fully-drained-body trip actually took.
    // X-Input-Tokens is known now (prompt is fixed). X-Output-Tokens can't be
    // sent here — the body streams AFTER these headers flush — so the gateway
    // meters output by counting the streamed bytes (chars/4) instead.
    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'X-Input-Tokens': String(promptTokens),
        ...corsHeaders(origin)
      }
    });
  }
};
