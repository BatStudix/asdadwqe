#!/usr/bin/env python3
"""Static file server with SPA fallback.

Serves files from the given --directory (or the current directory) like
`python3 -m http.server`, but any request path that isn't a real file or
directory (e.g. the client-side chat-code routes like /c/572-757-647) is
served index.html instead of a 404 — mirroring the RewriteRule used in
production (.htaccess). Public read-only shared-conversation links
(/share/:token) fall back to share.html instead, matching the dedicated
/share/ rule in .htaccess.
"""
import argparse
import functools
import http.server
import os
from urllib.parse import urlsplit


def make_handler(directory):
    class SPARequestHandler(http.server.SimpleHTTPRequestHandler):
        def translate_path(self, path):
            full_path = super().translate_path(path)
            if not os.path.isdir(full_path) and not os.path.isfile(full_path):
                url_path = urlsplit(path).path
                if url_path.startswith('/share/'):
                    return super().translate_path('/share.html')
                return super().translate_path('/index.html')
            return full_path
    return functools.partial(SPARequestHandler, directory=directory)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('port', nargs='?', type=int, default=5544)
    parser.add_argument('--directory', default='.')
    args = parser.parse_args()
    http.server.test(HandlerClass=make_handler(args.directory), port=args.port)


if __name__ == '__main__':
    main()
