-- ============================================================================
--  BatNXT — Chat sessions pin / read / archive status (additive)
--  Target: Supabase (Postgres 15+)
--  HOW TO APPLY: Supabase Dashboard → SQL Editor → paste → Run. Idempotent.
-- ============================================================================
alter table public.chat_sessions add column if not exists is_pinned   boolean not null default false;
alter table public.chat_sessions add column if not exists is_read     boolean not null default true;
alter table public.chat_sessions add column if not exists is_archived boolean not null default false;
create index if not exists idx_chat_sessions_user_archived
  on public.chat_sessions (user_id, is_archived, updated_at desc);
