-- ============================================================================
--  BatNXT — Permanent Ban schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS).
--    Does NOT touch db/schema.sql or any other schema_*.sql file —
--    this file only adds three new columns to the ALREADY EXISTING
--    `public.users` table.
--
--  DESIGN NOTES:
--    * This is a distinct, PERMANENT admin action, separate from the two
--      existing (temporary) restriction mechanisms:
--        1. `is_blocked` / `blocked_until` on `public.users` — a temporary,
--           time-boxed block set via the existing
--           POST /admin/user/:id/block /unblock endpoints.
--        2. The ephemeral in-Durable-Object rate-limit ban ladder
--           (UserAccountDO) — ephemeral abuse-throttling, not account-level.
--    * A banned user (`is_banned = true`) is fully locked out of chat and
--      generation regardless of credits/window state, until an admin
--      explicitly unbans them (there is no auto-expiry, unlike
--      `blocked_until`).
--    * `worker/gateway.js`'s `authenticate()` checks this flag right after
--      the existing `is_blocked` check and returns a distinct
--      `{ok:false,status:403,error:'banned',reason,bannedAt}` shape so the
--      client can tell a permanent ban apart from a temporary block/rate
--      limit and show the correct full-screen UI.
-- ============================================================================

alter table public.users
  add column if not exists is_banned boolean not null default false;

alter table public.users
  add column if not exists ban_reason text;

alter table public.users
  add column if not exists banned_at timestamptz;

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
