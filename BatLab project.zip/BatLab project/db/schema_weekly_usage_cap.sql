-- ============================================================================
--  BatNXT — Weekly Usage Cap schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS).
--    Does NOT touch db/schema.sql or any other schema_*.sql file —
--    this file only adds two new columns to the ALREADY EXISTING
--    `public.users` table. No new table is created.
--
--  DESIGN NOTES:
--    * The weekly cap (Free = no cap; Starter = 1050/wk; Pro = 2240/wk;
--      Max = 15000/wk, all resetting Monday 00:00 UTC) is computed and
--      authoritatively tracked by the Durable Object (worker/gateway.js,
--      UserAccountDO — weekly reserve/settle/alarm logic) — the DO's own
--      storage (ctx.storage) is the source of truth for whether a user is
--      currently within or over their weekly ceiling.
--    * These two columns are an async, best-effort MIRROR of the DO's
--      current weekly counters, written via the existing side-effect flush
--      mechanism (flushToSupabase()) purely so the admin dashboard / audit
--      trail can see weekly usage without querying the DO directly. They
--      are NOT read back by the DO and never drive billing decisions on
--      their own.
--    * `weekly_usage_credits`: credits consumed in the user's current
--      weekly period (mirrors the DO's running total; reset to 0 alongside
--      the DO's own reset at each Monday 00:00 UTC boundary, or immediately
--      on a paid "Weekly Reset" purchase).
--    * `weekly_period_start`: timestamp of the start of the user's current
--      weekly period (the most recent Monday 00:00 UTC boundary, or the
--      timestamp of their last paid "Weekly Reset" purchase, whichever is
--      more recent) — kept purely for admin/audit visibility into when the
--      mirrored counter above was last zeroed.
-- ============================================================================

alter table public.users
  add column if not exists weekly_usage_credits integer not null default 0;

alter table public.users
  add column if not exists weekly_period_start timestamptz null default null;

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
