-- ============================================================================
--  BatNXT — Library favorites (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
--
--  DESIGN NOTES:
--    * `is_favorite` is a simple per-row boolean flag (mirrors the existing
--      `marketing_analyses.is_favorite` column) rather than a separate join
--      table — it's a 1:1 flag on each library_images row, not a cross-source
--      snapshot like `starred_messages`.
--    * Unlike inserts (which only ever happen server-side via the
--      service-role key), the favorite toggle is written directly by the
--      client using the existing `supabase` client — same convention as
--      `starred_messages`' insert/delete policies. This requires an
--      owner-only UPDATE policy so a user can only flip their own rows.
-- ============================================================================

alter table public.library_images
  add column if not exists is_favorite boolean not null default false;

alter table public.library_images enable row level security;

drop policy if exists p_library_images_owner_update on public.library_images;
create policy p_library_images_owner_update on public.library_images
  for update using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
