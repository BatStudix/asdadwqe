-- ============================================================================
--  BatNXT — Starred messages persistence schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
--
--  DESIGN NOTES:
--    * One row per starred message, across BOTH Home chat and Marketing
--      analyses — `source` distinguishes which surface it came from
--      ('home' | 'marketing'), `session_id` is that surface's own session
--      identity (homeConvSessionId / marketingAnalysisId), and `msg_id` is
--      a lightweight client-minted id (mintMsgId(), stamped on every
--      pushed message — see js shim) identifying the message itself.
--    * msg_id (not array index) is the star's identity on purpose: Edit &
--      Resend / Regenerate truncate-and-rebuild the in-memory history
--      array, which would silently shift/orphan an index-based star.
--    * Rows are written directly by the client via the existing `supabase`
--      client (insert on star / delete on unstar), same client-direct-write
--      pattern as `marketing_analyses` — no worker route, no service-role key.
--    * `content_snippet`/`title` are denormalized snapshots captured at
--      star-time purely so the Starred list view can render a card without
--      re-fetching/re-parsing the full parent conversation on every load;
--      they are NOT kept in sync with later edits to the source message.
--    * The unique index makes star/unstar an idempotent toggle (a duplicate
--      star insert simply fails/no-ops instead of creating a second row).
-- ============================================================================

-- ── Extensions ──────────────────────────────────────────────────────────────
create extension if not exists "pgcrypto";   -- gen_random_uuid()

create table if not exists public.starred_messages (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references public.users (id) on delete cascade,
  source           text not null check (source in ('home', 'marketing')),
  session_id       text not null,
  msg_id           text not null,
  role             text,              -- 'user' | 'assistant', for display convenience
  content_snippet  text,              -- short plain-text preview, truncated client-side
  title            text,              -- parent conversation/analysis title, snapshot at star time
  created_at       timestamptz not null default now()
);

create unique index if not exists uq_starred_messages_identity
  on public.starred_messages (user_id, source, session_id, msg_id);

create index if not exists idx_starred_messages_user_created
  on public.starred_messages (user_id, created_at desc);

alter table public.starred_messages enable row level security;

drop policy if exists p_starred_messages_owner_select on public.starred_messages;
create policy p_starred_messages_owner_select on public.starred_messages
  for select using (auth.uid() = user_id);

drop policy if exists p_starred_messages_owner_insert on public.starred_messages;
create policy p_starred_messages_owner_insert on public.starred_messages
  for insert with check (auth.uid() = user_id);

drop policy if exists p_starred_messages_owner_delete on public.starred_messages;
create policy p_starred_messages_owner_delete on public.starred_messages
  for delete using (auth.uid() = user_id);

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
