-- ============================================================================
--  BatNXT — Conversation Permalinks & Sharing schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
--    Does NOT touch db/schema.sql — this file only adds to the ALREADY
--    EXISTING `public.chat_sessions` table (created elsewhere, outside this
--    repo's tracked SQL) and creates one brand-new table.
--
--  DESIGN NOTES:
--    * `chat_sessions` already exists live but has no migration file in this
--      repo, so its current RLS state is unknown/unverifiable from here.
--      This file (re-)enables RLS on it defensively and adds owner-only
--      policies, safe to apply regardless of whatever state it's currently
--      in — it will never make access MORE permissive than owner-only,
--      except for the one narrow, explicit "shared conversation" exception
--      below (§3), which is required for the public read-only share view.
--    * `conversation_shares` is designed with RLS from creation. A share
--      row is only ever readable by its owner or, if `is_active = true`, by
--      anyone (including anonymous/anon-key visitors) — this is what lets
--      the public share.html page resolve a token without being logged in.
--    * Revoking a share is a soft-delete (`is_active = false` +
--      `revoked_at`), never a hard delete, so there's an audit trail of
--      every link that was ever created.
-- ============================================================================

-- ── Extensions ──────────────────────────────────────────────────────────────
create extension if not exists "pgcrypto";   -- gen_random_uuid()

-- ============================================================================
--  1) chat_sessions — add the `code` column used for /c/XXX-XXX-XXX
--     permalinks (best-effort mirrored from the client already; this makes
--     it a real, indexed column so cross-device/incognito lookups work).
-- ============================================================================
alter table public.chat_sessions add column if not exists code text;

-- A session's code must be globally unique once set, but many older rows
-- won't have one yet (they get a code retro-generated on next open) — a
-- partial unique index allows any number of NULLs while still enforcing
-- uniqueness among the rows that do have a code.
create unique index if not exists uq_chat_sessions_code
  on public.chat_sessions (code) where code is not null;

-- ── Defensive RLS: owner-only access to chat_sessions ───────────────────────
alter table public.chat_sessions enable row level security;

drop policy if exists p_chat_sessions_owner_select on public.chat_sessions;
create policy p_chat_sessions_owner_select on public.chat_sessions
  for select using (auth.uid() = user_id);

drop policy if exists p_chat_sessions_owner_insert on public.chat_sessions;
create policy p_chat_sessions_owner_insert on public.chat_sessions
  for insert with check (auth.uid() = user_id);

drop policy if exists p_chat_sessions_owner_update on public.chat_sessions;
create policy p_chat_sessions_owner_update on public.chat_sessions
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists p_chat_sessions_owner_delete on public.chat_sessions;
create policy p_chat_sessions_owner_delete on public.chat_sessions
  for delete using (auth.uid() = user_id);

-- ============================================================================
--  2) conversation_shares — one row per "Share" link a user creates.
--     Revocation is a soft-delete (is_active=false), never a hard delete.
-- ============================================================================
create table if not exists public.conversation_shares (
  id          uuid primary key default gen_random_uuid(),
  session_id  text not null references public.chat_sessions (id) on delete cascade,
  user_id     uuid not null references auth.users (id) on delete cascade,
  share_token text not null unique,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  revoked_at  timestamptz
);
create index if not exists idx_conversation_shares_session
  on public.conversation_shares (session_id);
create index if not exists idx_conversation_shares_owner
  on public.conversation_shares (user_id, created_at desc);

alter table public.conversation_shares enable row level security;

-- Owner can see/manage all of their own share rows (active or revoked).
drop policy if exists p_conversation_shares_owner_select on public.conversation_shares;
create policy p_conversation_shares_owner_select on public.conversation_shares
  for select using (auth.uid() = user_id);

drop policy if exists p_conversation_shares_owner_insert on public.conversation_shares;
create policy p_conversation_shares_owner_insert on public.conversation_shares
  for insert with check (auth.uid() = user_id);

drop policy if exists p_conversation_shares_owner_update on public.conversation_shares;
create policy p_conversation_shares_owner_update on public.conversation_shares
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Anyone (including the anon key used by the public share.html page) may
-- look up a share row ONLY while it's active. A revoked/inactive share is
-- invisible to non-owners — resolving its token then correctly shows
-- "This shared conversation is no longer available."
drop policy if exists p_conversation_shares_public_active on public.conversation_shares;
create policy p_conversation_shares_public_active on public.conversation_shares
  for select using (is_active = true);

-- ============================================================================
--  3) chat_sessions — narrow public read exception for shared conversations.
--     Lets an anonymous visitor who has a valid, active share link resolve
--     conversation_shares → chat_sessions WITHOUT granting any broader read
--     access. Combined with the owner-only policies in §1 via OR (Postgres
--     RLS: multiple permissive policies on the same command are OR'd).
-- ============================================================================
drop policy if exists p_chat_sessions_public_shared on public.chat_sessions;
create policy p_chat_sessions_public_shared on public.chat_sessions
  for select using (
    exists (
      select 1 from public.conversation_shares cs
      where cs.session_id = chat_sessions.id
        and cs.is_active = true
    )
  );

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
