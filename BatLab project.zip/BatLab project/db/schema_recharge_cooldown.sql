-- ============================================================================
--  BatNXT — Recharge Cooldown schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS).
--    Does NOT touch db/schema.sql or any other schema_*.sql file —
--    this file only adds one new column to the ALREADY EXISTING
--    `public.users` table.
--
--  DESIGN NOTES:
--    * `last_recharge_at` records the timestamp of the user's most recent
--      successful "Recharge Now" purchase (any type — full_refill or
--      custom_amount). NULL means the user has never recharged.
--    * Enforced as a single, uniform cooldown (RECHARGE_COOLDOWN_DAYS,
--      currently 5 days) across ALL recharge types and ALL tiers, in
--      worker/gateway.js's handleRecharge() — this column is just the
--      persisted timestamp that check reads/writes against.
--    * The cooldown intentionally has NO exception for tier upgrades: it
--      stays anchored to `last_recharge_at` regardless of which plan the
--      user is on when they next try to recharge.
-- ============================================================================

alter table public.users
  add column if not exists last_recharge_at timestamptz null default null;

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
