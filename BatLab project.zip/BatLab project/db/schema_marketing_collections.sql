-- ============================================================================
--  BatNXT — Marketing Collections schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
--    Must be applied BEFORE schema_marketing_analyses.sql — that table's
--    `collection_id` column has a foreign key into this one.
--
--  DESIGN NOTES:
--    * Table-only for Marketing Phase 1 — no UI reads/writes it yet. It
--      exists now so marketing_analyses.collection_id has something to
--      reference from day one, avoiding a second migration in Phase 3 when
--      the Collections UI (named folders: Launch, SEO, Ads, Competitors,
--      Brand, App, Website) ships.
--    * RLS is full owner CRUD, matching chat_sessions/conversation_shares —
--      the client will create/rename/delete collections directly via the
--      existing `supabase` client, no worker route needed.
--    * (user_id, name) is unique so a user can't create two collections
--      with the same name.
-- ============================================================================

create extension if not exists "pgcrypto";   -- gen_random_uuid()

create table if not exists public.marketing_collections (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.users (id) on delete cascade,
  name       text not null,
  created_at timestamptz not null default now()
);
create unique index if not exists uq_marketing_collections_user_name
  on public.marketing_collections (user_id, name);

alter table public.marketing_collections enable row level security;

drop policy if exists p_marketing_collections_owner_select on public.marketing_collections;
create policy p_marketing_collections_owner_select on public.marketing_collections
  for select using (auth.uid() = user_id);

drop policy if exists p_marketing_collections_owner_insert on public.marketing_collections;
create policy p_marketing_collections_owner_insert on public.marketing_collections
  for insert with check (auth.uid() = user_id);

drop policy if exists p_marketing_collections_owner_update on public.marketing_collections;
create policy p_marketing_collections_owner_update on public.marketing_collections
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists p_marketing_collections_owner_delete on public.marketing_collections;
create policy p_marketing_collections_owner_delete on public.marketing_collections
  for delete using (auth.uid() = user_id);

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
