-- ============================================================================
--  BatNXT — Marketing Analyses persistence schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
--    Apply schema_marketing_collections.sql FIRST — collection_id below
--    references it.
--
--  DESIGN NOTES:
--    * One row per Marketing conversation (analogous to chat_sessions, not
--      library_images) — `id` is a client-generated text id ('mkt_' +
--      Date.now()), and `messages` stores the full conversation array,
--      mirroring chat_sessions.messages exactly.
--    * Rows are written directly by the client via the existing `supabase`
--      client (upsert), same pattern as saveHomeConvSession() — no worker
--      route, no service-role key.
--    * `scores` is numeric gauge data only ({"uiux":84,"seo":72}); the
--      qualitative competition/growth_potential/category/tags fields are
--      separate columns, not part of `scores` (see plan notes on why).
--    * `source_url`/`domain` are only populated when the analysis
--      originated from an actual URL turn (used by the future Recent
--      Websites feature) — an .html/.css-attachment-triggered analysis
--      still gets `scores`/`category`/etc. but no domain.
--    * All optional structured fields are nullable — plenty of rows will
--      have them null (idea-only briefs, non-website analyses).
-- ============================================================================

create table if not exists public.marketing_analyses (
  id               text primary key,
  user_id          uuid not null references public.users (id) on delete cascade,
  title            text,
  messages         jsonb not null,
  source_url       text,
  domain           text,
  scores           jsonb,             -- {"uiux":<0-100>,"seo":<0-100>}, nullable
  competition      text,              -- 'Low' | 'Medium' | 'High', nullable
  growth_potential text,              -- 'Low' | 'Medium' | 'High', nullable
  category         text,              -- one of the fixed category list, nullable
  tags             text[],
  is_favorite      boolean not null default false,
  collection_id    uuid references public.marketing_collections (id) on delete set null,
  is_archived      boolean not null default false,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create index if not exists idx_marketing_analyses_user_updated
  on public.marketing_analyses (user_id, updated_at desc);

alter table public.marketing_analyses enable row level security;

drop policy if exists p_marketing_analyses_owner_select on public.marketing_analyses;
create policy p_marketing_analyses_owner_select on public.marketing_analyses
  for select using (auth.uid() = user_id);

drop policy if exists p_marketing_analyses_owner_insert on public.marketing_analyses;
create policy p_marketing_analyses_owner_insert on public.marketing_analyses
  for insert with check (auth.uid() = user_id);

drop policy if exists p_marketing_analyses_owner_update on public.marketing_analyses;
create policy p_marketing_analyses_owner_update on public.marketing_analyses
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists p_marketing_analyses_owner_delete on public.marketing_analyses;
create policy p_marketing_analyses_owner_delete on public.marketing_analyses
  for delete using (auth.uid() = user_id);

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
