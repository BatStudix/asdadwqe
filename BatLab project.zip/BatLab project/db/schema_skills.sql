-- ============================================================================
--  BatNXT — Skills (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
--
--  DESIGN NOTES:
--    * Per-account skill library. New accounts start with zero rows (no seed
--      data) — the empty state is the default for every fresh user.
--    * Each skill is a simple name + free-text content pair, referenced in
--      chat via "@name" mentions and injected into the system prompt.
-- ============================================================================

create table if not exists public.skills (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  content text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_skills_user_id on public.skills(user_id);

alter table public.skills enable row level security;

drop policy if exists p_skills_owner_select on public.skills;
create policy p_skills_owner_select on public.skills
  for select using (auth.uid() = user_id);

drop policy if exists p_skills_owner_insert on public.skills;
create policy p_skills_owner_insert on public.skills
  for insert with check (auth.uid() = user_id);

drop policy if exists p_skills_owner_update on public.skills;
create policy p_skills_owner_update on public.skills
  for update using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists p_skills_owner_delete on public.skills;
create policy p_skills_owner_delete on public.skills
  for delete using (auth.uid() = user_id);

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
