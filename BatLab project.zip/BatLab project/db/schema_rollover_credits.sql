-- ============================================================================
--  BatNXT — Rollover Credits schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS).
--    Does NOT touch db/schema.sql or db/schema_conversation_sharing.sql —
--    this file only adds one new column to the ALREADY EXISTING
--    `public.users` table.
--
--  DESIGN NOTES:
--    * Rollover math (50% of a window's unused credits, capped at one full
--      window's worth) is computed and authoritatively tracked by the
--      Durable Object (worker/gateway.js, UserAccountDO._ensureWindow()) —
--      the DO's own storage is the source of truth for what a user's
--      current window allocation actually is.
--    * This column is an async, best-effort MIRROR of the rollover amount
--      granted at the start of the user's current window, written via the
--      existing side-effect flush mechanism (flushToSupabase()) purely so
--      the admin dashboard / audit trail can see it without querying the
--      DO directly. It is NOT read back by the DO and never drives billing
--      decisions on its own.
-- ============================================================================

alter table public.users
  add column if not exists rollover_credits integer not null default 0;

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
