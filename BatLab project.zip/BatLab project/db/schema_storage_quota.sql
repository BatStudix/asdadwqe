-- ============================================================================
--  BatNXT — Library storage quota RPC (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses CREATE OR REPLACE / DROP ... IF EXISTS).
--
--  DESIGN NOTES:
--    * Supabase disables PostgREST aggregate functions by default, so summing
--      `size_bytes` across a user's `library_images` rows needs a `security
--      definer` RPC (same pattern as the existing admin_* aggregates in
--      schema.sql) rather than a plain PostgREST `select=sum(...)` query.
--    * Called exclusively by worker/gateway.js via the existing `sbRpc()`
--      helper, using the service-role key — never called directly by the
--      client.
-- ============================================================================

-- ============================================================================
--  user_library_storage_bytes — total bytes a user currently has stored in
--  the Library (sum of library_images.size_bytes for that user).
-- ============================================================================
create or replace function public.user_library_storage_bytes(p_uid uuid)
returns bigint
language sql
security definer
set search_path = public
as $$
  select coalesce(sum(size_bytes), 0)::bigint
  from public.library_images
  where user_id = p_uid;
$$;

revoke execute on function public.user_library_storage_bytes(uuid) from public, anon, authenticated;
grant execute on function public.user_library_storage_bytes(uuid) to service_role;

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
