-- ============================================================================
--  BatNXT — App Config schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / ON CONFLICT DO NOTHING).
--    Does NOT touch db/schema.sql or any other schema_*.sql file — this file
--    only creates one new, standalone singleton table.
--
--  DESIGN NOTES:
--    * Singleton table (`id` fixed to 1 via CHECK) holding admin-editable
--      overrides for a scoped subset of the billing config: per-tier plan
--      credit allocations and window-reset hours only (mirrors the
--      hardcoded `PLANS` const in worker/gateway.js). Everything else that
--      drives real billing math (SERVICE_LIMITS, margins, model pricing
--      multipliers) is intentionally NOT covered by this table — those stay
--      hardcoded/DB-seeded elsewhere (model_pricing) and are deferred to a
--      follow-up, since they sit directly on the reserve/settle hot path
--      and warrant dedicated testing before being made runtime-configurable.
--    * `plans` is a jsonb blob shaped like:
--        { "free": {"creditsPerWindow": 200, "windowHours": 24}, ... }
--      Any tier/field an admin hasn't saved yet is simply absent — the
--      gateway's `getAppConfig()`/`effectivePlan()` fall back to the
--      hardcoded `PLANS` default for anything missing or invalid, so this
--      table can be empty (or not yet migrated) without breaking billing.
--    * Read via `worker/gateway.js`'s `getAppConfig()` (5-min cache, same
--      pattern as the existing `getPricing()`/model_pricing read), and used
--      ONLY inside `UserAccountDO._ensureWindow()` to size a NEW window's
--      allocation when one is opened. Not read anywhere else.
--    * Row Level Security is enabled with NO client policies — this table
--      is only ever read/written by the Worker via the Supabase service-role
--      key (`PATCH /admin/config`), never directly by the browser client.
-- ============================================================================

create table if not exists public.app_config (
  id int primary key default 1 check (id = 1),
  plans jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

insert into public.app_config (id) values (1) on conflict (id) do nothing;

alter table public.app_config enable row level security;

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
