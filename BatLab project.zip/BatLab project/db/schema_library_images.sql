-- ============================================================================
--  BatNXT — Settings "Library" image gallery schema (additive)
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / DROP POLICY IF EXISTS).
--
--  DESIGN NOTES:
--    * One row per image the user successfully attached to a chat/build
--      message AND that Moondream actually analyzed (imageAnalyzed=true) —
--      rows are only ever inserted by worker/gateway.js's
--      persistLibraryImage() helper, using the service-role key (bypasses
--      RLS), never directly by the client.
--    * `r2_key` points at the object in the Cloudflare R2 bucket
--      (`LIBRARY_IMAGES` binding) — the actual image bytes never live in
--      Postgres. The client never reads `r2_key` directly; it's only used
--      server-side by the GET /library/image/:id route to fetch from R2
--      after an ownership check.
--    * RLS is owner-only SELECT — the client lists a user's own images by
--      querying this table directly via the existing `supabase` client (same
--      pattern already used for `chat_sessions`). No insert/update/delete
--      policy is defined since all writes go through the service-role key.
-- ============================================================================

-- ── Extensions ──────────────────────────────────────────────────────────────
create extension if not exists "pgcrypto";   -- gen_random_uuid()

-- ============================================================================
--  library_images — one row per successfully-analyzed attached image.
-- ============================================================================
create table if not exists public.library_images (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.users (id) on delete cascade,
  r2_key       text not null,
  content_type text,
  size_bytes   integer,
  file_name    text,   -- original attachment filename, captured forward-only
  created_at   timestamptz not null default now()
);
create index if not exists idx_library_images_user_created
  on public.library_images (user_id, created_at desc);

-- Additive: bring pre-existing tables up to date (older rows keep file_name NULL,
-- the client synthesizes a display name for those). Idempotent / safe to re-run.
alter table public.library_images add column if not exists file_name text;

alter table public.library_images enable row level security;

drop policy if exists p_library_images_owner_select on public.library_images;
create policy p_library_images_owner_select on public.library_images
  for select using (auth.uid() = user_id);

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
