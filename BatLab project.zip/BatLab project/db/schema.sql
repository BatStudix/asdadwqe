-- ============================================================================
--  BatNXT v2 — Subscription / Usage Window / API-Cost-Protection schema
--  Target: Supabase (Postgres 15+)
--
--  HOW TO APPLY:
--    Supabase Dashboard → SQL Editor → paste this whole file → Run.
--    Idempotent: safe to re-run (uses IF NOT EXISTS / CREATE OR REPLACE).
--
--  DESIGN NOTES:
--    * The Cloudflare Durable Object (UserAccountDO) is the LIVE source of
--      truth for the request hot-path. These tables are the durable, queryable
--      MIRROR + audit trail, written asynchronously from the Worker via
--      ctx.waitUntil(). Nothing here is read synchronously on the generation
--      hot-path — only the admin dashboard and reconciliation read from here.
--    * model_pricing is deliberately DECOUPLED from plan/credit definitions so
--      per-operation cost can change (new model, new price) without ever
--      touching how many credits a plan grants.
--    * RLS: a normal user (anon/authenticated key) may read ONLY their own
--      rows. All privileged writes happen from the Worker using the SERVICE
--      ROLE key, which bypasses RLS. The service role key must live ONLY as a
--      Cloudflare Worker secret — never shipped to the browser.
-- ============================================================================

-- ── Extensions ──────────────────────────────────────────────────────────────
create extension if not exists "pgcrypto";   -- gen_random_uuid()

-- ============================================================================
--  1) users — usage-window / rate-limit / subscription state per account.
--     One row per auth user. FK-linked to auth.users(id) (== profiles.id).
--     NOTE: the existing `profiles` table (created by login.html on signup)
--     keeps display/theme/plan-label data; THIS table holds the billing +
--     enforcement state that v2 introduces.
-- ============================================================================
create table if not exists public.users (
  id                       uuid primary key references auth.users (id) on delete cascade,
  email                    text,
  -- 'free' | 'starter' | 'pro' | 'max'
  tier                     text not null default 'free',
  -- 'active' | 'past_due' | 'canceled' | 'none'
  subscription_status      text not null default 'none',
  subscription_started_at  timestamptz,
  subscription_renews_at   timestamptz,
  -- usually mirrors tier, but kept separate so rate-limit tuning is
  -- independent of billing tier if ever needed.
  rate_limit_tier          text not null default 'free',
  is_blocked               boolean not null default false,
  blocked_until            timestamptz,
  is_admin                 boolean not null default false,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

-- ============================================================================
--  2) usage_windows — each Usage Window is its own immutable-ish row (never a
--     counter that gets reset). credits_used is the only field that grows
--     during the window's life; on expiry status flips to 'expired' and a NEW
--     row is created for the next window. Gives full per-window audit history.
-- ============================================================================
create table if not exists public.usage_windows (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null references public.users (id) on delete cascade,
  window_start       timestamptz not null default now(),
  window_end         timestamptz not null,
  credits_allocated  integer not null,
  credits_used       integer not null default 0,
  -- 'active' | 'expired'
  status             text not null default 'active',
  created_at         timestamptz not null default now()
);
create index if not exists idx_usage_windows_user       on public.usage_windows (user_id, created_at desc);
create index if not exists idx_usage_windows_user_active on public.usage_windows (user_id) where status = 'active';

-- ============================================================================
--  3) credit_transactions — append-only ledger of every credit movement.
--     `amount` is signed: negative = charge, positive = grant/refund/refill.
-- ============================================================================
create table if not exists public.credit_transactions (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references public.users (id) on delete cascade,
  window_id      uuid references public.usage_windows (id) on delete set null,
  amount         integer not null,
  -- 'charge'|'refund'|'window_refill'|'recharge_purchase'|'admin_adjustment'
  type           text not null,
  service        text,               -- 'chat'|'website'|'game'|'tool'|'mobile'|null
  api_cost_usd   numeric(12,6),
  margin_pct     numeric(6,3),
  balance_after  integer,            -- remaining credits in the window after this txn
  reference      text,               -- free-form: reservationId, admin reason, etc.
  created_at     timestamptz not null default now()
);
create index if not exists idx_credit_tx_user on public.credit_transactions (user_id, created_at desc);
create index if not exists idx_credit_tx_type on public.credit_transactions (type, created_at desc);

-- ============================================================================
--  4) api_usage_logs — per-generation real cost record (one row per settled
--     request). Powers the admin per-model usage breakdown + margin reporting.
-- ============================================================================
create table if not exists public.api_usage_logs (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.users (id) on delete cascade,
  window_id       uuid references public.usage_windows (id) on delete set null,
  service         text not null,     -- 'chat'|'website'|'game'|'tool'|'mobile'
  model           text not null,     -- e.g. '@cf/zai-org/glm-5.2'
  input_tokens    integer not null default 0,
  output_tokens   integer not null default 0,
  actual_cost_usd numeric(12,6) not null default 0,
  margin_pct      numeric(6,3) not null default 0,
  credits_charged integer not null default 0,
  -- 'ok' | 'orphaned_reservation' | 'error'
  status          text not null default 'ok',
  created_at      timestamptz not null default now()
);
create index if not exists idx_api_usage_created       on public.api_usage_logs (created_at desc);
create index if not exists idx_api_usage_model_created on public.api_usage_logs (model, created_at desc);
create index if not exists idx_api_usage_user          on public.api_usage_logs (user_id, created_at desc);
create index if not exists idx_api_usage_service       on public.api_usage_logs (service, created_at desc);

-- ============================================================================
--  5) recharge_purchases — instant-buy records (Extra Window / Extra Credits /
--     Instant Refill). status starts 'pending_payment' (or 'completed' when no
--     gateway is wired and credits are granted immediately — see gateway.js).
-- ============================================================================
create table if not exists public.recharge_purchases (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.users (id) on delete cascade,
  window_id       uuid references public.usage_windows (id) on delete set null,
  -- 'extra_window' | 'extra_credits' | 'instant_refill'
  type            text not null,
  amount_usd      numeric(10,2) not null,
  credits_granted integer not null default 0,
  -- 'pending_payment' | 'completed' | 'failed'
  status          text not null default 'pending_payment',
  reference       text,
  created_at      timestamptz not null default now()
);
create index if not exists idx_recharge_user    on public.recharge_purchases (user_id, created_at desc);
create index if not exists idx_recharge_created on public.recharge_purchases (created_at desc);

-- ============================================================================
--  6) rate_limit_logs — mirror of DO-side rate-limit / ban escalation events.
-- ============================================================================
create table if not exists public.rate_limit_logs (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid references public.users (id) on delete cascade,
  ip_address     text,               -- hashed IP for unauthenticated guard
  requests_count integer not null default 0,
  window_start   timestamptz not null default now(),
  blocked_until  timestamptz,
  created_at     timestamptz not null default now()
);
create index if not exists idx_rate_limit_user on public.rate_limit_logs (user_id, created_at desc);

-- ============================================================================
--  7) cost_alerts — background alert rows (from the Cron worker).
-- ============================================================================
create table if not exists public.cost_alerts (
  id         uuid primary key default gen_random_uuid(),
  -- 'cost_over_80pct_revenue' | 'user_burned_50pct_under_1h' | 'rate_abuse' ...
  type       text not null,
  severity   text not null default 'warning',   -- 'info'|'warning'|'critical'
  message    text not null,
  metadata   jsonb,
  resolved   boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_cost_alerts_open on public.cost_alerts (created_at desc) where resolved = false;

-- ============================================================================
--  8) subscriptions — subscription history (one row per subscription period).
-- ============================================================================
create table if not exists public.subscriptions (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.users (id) on delete cascade,
  plan       text not null,          -- 'starter'|'pro'|'max'
  price      numeric(10,2) not null,
  started_at timestamptz not null default now(),
  renews_at  timestamptz,
  status     text not null default 'active',  -- 'active'|'canceled'|'past_due'
  created_at timestamptz not null default now()
);
create index if not exists idx_subscriptions_user on public.subscriptions (user_id, created_at desc);

-- ============================================================================
--  9) model_pricing — SEPARATE from plans. The cost calculator reads this at
--     request time so per-operation cost can be retuned without touching plan
--     credit allocations. Costs are per 1,000,000 tokens (USD).
-- ============================================================================
create table if not exists public.model_pricing (
  id                          uuid primary key default gen_random_uuid(),
  model                       text not null,
  -- default safety margin for a service when this model is used for it.
  service_default_margin_pct  numeric(6,3) not null,
  input_cost_per_1m           numeric(12,6) not null,
  output_cost_per_1m          numeric(12,6) not null,
  service                     text,          -- optional service hint
  updated_at                  timestamptz not null default now()
);
create unique index if not exists uq_model_pricing_model_service
  on public.model_pricing (model, coalesce(service, ''));

-- Seed current pricing for GLM-5.2 (Cloudflare Workers AI, $0.011/1k neurons).
--   input : 127,273 neurons / 1M tok → $1.40 / 1M
--   output: 400,000  neurons / 1M tok → $4.40 / 1M
insert into public.model_pricing (model, service, service_default_margin_pct, input_cost_per_1m, output_cost_per_1m)
values
  ('@cf/zai-org/glm-5.2', 'chat',    20.0, 1.40, 4.40),
  ('@cf/zai-org/glm-5.2', 'website', 27.5, 1.40, 4.40),
  ('@cf/zai-org/glm-5.2', 'game',    35.0, 1.40, 4.40),
  ('@cf/zai-org/glm-5.2', 'tool',    35.0, 1.40, 4.40),
  ('@cf/zai-org/glm-5.2', 'mobile',  35.0, 1.40, 4.40)
on conflict (model, coalesce(service, '')) do update
  set input_cost_per_1m          = excluded.input_cost_per_1m,
      output_cost_per_1m         = excluded.output_cost_per_1m,
      service_default_margin_pct = excluded.service_default_margin_pct,
      updated_at                 = now();

-- ============================================================================
--  ROW LEVEL SECURITY
--  Enable RLS on all user-scoped tables. With RLS enabled and only the SELECT
--  policies below, the anon/authenticated keys can read their own rows and
--  NOTHING else (no INSERT/UPDATE/DELETE policy = those are denied to them).
--  The Worker's service-role key bypasses RLS entirely for privileged writes.
-- ============================================================================
alter table public.users               enable row level security;
alter table public.usage_windows       enable row level security;
alter table public.credit_transactions enable row level security;
alter table public.api_usage_logs      enable row level security;
alter table public.recharge_purchases  enable row level security;
alter table public.subscriptions       enable row level security;
-- Worker-only tables: RLS on, NO user policies → totally invisible to clients.
alter table public.rate_limit_logs     enable row level security;
alter table public.cost_alerts         enable row level security;
alter table public.model_pricing       enable row level security;

-- Own-row SELECT policies (drop-then-create for idempotency).
drop policy if exists p_users_self            on public.users;
create policy p_users_self            on public.users
  for select using (auth.uid() = id);

drop policy if exists p_windows_self          on public.usage_windows;
create policy p_windows_self          on public.usage_windows
  for select using (auth.uid() = user_id);

drop policy if exists p_credit_tx_self        on public.credit_transactions;
create policy p_credit_tx_self        on public.credit_transactions
  for select using (auth.uid() = user_id);

drop policy if exists p_api_usage_self        on public.api_usage_logs;
create policy p_api_usage_self        on public.api_usage_logs
  for select using (auth.uid() = user_id);

drop policy if exists p_recharge_self         on public.recharge_purchases;
create policy p_recharge_self         on public.recharge_purchases
  for select using (auth.uid() = user_id);

drop policy if exists p_subscriptions_self    on public.subscriptions;
create policy p_subscriptions_self    on public.subscriptions
  for select using (auth.uid() = user_id);

-- ============================================================================
--  Convenience: auto-provision a public.users row when a new auth user is
--  created, so the Worker never races an "unknown user" on first request.
-- ============================================================================
create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (id, email, tier, rate_limit_tier)
  values (new.id, new.email, 'free', 'free')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists trg_on_auth_user_created on auth.users;
create trigger trg_on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_auth_user();

-- ============================================================================
--  ADMIN + CRON RPC FUNCTIONS
-- ----------------------------------------------------------------------------
--  Supabase disables PostgREST aggregate functions by default (count/sum/avg
--  over arbitrary rows), and the admin dashboard needs cross-user aggregates
--  that RLS would otherwise block. These `security definer` functions run with
--  the definer's privileges (bypassing RLS) and are the ONLY sanctioned way to
--  read aggregated, cross-user data.
--
--  SECURITY: every function below is REVOKEd from public/anon/authenticated and
--  GRANTed ONLY to service_role. The Gateway Worker calls them via
--  POST /rest/v1/rpc/<fn> using the service-role key, and ONLY after the caller
--  has been verified as `is_admin` in Worker code. A logged-in non-admin user
--  therefore cannot reach these even with a valid JWT — PostgREST refuses the
--  RPC because the anon/authenticated roles lack EXECUTE.
--
--  1 credit == $0.001 (CREDIT_USD). credit_revenue_usd is derived as
--  credits_charged * credit_usd_value() everywhere, matching the Worker's
--  cost model (single source of truth below, so this never drifts out of
--  sync with worker/gateway.js's CREDIT_USD again).
-- ============================================================================

-- ── 0) credit_usd_value() ───────────────────────────────────────────────────
--  Single source of truth for the USD value of 1 credit, mirroring
--  worker/gateway.js's CREDIT_USD constant. Used everywhere below instead of
--  a repeated literal so there is exactly one place to update if it changes.
create or replace function public.credit_usd_value()
returns numeric
language sql
immutable
as $$ select 0.001::numeric $$;

-- ── 1) admin_overview(p_from, p_to) ─────────────────────────────────────────
--  Combined + per-service API cost vs. credit revenue and realized margin,
--  plus a recharge revenue summary. Excludes status='error' rows (failed
--  generations were never billed). Realized margin is guarded against a
--  divide-by-zero when there is no revenue yet.
--  p_from/p_to (both nullable) scope the aggregation to created_at in
--  [p_from, p_to); either or both null means "no bound" on that side (the
--  default null/null preserves the original all-time behavior).
drop function if exists public.admin_overview();
create or replace function public.admin_overview(p_from timestamptz default null, p_to timestamptz default null)
returns jsonb
language sql
security definer
set search_path = public
as $$
  with bill as (
    select service,
           count(*)::bigint                       as request_count,
           coalesce(sum(actual_cost_usd), 0)::numeric        as cost_usd,
           coalesce(sum(credits_charged), 0)::bigint         as credits_charged
    from public.api_usage_logs
    where status <> 'error'
      and (p_from is null or created_at >= p_from)
      and (p_to   is null or created_at <  p_to)
    group by service
  ),
  per_service as (
    select service, request_count, cost_usd, credits_charged,
           (credits_charged * public.credit_usd_value())::numeric as credit_revenue_usd,
           case when credits_charged * public.credit_usd_value() > 0
                then round(((credits_charged * public.credit_usd_value() - cost_usd) / (credits_charged * public.credit_usd_value()) * 100)::numeric, 2)
                else 0 end as realized_margin_pct
    from bill
  ),
  combined as (
    select coalesce(sum(request_count), 0)::bigint      as request_count,
           coalesce(sum(cost_usd), 0)::numeric          as cost_usd,
           coalesce(sum(credits_charged), 0)::bigint    as credits_charged,
           coalesce(sum(credit_revenue_usd), 0)::numeric as credit_revenue_usd
    from per_service
  ),
  recharge as (
    select count(*)::bigint as count,
           coalesce(sum(amount_usd), 0)::numeric as revenue_usd
    from public.recharge_purchases
    where status = 'completed'
  )
  select jsonb_build_object(
    'combined', jsonb_build_object(
      'request_count',      (select request_count from combined),
      'cost_usd',           (select cost_usd from combined),
      'credits_charged',    (select credits_charged from combined),
      'credit_revenue_usd', (select credit_revenue_usd from combined),
      'realized_margin_pct',
        case when (select credit_revenue_usd from combined) > 0
             then round((((select credit_revenue_usd from combined) - (select cost_usd from combined))
                         / (select credit_revenue_usd from combined) * 100)::numeric, 2)
             else 0 end
    ),
    'by_service', coalesce((select jsonb_agg(to_jsonb(per_service)) from per_service), '[]'::jsonb),
    'recharge', (select to_jsonb(recharge) from recharge),
    'generated_at', now()
  );
$$;

-- ── 2) admin_usage_by_model() ───────────────────────────────────────────────
--  Per-model / per-service token + cost breakdown (for the "usage by model"
--  admin view). model_pricing is decoupled from plans, so this is how spend is
--  attributed back to whichever model actually served each request.
create or replace function public.admin_usage_by_model()
returns table (
  model          text,
  service        text,
  request_count  bigint,
  input_tokens   bigint,
  output_tokens  bigint,
  cost_usd       numeric,
  credits_charged bigint
)
language sql
security definer
set search_path = public
as $$
  select model,
         service,
         count(*)::bigint                          as request_count,
         coalesce(sum(input_tokens), 0)::bigint     as input_tokens,
         coalesce(sum(output_tokens), 0)::bigint    as output_tokens,
         coalesce(sum(actual_cost_usd), 0)::numeric as cost_usd,
         coalesce(sum(credits_charged), 0)::bigint  as credits_charged
  from public.api_usage_logs
  where status <> 'error'
  group by model, service
  order by cost_usd desc;
$$;

-- ── 3) admin_recharge_stats() ───────────────────────────────────────────────
--  Recharge counts + revenue grouped by pack type and payment status.
create or replace function public.admin_recharge_stats()
returns table (
  type        text,
  status      text,
  count       bigint,
  revenue_usd numeric,
  credits_granted bigint
)
language sql
security definer
set search_path = public
as $$
  select type,
         status,
         count(*)::bigint,
         coalesce(sum(amount_usd), 0)::numeric,
         coalesce(sum(credits_granted), 0)::bigint
  from public.recharge_purchases
  group by type, status
  order by type, status;
$$;

-- ── 4) admin_cost_trend(p_from, p_to) ───────────────────────────────────────
--  Daily API cost vs. credit revenue within [p_from, p_to) (either/both
--  nullable = no bound on that side; default null/null = all time), for the
--  dashboard trend table. Zero-filled days are the frontend's job; this
--  returns only days that had activity.
drop function if exists public.admin_cost_trend(integer);
create or replace function public.admin_cost_trend(p_from timestamptz default null, p_to timestamptz default null)
returns table (
  day               date,
  request_count     bigint,
  cost_usd          numeric,
  credit_revenue_usd numeric
)
language sql
security definer
set search_path = public
as $$
  select (created_at at time zone 'UTC')::date as day,
         count(*)::bigint,
         coalesce(sum(actual_cost_usd), 0)::numeric,
         (coalesce(sum(credits_charged), 0) * public.credit_usd_value())::numeric
  from public.api_usage_logs
  where status <> 'error'
    and (p_from is null or created_at >= p_from)
    and (p_to   is null or created_at <  p_to)
  group by day
  order by day;
$$;

-- ── 5) admin_user_detail(p_uid) ─────────────────────────────────────────────
--  One user's full billing picture: profile, active window, recent windows,
--  recent credit transactions, per-model usage, and subscription history.
--  This is the drill-down behind GET /admin/user/:id.
create or replace function public.admin_user_detail(p_uid uuid)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select jsonb_build_object(
    -- Explicit field allowlist (not to_jsonb(u)) — only columns actually
    -- rendered by admin.html's openUserDrawer(). Excludes subscription_status,
    -- subscription_renews_at, rate_limit_tier, blocked_until, updated_at,
    -- ban_reason, banned_at and any other users columns.
    -- `subscription_started_at` and `lifetime_credits_used` (the latter added
    -- by db/schema_lifetime_free_cap.sql) are exceptions: together they let
    -- the admin drawer show which Free-Plan Lifetime Cap tier (1000 vs 100 -
    -- see LIFETIME_FREE_CAP_NEW/_RETURNING in worker/gateway.js) applies to
    -- this user and their best-effort-mirrored UserAccountDO.lifetimeUsed
    -- total - neither is read back to drive billing decisions.
    'user', (
      select jsonb_build_object(
        'id', u.id,
        'email', u.email,
        'tier', u.tier,
        'is_banned', u.is_banned,
        'is_blocked', u.is_blocked,
        'is_admin', u.is_admin,
        'created_at', u.created_at,
        'subscription_started_at', u.subscription_started_at,
        'lifetime_credits_used', u.lifetime_credits_used
      )
      from public.users u where u.id = p_uid
    ),
    -- Note: admin.html reads w.ends_at / w.credits_allotted, which do not
    -- match the real usage_windows columns (window_end / credits_allocated).
    -- This is a pre-existing frontend/column-name mismatch, unrelated to this
    -- fix — preserved as-is (real column names kept) rather than silently
    -- changed here.
    'active_window', (
      select jsonb_build_object(
        'window_end', w.window_end,
        'credits_allocated', w.credits_allocated,
        'credits_used', w.credits_used
      )
      from public.usage_windows w
      where w.user_id = p_uid and w.status = 'active'
      order by w.window_start desc limit 1
    ),
    'recent_windows', coalesce((
      select jsonb_agg(jsonb_build_object(
        'window_end', w.window_end,
        'credits_allocated', w.credits_allocated,
        'credits_used', w.credits_used
      ) order by w.window_start desc)
      from (
        select * from public.usage_windows
        where user_id = p_uid
        order by window_start desc limit 20
      ) w
    ), '[]'::jsonb),
    -- Note: admin.html reads tx.reason, which does not exist on
    -- credit_transactions (real column is `reference`) — same pre-existing
    -- mismatch, preserved as-is.
    'transactions', coalesce((
      select jsonb_agg(jsonb_build_object(
        'created_at', t.created_at,
        'type', t.type,
        'amount', t.amount,
        'reference', t.reference
      ) order by t.created_at desc)
      from (
        select * from public.credit_transactions
        where user_id = p_uid
        order by created_at desc limit 50
      ) t
    ), '[]'::jsonb),
    'usage_by_model', coalesce((
      select jsonb_agg(row_to_json(m))
      from (
        select model, service,
               count(*)::bigint                       as request_count,
               coalesce(sum(input_tokens), 0)::bigint as input_tokens,
               coalesce(sum(output_tokens), 0)::bigint as output_tokens,
               coalesce(sum(actual_cost_usd), 0)::numeric as cost_usd,
               coalesce(sum(credits_charged), 0)::bigint  as credits_charged
        from public.api_usage_logs
        where user_id = p_uid and status <> 'error'
        group by model, service
      ) m
    ), '[]'::jsonb),
    'subscription', (
      select jsonb_build_object(
        'plan', s.plan,
        'renews_at', s.renews_at
      )
      from public.subscriptions s
      where s.user_id = p_uid
      order by s.started_at desc limit 1
    )
  );
$$;

-- ── 6) cron_check_cost_alerts() ─────────────────────────────────────────────
--  Background alerting, run by the alerts-cron Worker (worker/alerts-cron.js)
--  every 5–15 min. Two checks, both inserting IDEMPOTENTLY so re-runs never
--  duplicate an open alert:
--    (a) per service, last-24h API cost > 80% of that service's credit revenue
--        → one open alert per (service, UTC day).
--    (b) any active window that has burned > 50% of its allocation while the
--        window itself is < 1h old (fast-drain / possible abuse or runaway)
--        → one open alert per window_id.
--  Returns the number of NEW alerts inserted this run.
create or replace function public.cron_check_cost_alerts()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_inserted integer := 0;
  r record;
begin
  -- (a) cost approaching / exceeding revenue, per service, rolling 24h.
  for r in
    select service,
           coalesce(sum(actual_cost_usd), 0)::numeric   as cost_usd,
           (coalesce(sum(credits_charged), 0) * public.credit_usd_value())::numeric as revenue_usd
    from public.api_usage_logs
    where status <> 'error'
      and created_at >= now() - interval '24 hours'
    group by service
    having (coalesce(sum(credits_charged), 0) * public.credit_usd_value()) > 0
       and coalesce(sum(actual_cost_usd), 0) > 0.80 * (coalesce(sum(credits_charged), 0) * public.credit_usd_value())
  loop
    insert into public.cost_alerts (type, severity, message, metadata)
    select 'cost_over_80pct_revenue',
           case when r.cost_usd >= r.revenue_usd then 'critical' else 'warning' end,
           format('Service "%s": 24h API cost $%s is over 80%% of credit revenue $%s',
                  r.service, round(r.cost_usd, 4), round(r.revenue_usd, 4)),
           jsonb_build_object('service', r.service, 'cost_usd', r.cost_usd,
                              'revenue_usd', r.revenue_usd, 'day', (now() at time zone 'UTC')::date)
    where not exists (
      select 1 from public.cost_alerts a
      where a.type = 'cost_over_80pct_revenue'
        and a.resolved = false
        and a.metadata->>'service' = r.service
        and (a.metadata->>'day')::date = (now() at time zone 'UTC')::date
    );
    v_inserted := v_inserted + (case when found then 1 else 0 end);
  end loop;

  -- (b) single window burning >50% of allocation in under an hour.
  for r in
    select id as window_id, user_id, credits_allocated, credits_used, window_start
    from public.usage_windows
    where status = 'active'
      and window_start >= now() - interval '1 hour'
      and credits_allocated > 0
      and credits_used > 0.50 * credits_allocated
  loop
    insert into public.cost_alerts (type, severity, message, metadata)
    select 'user_burned_50pct_under_1h',
           'warning',
           format('User %s burned %s/%s credits in under 1h', r.user_id, r.credits_used, r.credits_allocated),
           jsonb_build_object('user_id', r.user_id, 'window_id', r.window_id,
                              'credits_used', r.credits_used, 'credits_allocated', r.credits_allocated)
    where not exists (
      select 1 from public.cost_alerts a
      where a.type = 'user_burned_50pct_under_1h'
        and a.resolved = false
        and a.metadata->>'window_id' = r.window_id::text
    );
    v_inserted := v_inserted + (case when found then 1 else 0 end);
  end loop;

  return v_inserted;
end;
$$;

-- ── Lock the RPCs down to service_role only ─────────────────────────────────
--  Without these REVOKEs, PostgREST would expose the functions to any logged-in
--  (authenticated) user, who could then read cross-user aggregates. The Worker
--  is the only intended caller and it uses the service-role key.
revoke execute on function public.admin_overview(timestamptz, timestamptz)     from public, anon, authenticated;
revoke execute on function public.admin_usage_by_model()      from public, anon, authenticated;
revoke execute on function public.admin_recharge_stats()      from public, anon, authenticated;
revoke execute on function public.admin_cost_trend(timestamptz, timestamptz)   from public, anon, authenticated;
revoke execute on function public.admin_user_detail(uuid)     from public, anon, authenticated;
revoke execute on function public.cron_check_cost_alerts()    from public, anon, authenticated;

grant execute on function public.admin_overview(timestamptz, timestamptz)     to service_role;
grant execute on function public.admin_usage_by_model()      to service_role;
grant execute on function public.admin_recharge_stats()      to service_role;
grant execute on function public.admin_cost_trend(timestamptz, timestamptz)   to service_role;
grant execute on function public.admin_user_detail(uuid)     to service_role;
grant execute on function public.cron_check_cost_alerts()    to service_role;

-- ============================================================================
--  END OF SCHEMA
-- ============================================================================
