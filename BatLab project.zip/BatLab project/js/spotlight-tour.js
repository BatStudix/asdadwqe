/* ── Spotlight Tour engine ──────────────────────────────────────────────
   Generic, reusable step-by-step UI coachmark engine. Zero Supabase/business
   logic dependency — persistence (tour_state) lives entirely in the shim's
   saveTourState()/markTourSeen() helpers. This file only knows how to render
   a highlight + tooltip over a target element and walk through a list of
   steps; callers own everything else (what the steps are, when to start,
   what happens on skip/complete).

   Public API:
     window.SpotlightTour.start(steps, opts)   // opts: { onSkip, onComplete }
     window.SpotlightTour.next()
     window.SpotlightTour.skip()
     window.SpotlightTour.end()
     window.SpotlightTour.isActive()
     window.SpotlightTour.destroy()

   Step shape:
     {
       target: "#homeChips",              // CSS selector, re-resolved at step-entry (not cached)
       titleKey: "tour.home.step1.title",  // resolved via BatLang.t(key) at render time
       bodyKey:  "tour.home.step1.body",
       placement: "bottom",                // "top" | "bottom" | "left" | "right" | "auto"
       advance: "event",                   // "manual" (Next button) | "event" (auto-advance)
       event: { selector: "#homeChips .home-chip", type: "click" }, // only if advance === "event"
       allowSkip: true
     }
*/
(function (global) {
  'use strict';

  var steps = [];
  var stepIndex = -1;
  var active = false;
  var opts = {};
  var els = null; // lazily-built singleton DOM (backdrop/highlight/tooltip)
  var eventCleanup = null; // removes the current step's advance-on-event listener

  function t(key) {
    if (global.BatLang && typeof global.BatLang.t === 'function') {
      var v = global.BatLang.t(key);
      if (v !== undefined) return v;
    }
    return key;
  }

  function buildDom() {
    if (els) return els;

    // Click-blocking mask: 4 bands surrounding the highlighted target so
    // everything outside it is inert, while the target itself (no overlay
    // sits above it) keeps receiving clicks natively.
    var maskTop = document.createElement('div');
    maskTop.className = 'spotlight-mask-part spotlight-mask-top';
    var maskBottom = document.createElement('div');
    maskBottom.className = 'spotlight-mask-part spotlight-mask-bottom';
    var maskLeft = document.createElement('div');
    maskLeft.className = 'spotlight-mask-part spotlight-mask-left';
    var maskRight = document.createElement('div');
    maskRight.className = 'spotlight-mask-part spotlight-mask-right';

    var highlight = document.createElement('div');
    highlight.className = 'spotlight-highlight';

    var tooltip = document.createElement('div');
    tooltip.className = 'spotlight-tooltip';
    tooltip.innerHTML =
      '<div class="spotlight-step-count" id="spotlightStepCount"></div>' +
      '<div class="spotlight-title" id="spotlightTitle"></div>' +
      '<div class="spotlight-body" id="spotlightBody"></div>' +
      '<div class="spotlight-actions">' +
        '<button type="button" class="spotlight-skip" id="spotlightSkipBtn"></button>' +
        '<button type="button" class="spotlight-next" id="spotlightNextBtn"></button>' +
      '</div>';

    document.body.appendChild(maskTop);
    document.body.appendChild(maskBottom);
    document.body.appendChild(maskLeft);
    document.body.appendChild(maskRight);
    document.body.appendChild(highlight);
    document.body.appendChild(tooltip);

    tooltip.querySelector('#spotlightSkipBtn').addEventListener('click', function () {
      global.SpotlightTour.skip();
    });
    tooltip.querySelector('#spotlightNextBtn').addEventListener('click', function () {
      global.SpotlightTour.next();
    });

    els = {
      highlight: highlight, tooltip: tooltip,
      maskTop: maskTop, maskBottom: maskBottom, maskLeft: maskLeft, maskRight: maskRight
    };
    return els;
  }

  function currentStep() {
    return steps[stepIndex];
  }

  function clearEventListener() {
    if (eventCleanup) { eventCleanup(); eventCleanup = null; }
  }

  function reposition() {
    if (!active) return;
    var step = currentStep();
    if (!step) return;
    var target = document.querySelector(step.target);
    if (!target) {
      // Target vanished (e.g. view switched underneath the tour) — bail out safely.
      global.SpotlightTour.end();
      return;
    }
    var rect = target.getBoundingClientRect();
    var pad = 6;
    var hl = els.highlight;
    var hlLeft = rect.left - pad;
    var hlTop = rect.top - pad;
    var hlWidth = rect.width + pad * 2;
    var hlHeight = rect.height + pad * 2;
    hl.style.left = hlLeft + 'px';
    hl.style.top = hlTop + 'px';
    hl.style.width = hlWidth + 'px';
    hl.style.height = hlHeight + 'px';

    // Mask bands: everything outside the highlighted rect, split into 4
    // rectangles so the rect itself is left uncovered (target stays clickable).
    var vw = window.innerWidth, vh = window.innerHeight;
    var hlRight = hlLeft + hlWidth, hlBottom = hlTop + hlHeight;
    els.maskTop.style.left = '0px'; els.maskTop.style.top = '0px';
    els.maskTop.style.width = vw + 'px'; els.maskTop.style.height = Math.max(0, hlTop) + 'px';
    els.maskBottom.style.left = '0px'; els.maskBottom.style.top = Math.max(0, hlBottom) + 'px';
    els.maskBottom.style.width = vw + 'px'; els.maskBottom.style.height = Math.max(0, vh - hlBottom) + 'px';
    els.maskLeft.style.left = '0px'; els.maskLeft.style.top = Math.max(0, hlTop) + 'px';
    els.maskLeft.style.width = Math.max(0, hlLeft) + 'px'; els.maskLeft.style.height = hlHeight + 'px';
    els.maskRight.style.left = Math.max(0, hlRight) + 'px'; els.maskRight.style.top = Math.max(0, hlTop) + 'px';
    els.maskRight.style.width = Math.max(0, vw - hlRight) + 'px'; els.maskRight.style.height = hlHeight + 'px';

    var tip = els.tooltip;
    var tw = tip.offsetWidth || 280;
    var th = tip.offsetHeight || 120;
    var placement = step.placement || 'bottom';
    if (placement === 'auto') {
      placement = (rect.bottom + th + 16 < window.innerHeight) ? 'bottom' : 'top';
    }
    var left, top;
    if (placement === 'bottom') {
      left = rect.left + rect.width / 2 - tw / 2;
      top = rect.bottom + 14;
    } else if (placement === 'top') {
      left = rect.left + rect.width / 2 - tw / 2;
      top = rect.top - th - 14;
    } else if (placement === 'left') {
      left = rect.left - tw - 14;
      top = rect.top + rect.height / 2 - th / 2;
    } else { // right
      left = rect.right + 14;
      top = rect.top + rect.height / 2 - th / 2;
    }
    // Viewport-edge clamping (same idea as positionUsagePopup()).
    if (left < 8) left = 8;
    if (left + tw > window.innerWidth - 8) left = window.innerWidth - tw - 8;
    if (top < 8) top = 8;
    if (top + th > window.innerHeight - 8) top = window.innerHeight - th - 8;
    tip.style.left = left + 'px';
    tip.style.top = top + 'px';
  }

  function renderStep() {
    clearEventListener();
    var step = currentStep();
    if (!step) { global.SpotlightTour.end(); return; }

    var target = document.querySelector(step.target);
    if (!target) { global.SpotlightTour.end(); return; }

    var dom = buildDom();
    dom.tooltip.querySelector('#spotlightTitle').textContent = t(step.titleKey);
    dom.tooltip.querySelector('#spotlightBody').textContent = t(step.bodyKey);
    dom.tooltip.querySelector('#spotlightStepCount').textContent =
      (stepIndex + 1) + ' / ' + steps.length;

    var skipBtn = dom.tooltip.querySelector('#spotlightSkipBtn');
    skipBtn.style.display = (step.allowSkip === false) ? 'none' : '';
    skipBtn.textContent = t('tour.nav.skip');

    var nextBtn = dom.tooltip.querySelector('#spotlightNextBtn');
    var isLast = stepIndex === steps.length - 1;
    nextBtn.textContent = t(isLast ? 'tour.nav.done' : 'tour.nav.next');
    // Always show Next: even on "event" steps, it's an optional bypass for
    // users who don't want to perform the real action right now — the real
    // action still auto-advances instantly when it happens.
    nextBtn.style.display = '';

    reposition();

    if (step.advance === 'event' && step.event) {
      var onEvt = function (e) {
        if (e.target.closest && e.target.closest(step.event.selector)) {
          // Let the real click/input finish first, then advance.
          document.removeEventListener(step.event.type, onEvt, true);
          eventCleanup = null;
          setTimeout(function () { global.SpotlightTour.next(); }, 0);
        }
      };
      document.addEventListener(step.event.type, onEvt, { capture: true });
      // Must be manually removable (not {once:true}) so clicking "Next"
      // instead of performing the real action doesn't leave this listener
      // dangling — otherwise a later, unrelated occurrence of the same
      // action would wrongly fire next() again.
      eventCleanup = function () {
        document.removeEventListener(step.event.type, onEvt, true);
      };
    }
  }

  function attachGlobalListeners() {
    window.addEventListener('resize', reposition);
    window.addEventListener('scroll', reposition, true);
  }
  function detachGlobalListeners() {
    window.removeEventListener('resize', reposition);
    window.removeEventListener('scroll', reposition, true);
  }

  global.SpotlightTour = {
    start: function (stepList, options) {
      if (!Array.isArray(stepList) || !stepList.length) return;
      steps = stepList;
      stepIndex = 0;
      opts = options || {};
      active = true;
      buildDom();
      els.highlight.classList.add('open');
      els.tooltip.classList.add('open');
      els.maskTop.classList.add('open');
      els.maskBottom.classList.add('open');
      els.maskLeft.classList.add('open');
      els.maskRight.classList.add('open');
      attachGlobalListeners();
      renderStep();
    },
    next: function () {
      if (!active) return;
      clearEventListener();
      stepIndex++;
      if (stepIndex >= steps.length) {
        var onComplete = opts.onComplete;
        global.SpotlightTour.end();
        if (typeof onComplete === 'function') onComplete();
        return;
      }
      renderStep();
    },
    skip: function () {
      if (!active) return;
      var onSkip = opts.onSkip;
      global.SpotlightTour.end();
      if (typeof onSkip === 'function') onSkip();
    },
    end: function () {
      if (!active) return;
      active = false;
      clearEventListener();
      detachGlobalListeners();
      if (els) {
        els.highlight.classList.remove('open');
        els.tooltip.classList.remove('open');
        els.maskTop.classList.remove('open');
        els.maskBottom.classList.remove('open');
        els.maskLeft.classList.remove('open');
        els.maskRight.classList.remove('open');
      }
      steps = [];
      stepIndex = -1;
      opts = {};
    },
    isActive: function () { return active; },
    destroy: function () {
      global.SpotlightTour.end();
      if (els) {
        els.highlight.remove();
        els.tooltip.remove();
        els.maskTop.remove();
        els.maskBottom.remove();
        els.maskLeft.remove();
        els.maskRight.remove();
        els = null;
      }
    }
  };
})(window);
