// js/creditConfig.js
//
// Display-only cost-preview config. Mirrors the *real* cost formulas and
// constants from worker/gateway.js (CREDIT_USD, DEFAULT_MODEL_COST,
// SERVICE_LIMITS, chatTierCredits) so the numbers shown to the user in the
// UI can never drift out of sync with how credits are actually calculated
// server-side.
//
// IMPORTANT: this file NEVER performs or influences real billing. The
// gateway (worker/gateway.js) remains the sole authority for what a user is
// actually charged. If you change the constants below, they must match
// gateway.js's Section 2 "COST CALCULATOR" constants exactly, or the
// preview shown to users will be wrong.

export const CREDIT_USD = 0.001; // 1 credit === $0.001 of budget

/** Fallback token pricing (USD per 1,000,000 tokens), mirrors gateway.js's DEFAULT_MODEL_COST. */
export const DEFAULT_MODEL_COST = {
  // bat 1.2 (Prime) - Workers AI, called directly (no AI Gateway, no BYOK).
  '@cf/moonshotai/kimi-k2.7-code': { inputPer1M: 0.95, outputPer1M: 4.00 },
  // bat 1.2 flash - Workers AI, called directly (no AI Gateway, no BYOK).
  '@cf/meta/llama-4-scout-17b-16e-instruct': { inputPer1M: 0.27, outputPer1M: 0.85 },
  // bat 1.2 core - Workers AI, called directly (no AI Gateway, no BYOK).
  '@cf/nvidia/nemotron-3-120b-a12b': { inputPer1M: 0.50, outputPer1M: 1.50 },
  // bat 2.2 (Marketing eco, /chat/marketing-eco) - Workers AI, called
  // directly (no AI Gateway, no BYOK). Mirrors gateway.js exactly.
  '@cf/google/gemma-4-26b-a4b-it': { inputPer1M: 0.10, outputPer1M: 0.30 },
};
const DEFAULT_MODEL = '@cf/moonshotai/kimi-k2.7-code';

/** Per-service safety ceilings + margin band, mirrors gateway.js's SERVICE_LIMITS. */
export const SERVICE_LIMITS = {
  chat:        { maxInput: 6000, maxOutput: 16384, margin: 0.20  },
  chat_flash:  { maxInput: 6000, maxOutput: 16384, margin: 0.20  },
  // bat 1.2 core (@cf/nvidia/nemotron-3-120b-a12b) - 4096 here is an
  // intentional product/design cap, NOT a hard model ceiling (unlike the
  // old minimax/m3, which really did max out at 4096 completion tokens).
  chat_core:   { maxInput: 6000, maxOutput: 4096,  margin: 0.20  },
  // bat 2.2 (Marketing eco, @cf/google/gemma-4-26b-a4b-it) - same shape as
  // chat_flash (long-form analysis, generous output ceiling).
  chat_marketing_eco: { maxInput: 6000, maxOutput: 16384, margin: 0.20 },
  website:     { maxInput: 3000, maxOutput: 16000, margin: 0.275 },
  game:        { maxInput: 2000, maxOutput: 8192,  margin: 0.35  },
  tool:        { maxInput: 2000, maxOutput: 8192,  margin: 0.35  },
  mobile:      { maxInput: 2000, maxOutput: 8192,  margin: 0.35  },
};

function costUsd(inTok, outTok, model) {
  const p = DEFAULT_MODEL_COST[model] || DEFAULT_MODEL_COST[DEFAULT_MODEL];
  return inTok * (p.inputPer1M / 1e6) + outTok * (p.outputPer1M / 1e6);
}

function creditsFromUsd(usd, margin) {
  return Math.ceil((usd * (1 + margin)) / CREDIT_USD);
}

/** Max credits a single op of this service could ever cost (reserve-time ceiling). */
export function maxCreditsFor(service, model) {
  const lim = SERVICE_LIMITS[service] || SERVICE_LIMITS.game;
  return creditsFromUsd(costUsd(lim.maxInput, lim.maxOutput, model || DEFAULT_MODEL), lim.margin);
}

/**
 * bat 2.2 (Marketing eco) credit-tier config. Display-only mirror of
 * gateway.js's CHAT_MARKETING_ECO_TIER_CONFIG / chatMarketingEcoTierCredits()
 * exactly. Same shape/mechanics as CHAT_FLASH_TIER_CONFIG below (flat tiers
 * by real output tokens + dynamic overflow above the top tier), priced
 * against @cf/google/gemma-4-26b-a4b-it's per-token cost.
 */
export const CHAT_MARKETING_ECO_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 1 },
    { maxOutput: 300,  credits: 1 },
    { maxOutput: 700,  credits: 1 },
    { maxOutput: 1500, credits: 2 },
    { maxOutput: 3000, credits: 2 },
    { maxOutput: 5000, credits: 3 },
    { maxOutput: 8000, credits: 4 },
  ],
  safetyMultiplier: 1.4,
  creditValueUsd: CREDIT_USD,
};

/** Display-only mirror of gateway.js's chatMarketingEcoTierCredits(). */
export function chatMarketingEcoTierCredits(outputTokens, inputTokens, model) {
  for (const tier of CHAT_MARKETING_ECO_TIER_CONFIG.tiers) {
    if (outputTokens < tier.maxOutput) return tier.credits;
  }
  const cost = costUsd(inputTokens || 0, outputTokens, model || '@cf/google/gemma-4-26b-a4b-it');
  return Math.ceil((cost * CHAT_MARKETING_ECO_TIER_CONFIG.safetyMultiplier) / CHAT_MARKETING_ECO_TIER_CONFIG.creditValueUsd);
}

/**
 * Chat credit-tier config (Phase 4), mirrors gateway.js's CHAT_TIER_CONFIG /
 * chatTierCredits() exactly. Fixed tiers up to 8000 output tokens, then a
 * dynamic cost-based formula above that. Keep in sync with gateway.js.
 */
export const CHAT_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 7  },
    { maxOutput: 300,  credits: 8  },
    { maxOutput: 700,  credits: 10 },
    { maxOutput: 1500, credits: 14 },
    { maxOutput: 3000, credits: 20 },
    { maxOutput: 5000, credits: 29 },
    { maxOutput: 8000, credits: 43 },
  ],
  safetyMultiplier: 1.4,
  creditValueUsd: CREDIT_USD,
};

/** Display-only mirror of gateway.js's chatTierCredits(). */
export function chatTierCredits(outputTokens, inputTokens, model) {
  for (const tier of CHAT_TIER_CONFIG.tiers) {
    if (outputTokens < tier.maxOutput) return tier.credits;
  }
  const cost = costUsd(inputTokens || 0, outputTokens, model || DEFAULT_MODEL);
  return Math.ceil((cost * CHAT_TIER_CONFIG.safetyMultiplier) / CHAT_TIER_CONFIG.creditValueUsd);
}

/** Display-only mirror of gateway.js's CHAT_FLASH_TIER_CONFIG (bat 1.2 flash). */
export const CHAT_FLASH_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 2  },
    { maxOutput: 300,  credits: 3  },
    { maxOutput: 700,  credits: 3  },
    { maxOutput: 1500, credits: 4  },
    { maxOutput: 3000, credits: 5  },
    { maxOutput: 5000, credits: 7  },
    { maxOutput: 8000, credits: 10 },
  ],
  safetyMultiplier: 1.4,
  creditValueUsd: CREDIT_USD,
};

/** Display-only mirror of gateway.js's chatFlashTierCredits(). */
export function chatFlashTierCredits(outputTokens, inputTokens, model) {
  for (const tier of CHAT_FLASH_TIER_CONFIG.tiers) {
    if (outputTokens < tier.maxOutput) return tier.credits;
  }
  const cost = costUsd(inputTokens || 0, outputTokens, model || '@cf/meta/llama-4-scout-17b-16e-instruct');
  return Math.ceil((cost * CHAT_FLASH_TIER_CONFIG.safetyMultiplier) / CHAT_FLASH_TIER_CONFIG.creditValueUsd);
}

/** Display-only mirror of gateway.js's CHAT_CORE_TIER_CONFIG (bat 1.2 core,
 *  @cf/nvidia/nemotron-3-120b-a12b). NO dynamic/overflow tier: 4096 is an
 *  intentional product/design cap for this service, not a hard model ceiling. */
export const CHAT_CORE_TIER_CONFIG = {
  tiers: [
    { maxOutput: 100,  credits: 4  },
    { maxOutput: 300,  credits: 4  },
    { maxOutput: 700,  credits: 5  },
    { maxOutput: 1500, credits: 6  },
    { maxOutput: 3000, credits: 9  },
    { maxOutput: 4096, credits: 11 }, // terminal tier - 4096 is a design cap, not a hard model ceiling
  ],
};

/** Display-only mirror of gateway.js's chatCoreTierCredits(). Inclusive "<=" boundary,
 *  matching gateway.js exactly (4096 is a real, literal ceiling, not a generous bound). */
export function chatCoreTierCredits(outputTokens) {
  for (const tier of CHAT_CORE_TIER_CONFIG.tiers) {
    if (outputTokens <= tier.maxOutput) return tier.credits;
  }
  return CHAT_CORE_TIER_CONFIG.tiers[CHAT_CORE_TIER_CONFIG.tiers.length - 1].credits;
}

/** Display metadata per service: label + credit range shown in the cost-preview UI. */
export const SERVICE_COST_INFO = {
  chat: {
    label: 'BAT 5 Prime',
    min: CHAT_TIER_CONFIG.tiers[0].credits,
    max: chatTierCredits(SERVICE_LIMITS.chat.maxOutput, SERVICE_LIMITS.chat.maxInput),
  },
  chat_flash: {
    label: 'BAT 1.0 Flash',
    min: CHAT_FLASH_TIER_CONFIG.tiers[0].credits,
    max: chatFlashTierCredits(SERVICE_LIMITS.chat_flash.maxOutput, SERVICE_LIMITS.chat_flash.maxInput),
  },
  chat_core: {
    label: 'BAT 1.4 Core',
    min: CHAT_CORE_TIER_CONFIG.tiers[0].credits,
    max: chatCoreTierCredits(SERVICE_LIMITS.chat_core.maxOutput),
  },
  chat_marketing_eco: {
    label: 'BAT 1.1',
    min: CHAT_MARKETING_ECO_TIER_CONFIG.tiers[0].credits,
    max: chatMarketingEcoTierCredits(SERVICE_LIMITS.chat_marketing_eco.maxOutput, SERVICE_LIMITS.chat_marketing_eco.maxInput),
  },
  // Marketing's "Prime" tab routes through the same /chat + Kimi service as
  // Home chat's own Prime tier (see chat_marketing_prime is NOT a distinct
  // SERVICE_LIMITS/tier-config entry — it deliberately reuses CHAT_TIER_CONFIG
  // and SERVICE_LIMITS.chat as-is, since the underlying route/model/credits
  // are identical to `chat`). This entry exists purely so Marketing's
  // composer tab and cost-preview can show a distinct display label
  // ("BAT 5.6 Growth") without renaming Home chat's own "BAT 5 Prime" label.
  chat_marketing_prime: {
    label: 'BAT 5.6 Growth',
    min: CHAT_TIER_CONFIG.tiers[0].credits,
    max: chatTierCredits(SERVICE_LIMITS.chat.maxOutput, SERVICE_LIMITS.chat.maxInput),
  },
  website: { label: 'Website Generation',    min: null, max: maxCreditsFor('website') },
  game:    { label: 'Game Generation',       min: null, max: maxCreditsFor('game') },
  tool:    { label: 'App / Tool Generation', min: null, max: maxCreditsFor('tool') },
};

/** Reserved for future service types — no cost data defined yet. */
export const FUTURE_SERVICES = {
  image: null, video: null, voice: null, agent: null, code_review: null, deep_research: null,
};

/** Display-only mirror of gateway.js's MOONDREAM_FLAT_SURCHARGE_CREDITS — the
 *  flat additive credits charged on top of the normal chat/chat_flash/chat_core
 *  tier charge whenever an attached image is analyzed by Moondream as part of
 *  chat's image-preprocessing pipeline (see applyImagePreprocessing() in
 *  worker/worker.js and the surcharge logic in settle() in worker/gateway.js). */
export const MOONDREAM_SURCHARGE_CREDITS = 5;

/** Display-only mirror of gateway.js's MARKETING_EXTRACT_FLAT_CREDITS — the
 *  flat per-call credit charge for /marketing/extract (server-side URL fetch
 *  + env.AI.toMarkdown(), or uploaded-file + env.AI.toMarkdown()). */
export const MARKETING_EXTRACT_FLAT_CREDITS = 5;

/**
 * Returns a short human-readable cost-preview string for a service, e.g.
 * "~5-20 credits" (chat) or "up to ~96 credits" (website). Returns '' for
 * unknown/future services.
 */
export function formatCostPreview(service) {
  const info = SERVICE_COST_INFO[service];
  if (!info) return '';
  if (info.min == null) return `up to ~${info.max} credits`;
  return `~${info.min}-${info.max} credits`;
}
