import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { tryTemplatePipeline, TEMPLATE_STAGE_LABELS } from './templates/index.js';
import { SERVICE_COST_INFO, formatCostPreview, MOONDREAM_SURCHARGE_CREDITS } from './creditConfig.js';

    let currentUser = null;
    let currentCredits = 0;
    let currentPlan = 'free';
    // Boot gate: true once the first authoritative account resolution has run
    // (refreshAccountState success OR the guest fallback). Until then the
    // credit fraction widget shows a neutral placeholder instead of a possibly
    // stale/negative cached value, and the #appBootSkeleton overlay stays up.
    let _accountReady = false;
    // Funnel called by every "account resolved" path (logged-in /me success and
    // the guest fallback). Idempotent: flips the gate once, repaints credits with
    // the now-trusted value, and dismisses the boot skeleton.
    function markAccountReady() {
      if (_accountReady) return;
      _accountReady = true;
      try { if (typeof window.updateCreditDisplay === 'function') window.updateCreditDisplay(); } catch (_) {}
      try { if (typeof window.renderAllCreditWidgets === 'function') window.renderAllCreditWidgets(); } catch (_) {}
      try { if (typeof window._hideBootSkeleton === 'function') window._hideBootSkeleton(); } catch (_) {}
    }
    // Boot-skeleton timing controller. Shows on first paint (the element is in
    // static HTML, opacity:1), then hides once markAccountReady() fires — but no
    // sooner than MIN (avoids a jarring sub-frame flash) and no later than MAX
    // (a hard cap so a slow/stalled /me can never trap the user behind it).
    (function () {
      const MIN_MS = 400, MAX_MS = 2000, FADE_MS = 350;
      const el = document.getElementById('appBootSkeleton');
      if (!el) { window._hideBootSkeleton = function () {}; return; }
      const startedAt = Date.now();
      let hidden = false;
      function remove() {
        if (el && el.parentNode) el.parentNode.removeChild(el);
      }
      function hide() {
        if (hidden) return;
        hidden = true;
        const elapsed = Date.now() - startedAt;
        const wait = Math.max(0, MIN_MS - elapsed);
        setTimeout(function () {
          el.classList.add('hiding');
          setTimeout(remove, FADE_MS + 40);
        }, wait);
      }
      window._hideBootSkeleton = hide;
      // Hard safety cap: never leave the skeleton up past MAX, even if account
      // resolution never fires. Also flip the gate so credits stop showing '—'.
      setTimeout(function () { _accountReady = true; hide(); }, MAX_MS);
    })();
    let currentDisplayName = '';
    let currentAboutMe = '';
    let memoryEnabled = false;
    let userMemories = []; // [{id, content, created_at}] — auto/manual facts remembered about the user
    let selectedType = "";
    let seoEnabled = true; // Auto SEO is always enabled (no user-facing toggle)
    // Per-window credit allocation (usage windows replace calendar resets — server-enforced).
    const PLAN_MAX = { free: 200, starter: 100, pro: 160, max: 800 };
    // Window length in hours per tier (used only for display copy; server is source of truth).
    const PLAN_WINDOW_HOURS = { free: 24, starter: 8, pro: 5, max: 5 };

    /* ── Home inline chat state (declared early to avoid TDZ in syncFooter) ── */
    let homeConvHistory = [];
    let homeConvActive = false;
    let homeConvSessionId = null;
    let homeChatSessions = [];

    /* ── Marketing view state — fully separate from the Home composer above
       (own history/model/attachment, never touches selectedType/selectedModel
       or getChatSystem()) so this feature carries zero risk to the existing
       chat/build flow. See plan at .claude/plans/magical-growing-flute.md. ── */
    let marketingSelectedModel = 'BAT 2.2'; // 'BAT 2.2' (Gemma, eco) | 'BAT 2.2 Prime' (Kimi)
    let marketingHistory = [];
    let marketingAttachedFiles = []; // Array<{ name, size, base64 } | { name, size, text }>, capped at MARKETING_ATTACH_MAX_FILES
    let marketingBusy = false;
    // Set true by window.marketingGoDeeper right before it calls
    // sendMarketingMessage(), so the next turn's thinking-status text uses the
    // "Digging deeper..." context line. Consumed (reset) at the top of send.
    let _marketingGoDeeperPending = false;

    /* ── Chats view (full list, separate from the sidebar's capped-at-20 cache) ── */
    let chatsViewSessions = [];
    let chatsSearchQuery = '';
    let chatsSelectionMode = false;
    let chatsSelectedIds = new Set();

    /* ── Gateway (single authenticated entry point — subscription/credit/rate-limit
       enforcement now lives server-side in the Cloudflare gateway Worker). ── */
    const GATEWAY_URL = "https://gateway.mustafathth123.workers.dev";

    // Client-side mirror of worker/gateway.js's RECHARGE pricing table (spec §4).
    // Display-only — the server re-validates tier + price on every /recharge/:type
    // call, so this table drifting out of sync would only affect displayed price,
    // never the amount actually charged/granted.
    const RECHARGE_PRICES = {
      full_refill: { free: 1.49, starter: 2.49, pro: 3.49, max: 12.99 },
    };
    const CUSTOM_AMOUNT_USD_PER_CREDIT = 0.003;
    const CUSTOM_AMOUNT_MIN_CREDITS = 100;
    const CUSTOM_AMOUNT_MAX_CREDITS = 2000;
    const CUSTOM_AMOUNT_STEP_CREDITS = 50;

    // Client-side mirror of worker/gateway.js's Weekly Usage Cap system
    // (WEEKLY_CAP_CREDITS / WEEKLY_RESET_USD). Display-only — the server
    // re-validates tier + price on every /weekly-reset call. Free has no
    // weekly cap (null) so it's omitted from both tables below.
    const WEEKLY_CAP_CREDITS = { starter: 1050, pro: 2240, max: 15000 };
    const WEEKLY_RESET_PRICES = { starter: 2.99, pro: 5.99, max: 19.99 };
    const WEEKLY_CAP_WARNING_RATIO = 0.8;

    /* ── BatCache: tiny localStorage-backed stale-while-revalidate cache ──
       Used to paint the last-known username/avatar/plan/credits/recent-chat
       list instantly on load, before the network round-trip finishes. No
       TTL/expiry — cached values are always shown immediately, then silently
       overwritten once a live fetch resolves (see hydrateFromCache/loadUser). */
    const BatCache = {
      get(key) {
        try {
          const raw = localStorage.getItem(key);
          if (!raw) return null;
          const env = JSON.parse(raw);
          return (env && 'v' in env) ? env.v : null;
        } catch (e) { return null; }
      },
      set(key, value) {
        try { localStorage.setItem(key, JSON.stringify({ v: value, t: Date.now() })); } catch (e) {}
      }
    };
    const BATNXT_CACHE_PROFILE = 'batnxt_cache_profile';
    const BATNXT_CACHE_ACCOUNT = 'batnxt_cache_account';
    const BATNXT_CACHE_HOME_CHATS = 'batnxt_cache_home_chats';

    /* ── fadeInSwap: retrigger a short fade/slide-in CSS animation on an
       element (used when skeleton/cached content is replaced by live data) ── */
    function fadeInSwap(el) {
      if (!el) return;
      el.classList.remove('fade-swap-in');
      void el.offsetWidth; // force reflow so the animation restarts
      el.classList.add('fade-swap-in');
    }
    window.fadeInSwap = fadeInSwap;

    async function getAccessToken() {
      try {
        const { data } = await supabase.auth.getSession();
        return (data && data.session && data.session.access_token) || null;
      } catch (e) {
        return null;
      }
    }

    function handleSoftWarning(warning) {
      const lang = BatLang.lang;
      let msg;
      if (warning === 'soft_90') {
        msg = lang === 'ar' ? 'تنبيه: استهلكت 90% من رصيدك لهذه الفترة.'
          : lang === 'tr' ? "Uyarı: bu pencerede kredinizin %90'ını kullandınız."
          : "Heads up: you've used 90% of your credits for this window.";
      } else {
        msg = lang === 'ar' ? 'تنبيه: استهلكت 80% من رصيدك لهذه الفترة.'
          : lang === 'tr' ? "Uyarı: bu pencerede kredinizin %80'ini kullandınız."
          : "Heads up: you've used 80% of your credits for this window.";
      }
      showToast(msg, 'warning');
    }

    // Live mm:ss/hh:mm:ss countdown shown on the out-of-credits screen — computed
    // client-side from the server's windowEndsAt ISO timestamp (server remains the
    // source of truth; this is display-only and never gates access itself).
    let _outOfCreditsInterval = null;
    function stopOutOfCreditsCountdown() {
      if (_outOfCreditsInterval) { clearInterval(_outOfCreditsInterval); _outOfCreditsInterval = null; }
    }
    // Hours:minutes only (no seconds) — reset/refill countdowns show HH:MM so
    // the time reads calmly instead of ticking every second. Floors to the
    // minute (drops the seconds), matching "23:17:12" → "23:17".
    function formatCountdown(ms) {
      if (!(ms > 0)) return '00:00';
      const totalMin = Math.floor(ms / 60000);
      const h = String(Math.floor(totalMin / 60)).padStart(2, '0');
      const m = String(totalMin % 60).padStart(2, '0');
      return h + ':' + m;
    }

    let _lastWindowEndsAt = null;
    // Which _lastWindowEndsAt value we've already fired a resync /me call
    // for (see creditWindowState() below) — one-shot per stale windowEnd,
    // NOT a time throttle, because the server only ever renews the window
    // lazily inside reserve() (a real billed request), never inside /me's
    // getState(). A time-based throttle would keep re-firing /me forever
    // (every few seconds, indefinitely) for any user whose window has
    // expired but who hasn't sent a new message yet, since each resync
    // just gets back the exact same still-expired windowEnd — this caused
    // an infinite /me polling loop that got users' IPs rate-limited
    // (fixed 2026-07-23). Resets naturally once _lastWindowEndsAt actually
    // changes (a real new window opened server-side).
    let _lastResyncedWindowEnd = null;
    // Real server-confirmed allocation for the current window (from /me's
    // window.creditsAllocated) — used as the widget's "max" denominator so a
    // plan-config-overridden window (see gateway.js PLANS/effectivePlan())
    // displays correctly instead of falling back to the static PLAN_MAX
    // table. Null until the first /me response arrives.
    let _lastWindowAllocated = null;
    // Mirrors /me's `lifetime` object (see gateway.js UserAccountDO.getState()):
    // { used, cap }. `cap` is null for paid tiers (the Free-Plan Lifetime
    // Credit Cap - see LIFETIME_FREE_CAP_NEW/_RETURNING in gateway.js - only
    // ever applies to the free tier). Null until the first /me response.
    let _lastLifetime = null;
    // Mirrors /me's `nextRechargeAt` (ISO timestamp, or null) — set while a
    // "Recharge Now" cooldown is active (see gateway.js RECHARGE_COOLDOWN_DAYS).
    // Null/past means recharging is currently allowed.
    let _lastNextRechargeAt = null;
    // Mirrors /me's `weekly` object (see gateway.js UserAccountDO.getState()):
    // { usage, cap, periodStart, resetAt, warningRatio }. `cap` is null for
    // tiers with no weekly ceiling (free). Null until the first /me response.
    let _lastWeekly = null;

    // ── Shared live credit-window engine ──
    // Single source of truth for the "lazy-start" reset countdown: the window
    // doesn't run on a fixed clock — it only begins once the user sends their
    // first message after the previous window ended (_lastWindowEndsAt stays
    // null until then). Every credit display in the app (Settings, Billing,
    // home indicator, out-of-credits modal) renders from this same state via
    // renderCreditWidget(), driven by a single shared 1s ticker (see
    // startCreditsTicker below) instead of each display having its own timer.
    function creditWindowState() {
      // Prefer the real server-confirmed allocation once known (handles the
      // trial-reduced-credits case correctly); fall back to the static table
      // only before the first /me response has arrived.
      const max = _lastWindowAllocated || PLAN_MAX[currentPlan] || PLAN_MAX.free;
      let started = !!_lastWindowEndsAt;
      let remainingMs = started ? (new Date(_lastWindowEndsAt).getTime() - Date.now()) : null;
      if (started && remainingMs <= 0) {
        // The local countdown has elapsed — show credits as reset (100%)
        // immediately for a snappy UI, while confirming the real state with
        // the server ONCE per distinct expired windowEnd (not a repeating
        // timer — see _lastResyncedWindowEnd comment above). /me never
        // renews the window itself, so retrying this on a timer would just
        // keep re-confirming the same still-expired value forever.
        started = false;
        remainingMs = null;
        if (_lastResyncedWindowEnd !== _lastWindowEndsAt) {
          _lastResyncedWindowEnd = _lastWindowEndsAt;
          refreshAccountState();
        }
      }
      const exhausted = started && currentCredits <= 0;
      const pct = started ? Math.max(0, Math.min(100, (currentCredits / max) * 100)) : 100;
      return { max, pct, started, remainingMs, exhausted };
    }

    // Renders one credit widget (a set of DOM element IDs) from the shared
    // state above. `ids`: { numEl, fillEl, periodEl, bannerEl, fraction, verbose }.
    // - fraction: numEl shows "X / Y credits" instead of just "X"
    // - verbose: periodEl uses the long explainer copy (Settings/Billing) vs.
    //   the compact copy (home indicator near the send button)
    function renderCreditWidget(ids) {
      const s = creditWindowState();
      const lang = BatLang.lang;
      const hrs = PLAN_WINDOW_HOURS[currentPlan] || 24;

      if (ids.numEl) {
        const el = document.getElementById(ids.numEl);
        if (el) {
          if (ids.fraction && !_accountReady) {
            // Boot gate: before the first authoritative account resolution the
            // fraction ("X / Y credits") could paint a stale/negative cached
            // value. Show a neutral placeholder until markAccountReady() fires.
            el.textContent = '— / ' + s.max + ' credits';
          } else {
            const shown = s.started ? currentCredits : s.max;
            el.textContent = ids.fraction ? (shown + ' / ' + s.max + ' credits') : String(shown);
          }
        }
      }
      if (ids.fillEl) {
        const el = document.getElementById(ids.fillEl);
        if (el) {
          el.style.width = s.pct + '%';
          el.style.background = s.exhausted || s.pct <= 20 ? 'var(--red)' : s.pct <= 50 ? '#facc15' : 'var(--accent)';
        }
      }
      if (ids.bannerEl) {
        const el = document.getElementById(ids.bannerEl);
        if (el) el.classList.toggle('show', s.exhausted);
      }
      if (ids.periodEl) {
        const el = document.getElementById(ids.periodEl);
        if (el && ids.shortReset) {
          // Popup mode: nothing while the window hasn't started, otherwise a
          // live "Full in HH:MM" countdown (matches the Settings reset timer,
          // hours:minutes, no seconds) instead of a coarse whole-hour value.
          let text = '';
          if (s.started) {
            const cd = formatCountdown(s.remainingMs);
            if (lang === 'ar') {
              text = 'يمتلئ خلال ' + cd;
            } else if (lang === 'tr') {
              text = cd + ' sonra dolu';
            } else {
              text = 'Full in ' + cd;
            }
          }
          el.textContent = text;
        } else if (el) {
          let text;
          if (!s.started) {
            text = ids.verbose
              ? (lang === 'ar' ? ('يبلش العداد لما تبعت أول رسالة، وبيتجدد كل ' + hrs + ' ساعة بعدها')
                 : lang === 'tr' ? ('Sayaç ilk mesajını gönderdiğinde başlar, ardından her ' + hrs + ' saatte bir yenilenir')
                 : ('Resets every ' + (hrs === 24 ? '1 day' : hrs + 'h') + ', starts counting after your first message'))
              : (lang === 'ar' ? ('كل ' + hrs + ' س') : lang === 'tr' ? (hrs + ' saatte bir') : ('every ' + hrs + 'h'));
          } else if (s.exhausted) {
            const cd = formatCountdown(s.remainingMs);
            text = ids.verbose
              ? (lang === 'ar' ? ('نفذ رصيدك — استنى ' + cd) : lang === 'tr' ? ('Krediniz bitti — ' + cd + ' bekleyin') : ('Out of credits — wait ' + cd))
              : (lang === 'ar' ? ('استنى ' + cd) : lang === 'tr' ? (cd + ' bekleyin') : ('wait ' + cd));
          } else {
            const cd = formatCountdown(s.remainingMs);
            text = ids.verbose
              ? (lang === 'ar' ? ('يتجدد خلال ' + cd) : lang === 'tr' ? (cd + ' içinde yenilenir') : ('Resets in ' + cd))
              : cd;
          }
          el.textContent = text;
        }
      }
    }

    // Re-renders every known credit widget across the app from current
    // state. Cheap no-op for widgets whose elements aren't in the DOM right
    // now (e.g. Settings modal closed) since getElementById just returns null.
    function renderAllCreditWidgets() {
      renderCreditWidget({ numEl: 'settingsCredsNum', fillEl: 'settingsCreditsFill', periodEl: 'settingsCredsReset', fraction: true, verbose: true });
      renderCreditWidget({ numEl: 'billingCredsNum', fillEl: 'billingCreditsFill', periodEl: 'billingCredsReset', fraction: true, verbose: true });
      // Composer pill: fill only (no visible number/period text there anymore).
      renderCreditWidget({ fillEl: 'homeCredsFill', bannerEl: 'creditsZeroBanner' });
      // Marketing composer mirrors the same live fill (no separate banner there).
      renderCreditWidget({ fillEl: 'marketingCredsFill' });
      // Usage popup content: fraction ("200 / 200 credits") + short reset text
      // ("Full in Xh"), shown only while a timer is actually running.
      renderCreditWidget({ numEl: 'homeCredsNum', fillEl: 'homeCredsFillPopup', periodEl: 'homeCredsPeriod', fraction: true, shortReset: true });
      const timerEl = document.getElementById('outOfCreditsTimer');
      if (timerEl) {
        const s = creditWindowState();
        timerEl.textContent = s.started ? formatCountdown(s.remainingMs) : '00:00';
      }
    }
    window.renderAllCreditWidgets = renderAllCreditWidgets;

    // Renders the Billing-tab Free-Plan Lifetime Credit Cap section (progress
    // bar + blocked banner) from the latest /me `lifetime` object. Hidden
    // entirely for tiers with no cap (lifetime.cap === null, i.e. any paid
    // tier). Unlike updateWeeklyCapUI() below, there is no "warning" state or
    // reset button — the cap never resets, so once reached the only path
    // forward is upgrading (see LIFETIME_FREE_CAP_NEW/_RETURNING in
    // gateway.js).
    function updateLifetimeCapUI() {
      const section = document.getElementById('billingLifetimeSection');
      const l = _lastLifetime;
      if (!section) return;
      if (!l || l.cap == null) {
        section.style.display = 'none';
        return;
      }
      section.style.display = '';
      const pct = Math.max(0, Math.min(100, (l.used / l.cap) * 100));
      const numEl = document.getElementById('billingLifetimeNum');
      if (numEl) numEl.textContent = Math.min(l.used, l.cap) + ' / ' + l.cap;
      const fillEl = document.getElementById('billingLifetimeFill');
      if (fillEl) {
        fillEl.style.width = pct + '%';
        fillEl.style.background = pct >= 100 ? 'var(--red)' : pct >= 80 ? '#facc15' : 'var(--accent)';
      }
      const capBanner = document.getElementById('billingLifetimeCapBanner');
      if (capBanner) capBanner.classList.toggle('show', pct >= 100);
    }

    // Renders the Billing-tab Weekly Usage Cap section (progress bar +
    // warning/blocked banners) from the latest /me `weekly` object. Hidden
    // entirely for tiers with no cap (weekly.cap === null, e.g. free).
    function updateWeeklyCapUI() {
      const section = document.getElementById('billingWeeklySection');
      const w = _lastWeekly;
      if (!section) return;
      if (!w || w.cap == null) {
        section.style.display = 'none';
        return;
      }
      section.style.display = '';
      const pct = Math.max(0, Math.min(100, (w.usage / w.cap) * 100));
      const numEl = document.getElementById('billingWeeklyNum');
      if (numEl) numEl.textContent = Math.min(w.usage, w.cap) + ' / ' + w.cap + ' credits this week';
      const fillEl = document.getElementById('billingWeeklyFill');
      if (fillEl) {
        fillEl.style.width = pct + '%';
        fillEl.style.background = pct >= 100 ? 'var(--red)' : pct >= (w.warningRatio || WEEKLY_CAP_WARNING_RATIO) * 100 ? '#facc15' : 'var(--accent)';
      }
      const warnBanner = document.getElementById('billingWeeklyWarningBanner');
      const blockedBanner = document.getElementById('billingWeeklyBlockedBanner');
      const blocked = pct >= 100;
      const warning = !blocked && pct >= (w.warningRatio || WEEKLY_CAP_WARNING_RATIO) * 100;
      if (warnBanner) warnBanner.classList.toggle('show', warning);
      if (blockedBanner) blockedBanner.classList.toggle('show', blocked);
    }

    // Paid "Weekly Reset" purchase — stub payment flow mirroring doRecharge(),
    // but for the independent Weekly Usage Cap counter (see gateway.js
    // handleWeeklyReset()/UserAccountDO.resetWeekly()). No cooldown, unlike
    // Recharge Now.
    async function doWeeklyReset() {
      const price = WEEKLY_RESET_PRICES[currentPlan];
      if (price == null) return;
      const lang = BatLang.lang;
      const confirmMsg = lang === 'ar' ? ('تصفير استخدامك الأسبوعي مقابل $' + price + '؟')
        : lang === 'tr' ? ('Haftalık kullanımınızı $' + price + ' karşılığında sıfırlamak istiyor musunuz?')
        : ('Reset your weekly usage for $' + price + '?');
      if (!window.confirm(confirmMsg)) return;
      const btns = [document.getElementById('weeklyResetBtnWarning'), document.getElementById('weeklyResetBtnBlocked')].filter(Boolean);
      btns.forEach(b => b.disabled = true);
      try {
        await gatewayFetch('/weekly-reset', {});
        const msg = lang === 'ar' ? 'تم تصفير استخدامك الأسبوعي بنجاح!'
          : lang === 'tr' ? 'Haftalık kullanımınız sıfırlandı!'
          : 'Weekly usage reset successfully!';
        showToast(msg, 'success');
        await refreshAccountState();
      } catch (e) {
        if (e && e.message !== 'no_credits' && e.message !== 'rate_limited') {
          const msg = lang === 'ar' ? 'فشلت عملية التصفير. حاول مرة أخرى.'
            : lang === 'tr' ? 'Sıfırlama başarısız oldu. Tekrar deneyin.'
            : 'Weekly reset failed. Please try again.';
          showToast(msg, 'error');
        }
      } finally {
        btns.forEach(b => b.disabled = false);
      }
    }
    window.doWeeklyReset = doWeeklyReset;

    // Single shared 1s ticker driving every live credit widget in the app —
    // started once on first login/account load and kept running for the
    // whole session (replaces the old out-of-credits-only private interval).
    let _creditsTicker = null;
    function startCreditsTicker() {
      if (_creditsTicker) return;
      renderAllCreditWidgets();
      _creditsTicker = setInterval(renderAllCreditWidgets, 1000);
    }
    window.startCreditsTicker = startCreditsTicker;

    // Tier-aware out-of-credits modal copy (title/desc/upgrade-CTA). Mirrors
    // updateUpgradeButtonText()'s exact pattern (map keyed by currentPlan,
    // en/ar/tr text with fallback to en) — fixes the bug where a Max-tier
    // user (the ceiling plan) saw a static "Upgrade to Pro" CTA that made no
    // sense since Pro < Max. Max has no `cta` entry, so the upgrade button
    // is hidden entirely (nothing above Max to upgrade to); only the
    // explanatory message + countdown + "Recharge Now" remain for Max.
    function updateOutOfCreditsModalText() {
      const lang = BatLang.lang;
      const TEXT = {
        free: {
          en: { title: 'Out of credits', desc: "You've used all your credits. Upgrade your plan for more generations.", cta: 'Upgrade Plan →' },
          ar: { title: 'نفدت كريديتاتك', desc: 'لقد استنفدت جميع كريديتاتك. رقّي خطتك للحصول على مزيد من التوليدات.', cta: 'ترقية الخطة ←' },
          tr: { title: 'Krediler tükendi', desc: 'Tüm kredilerinizi kullandınız. Daha fazla oluşturma için planınızı yükseltin.', cta: 'Planı Yükselt →' },
        },
        starter: {
          en: { title: 'Out of credits', desc: "You've used all your credits. Upgrade to Pro for more generations.", cta: 'Upgrade to Pro →' },
          ar: { title: 'نفدت كريديتاتك', desc: 'لقد استنفدت جميع كريديتاتك. ارقِ إلى برو للحصول على مزيد من التوليدات.', cta: 'الترقية إلى برو ←' },
          tr: { title: 'Krediler tükendi', desc: "Tüm kredilerinizi kullandınız. Daha fazla oluşturma için Pro'ya yükseltin.", cta: "Pro'ya Yükselt →" },
        },
        pro: {
          en: { title: 'Out of credits', desc: "You've used all your credits. Upgrade to Max for more generations.", cta: 'Upgrade to Max →' },
          ar: { title: 'نفدت كريديتاتك', desc: 'لقد استنفدت جميع كريديتاتك. ارقِ إلى ماكس للحصول على مزيد من التوليدات.', cta: 'الترقية إلى ماكس ←' },
          tr: { title: 'Krediler tükendi', desc: "Tüm kredilerinizi kullandınız. Daha fazla oluşturma için Max'e yükseltin.", cta: "Max'e Yükselt →" },
        },
        max: {
          en: { title: 'Out of credits', desc: "You've used all your credits for this window. They'll refresh automatically — or recharge now for more." },
          ar: { title: 'نفدت كريديتاتك', desc: 'لقد استنفدت جميع كريديتاتك لهذه النافذة. ستتجدد تلقائياً — أو يمكنك الشحن الآن للحصول على المزيد.' },
          tr: { title: 'Krediler tükendi', desc: 'Bu pencere için tüm kredilerinizi kullandınız. Otomatik olarak yenilenecek — ya da daha fazlası için şimdi yükleyin.' },
        },
      };
      const entry = TEXT[currentPlan] || TEXT.free;
      const t = entry[lang] || entry.en;
      const titleEl = document.getElementById('upgradeModalTitle');
      const descEl = document.getElementById('upgradeModalDesc');
      const ctaBtn = document.getElementById('upgradeBtn');
      if (titleEl) titleEl.textContent = t.title;
      if (descEl) descEl.textContent = t.desc;
      if (ctaBtn) {
        if (t.cta) { ctaBtn.style.display = ''; ctaBtn.textContent = t.cta; }
        else { ctaBtn.style.display = 'none'; } // max tier: nothing to upgrade to
      }
    }
    window.updateOutOfCreditsModalText = updateOutOfCreditsModalText;

    // Out-of-credits (402) path: full-screen modal (reuses #upgradeModal) with a
    // live countdown to window_end + an extra "Recharge Now" CTA alongside the
    // existing "Upgrade" CTA — per plan §3. Distinct from showUpgradeModal(),
    // which is the plain "just go check out plans" entry point (sidebar CTA,
    // ?openUpgrade=1 redirect) and has no countdown/recharge state to show.
    function showOutOfCredits(windowEndsAt) {
      _lastWindowEndsAt = windowEndsAt || null;
      document.getElementById("upgradeModal").classList.add("active");
      updateOutOfCreditsModalText();
      const countdown = document.getElementById('outOfCreditsCountdown');
      const timerEl = document.getElementById('outOfCreditsTimer');
      const rechargeBtn = document.getElementById('rechargeNowBtn');
      if (rechargeBtn) rechargeBtn.style.display = 'block';
      startCreditsTicker();
      if (countdown && timerEl && _lastWindowEndsAt) {
        countdown.style.display = 'flex';
        timerEl.textContent = formatCountdown(new Date(_lastWindowEndsAt).getTime() - Date.now());
      } else if (countdown) {
        countdown.style.display = 'none';
      }
    }

    function showRateLimited(retryAfter) {
      const secs = Number(retryAfter) || 30;
      const lang = BatLang.lang;
      const msg = lang === 'ar' ? ('لقد تجاوزت الحد المسموح. حاول مرة أخرى بعد ' + secs + ' ثانية.')
        : lang === 'tr' ? ('Çok fazla istek. ' + secs + ' saniye sonra tekrar deneyin.')
        : ('Too many requests. Try again in ' + secs + 's.');
      showToast(msg, 'error');
    }

    // Permanent-ban (403) full-screen block — non-dismissable, shown on top
    // of everything else (loading overlay, chat UI, other modals) via CSS
    // z-index alone, so no other overlay needs to be explicitly closed.
    let _banScreenShown = false;
    function showBanScreen(reason) {
      _banScreenShown = true;
      const reasonEl = document.getElementById('banReasonText');
      if (reasonEl) reasonEl.textContent = reason || '';
      const screen = document.getElementById('banScreen');
      if (screen) screen.classList.add('active');
    }
    window.showBanScreen = showBanScreen;

    // Prime is a Pro/Max-only model — a Free/Starter plan that hits a
    // Prime-gated surface (the bare /chat route, see gateway.js's
    // plan_restricted 403) gets a clear upgrade prompt instead of the old
    // silent "generation_failed". Reuses the server's own message when
    // present so the copy stays in sync with the gateway.
    function showPlanRestricted(info) {
      info = info || {};
      const msg = info.message ||
        (BatLang.lang === 'ar'
          ? 'هذا النموذج متاح لخطط Pro و Max فقط. رقِّ خطتك للمتابعة.'
          : 'This model is available on the Pro and Max plans only. Upgrade to continue.');
      showToast(msg, 'error');
      if (typeof showUpgradeModal === 'function' && document.getElementById('upgradeModal')) {
        showUpgradeModal();
      }
    }
    window.showPlanRestricted = showPlanRestricted;

    // Centralized fetch to the gateway Worker. Injects the Supabase JWT, and
    // surfaces credit/rate-limit responses via shared UI (unless opts.silent,
    // used for background/best-effort calls like memory extraction).
    async function gatewayFetch(path, body, opts = {}) {
      const token = await getAccessToken();
      if (!token) throw new Error('not_authenticated');

      let res;
      try {
        res = await fetch(GATEWAY_URL + path, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token,
          },
          body: JSON.stringify(body),
          signal: opts.signal,
        });
      } catch (e) {
        if (e && e.name === 'AbortError') throw e;
        throw new Error('network_error');
      }

      if (res.status === 402) {
        let data = {};
        try { data = await res.json(); } catch (_) {}
        // Weekly Usage Cap reached (see gateway.js handleGenerate()) is a
        // distinct 402 shape (weeklyUsage/weeklyCap/weeklyResetAt, no
        // windowEndsAt) - route it to the Billing tab's weekly banners
        // instead of the generic per-window out-of-credits modal.
        if (data.error === 'weekly_cap_reached') {
          _lastWeekly = { usage: data.weeklyUsage, cap: data.weeklyCap, resetAt: data.weeklyResetAt, warningRatio: WEEKLY_CAP_WARNING_RATIO };
          updateWeeklyCapUI();
          if (!opts.silent) {
            const lang = BatLang.lang;
            const msg = lang === 'ar' ? 'وصلت لحد استخدامك الأسبوعي. راجع تبويب الفوترة.'
              : lang === 'tr' ? 'Haftalık kullanım limitinize ulaştınız. Faturalandırma sekmesine bakın.'
              : 'You\'ve reached your weekly usage cap. Check the Billing tab.';
            showToast(msg, 'error');
            if (typeof window.showSettingsModal === 'function') window.showSettingsModal();
            if (typeof window.spShowTab === 'function') window.spShowTab('billing');
          }
          throw new Error('weekly_cap_reached');
        }
        // Free-Plan Lifetime Credit Cap reached (see gateway.js reserve()'s
        // "2.6" gate). Unlike weekly_cap_reached above, this 402 body does
        // NOT carry lifetimeUsed/lifetimeCap - gateway.js's /generate
        // failure response only forwards the same generic fields it always
        // does (error/windowEndsAt/balance/retryAfter/upgradeUrl) - so pull
        // the authoritative numbers via a background /me refresh instead of
        // trusting this response body, matching the general "exact numbers
        // come from /me" pattern used everywhere else in this file.
        if (data.error === 'lifetime_cap_reached') {
          refreshAccountState();
          if (!opts.silent) {
            const lang = BatLang.lang;
            const msg = lang === 'ar' ? 'خلص رصيدك المجاني مدى الحياة. اشترك لتكمل.'
              : lang === 'tr' ? 'Ücretsiz ömür boyu krediniz tükendi. Devam etmek için abone olun.'
              : 'You\'ve used up your free lifetime credits. Subscribe to keep going.';
            showToast(msg, 'error');
            if (typeof window.showSettingsModal === 'function') window.showSettingsModal();
            if (typeof window.spShowTab === 'function') window.spShowTab('billing');
          }
          throw new Error('lifetime_cap_reached');
        }
        if (!opts.silent) showOutOfCredits(data.windowEndsAt);
        throw new Error('no_credits');
      }
      if (res.status === 429) {
        let data = {};
        try { data = await res.json(); } catch (_) {}
        // Recharge cooldown (see gateway.js handleRecharge()) is a distinct 429
        // shape (nextRechargeAt/cooldownDays, no retryAfter) - don't run it
        // through the generic short-window rate-limit toast.
        if (data.error === 'recharge_on_cooldown') {
          const err = new Error('recharge_on_cooldown');
          err.nextRechargeAt = data.nextRechargeAt || null;
          throw err;
        }
        if (!opts.silent) showRateLimited(data.retryAfter || res.headers.get('Retry-After'));
        throw new Error('rate_limited');
      }
      if (res.status === 403) {
        // Read the 403 body ONCE and fully resolve it here — every branch
        // throws, so control never falls through to the generic !res.ok
        // handler below. (Previously only 'banned' was handled and the rest
        // fell through, where a SECOND res.json() on the already-consumed
        // body threw and got swallowed, masking the real error — e.g.
        // 'plan_restricted' — as a generic 'generation_failed'.)
        let data = {};
        try { data = await res.json(); } catch (_) {}
        if (data.error === 'banned') {
          showBanScreen(data.reason);
          throw new Error('banned');
        }
        if (data.error === 'plan_restricted') {
          // Prime (Pro/Max-only) model requested by a plan without access.
          // Surface a clear upgrade prompt for real, user-initiated calls;
          // silent/background helpers just get the typed error (and now route
          // around Prime entirely via bgChatRoute()).
          if (!opts.silent) showPlanRestricted(data);
          const err = new Error('plan_restricted');
          err.planRestricted = {
            message: data.message || '',
            requiredPlans: data.requiredPlans || ['pro', 'max'],
            upgradeUrl: data.upgradeUrl || '/upgrade.html',
            currentTier: data.currentTier || '',
          };
          throw err;
        }
        // account_blocked (temporary block) or any other 403 — surface the
        // server's own specific error code rather than a masked generic one.
        throw new Error(data.error || 'forbidden');
      }
      if (!res.ok) {
        let msg = 'generation_failed';
        try {
          const data = await res.json();
          // gateway.js's handleGenerate() wraps ANY non-2xx response from the
          // downstream generation Worker as { error: 'upstream_error', status,
          // detail } (always HTTP 502) — detail is the downstream worker's own
          // raw JSON error body text (e.g. worker.js's deny() output), so
          // unwrap it to recover the actual, specific error message instead of
          // surfacing the generic 'upstream_error' string.
          if (data && data.error === 'upstream_error' && data.detail) {
            try {
              const inner = JSON.parse(data.detail);
              msg = (inner && inner.error) || data.detail;
            } catch (_) {
              msg = data.detail;
            }
          } else {
            msg = (data && data.error) || msg;
          }
        } catch (_) {}
        throw new Error(msg);
      }

      const windowEndsAt = res.headers.get('X-Window-Ends-At');
      const warning = res.headers.get('X-Credit-Warning');
      if (warning && !opts.silent) handleSoftWarning(warning);

      // Optimistic local decrement: X-Credits-Charged is the worst-case
      // credit hold the gateway reserved for this exact request (see
      // reserve()'s `reservedCredits` in worker/gateway.js) - it's the
      // server's own number, just delivered synchronously via header instead
      // of waiting on the follow-up /me round trip below. This removes the
      // perceived lag between sending a message and seeing the credit count
      // drop. It is not necessarily the final charge (the real settle()
      // amount is computed asynchronously after the response streams back),
      // so refreshAccountState() still runs right after to reconcile with
      // the authoritative, settled balance - this just paints an accurate-
      // enough number a few ms sooner.
      const charged = Number(res.headers.get('X-Credits-Charged')) || 0;
      if (charged > 0 && !opts.silent) {
        currentCredits = Math.max(0, currentCredits - charged);
        if (typeof window.updateCreditDisplay === 'function') window.updateCreditDisplay();
      }

      // Fire-and-forget balance sync so the credit UI reflects the charge
      // that was just settled server-side. Skipped for silent/background
      // calls to avoid extra requests for calls the user never sees.
      // Uses the poller (not a single refresh) because settle() runs a moment
      // later — after the reply finishes streaming — so we must re-check /me
      // until the worst-case hold is released, otherwise the UI stays stuck on
      // the held (over-charged) number until a manual reload.
      if (!opts.silent) reconcileCreditsAfterSettle();

      return { res, windowEndsAt, warning };
    }

    // Local, fully hardcoded status-hint text (replaces the old backend
    // /status-hint AI call). Returns the message for a given attachment
    // `type` ('text'|'file'|'image') and `phase` ('initial'|'thinking'), in
    // the current UI language — each language uses its own full sentence,
    // not just the product name kept in English.
    function _statusHintText(type, phase) {
      const lang = (typeof BatLang !== 'undefined') ? BatLang.lang : 'en';
      const TYPE_MSG = {
        text:  { en: 'Understanding and reading your request...',        ar: 'جاري فهم طلبك وقراءته...',      tr: 'İsteğinizi anlıyor ve okuyorum...' },
        file:  { en: 'Reading the files and understanding your request...', ar: 'جاري قراءة الملفات وفهم طلبك...', tr: 'Dosyaları okuyor ve isteğinizi anlıyorum...' },
        image: { en: 'Reading the image and understanding your request...', ar: 'جاري قراءة الصورة وفهم طلبك...',  tr: 'Görseli okuyor ve isteğinizi anlıyorum...' },
        export: { en: 'Preparing your conversation file...',                ar: 'جاري تجهيز ملف محادثتك...',      tr: 'Sohbet dosyanız hazırlanıyor...' }
      };
      const THINK_MSG = { en: 'BatNXT is thinking...', ar: 'BatNXT يفكر...', tr: 'BatNXT düşünüyor...' };
      const entry = phase === 'thinking' ? THINK_MSG : (TYPE_MSG[type] || TYPE_MSG.text);
      return entry[lang] || entry.en;
    }

    // Pulls the live, authoritative account/window state from the gateway
    // (GET /me → Durable Object) and syncs it into the local UI state.
    // Credits/tier are no longer stored on the `profiles` table.
    async function refreshAccountState() {
      const token = await getAccessToken();
      if (!token) return null;
      try {
        const res = await fetch(GATEWAY_URL + '/me', {
          headers: { 'Authorization': 'Bearer ' + token },
        });
        if (res.status === 403) {
          let data = {};
          try { data = await res.json(); } catch (_) {}
          if (data.error === 'banned') showBanScreen(data.reason);
          return null;
        }
        if (!res.ok) {
          console.error('refreshAccountState: /me returned', res.status, res.statusText);
          return null;
        }
        const st = await res.json();
        currentPlan = st.tier || 'free';
        const w = st.window;
        if (w) {
          const avail = (w.creditsAllocated || 0) - (w.creditsUsed || 0) - (st.reserved || 0);
          currentCredits = Math.max(0, avail);
          _lastWindowEndsAt = w.windowEnd || null;
          _lastWindowAllocated = w.creditsAllocated || null;
        } else {
          // No active window (e.g. brand-new signup pre-first-message, or a
          // pending post-upgrade reset — see windowPendingReset in gateway.js).
          // Show the new/current tier's full allocation instead of 0 so the
          // credit bar doesn't flash empty; the countdown stays inactive
          // (_lastWindowEndsAt null) until a real window actually opens.
          currentCredits = PLAN_MAX[currentPlan] ?? 0;
          _lastWindowEndsAt = null;
          _lastWindowAllocated = PLAN_MAX[currentPlan] ?? null;
        }
        _lastLifetime = st.lifetime || null;
        updateLifetimeCapUI();
        _lastWeekly = st.weekly || null;
        updateWeeklyCapUI();
        _lastNextRechargeAt = st.nextRechargeAt || null;
        const ddPlan = document.getElementById('ddPlan');
        if (ddPlan) ddPlan.textContent = currentPlan.toUpperCase();
        if (typeof window.updateCreditDisplay === 'function') window.updateCreditDisplay();
        BatCache.set(BATNXT_CACHE_ACCOUNT, { tier: currentPlan, credits: currentCredits });
        markAccountReady();
        return st;
      } catch (e) {
        console.error('refreshAccountState: failed to sync account state:', e);
        return null;
      }
    }

    // After a billed call, reserve() holds a WORST-CASE credit amount and the
    // real (usually much smaller) cost is only booked later by settle(), which
    // runs server-side once the reply has finished streaming. /me subtracts any
    // still-outstanding reservation, so a single refresh fired right after the
    // response headers reads the HELD (worst-case) balance and leaves the credit
    // UI showing an over-charge until the next manual reload — e.g. Flash:
    // 37 → shows 20 (17 held) → real 35 once settle() releases the hold.
    // Poll /me with backoff until no reservation is outstanding so the display
    // self-corrects to the settled balance without a reload. Stops early the
    // moment the hold clears (usually after 1–2 polls).
    //
    // _creditReconcileActive guards against concurrent callers (e.g. several
    // parallel gatewayFetch() calls resolving at once, as with multi-file
    // attach): without it, each resolution independently fires its own
    // immediate refreshAccountState() call before any of them get a chance
    // to schedule/cancel a shared timer, producing a burst of simultaneous
    // /me requests. While a cycle is already active, further calls are a
    // no-op — the in-flight cycle already covers reconciling the balance.
    let _creditReconcileTimer = null;
    let _creditReconcileActive = false;
    function reconcileCreditsAfterSettle() {
      if (_creditReconcileActive) return;
      _creditReconcileActive = true;
      if (_creditReconcileTimer) { clearTimeout(_creditReconcileTimer); _creditReconcileTimer = null; }
      const delays = [800, 1600, 2800, 4500, 7000, 10000];
      let i = 0;
      (function poll() {
        refreshAccountState().then(function (st) {
          const stillHeld = st && Number(st.reserved) > 0;
          if (stillHeld && i < delays.length) {
            _creditReconcileTimer = setTimeout(poll, delays[i++]);
          } else {
            _creditReconcileTimer = null;
            _creditReconcileActive = false;
          }
        }).catch(function () {
          _creditReconcileTimer = null;
          _creditReconcileActive = false;
        });
      })();
    }

    /* ── inline generation workspace state ── */
    let lastPrompt = '', lastType = '', lastSubtype = '', lastHTML = '';
    let _genInChatMode = false; // true → generation stays inside the home chat (no workspace split-panel)
    let selectedModel = sessionStorage.getItem('batlab_model') || 'BAT 1.2 Core';

    // Unified badge so the compact button always shows which variant is active.
    const MODEL_BADGE = {
      'BAT 1.2':       { text: 'PRIME', cls: 'badge-prime' },
      'BAT 1.2 Flash': { text: 'FLASH', cls: 'badge-flash' },
      'BAT 1.2 Core':  { text: 'CORE',  cls: 'badge-core' },
      'Alfred':        { text: 'ULTRA', cls: 'badge-max' },
    };
    // Display-only version numbers shown to the user (button label + dropdown
    // rows). Keys are the internal model identifiers used for routing/gating
    // elsewhere (selectedModel, MODEL_TIER, chatRoutePath()) and MUST stay in
    // sync with those — only the values here are cosmetic.
    const MODEL_VERSION_LABEL = {
      'BAT 1.2':       'BAT 5',
      'BAT 1.2 Flash': 'BAT 1.0',
      'BAT 1.2 Core':  'BAT 1.4',
    };
    // Which plan tier each model requires, and how plans rank against each other.
    // BAT 5 (Prime) is Pro/Max only as of 2026-07-19 - enforced server-side
    // too (gateway.js dispatch handler); this entry just drives the existing
    // lock-icon/upgrade-modal UI so Free/Starter never see it as selectable.
    const MODEL_TIER = {
      'BAT 1.2':       'pro',
      'BAT 1.2 Flash': 'free',
      'BAT 1.2 Core':  'free',
      'Alfred':        'pro',
      // Marketing tool models (2026-07-20). 'BAT 2.2' is also implicitly
      // gated by TOOL_TIER.marketing below (Free can't open the tool at
      // all); listed here too so modelAllowed() stays correct if ever
      // called on it directly outside the Marketing view.
      'BAT 2.2':       'starter',
      'BAT 2.2 Prime': 'pro',
    };
    const PLAN_RANK = { free: 0, starter: 1, pro: 2, max: 3 };
    function modelAllowed(model) {
      const need = PLAN_RANK[MODEL_TIER[model] || 'free'] || 0;
      const have = PLAN_RANK[currentPlan] || 0;
      return have >= need;
    }
    // Exposed for the sidebar's Alfred CREATE-row handler (index.html), which
    // needs to plan-check before deciding whether to open alfred.html or show
    // the pricing modal.
    window.modelAllowed = modelAllowed;

    // Which plan tier each whole TOOL (not an individual model) requires —
    // the Marketing tool itself is open to every plan including Free (BAT
    // 2.2 Prime inside it still requires Pro/Max via MODEL_TIER above).
    // Mirrors the server-side gate (gateway.js dispatch handler); this
    // drives the sidebar lock-icon/upgrade-modal UI.
    const TOOL_TIER = {};
    function toolAllowed(tool) {
      const need = PLAN_RANK[TOOL_TIER[tool] || 'free'] || 0;
      const have = PLAN_RANK[currentPlan] || 0;
      return have >= need;
    }
    function updateModelLabel(model) {
      const lbl = document.getElementById('homeModelLabel');
      const badge = document.getElementById('homeModelBadge');
      // Label shows the tier-specific version number (badge carries the
      // variant, e.g. Flash/Core/Prime) so it never duplicates the badge text.
      if (lbl) lbl.textContent = MODEL_VERSION_LABEL[model]
        || (model.startsWith('BAT 2.2') ? 'BAT 2.2' : model);
      if (badge) {
        const info = MODEL_BADGE[model] || MODEL_BADGE['BAT 1.2'];
        badge.textContent = info.text;
        badge.className = 'home-model-badge ' + info.cls;
      }
    }

    window.closeModelMenu = function () {
      const wrap = document.getElementById('homeModelWrap');
      const btn = document.getElementById('homeModelBtn');
      if (!wrap) return;
      wrap.classList.remove('open', 'models-open', 'effort-open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
    };
    window.toggleModelMenu = function (e) {
      if (e) e.stopPropagation();
      const wrap = document.getElementById('homeModelWrap');
      const btn = document.getElementById('homeModelBtn');
      if (!wrap) return;
      if (wrap.classList.contains('open')) { window.closeModelMenu(); return; }
      // Only one composer flyout (model picker or credit/usage popup) should
      // be visible at a time — close the usage popup before opening this one.
      if (typeof window.closeUsagePopup === 'function') window.closeUsagePopup();
      wrap.classList.add('open');
      if (btn) btn.setAttribute('aria-expanded', 'true');
    };
    function isProPlan() { return currentPlan === 'pro' || currentPlan === 'max'; }

    // Mobile UI + Tool build types are Pro/Max-only.
    const PRO_TYPES = ['mobile', 'tool'];

    // Keeps the Mobile/Tool chips' lock icon in sync with the user's plan, and
    // silently falls back to 'game' if a previously-selected gated type is no
    // longer accessible (e.g. plan downgraded since the last visit).
    function syncTypeLockUI() {
      const locked = !isProPlan();
      document.querySelectorAll('#homeChips .home-chip').forEach(function (c) {
        if (PRO_TYPES.includes(c.dataset.value)) c.classList.toggle('locked', locked);
      });
      if (locked && PRO_TYPES.includes(selectedType)) {
        selectedType = '';
        document.querySelectorAll('#homeChips .home-chip').forEach(c => c.classList.remove('active'));
        renderCostPreview();
      }
    }
    window.syncTypeLockUI = syncTypeLockUI;

    // Keeps the Marketing sidebar entry's lock icon in sync with the user's
    // plan, and bounces the user back to Home if they're currently viewing
    // Marketing but their plan no longer allows it (e.g. downgraded mid-
    // session). Mirrors syncTypeLockUI() above.
    function syncToolLockUI() {
      const btn = document.getElementById('sidebarMoreMarketingBtn');
      if (btn) btn.classList.toggle('locked', !toolAllowed('marketing'));
      const marketingView = document.getElementById('marketingView');
      if (!toolAllowed('marketing') && marketingView && marketingView.style.display !== 'none') {
        showView('home');
      }
    }
    window.syncToolLockUI = syncToolLockUI;

    // Opens the Marketing tool, or shows the upgrade modal instead if the
    // user's plan doesn't allow it (Free). Marketing is now a top-level
    // CREATE row (no longer nested in the retired "More" flyout), so there's
    // no flyout to close before navigating.
    window.openMarketingTool = function () {
      if (!toolAllowed('marketing')) { showPricingModal(); return; }
      showView('marketing');
    };

    // Keeps the Pro option's lock icon/desc in sync with the user's plan, and
    // silently falls back to the base model if a previously-selected Pro model
    // is no longer accessible (e.g. plan downgraded since the last visit).
    function syncModelLockUI() {
      // Lock every option the current plan can't reach (Pro models on Free,
      // Alfred on anything below Max), and fall back to the base model if the
      // stored selection is no longer accessible.
      document.querySelectorAll('.home-model-opt').forEach(function (opt) {
        const model = opt.dataset.model;
        if (!model) return;
        opt.classList.toggle('locked', !modelAllowed(model));
      });
      if (!modelAllowed(selectedModel)) {
        // Falls back to Core, the app-wide default model - Prime is now
        // Pro/Max-gated itself, so a Free/Starter user whose selection
        // becomes disallowed must land on a model they can actually use.
        selectedModel = 'BAT 1.2 Core';
        sessionStorage.setItem('batlab_model', selectedModel);
        updateModelLabel(selectedModel);
        document.querySelectorAll('.home-model-opt').forEach(o =>
          o.classList.toggle('active', o.dataset.model === selectedModel));
        if (typeof renderCostPreview === 'function') renderCostPreview();
      }
    }
    window.syncModelLockUI = syncModelLockUI;

    window.selectModel = function (model, el) {
      if (!modelAllowed(model)) {
        const wrap = document.getElementById('homeModelWrap');
        if (wrap) wrap.classList.remove('open');
        const btn = document.getElementById('homeModelBtn');
        if (btn) btn.setAttribute('aria-expanded', 'false');
        showPricingModal();
        return;
      }
      // Alfred is a full agent experience — it lives on its own page.
      if (model === 'Alfred') {
        const wrap = document.getElementById('homeModelWrap');
        if (wrap) wrap.classList.remove('open');
        const btn = document.getElementById('homeModelBtn');
        if (btn) btn.setAttribute('aria-expanded', 'false');
        window.location.href = 'alfred.html';
        return;
      }
      selectedModel = model;
      sessionStorage.setItem('batlab_model', model);
      updateModelLabel(model);
      document.querySelectorAll('.home-model-opt').forEach(o => o.classList.toggle('active', o === el));
      const wrap = document.getElementById('homeModelWrap');
      if (wrap) wrap.classList.remove('open');
      const btn = document.getElementById('homeModelBtn');
      if (btn) btn.setAttribute('aria-expanded', 'false');
      if (typeof renderCostPreview === 'function') renderCostPreview();
    };
    // close the model menu on any outside click
    document.addEventListener('click', function (e) {
      const wrap = document.getElementById('homeModelWrap');
      if (wrap && wrap.classList.contains('open') && !wrap.contains(e.target)) {
        wrap.classList.remove('open');
        const btn = document.getElementById('homeModelBtn');
        if (btn) btn.setAttribute('aria-expanded', 'false');
      }
    });
    // reflect the stored model on load
    (function syncModelUI() {
      updateModelLabel(selectedModel);
      document.querySelectorAll('.home-model-opt').forEach(o =>
        o.classList.toggle('active', o.dataset.model === selectedModel));
      syncModelLockUI();
      syncTypeLockUI();
      syncToolLockUI();
      syncMarketingModelLockUI();
    })();





    // TODO: paste your Supabase project URL + anon (public) key here
    const SUPABASE_URL = "https://pjvjzpqrtatiznysvbep.supabase.co";
    const SUPABASE_ANON_KEY = "sb_publishable_beUc-ELD9Sk4xLuRpa-fZA_CqT4KVr1";

    const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    /* ── Cache hydration: paint the last-known username/avatar/plan/credits
       instantly from BatCache, before loadUser()'s network round-trip
       resolves. Purely cosmetic — loadUser() always re-fetches live data and
       overwrites everything painted here. ── */
    function hydrateFromCache(user) {
      const cachedProfile = BatCache.get(BATNXT_CACHE_PROFILE);
      if (cachedProfile) {
        const meta = user.user_metadata || {};
        const displayName = cachedProfile.display_name || meta.full_name || meta.name || 'User';
        const initials = (displayName || user.email || 'U').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
        const avatarEl = document.getElementById('avatarInitials');
        if (avatarEl) avatarEl.textContent = initials;
        const photoURL = cachedProfile.photo_url || meta.avatar_url || meta.picture || '';
        if (photoURL && avatarEl) {
          const img = document.createElement('img');
          img.id = 'avatarInitials'; // preserve id so loadUser()'s later getElementById lookup still finds it
          img.src = photoURL;
          avatarEl.replaceWith(img);
        }
        const ddName = document.getElementById('ddName');
        if (ddName) ddName.textContent = displayName;
        const ddEmail = document.getElementById('ddEmail');
        if (ddEmail) ddEmail.textContent = user.email || '';
        const firstName = displayName.split(' ')[0];
        const nameEl = document.getElementById('homeName');
        if (nameEl && firstName) nameEl.textContent = firstName;
      }
      const cachedAccount = BatCache.get(BATNXT_CACHE_ACCOUNT);
      if (cachedAccount) {
        if (cachedAccount.tier) currentPlan = cachedAccount.tier;
        const ddPlan = document.getElementById('ddPlan');
        if (ddPlan) ddPlan.textContent = (currentPlan || 'free').toUpperCase();
        if (typeof cachedAccount.credits === 'number') {
          // Clamp ≥0: a stale/corrupt cached value must never paint a negative
          // credit count (root cause of the "-7 / 100 credits" flash). This is
          // the only currentCredits write that wasn't already floored at 0; the
          // authoritative /me value from refreshAccountState() overwrites it.
          currentCredits = Math.max(0, cachedAccount.credits);
          if (typeof window.updateCreditDisplay === 'function') window.updateCreditDisplay();
        }
      }
    }

    /* ── Auth guard ──
       Signed-out visitors are now allowed to browse the app as a guest.
       They're only sent to login.html when they try to actually do
       something (send a message, generate, etc.) — see requireLogin(). */
    let _authHandled = false;
    async function handleAuthChange(session) {
      const user = session && session.user;
      if (!user) { currentUser = null; loadGuestUI(); return; }
      if (_authHandled && currentUser && currentUser.id === user.id) return;
      _authHandled = true;
      currentUser = user;
      hydrateFromCache(user);
      await loadUser(user);
    }
    supabase.auth.onAuthStateChange((_event, session) => { handleAuthChange(session); });
    supabase.auth.getSession().then(({ data }) => handleAuthChange(data.session)).catch((e) => {
      console.error('Failed to get session:', e);
      currentUser = null;
      loadGuestUI();
    });

    /* ── Guest UI ── */
    function loadGuestUI() {
      const initialsEl = document.getElementById("avatarInitials");
      if (initialsEl) initialsEl.textContent = "G";
      const ddName = document.getElementById("ddName");
      if (ddName) ddName.textContent = "Guest Account";
      const ddEmail = document.getElementById("ddEmail");
      if (ddEmail) ddEmail.textContent = "";
      const ddPlan = document.getElementById("ddPlan");
      if (ddPlan) ddPlan.textContent = "FREE";

      const nameEl = document.getElementById("homeName");
      if (nameEl) nameEl.textContent = "Guest";

      // Guest: reveal the "Start free" CTA and turn the sign-out row into "Login free".
      const startFreeBtn = document.getElementById("startFreeBtn");
      if (startFreeBtn) startFreeBtn.style.display = "inline-flex";
      const logoutLabel = document.querySelector('#logoutBtn [data-i18n]');
      if (logoutLabel) {
        logoutLabel.setAttribute('data-i18n', 'nav.loginFree');
        logoutLabel.textContent = BatLang.t('nav.loginFree');
      }

      updateCreditDisplay();
      // Guest fallback is an authoritative resolution too — open the boot gate
      // and dismiss the skeleton (guests have no /me to wait on).
      markAccountReady();
    }

    /* ── Login guard for actions (sending messages, generating, etc.) ── */
    function requireLogin() {
      if (currentUser) return true;
      window.location.href = "login.html";
      return false;
    }
    window.requireLogin = requireLogin;

    async function loadUser(user) {
      // The profile fetch and refreshAccountState() are independent — run
      // them in parallel (instead of sequentially) so neither blocks the
      // other, and so loadGenHistory()/loadHomeChatSessions()/
      // loadUserMemories() below can start as early as possible.
      // allSettled (not all) so one failing fetch doesn't block the other.
      const [profileResult] = await Promise.allSettled([
        supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
        refreshAccountState()
      ]);
      let profile = {};
      if (profileResult.status === 'fulfilled') {
        const { data, error } = profileResult.value;
        if (error) console.error('Failed to load profile:', error);
        profile = data || {};
      } else {
        console.error('Failed to load profile:', profileResult.reason);
      }
      // Credits/tier are enforced server-side (gateway + Durable Object) now;
      // profiles.credits/plan are legacy v1 columns and no longer authoritative.
      BatCache.set(BATNXT_CACHE_PROFILE, {
        display_name: profile.display_name || null,
        photo_url: profile.photo_url || null
      });
      const meta = user.user_metadata || {};
      currentDisplayName = profile.display_name || meta.full_name || meta.name || "User";
      currentAboutMe = profile.about_me || '';
      memoryEnabled = profile.memory_enabled === true; // default off
      loadUserMemories();
      if (typeof syncModelLockUI === 'function') syncModelLockUI();
      if (typeof syncTypeLockUI === 'function') syncTypeLockUI();
      if (typeof syncToolLockUI === 'function') syncToolLockUI();
      if (typeof syncMarketingModelLockUI === 'function') syncMarketingModelLockUI();

      const initials = (currentDisplayName || user.email || "U")
        .split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
      document.getElementById("avatarInitials").textContent = initials;
      const photoURL = profile.photo_url || meta.avatar_url || meta.picture || "";
      if (photoURL) {
        const img = document.createElement("img");
        img.src = photoURL;
        document.getElementById("avatarInitials").replaceWith(img);
      }

      document.getElementById("ddName").textContent = currentDisplayName;
      document.getElementById("ddEmail").textContent = user.email || "";
      document.getElementById("ddPlan").textContent = (currentPlan || "free").toUpperCase();

      const firstName = currentDisplayName.split(" ")[0];
      const nameEl = document.getElementById("homeName");
      if (nameEl && firstName) nameEl.textContent = firstName;

      const usernameInput = document.getElementById('spUsernameInput');
      if (usernameInput) usernameInput.value = currentDisplayName;

      // Logged in: hide the "Start free" CTA and restore the "Sign Out" label.
      const startFreeBtn = document.getElementById("startFreeBtn");
      if (startFreeBtn) startFreeBtn.style.display = "none";
      const logoutLabel = document.querySelector('#logoutBtn [data-i18n]');
      if (logoutLabel) {
        logoutLabel.setAttribute('data-i18n', 'nav.signout');
        logoutLabel.textContent = BatLang.t('nav.signout');
      }

      updateCreditDisplay();
      loadGenHistory();
      loadHomeChatSessions().then(function () {
        if (!window.__batnxtChatUrlChecked) {
          window.__batnxtChatUrlChecked = true;
          openChatFromUrlIfPresent();
        }
      });
      // Preload the full (uncapped) chats list in the background so the sidebar's
      // "Show all" in-place expand (renderHomeChatHistory) is instant on first click.
      loadChatsViewSessions();
    }

    /* ── Save username from Settings ── */
    window.saveUsername = async function () {
      if (!currentUser) { requireLogin(); return; }
      const input = document.getElementById('spUsernameInput');
      const val = (input.value || '').trim();
      if (!val || val === currentDisplayName) return;

      await supabase.from('profiles').update({ display_name: val }).eq('id', currentUser.id);

      currentDisplayName = val;
      document.getElementById('ddName').textContent = val;
      const firstName = val.split(' ')[0];
      const nameEl = document.getElementById('homeName');
      if (nameEl && firstName) nameEl.textContent = firstName;
      const initialsEl = document.getElementById('avatarInitials');
      if (initialsEl) {
        initialsEl.textContent = val.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
      }
      if (typeof showToast === 'function') showToast(BatLang.t('sp.username.saved') || 'Saved');
    };

    /* ── Memory: "About Me" + auto-saved facts ──
       Lets BatNXT personalize replies using a manually-written bio plus short
       facts it quietly extracts from the conversation (opt-in via memoryEnabled). */
    async function loadUserMemories() {
      if (!currentUser) { userMemories = []; return; }
      const { data, error } = await supabase.from('memories').select('*').eq('user_id', currentUser.id).order('created_at', { ascending: false });
      if (error) { console.error('Failed to load memories:', error); userMemories = []; return; }
      userMemories = data || [];
      renderMemories();
    }

    function renderMemories() {
      const empty = document.getElementById('settingsMemoryEmpty');
      const list = document.getElementById('settingsMemoryList');
      if (!list) return;
      list.innerHTML = '';
      if (empty) empty.style.display = userMemories.length ? 'none' : '';
      userMemories.forEach(function (m) {
        const row = document.createElement('div');
        row.className = 'settings-mem-item';
        const txt = document.createElement('span');
        txt.className = 'settings-mem-text';
        txt.textContent = m.content;
        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'settings-mem-del';
        del.innerHTML = '✕';
        del.onclick = function () { window.deleteMemory(m.id); };
        row.appendChild(txt);
        row.appendChild(del);
        list.appendChild(row);
      });
    }

    window.saveAboutMe = async function () {
      if (!currentUser) { requireLogin(); return; }
      const input = document.getElementById('spAboutMeInput');
      const val = (input && input.value || '').trim().slice(0, 600);
      const { error } = await supabase.from('profiles').update({ about_me: val }).eq('id', currentUser.id);
      if (error) {
        console.error('Failed to save About Me:', error);
        if (typeof showToast === 'function') showToast(BatLang.t('sp.memory.saveFailed') || 'Could not save — please try again', 'error');
        return;
      }
      currentAboutMe = val;
      if (typeof showToast === 'function') showToast(BatLang.t('sp.memory.saved') || 'Saved');
    };

    window.setMemoryEnabled = async function (val) {
      if (!currentUser) { requireLogin(); return; }
      const on = (val === true || val === 'true');
      memoryEnabled = on;
      const { error } = await supabase.from('profiles').update({ memory_enabled: on }).eq('id', currentUser.id);
      if (error) console.error('Failed to save memory toggle:', error);
    };

    window.deleteMemory = async function (id) {
      if (!currentUser) return;
      userMemories = userMemories.filter(function (m) { return m.id !== id; });
      renderMemories();
      await supabase.from('memories').delete().eq('id', id).eq('user_id', currentUser.id);
    };

    window.clearAllMemories = async function () {
      if (!currentUser || !userMemories.length) return;
      if (!confirm(BatLang.t('sp.memory.clearConfirm') || 'Clear all remembered facts?')) return;
      userMemories = [];
      renderMemories();
      await supabase.from('memories').delete().eq('user_id', currentUser.id);
    };

    // ── Memory-extraction eligibility filter ──────────────────────────────
    // Pure code logic (no AI/network call) that decides whether a message is
    // even worth sending to maybeExtractMemory() below. Messages that are too
    // short, or that are just a common greeting/acknowledgement, essentially
    // never contain a durable fact — so we skip the (paid) /chat call for them
    // entirely instead of paying for the AI to say "NONE".
    //
    // Tune these two values freely — nothing else needs to change.
    const MEMORY_FILTER_MIN_WORDS = 10; // messages with fewer words than this are skipped. Arabic and English are both space-delimited (unlike e.g. Chinese), so a plain whitespace split works for either language.
    const MEMORY_FILTER_COMMON_PHRASES = [
      // Arabic greetings / small talk / acknowledgements
      'مرحبا', 'مرحباً', 'أهلا', 'اهلا', 'هلا', 'هلا وغلا',
      'كيفك', 'كيف حالك', 'شلونك', 'شو اخبارك', 'ايش اخبارك', 'شو الاخبار',
      'صباح الخير', 'صباح النور', 'مساء الخير', 'مساء النور',
      'شكرا', 'شكراً', 'شكرا الك', 'شكراً لك', 'يعطيك العافية', 'تسلم', 'تسلم ايدك',
      'تمام', 'ماشي', 'اوك', 'اوكي', 'أوكي', 'حسنا', 'حسناً', 'طيب',
      'نعم', 'لا', 'اكيد', 'بالتأكيد', 'بخير الحمد لله', 'الحمد لله بخير', 'بخير وانت', 'بخير وانتي',
      'مع السلامة', 'باي', 'الى اللقاء', 'وداعا',
      // English greetings / small talk / acknowledgements
      'hi', 'hey', 'hello', 'hey there', 'yo', 'sup',
      'good morning', 'good afternoon', 'good evening', 'good night',
      'how are you', 'how are you doing', "how's it going", "what's up", 'whats up',
      'thanks', 'thank you', 'thx', 'ty',
      'ok', 'okay', 'cool', 'nice', 'great', 'awesome', 'got it', 'sounds good',
      'no problem', 'np', 'sure', 'yes', 'no',
      'bye', 'goodbye', 'see you', 'see ya', 'take care'
    ];

    function isMemoryExtractionEligible(rawMsg) {
      const text = String(rawMsg || '').trim();
      if (!text) return false;
      // Strip common leading/trailing quotes & punctuation (Latin + Arabic) before matching.
      const normalized = text
        .replace(/^[\s"'“”‘’.,!?؟…]+|[\s"'“”‘’.,!?؟…]+$/g, '')
        .toLowerCase();
      if (MEMORY_FILTER_COMMON_PHRASES.indexOf(normalized) !== -1) return false;
      const wordCount = text.split(/\s+/).filter(Boolean).length;
      if (wordCount < MEMORY_FILTER_MIN_WORDS) return false;
      return true;
    }

    // Auto-title uses a MUCH lighter gate than memory extraction: most first
    // messages worth naming are short (e.g. "build me a todo app", "اعملي لعبة"),
    // so the 10-word MEMORY_FILTER_MIN_WORDS bar is far too high here and was
    // silently skipping titles for nearly every real request. We only skip
    // empty input and pure greetings/small-talk (where the first-message
    // truncation fallback title is already fine).
    const TITLE_MIN_WORDS = 2;
    function isTitleEligible(rawMsg) {
      const text = String(rawMsg || '').trim();
      if (!text) return false;
      const normalized = text
        .replace(/^[\s"'“”‘’.,!?؟…]+|[\s"'“”‘’.,!?؟…]+$/g, '')
        .toLowerCase();
      if (MEMORY_FILTER_COMMON_PHRASES.indexOf(normalized) !== -1) return false;
      const wordCount = text.split(/\s+/).filter(Boolean).length;
      if (wordCount < TITLE_MIN_WORDS) return false;
      return true;
    }

    /* ── "Thought for Xs" gating ──
       Decides whether a reply is substantive enough to warrant the reasoning
       widget. Two ways to qualify (approved: "word-count + keyword intent"):
         1. Long/non-trivial message — reuses the memory gate (≥10 words & not a
            greeting/small-talk phrase), so genuinely detailed asks always show it.
         2. Clear build/analyze/strategy intent — a shorter message (e.g.
            "اعملي موقع", "analyze this site", "financial plan") still qualifies via
            keyword match, but requires ≥2 words so a bare keyword doesn't trip it.
       Export requests are always excluded (they render the Analyzing card, not a
       thinking widget). Kept intentionally cheap/synchronous — it gates a
       best-effort UX nicety, so a miss just means no widget, never a broken reply. */
    const THINKING_KEYWORD_EN = /\b(build|create|make|generate|develop|design|implement|code|program|analy[sz]e|review|audit|evaluate|assess|compare|plan|strateg|optimi[sz]e|refactor|debug|website|web\s?app|web\s?site|landing|dashboard|application|app|game|tool|financ|invest|budget|revenue|profit|market|business)\b/i;
    const THINKING_KEYWORD_AR = /(اعمل|أعمل|اعملي|سوي|سويلي|صمم|صممي|ابن|ابني|انشئ|أنشئ|انشئلي|برمج|اكتب|اكتبلي|طور|طوّر|حلل|حلّل|حللي|راجع|قيّم|قيم|قارن|خطط|خطة|استراتيج|موقع|تطبيق|لعبة|اداة|أداة|لوحة|مالي|استثمار|ميزاني|ربح|ارباح|أرباح|تسويق|مشروع)/;
    function isSubstantiveForThinking(rawMsg) {
      const text = String(rawMsg || '').trim();
      if (!text) return false;
      // Export requests get the Analyzing card, not a thinking widget.
      if (typeof detectExportRequest === 'function' && detectExportRequest(text)) return false;
      // 1) Long, non-trivial message (≥10 words, not small talk).
      if (isMemoryExtractionEligible(text)) return true;
      // 2) Shorter, but a clear build/analyze/strategy intent.
      const wordCount = text.split(/\s+/).filter(Boolean).length;
      if (wordCount < 2) return false;
      return THINKING_KEYWORD_EN.test(text) || THINKING_KEYWORD_AR.test(text);
    }

    // Fire-and-forget: after a real reply, ask the lightweight worker whether the
    // user's last message contains a durable fact/preference worth remembering,
    // and silently save it if so. Never blocks or errors the chat UI.
    async function maybeExtractMemory(userMsg, aiMsg) {
      if (!currentUser || !memoryEnabled) return;
      try {
        const { res } = await gatewayFetch(bgChatRoute(), {
          system: 'You extract durable, worth-remembering facts about a user from one chat message — things like their name, profession, preferences, ongoing projects, or recurring tasks. Ignore small talk, one-off questions, and anything not worth remembering long-term. Reply with EXACTLY the word NONE if there is nothing worth remembering. Otherwise reply with ONE short factual sentence (max 140 characters) written in the same language as the user message, summarizing the fact in third person (e.g. "Works as a graphic designer.", "Prefers dark, minimal UI designs."). No quotes, no explanation, nothing else.',
          messages: [{ role: 'user', content: 'User message: ' + String(userMsg || '').slice(0, 600) }],
          // Marks this as a background helper call so the gateway rate-limits
          // it on its own separate lane instead of the user's real chat lane
          // (still billed normally for real token usage — see gateway.js).
          background: true
        }, { silent: true });
        // Streamed text/plain, not JSON — see the note in sendHwChatMessage().
        // The old res.json() threw on every call straight into the silent catch
        // below, so memory extraction NEVER ran for anyone: no memory was ever
        // saved, and the failure was invisible by design.
        // bgChatRoute() resolves to /chat/core for Free (and for anyone on the
        // Core selector), which emits <REASONING> — strip it BEFORE the NONE
        // test and the quote-trim below, or the model's chain-of-thought would
        // be stored verbatim as the "memory" and would never match /^none$/.
        const raw = stripInlineReasoning(await streamPlainText(res))
          .trim().replace(/^["'""'']+|["'""'']+$/g, '');
        if (!raw || /^none$/i.test(raw)) return;
        const content = raw.slice(0, 200);
        const { data: inserted, error } = await supabase.from('memories').insert({ user_id: currentUser.id, content: content }).select().maybeSingle();
        if (error) { console.error('Failed to save memory:', error); return; }
        if (inserted) { userMemories.unshift(inserted); renderMemories(); }
      } catch (e) { /* fail silently — memory extraction is best-effort */ }
    }

    /* ── Upgrade button text (Account tab + Billing tab) ──
     * Both buttons are fully JS-driven (no data-i18n) so their text/visibility
     * tracks the user's *current* tier instead of a static "Upgrade to Pro".
     */
    function updateUpgradeButtonText() {
      const ids = ['accountUpgradeBtn', 'billingUpgradeBtn'];
      const lang = BatLang.lang;
      const TEXT = {
        free:    { en: 'Upgrade Plan →',   ar: 'ترقية الخطة ←',        tr: 'Planı Yükselt →' },
        starter: { en: 'Upgrade to Pro →', ar: 'الترقية إلى برو ←',    tr: "Pro'ya Yükselt →" },
        pro:     { en: 'Upgrade to Max →', ar: 'الترقية إلى ماكس ←',   tr: "Max'e Yükselt →" },
      };
      const entry = TEXT[currentPlan];
      for (const id of ids) {
        const btn = document.getElementById(id);
        if (!btn) continue;
        if (!entry) { btn.style.display = 'none'; continue; } // max tier: hide
        btn.style.display = '';
        btn.textContent = entry[lang] || entry.en;
      }
    }
    window.updateUpgradeButtonText = updateUpgradeButtonText;

    /* ── Credit display ── */
    window.updateCreditDisplay = function () {
      var _cN = document.getElementById("creditsNum");
      if (_cN) _cN.textContent = currentCredits;
      var _cB = document.getElementById("creditsBig");
      if (_cB) _cB.textContent = currentCredits;
      const hintEl = document.getElementById("creditHintNum");
      if (hintEl) hintEl.textContent = currentCredits;

      // Reflect the real plan in the credits dropdown (was hard-coded "Free plan").
      const planName = (PLAN_LABELS[currentPlan] || 'Free');
      const planTextEl = document.getElementById("creditsPlanText");
      if (planTextEl) {
        planTextEl.removeAttribute('data-i18n'); // stop setLang() overwriting it
        const lang = BatLang.lang;
        planTextEl.textContent = lang === 'ar'
          ? ('أنت على خطة ' + planName + '.')
          : lang === 'tr'
            ? (planName + ' planındasınız.')
            : ("You're on the " + planName + " plan.");
      }
      // Hide the upgrade CTA once the user is already on a paid plan.
      const upBtn = document.getElementById("upgradeFromCreditsBtn");
      if (upBtn) upBtn.style.display = (currentPlan === 'free') ? '' : 'none';
      updateUpgradeButtonText();
    };

    /* ── Dropdowns ── */
    function initDropdown(triggerEl, panelEl) {
      triggerEl.addEventListener("click", (e) => {
        e.stopPropagation();
        document.querySelectorAll(".dropdown-panel.open").forEach(p => {
          if (p !== panelEl) p.classList.remove("open");
        });
        panelEl.classList.toggle("open");
      });
    }
    const _creditsBtn = document.getElementById("creditsBtn");
    if (_creditsBtn) initDropdown(_creditsBtn, document.getElementById("creditsDropdown"));
    document.addEventListener("click", () => {
      document.querySelectorAll(".dropdown-panel.open").forEach(p => p.classList.remove("open"));
    });

    /* ── Profile popup menu ── */
    const _profileTrigger = document.getElementById("profileTrigger");
    const _sidebarProfile = document.getElementById("sidebarProfile");
    if (_profileTrigger && _sidebarProfile) {
      _profileTrigger.addEventListener("click", (e) => {
        e.stopPropagation();
        const open = _sidebarProfile.classList.toggle("open");
        _profileTrigger.setAttribute("aria-expanded", open ? "true" : "false");
      });
      document.addEventListener("click", () => {
        _sidebarProfile.classList.remove("open");
        _profileTrigger.setAttribute("aria-expanded", "false");
        if (typeof window.closeProfileLangFlyout === 'function') window.closeProfileLangFlyout();
      });
      const _profileMenu = document.getElementById("profileMenu");
      if (_profileMenu) _profileMenu.addEventListener("click", (e) => e.stopPropagation());
      // The language flyout lives outside #profileMenu (see the flyout's own
      // comment in index.html for why), so it needs the same stopPropagation
      // guard to avoid the handler above closing the whole menu out from
      // under it when the user clicks inside the flyout itself.
      const _profileLangFlyout = document.getElementById("profileLangFlyout");
      if (_profileLangFlyout) _profileLangFlyout.addEventListener("click", (e) => e.stopPropagation());
    }

    /* ── Upgrade modal ── */
    function showUpgradeModal() {
      // Plain "go look at plans" entry point (sidebar CTA, ?openUpgrade=1
      // redirect) — no out-of-credits countdown/Recharge CTA to show here.
      stopOutOfCreditsCountdown();
      const countdown = document.getElementById('outOfCreditsCountdown');
      const rechargeBtn = document.getElementById('rechargeNowBtn');
      if (countdown) countdown.style.display = 'none';
      if (rechargeBtn) rechargeBtn.style.display = 'none';
      updateOutOfCreditsModalText(); // shares #upgradeModal's title/desc/CTA — keep tier-aware here too
      document.getElementById("upgradeModal").classList.add("active");
    }
    window.showUpgradeModal = showUpgradeModal;

    // Redirected here from a Max-gated page (e.g. alfred.html) without
    // access — surface the upgrade modal automatically.
    (function checkOpenUpgradeParam() {
      try {
        var params = new URLSearchParams(window.location.search);
        if (params.get('openUpgrade') === '1') {
          var attempts = 0;
          var chk = setInterval(function () {
            attempts++;
            if (typeof window.showUpgradeModal === 'function' && document.getElementById('upgradeModal')) {
              clearInterval(chk);
              window.showUpgradeModal();
            } else if (attempts > 40) {
              clearInterval(chk);
            }
          }, 100);
        }
      } catch (e) {}
    })();

    document.getElementById("modalDismiss").addEventListener("click", () => {
      document.getElementById("upgradeModal").classList.remove("active");
      stopOutOfCreditsCountdown();
    });

    /* ── Recharge Now modal ── */
    function computeFullRefillLabel(tier) {
      const usd = RECHARGE_PRICES.full_refill[tier] ?? RECHARGE_PRICES.full_refill.free;
      return '$' + usd.toFixed(2);
    }
    function updateCustomAmountUI() {
      const slider = document.getElementById('rechargeCustomSlider');
      if (!slider) return;
      const credits = Number(slider.value) || CUSTOM_AMOUNT_MIN_CREDITS;
      const usd = credits * CUSTOM_AMOUNT_USD_PER_CREDIT;
      const creditsOut = document.getElementById('rechargeCustomCredits');
      const priceOut = document.getElementById('rechargeCustomPrice');
      if (creditsOut) creditsOut.textContent = credits;
      if (priceOut) priceOut.textContent = '$' + usd.toFixed(2);
    }
    // Shows a specific date ("You can recharge again on <date>") + a simple
    // day-count line below it, in place of the recharge options, while
    // _lastNextRechargeAt is in the future. Deliberately static (computed once
    // per render) - no live countdown-by-seconds, per design.
    function updateRechargeCooldownUI() {
      const notice = document.getElementById('rechargeCooldownNotice');
      const dateEl = document.getElementById('rechargeCooldownDate');
      const subEl = document.getElementById('rechargeCooldownSub');
      const optionsEl = document.getElementById('rechargeOptions');
      const customEl = document.getElementById('rechargeCustom');
      const onCooldown = !!(_lastNextRechargeAt && new Date(_lastNextRechargeAt).getTime() > Date.now());
      if (notice) notice.classList.toggle('show', onCooldown);
      if (optionsEl) optionsEl.style.display = onCooldown ? 'none' : '';
      if (customEl) customEl.style.display = onCooldown ? 'none' : '';
      if (!onCooldown) return;
      const lang = BatLang.lang;
      const locale = { ar: 'ar-SA', tr: 'tr-TR', en: 'en-US' }[lang] || 'en-US';
      const allowedAt = new Date(_lastNextRechargeAt);
      if (dateEl) dateEl.textContent = allowedAt.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
      const daysLeft = Math.max(1, Math.ceil((allowedAt.getTime() - Date.now()) / (24 * 60 * 60 * 1000)));
      if (subEl) {
        subEl.textContent = lang === 'ar' ? `باقي ${daysLeft} يوم`
          : lang === 'tr' ? `${daysLeft} gün kaldı`
          : `${daysLeft} day${daysLeft === 1 ? '' : 's'} left`;
      }
    }
    function renderRechargeModal() {
      const tier = currentPlan || 'free';
      const refill = document.getElementById('rechargePriceRefill');
      if (refill) refill.textContent = computeFullRefillLabel(tier);
      const slider = document.getElementById('rechargeCustomSlider');
      if (slider) {
        slider.min = CUSTOM_AMOUNT_MIN_CREDITS;
        slider.max = CUSTOM_AMOUNT_MAX_CREDITS;
        slider.step = CUSTOM_AMOUNT_STEP_CREDITS;
        if (!slider.value || Number(slider.value) < CUSTOM_AMOUNT_MIN_CREDITS) {
          slider.value = CUSTOM_AMOUNT_MIN_CREDITS;
        }
      }
      updateCustomAmountUI();
      updateRechargeCooldownUI();
    }
    window.showRechargeModal = function () {
      renderRechargeModal();
      const m = document.getElementById('rechargeModal');
      if (m) m.classList.add('active');
    };
    window.closeRechargeModal = function () {
      const m = document.getElementById('rechargeModal');
      if (m) m.classList.remove('active');
    };

    // Generic in-app confirm dialog, replacing native window.confirm() popups
    // (which look like broken browser chrome, e.g. "localhost:PORT says...").
    // Usage: const ok = await window.showConfirmDialog(title, message, okLabel);
    let _confirmDialogResolve = null;
    window.showConfirmDialog = function (title, message, okLabel) {
      return new Promise((resolve) => {
        _confirmDialogResolve = resolve;
        const modal = document.getElementById('confirmDialogModal');
        const titleEl = document.getElementById('confirmDialogTitle');
        const msgEl = document.getElementById('confirmDialogMsg');
        const okBtn = document.getElementById('confirmDialogOk');
        if (titleEl) titleEl.textContent = title;
        if (msgEl) msgEl.textContent = message;
        if (okBtn) okBtn.textContent = okLabel || 'Delete';
        if (modal) modal.classList.add('active');
      });
    };
    window.closeConfirmDialog = function (result) {
      const modal = document.getElementById('confirmDialogModal');
      if (modal) modal.classList.remove('active');
      if (_confirmDialogResolve) { _confirmDialogResolve(result); _confirmDialogResolve = null; }
    };

    // ── Usage popup ──────────────────────────────────────────────────────
    // Opens above the composer credits pill. Shows plan, credit balance +
    // reset countdown (kept live by the 1s credit ticker), the weekly cap for
    // paid plans, and an upgrade CTA. Positioned `fixed` from the pill's rect.
    // The usage popup is shared by the Home composer pill (#homeCredsPill) and
    // the Marketing composer pill (#marketingCredsPill). Only one composer is
    // ever on screen at a time, so anchor/aria logic must target whichever pill
    // is actually visible (offsetParent === null ⇒ it or an ancestor is
    // display:none, i.e. the hidden view's pill). Falls back to the home pill.
    function activeCredsPill() {
      const mkt = document.getElementById('marketingCredsPill');
      if (mkt && mkt.offsetParent !== null) return mkt;
      return document.getElementById('homeCredsPill');
    }
    function positionUsagePopup() {
      const pill = activeCredsPill();
      const popup = document.getElementById('usagePopup');
      if (!pill || !popup) return;
      const rect = pill.getBoundingClientRect();
      const w = 262;
      let left = rect.left + rect.width / 2 - w / 2;
      if (left < 8) left = 8;
      if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
      popup.style.left = left + 'px';
      // Anchor above the pill regardless of the popup's (variable) height.
      popup.style.bottom = (window.innerHeight - rect.top + 8) + 'px';
    }
    function renderUsagePopupExtras() {
      const planEl = document.getElementById('usagePopupPlan');
      if (planEl) planEl.textContent = (typeof PLAN_LABELS !== 'undefined' && PLAN_LABELS[currentPlan]) || currentPlan || 'Free';
      // Max plan has nothing to upgrade to — hide the CTA there.
      const upBtn = document.getElementById('usagePopupUpgrade');
      if (upBtn) upBtn.style.display = (currentPlan === 'max') ? 'none' : '';
      // Weekly cap (paid plans only; free has no cap → hidden).
      const weeklyWrap = document.getElementById('usagePopupWeekly');
      const w = _lastWeekly;
      if (weeklyWrap) {
        if (!w || w.cap == null) { weeklyWrap.style.display = 'none'; }
        else {
          weeklyWrap.style.display = '';
          const pct = Math.max(0, Math.min(100, (w.usage / w.cap) * 100));
          const fill = document.getElementById('usagePopupWeeklyFill');
          if (fill) {
            fill.style.width = pct + '%';
            fill.style.background = pct >= 100 ? 'var(--red)' : pct >= 80 ? '#facc15' : 'var(--accent)';
          }
          const num = document.getElementById('usagePopupWeeklyNum');
          if (num) num.textContent = Math.min(w.usage, w.cap) + ' / ' + w.cap + ' credits this week';
        }
      }
      // Free-Plan Lifetime Credit Cap mini-bar (see LIFETIME_FREE_CAP_NEW/
      // _RETURNING in worker/gateway.js) - mirrors the weekly block above;
      // only free-tier accounts ever have _lastLifetime.cap set (paid tiers
      // aren't gated by this counter, same condition updateLifetimeCapUI()
      // in the Billing tab uses).
      const lifetimeWrap = document.getElementById('usagePopupLifetime');
      const l = _lastLifetime;
      if (!lifetimeWrap) return;
      if (!l || l.cap == null) { lifetimeWrap.style.display = 'none'; return; }
      lifetimeWrap.style.display = '';
      const lpct = Math.max(0, Math.min(100, (l.used / l.cap) * 100));
      const lfill = document.getElementById('usagePopupLifetimeFill');
      if (lfill) {
        lfill.style.width = lpct + '%';
        lfill.style.background = lpct >= 100 ? 'var(--red)' : lpct >= 80 ? '#facc15' : 'var(--accent)';
      }
      const lnum = document.getElementById('usagePopupLifetimeNum');
      if (lnum) lnum.textContent = Math.min(l.used, l.cap) + ' / ' + l.cap + ' lifetime credits';
    }
    window.toggleUsagePopup = function (e) {
      if (e) e.stopPropagation();
      const pill = activeCredsPill();
      const popup = document.getElementById('usagePopup');
      if (!pill || !popup) return;
      if (popup.classList.contains('open')) { window.closeUsagePopup(); return; }
      // Only one composer flyout (model picker or credit/usage popup) should
      // be visible at a time — close the model menu before opening this one.
      if (typeof window.closeModelMenu === 'function') window.closeModelMenu();
      if (typeof renderAllCreditWidgets === 'function') renderAllCreditWidgets();
      renderUsagePopupExtras();
      positionUsagePopup();
      popup.classList.add('open');
      pill.setAttribute('aria-expanded', 'true');
    };
    window.closeUsagePopup = function () {
      const popup = document.getElementById('usagePopup');
      if (popup) popup.classList.remove('open');
      // Reset aria on both composer pills (only one is ever open at a time, but
      // clearing both keeps their states correct regardless of which opened it).
      ['homeCredsPill', 'marketingCredsPill'].forEach(function (id) {
        const p = document.getElementById(id);
        if (p) p.setAttribute('aria-expanded', 'false');
      });
    };
    // Jump from the usage popup straight to Settings → Usage & billing.
    window.goToUsageBilling = function (e) {
      if (e) e.stopPropagation();
      window.closeUsagePopup();
      if (typeof window.showSettingsModal === 'function') window.showSettingsModal();
      if (typeof window.spShowTab === 'function') window.spShowTab('billing');
    };
    document.addEventListener('click', function (e) {
      const popup = document.getElementById('usagePopup');
      const pill = document.getElementById('homeCredsPill');
      if (popup && popup.classList.contains('open') &&
          !popup.contains(e.target) && (!pill || !pill.contains(e.target))) {
        window.closeUsagePopup();
      }
    });
    window.addEventListener('resize', function () {
      const popup = document.getElementById('usagePopup');
      if (popup && popup.classList.contains('open')) positionUsagePopup();
    });
    async function doRecharge(type, credits) {
      const controls = document.querySelectorAll('.recharge-option, .recharge-custom-btn, #rechargeCustomSlider');
      controls.forEach(b => b.disabled = true);
      try {
        const payload = type === 'custom_amount' ? { credits } : {};
        const { res } = await gatewayFetch('/recharge/' + type, payload);
        await res.json();
        const lang = BatLang.lang;
        const msg = lang === 'ar' ? 'تم الشحن بنجاح!'
          : lang === 'tr' ? 'Yükleme başarılı!'
          : 'Recharge successful!';
        showToast(msg, 'success');
        window.closeRechargeModal();
        document.getElementById('upgradeModal').classList.remove('active');
        stopOutOfCreditsCountdown();
        await refreshAccountState();
      } catch (e) {
        if (e && e.message === 'recharge_on_cooldown') {
          // Stale modal state (e.g. two tabs, or clicking right at the
          // boundary) - resync the cooldown notice instead of the generic
          // failure toast below.
          _lastNextRechargeAt = e.nextRechargeAt || _lastNextRechargeAt;
          updateRechargeCooldownUI();
        } else if (e && e.message !== 'no_credits' && e.message !== 'rate_limited') {
          // gatewayFetch already surfaces 402/429 via its own shared UI; anything
          // else (network/server error) gets a dedicated recharge-failed toast.
          const lang = BatLang.lang;
          const msg = lang === 'ar' ? 'فشلت عملية الشحن. حاول مرة أخرى.'
            : lang === 'tr' ? 'Yükleme başarısız oldu. Tekrar deneyin.'
            : 'Recharge failed. Please try again.';
          showToast(msg, 'error');
        }
      } finally {
        controls.forEach(b => b.disabled = false);
      }
    }
    const _rechargeOptionsEl = document.getElementById('rechargeOptions');
    if (_rechargeOptionsEl) {
      _rechargeOptionsEl.addEventListener('click', (e) => {
        const opt = e.target.closest('.recharge-option[data-type="full_refill"]');
        if (!opt) return;
        doRecharge('full_refill');
      });
    }
    const _rechargeCustomSlider = document.getElementById('rechargeCustomSlider');
    if (_rechargeCustomSlider) _rechargeCustomSlider.addEventListener('input', updateCustomAmountUI);
    const _rechargeCustomBtn = document.getElementById('rechargeCustomBtn');
    if (_rechargeCustomBtn) {
      _rechargeCustomBtn.addEventListener('click', () => {
        const slider = document.getElementById('rechargeCustomSlider');
        const credits = Number(slider && slider.value) || CUSTOM_AMOUNT_MIN_CREDITS;
        doRecharge('custom_amount', credits);
      });
    }
    const _rechargeDismissBtn = document.getElementById('rechargeDismiss');
    if (_rechargeDismissBtn) _rechargeDismissBtn.addEventListener('click', window.closeRechargeModal);
    const _rechargeNowBtn = document.getElementById('rechargeNowBtn');
    if (_rechargeNowBtn) _rechargeNowBtn.addEventListener('click', () => window.showRechargeModal());
    const _weeklyResetBtnWarning = document.getElementById('weeklyResetBtnWarning');
    if (_weeklyResetBtnWarning) _weeklyResetBtnWarning.addEventListener('click', () => window.doWeeklyReset());
    const _weeklyResetBtnBlocked = document.getElementById('weeklyResetBtnBlocked');
    if (_weeklyResetBtnBlocked) _weeklyResetBtnBlocked.addEventListener('click', () => window.doWeeklyReset());

    /* ── Settings / News / Support modals ── */
    const PLAN_LABELS = { free: 'Free', starter: 'Starter', pro: 'Pro', max: 'Max' };
    const PLAN_CREDIT_LABELS = { free: '200 credits / 24h', starter: '100 credits / 9h', pro: '160 credits / 6h', max: '800 credits / 6h' };

    window.refreshLangBtns = function() {
      const lang = BatLang.lang;
      ['en','ar','tr'].forEach(function(l) {
        var cap = l.charAt(0).toUpperCase() + l.slice(1);
        var pl = document.getElementById('pl' + cap);
        if (pl) pl.classList.toggle('lang-active', l === lang);
        var sl = document.getElementById('sl' + cap);
        if (sl) sl.classList.toggle('lang-active', l === lang);
      });
      document.querySelectorAll('.lang-opt').forEach(function(opt) {
        opt.classList.toggle('active', opt.dataset.lang === lang);
      });
    };

    window.showSettingsModal = function() {
      // Account tab and Usage & Billing tab both show plan/credits — kept live
      // via the shared credit-window engine (renderCreditWidget/startCreditsTicker)
      // instead of a one-shot static render.
      ['settings', 'billing'].forEach(function(prefix) {
        const pName = document.getElementById(prefix + 'PlanName');
        const pSub  = document.getElementById(prefix + 'PlanSub');
        if (pName) pName.textContent = PLAN_LABELS[currentPlan] || currentPlan;
        if (pSub)  pSub.textContent  = PLAN_CREDIT_LABELS[currentPlan] || '';
      });
      renderCreditWidget({ numEl: 'settingsCredsNum', fillEl: 'settingsCreditsFill', periodEl: 'settingsCredsReset', fraction: true, verbose: true });
      renderCreditWidget({ numEl: 'billingCredsNum', fillEl: 'billingCreditsFill', periodEl: 'billingCredsReset', fraction: true, verbose: true });
      startCreditsTicker();
      updateUpgradeButtonText();
      const usernameInput = document.getElementById('spUsernameInput');
      if (usernameInput) usernameInput.value = currentDisplayName || '';
      window.refreshLangBtns();
      const aboutInput = document.getElementById('spAboutMeInput');
      if (aboutInput) aboutInput.value = currentAboutMe || '';
      const memToggle = document.getElementById('spMemoryToggle');
      if (memToggle) memToggle.value = memoryEnabled ? 'true' : 'false';
      renderMemories();
      document.getElementById('settingsModal').classList.add('active');
      document.getElementById('sidebarProfile').classList.remove('open');
    };

    /* ── Settings tab switcher ── */
    window.spShowTab = function(tab, btn) {
      document.querySelectorAll('.sp-section').forEach(el => el.classList.remove('sp-visible'));
      document.querySelectorAll('.sp-nav-btn').forEach(el => el.classList.remove('sp-active'));
      const sec = document.getElementById('spTab-' + tab);
      if (sec) sec.classList.add('sp-visible');
      if (btn) btn.classList.add('sp-active');
    };

    /* searchable language dropdown inside Settings → General */
    function spLangDDRender(filterText) {
      const listEl = document.getElementById('spLangDDList');
      if (!listEl || typeof BatLang === 'undefined' || !BatLang.LANGS) return;
      const currentLang = BatLang.lang;
      const q = (filterText || '').trim().toLowerCase();
      const items = BatLang.LANGS.filter(function(l) {
        if (!q) return true;
        return l.label.toLowerCase().indexOf(q) !== -1 ||
               l.native.toLowerCase().indexOf(q) !== -1 ||
               l.code.toLowerCase().indexOf(q) !== -1;
      });
      listEl.innerHTML = '';
      if (!items.length) {
        const empty = document.createElement('div');
        empty.className = 'sp-lang-dd-empty';
        empty.textContent = BatLang.t('sp.language.noResults') || 'No languages found';
        listEl.appendChild(empty);
        return;
      }
      items.forEach(function(l) {
        const opt = document.createElement('div');
        opt.className = 'sp-lang-dd-opt' + (l.code === currentLang ? ' lang-active' : '');
        opt.setAttribute('data-lang', l.code);
        opt.innerHTML =
          '<span class="sp-lang-dd-opt-flag">' + l.flag + '</span>' +
          '<span class="sp-lang-dd-opt-names">' +
            '<span class="sp-lang-dd-opt-native">' + l.native + '</span>' +
            '<span class="sp-lang-dd-opt-label">' + l.label + '</span>' +
          '</span>' +
          (l.code === currentLang
            ? '<svg class="sp-lang-dd-opt-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>'
            : '');
        opt.addEventListener('click', function() {
          setLang(l.code);
          window.refreshLangBtns();
          window.closeLangDropdown();
        });
        listEl.appendChild(opt);
      });
    }

    window.filterLangDropdown = function(text) {
      spLangDDRender(text);
    };

    window.toggleLangDropdown = function(e) {
      if (e) e.stopPropagation();
      const dd = document.getElementById('spLangDD');
      if (!dd) return;
      if (dd.classList.contains('sp-lang-dd-open')) {
        window.closeLangDropdown();
        return;
      }
      dd.classList.add('sp-lang-dd-open');
      const search = document.getElementById('spLangDDSearch');
      if (search) search.value = '';
      spLangDDRender('');
      if (search) setTimeout(function() { search.focus(); }, 0);
    };

    window.closeLangDropdown = function() {
      const dd = document.getElementById('spLangDD');
      if (dd) dd.classList.remove('sp-lang-dd-open');
    };

    document.addEventListener('click', function(e) {
      const dd = document.getElementById('spLangDD');
      if (dd && dd.classList.contains('sp-lang-dd-open') && !dd.contains(e.target)) {
        window.closeLangDropdown();
      }
    });

    /* Language flyout inside the profile menu — click "Language" to reveal
       a side panel listing all languages (reuses the same sp-lang-dd-opt*
       row styling as the Settings dropdown, just in a fixed-position
       flyout so it isn't clipped by .profile-menu's overflow/transform). */
    function renderProfileLangFlyout() {
      const listEl = document.getElementById('profileLangFlyout');
      if (!listEl || typeof BatLang === 'undefined' || !BatLang.LANGS) return;
      const currentLang = BatLang.lang;
      listEl.innerHTML = '';
      BatLang.LANGS.forEach(function(l) {
        const opt = document.createElement('div');
        opt.className = 'sp-lang-dd-opt' + (l.code === currentLang ? ' lang-active' : '');
        opt.innerHTML =
          '<span class="sp-lang-dd-opt-flag">' + l.flag + '</span>' +
          '<span class="sp-lang-dd-opt-names">' +
            '<span class="sp-lang-dd-opt-native">' + l.native + '</span>' +
            '<span class="sp-lang-dd-opt-label">' + l.label + '</span>' +
          '</span>' +
          (l.code === currentLang
            ? '<svg class="sp-lang-dd-opt-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>'
            : '');
        opt.addEventListener('click', function() {
          setLang(l.code);
          window.refreshLangBtns();
          window.closeProfileLangFlyout();
          const sp = document.getElementById('sidebarProfile');
          if (sp) sp.classList.remove('open');
        });
        listEl.appendChild(opt);
      });
    }

    window.toggleProfileLangFlyout = function(e) {
      if (e) e.stopPropagation();
      const btn = document.getElementById('menuLanguage');
      const flyout = document.getElementById('profileLangFlyout');
      if (!btn || !flyout) return;
      if (flyout.classList.contains('open')) {
        window.closeProfileLangFlyout();
        return;
      }
      renderProfileLangFlyout();
      const rect = btn.getBoundingClientRect();
      const flyoutWidth = 220;
      let left = rect.right + 8;
      if (left + flyoutWidth > window.innerWidth - 8) left = rect.left - flyoutWidth - 8;
      let top = rect.top;
      const flyoutMaxHeight = 320;
      if (top + flyoutMaxHeight > window.innerHeight - 8) top = Math.max(8, window.innerHeight - flyoutMaxHeight - 8);
      flyout.style.left = left + 'px';
      flyout.style.top = top + 'px';
      flyout.classList.add('open');
      btn.setAttribute('aria-expanded', 'true');
    };

    window.closeProfileLangFlyout = function() {
      const btn = document.getElementById('menuLanguage');
      const flyout = document.getElementById('profileLangFlyout');
      if (flyout) flyout.classList.remove('open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
    };

    document.addEventListener('click', function(e) {
      const flyout = document.getElementById('profileLangFlyout');
      const btn = document.getElementById('menuLanguage');
      if (flyout && flyout.classList.contains('open') &&
          !flyout.contains(e.target) && (!btn || !btn.contains(e.target))) {
        window.closeProfileLangFlyout();
      }
    });

    document.addEventListener('keydown', function(e) {
      if (e.key !== 'Escape') return;
      window.closeLangDropdown();
      // Also close the sidebar's history/Projects context menu (if open)
      // and clear an active sidebar search, extending the single Escape
      // listener rather than adding a second one.
      if (_shiMenuEl) { _shiMenuEl.remove(); _shiMenuEl = null; }
      if (_shiMenuClose) { document.removeEventListener('click', _shiMenuClose); _shiMenuClose = null; }
      var searchInput = document.getElementById('sidebarSearchInput');
      if (searchInput && searchInput.value) {
        searchInput.value = '';
        if (typeof window.filterSidebar === 'function') window.filterSidebar('');
      }
      if (searchInput === document.activeElement) searchInput.blur();
    });

    const _origRefreshLangBtns = window.refreshLangBtns;
    window.refreshLangBtns = function() {
      if (_origRefreshLangBtns) _origRefreshLangBtns();
      if (typeof BatLang === 'undefined' || !BatLang.LANGS) return;
      const lang = BatLang.lang;
      const info = BatLang.LANGS.find(function(l) { return l.code === lang; }) || BatLang.LANGS[0];
      const flagEl = document.getElementById('spLangDDFlag');
      const nameEl = document.getElementById('spLangDDName');
      if (flagEl && info) flagEl.textContent = info.flag;
      if (nameEl && info) nameEl.textContent = info.native;
      const dd = document.getElementById('spLangDD');
      if (dd && dd.classList.contains('sp-lang-dd-open')) {
        const search = document.getElementById('spLangDDSearch');
        spLangDDRender(search ? search.value : '');
      }
    };

    /* appearance toggle */
    window.spApplyAppearance = function(val) {
      if (val === 'light') {
        document.documentElement.classList.add('light-theme');
        document.documentElement.style.setProperty('--bg','#c5d1c0');
        document.documentElement.style.setProperty('--surface','#ffffff');
        document.documentElement.style.setProperty('--surface2','#eef0f4');
        document.documentElement.style.setProperty('--card','#ffffff');
        document.documentElement.style.setProperty('--border','#d8dde8');
        document.documentElement.style.setProperty('--border-soft','rgba(0,0,0,0.07)');
        document.documentElement.style.setProperty('--text','#0d1117');
        document.documentElement.style.setProperty('--text-secondary','#374151');
        document.documentElement.style.setProperty('--text-muted','#6b7280');
      } else {
        document.documentElement.classList.remove('light-theme');
        document.documentElement.style.setProperty('--bg','#060810');
        document.documentElement.style.setProperty('--surface','#0b0f1a');
        document.documentElement.style.setProperty('--surface2','#0f1420');
        document.documentElement.style.setProperty('--card','#0c1018');
        document.documentElement.style.setProperty('--border','#1a2235');
        document.documentElement.style.setProperty('--border-soft','rgba(255,255,255,0.06)');
        document.documentElement.style.setProperty('--text','#f0f4fc');
        document.documentElement.style.setProperty('--text-secondary','#8892a4');
        document.documentElement.style.setProperty('--text-muted','#4a566a');
      }
    };
    /* ── home composer theme toggle ── */
    var _currentTheme = localStorage.getItem('batlab_theme') || 'light';

    function _applyThemeIcon(theme) {
      var icon = document.getElementById('homeThemeIcon');
      if (!icon) return;
      if (theme === 'light') {
        // moon icon when light (click → go dark)
        icon.innerHTML = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
      } else {
        // sun icon when dark (click → go light)
        icon.innerHTML = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
      }
    }

    window.homeToggleTheme = function () {
      _currentTheme = (_currentTheme === 'dark') ? 'light' : 'dark';
      localStorage.setItem('batlab_theme', _currentTheme);
      window.spApplyAppearance(_currentTheme);
      // Sync the settings dropdown if it exists
      var sel = document.getElementById('spAppearance');
      if (sel) sel.value = _currentTheme;
      _applyThemeIcon(_currentTheme);
    };

    // Apply saved theme on load
    (function () {
      window.spApplyAppearance(_currentTheme);
      // Wait for DOM to set icon
      var ready = function() { _applyThemeIcon(_currentTheme); };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
      else ready();
    })();

    window.closeSettingsModal = function() {
      document.getElementById('settingsModal').classList.remove('active');
    };

    window.showNewsModal = function() {
      document.getElementById('newsModal').classList.add('active');
      document.getElementById('sidebarProfile').classList.remove('open');
    };
    window.closeNewsModal = function() {
      document.getElementById('newsModal').classList.remove('active');
    };

    window.showSupportModal = function() {
      document.getElementById('supportModal').classList.add('active');
      document.getElementById('sidebarProfile').classList.remove('open');
    };
    window.closeSupportModal = function() {
      document.getElementById('supportModal').classList.remove('active');
    };

    /* ── Toast ── */
    function showToast(msg, type = "success") {
      const el = document.getElementById("toast");
      el.textContent = msg;
      el.className = `toast show ${type}`;
      setTimeout(() => el.classList.remove("show"), 3500);
    }

    /* ── Generation History (Supabase) ── */
    let genHistory = [];

    async function saveGenHistory(prompt, type, subtype = '', chatSessionId = null) {
      if (!currentUser) return;
      try {
        const { data, error } = await supabase.from('generations').insert({
          user_id: currentUser.id,
          prompt,
          type,
          subtype,
          chat_session_id: chatSessionId,
          archived: false
        }).select().single();
        if (error) throw error;
        // add locally for instant UI update
        genHistory.unshift({ id: data.id, prompt, type, subtype, chatSessionId, archived: false, ts: Date.now() });
        genHistory = genHistory.slice(0, 30);
        renderGenHistory();
      } catch(e) {
        console.error('Failed to save generation:', e);
      }
    }

    let recentLoadFailed = false;
    async function loadGenHistory() {
      if (!currentUser) return;
      recentLoadFailed = false;
      renderRecentSkeleton();
      try {
        const { data, error } = await supabase.from('generations')
          .select('*')
          .eq('user_id', currentUser.id)
          .order('ts', { ascending: false })
          .limit(50);
        if (error) throw error;
        const all = (data || []).map(d => ({
          id: d.id,
          prompt: d.prompt,
          type: d.type,
          subtype: d.subtype || '',
          chatSessionId: d.chat_session_id || null,
          ts: d.ts ? new Date(d.ts).getTime() : Date.now()
        }));
        genHistory = all.slice(0, 30);
      } catch(e) {
        console.error('Failed to load history:', e);
        genHistory = [];
        recentLoadFailed = true;
      } finally {
        // always hide skeleton regardless of success/failure
        const loading = document.getElementById('genHistoryLoading');
        if (loading) loading.style.display = 'none';
        renderGenHistory();
      }
    }
    window.loadGenHistory = loadGenHistory;

    // Permanently clear ALL generations (kept for compatibility).
    window.clearGenHistory = async function() {
      if (!currentUser) return;
      try {
        await supabase.from('generations').delete().eq('user_id', currentUser.id);
        genHistory = [];
        renderGenHistory();
      } catch(e) {
        console.error('Failed to clear history:', e);
      }
    };

    function timeAgo(ts) {
      const diff = Date.now() - ts;
      const m = Math.floor(diff / 60000);
      if (m < 1) return 'just now';
      if (m < 60) return `${m}m ago`;
      const h = Math.floor(m / 60);
      if (h < 24) return `${h}h ago`;
      return `${Math.floor(h/24)}d ago`;
    }

    function renderGenHistory() {
      renderRecentHome();
      renderProjectsSidebarHistory();
      const list = document.getElementById('genHistoryList');
      const empty = document.getElementById('genHistoryEmpty');
      const loading = document.getElementById('genHistoryLoading');
      if (!list) return;
      if (loading) loading.style.display = 'none';

      if (genHistory.length === 0) {
        if (empty) empty.style.display = 'flex';
        list.querySelectorAll('.gen-history-item').forEach(el => el.remove());
        return;
      }
      if (empty) empty.style.display = 'none';
      list.querySelectorAll('.gen-history-item').forEach(el => el.remove());
      genHistory.forEach(item => {
        const div = document.createElement('div');
        div.className = 'gen-history-item';
        div.innerHTML = `
          <div class="ghi-top">
            <span class="ghi-badge ${item.type}">${{game:'🎮 Game',website:'🌐 Site',tool:'🛠 Tool',mobile:'📱 Mobile'}[item.type]||item.type}</span>
            <span class="ghi-time">${timeAgo(item.ts)}</span>
          </div>
          <div class="ghi-prompt">${item.prompt}</div>
          <div class="ghi-action">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:11px;height:11px"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
            Use this prompt →
          </div>`;
        div.addEventListener('click', () => {
          const inp = document.getElementById('promptInput');
          if (inp) { inp.value = item.prompt; inp.dispatchEvent(new Event('input')); }
          document.querySelectorAll('.type-card').forEach(c => c.classList.toggle('active-card', c.dataset.value === item.type));
          document.querySelectorAll('#typePills .type-pill').forEach(p => p.classList.toggle('active', p.dataset.value === item.type));
          selectedType = item.type;
          renderCostPreview();
        });
        list.appendChild(div);
      });
    }

    /* ── Logout ── */
    document.getElementById("logoutBtn").addEventListener("click", async () => {
      await supabase.auth.signOut();
      window.location.href = "login.html";
    });

    // Reusable global sign-out, e.g. for the permanent-ban screen's
    // "Sign out" button (which has no other UI path to the logout button).
    window.signOut = async function () {
      try { await supabase.auth.signOut(); } catch (_) {}
      window.location.href = "login.html";
    };

    /* ── Spinner keyframe ── */
    const style = document.createElement("style");
    style.textContent = "@keyframes spin { to { transform: rotate(360deg); } }";
    document.head.appendChild(style);

    /* ── Footer visibility: hide when an active conversation has user messages ── */
    window.syncFooter = function() {
      var footer = document.getElementById('siteFooter');
      if (!footer) return;
      var chatHasMessages = Array.isArray(chatHistory) && chatHistory.some(function(m) { return m.role === 'user'; });
      var homeHasMessages = Array.isArray(homeConvHistory) && homeConvHistory.some(function(m) { return m.role === 'user'; });
      footer.classList.toggle('footer-hidden', chatHasMessages || homeHasMessages);
    };

    /* ── View switching ── */
    window.showView = function(view) {
      ['home','chat','projects','library','chats','marketing','starred','design','skills'].forEach(v => {
        const el = document.getElementById(v+'View');
        if (!el) return;
        el.style.display = (v === view) ? 'flex' : 'none';
        const si = document.getElementById('sidebar'+v.charAt(0).toUpperCase()+v.slice(1));
        if (si) si.classList.toggle('active', v === view);
      });
      // toggle sub-groups
      const projectsGroup = document.getElementById('sidebarProjectsGroup');
      if (projectsGroup) projectsGroup.classList.toggle('open', view === 'projects');
      const chatHistoryPanel = document.getElementById('sidebarChatStandalone');
      if (chatHistoryPanel) chatHistoryPanel.classList.toggle('open', view === 'chat');
      // load projects when switching to projects view
      if (view === 'projects') loadProjects();
      // refresh chat history list whenever the user navigates to chat
      if (view === 'chat') renderChatHistory();
      // refresh home chat history list whenever the user navigates to home
      if (view === 'home') { renderHomeChatHistory(); updateHomeBreadcrumb(); renderHomeProjectsGrid(); }
      // load the Library when switching to the library view
      if (view === 'library') renderLibrary();
      // refresh the Chats list when switching to the chats view (render
      // immediately from whatever's cached, then again once the fresh
      // fetch resolves — same pattern the old Settings tab used)
      if (view === 'chats') { renderChatsList(); loadChatsViewSessions(); }
      // refresh the Starred list whenever the user navigates there
      if (view === 'starred') renderStarred();
      // refresh the Marketing cost-preview label whenever the user navigates there
      if (view === 'marketing') { updateMarketingCostPreview(); mktRecentStripLoad(); mktHistoryCountLoad(); }
      // #homeCostPreview now lives in the navbar (outside #homeView), so it
      // no longer gets auto-hidden along with the rest of the Home view —
      // show it only while the Home view itself is active.
      const homeCostPreviewNav = document.getElementById('homeCostPreview');
      if (homeCostPreviewNav) homeCostPreviewNav.style.display = (view === 'home') ? '' : 'none';
      window.syncFooter();
    };

    /* ── Projects ──
       A "project" is just an explicit link created via "Add to project"
       (see addHomeChatToProject above). Nothing lands here automatically —
       the list is read straight from local project links, so it never
       depends on guessing the remote generations schema. ── */
    let allProjects = [];
    let activeProjectFilter = 'all';

    function loadProjects() {
      const grid = document.getElementById('projectsGrid');
      const emptyEl = document.getElementById('projectsEmpty');
      if (!grid) return;
      allProjects = getProjectLinks().map(function(l) {
        return { id: l.chatSessionId, chatSessionId: l.chatSessionId, prompt: l.title, type: l.type, ts: l.ts };
      });
      emptyEl.style.display = 'none';
      renderProjects();
    }

    function renderProjects() {
      const grid = document.getElementById('projectsGrid');
      const emptyEl = document.getElementById('projectsEmpty');
      if (!grid) return;
      renderProjectsSidebarHistory();

      const filtered = activeProjectFilter === 'all'
        ? allProjects
        : allProjects.filter(p => p.type === activeProjectFilter);

      grid.innerHTML = '';

      if (filtered.length === 0) {
        emptyEl.style.display = 'flex';
        return;
      }
      emptyEl.style.display = 'none';

      const typeLabel = { game: 'Game', website: 'Website', tool: 'Tool', mobile: 'Mobile App' };
      // Avatar accent colours (unchanged — shared with renderHomeProjectsGrid)
      const typeColor = { game: '#c084fc', website: '#60a5fa', tool: '#fb923c', mobile: '#22d3ee' };
      const locale = { ar: 'ar-SA', tr: 'tr-TR', en: 'en-US' }[BatLang.lang] || 'en-US';
      const dateStr = ts => new Date(ts).toLocaleDateString(locale, { day:'numeric', month:'short', year:'numeric' });

      // Sync the "N projects total" counter in the header
      const countEl = document.getElementById('projectsCount');
      if (countEl) countEl.textContent = allProjects.length;

      filtered.forEach(item => {
        const card = document.createElement('div');
        card.className = `proj-card type-${item.type}`;
        card.style.cursor = 'pointer';
        const status = getProjectCardStatus(item.chatSessionId);
        const statusLabel = escapeHtml(BatLang.t('home.recent.status.' + status));
        const title = item.prompt || 'Untitled';
        const label = escapeHtml(title);
        // Two-letter initials (e.g. "Nova CRM" → "NC")
        const titleWords = title.trim().split(/\s+/).filter(Boolean);
        const initialsRaw = titleWords.length > 1
          ? titleWords[0].charAt(0) + titleWords[1].charAt(0)
          : (titleWords[0] || '?').slice(0, 2);
        const initial = escapeHtml((initialsRaw || '?').toUpperCase());
        const color = typeColor[item.type] || '#6e7f97';
        const tLabel = escapeHtml(typeLabel[item.type] || item.type);
        card.innerHTML = `
          <div class="proj-card-thumb">
            <div class="proj-card-avatar" style="background:${color}22;color:${color};border:1.5px solid ${color}55;">${initial}</div>
          </div>
          <div class="proj-card-info">
            <div class="proj-card-info-row">
              <div class="proj-card-title">${label}</div>
              <span class="home-proj-status home-proj-status-${status}"><span class="home-proj-status-dot"></span>${statusLabel}</span>
            </div>
            <span class="proj-card-type-pill">${tLabel}</span>
          </div>
          <div class="proj-card-actions">
            <button class="proj-btn proj-btn-delete" onclick="event.stopPropagation(); deleteProject('${item.chatSessionId}')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>
              ${BatLang.t('projects.delete')}
            </button>
          </div>`;
        card.addEventListener('click', function() { window.openProject(item.chatSessionId); });
        grid.appendChild(card);
      });

      // Append "New Project" card as the last grid item
      const newProjCard = document.createElement('button');
      newProjCard.type = 'button';
      newProjCard.className = 'proj-new-card';
      newProjCard.onclick = function() { showView('home'); };
      newProjCard.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
        <span>${BatLang.t('projects.new') || 'New Project'}</span>`;
      grid.appendChild(newProjCard);
    }

    window.setProjectFilter = function(filter) {
      activeProjectFilter = filter;
      document.querySelectorAll('.proj-filter').forEach(b => {
        b.classList.toggle('active-filter', b.dataset.filter === filter);
      });
      renderProjects();
    };

    // Removes the project link only — the underlying conversation is untouched
    // and can be re-added to a project later from its own menu.
    window.deleteProject = function(id) {
      const links = getProjectLinks().filter(function(l) { return l.chatSessionId !== id; });
      setProjectLinks(links);
      allProjects = allProjects.filter(p => p.chatSessionId !== id);
      showToast(BatLang.t('toast.removedFromProject'), 'success');
      renderProjects();
      renderHomeChatHistory();
      renderHomeProjectsGrid();
    };
    /* ── Chat ── */
    const CHAT_MODEL_NAMES = {
      'BAT 1.2':       'Bat AI 5 PRIME',
      'BAT 1.2 Flash': 'Bat AI 1.0 FLASH',
      'BAT 1.2 Core':  'Bat AI 1.4 CORE',
      'Alfred':        'Alfred',
    };
    // Real user-facing chat turns (sendChatMessage / homeConvGetReply) route
    // through this so a "BAT 1.2 Flash" selection hits the GLM-4.7-Flash-backed
    // /chat/flash route instead of the default GLM /chat route. The
    // workspace-embedded chat (sendHwChatMessage, which uses
    // getHwWorkspaceSystem() not getChatSystem()) is user-facing but has no
    // model picker, so it routes through hwChatRoute() below instead.
    // Lightweight background
    // helpers (memory extraction, intent classifier, pre-gen "thinking")
    // route through bgChatRoute() below so they never hard-require Prime.
    function chatRoutePath() {
      return selectedModel === 'BAT 1.2 Flash' ? '/chat/flash'
        : selectedModel === 'BAT 1.2 Core' ? '/chat/core'
        : '/chat';
    }
    // Route for lightweight, non-user-facing background helpers. The bare
    // /chat route is Prime and Pro/Max-only (gateway.js plan gate: service
    // === 'chat'), so calling it on Free/Starter returns 403 plan_restricted
    // and used to silently break the whole Build flow for EVERY Free user
    // (the classifier/pre-gen calls failed, the build was misclassified as
    // chat or degraded). These tasks (a one-word intent, a 3-5 sentence
    // "thinking" blurb, a memory sentence) don't need Prime, so send them to
    // Core — which is available on every plan — for anyone who can't use
    // Prime. Pro/Max keep their selected model via chatRoutePath().
    function bgChatRoute() {
      return isProPlan() ? chatRoutePath() : '/chat/core';
    }
    // Route for the workspace-embedded chat (sendHwChatMessage). Kept separate
    // from BOTH chatRoutePath() and bgChatRoute() on purpose:
    //   • not chatRoutePath() — the workspace has no model picker of its own,
    //     so workspace chat has never followed `selectedModel` and must not
    //     start to; Pro/Max keep exactly the Prime behaviour they have today.
    //   • not bgChatRoute() — that one is documented for lightweight,
    //     non-user-facing helpers, and its isProPlan() branch resolves through
    //     chatRoutePath(), which would couple Pro/Max workspace chat to the
    //     selector as a side effect.
    // Free/Starter previously hit the bare /chat plan gate (gateway.js:
    // service === 'chat') and got a 403 upgrade prompt, i.e. no workspace chat
    // at all. Core is available on every plan, so they get a working (and
    // genuinely capable) assistant instead. Product decision 2026-07-24.
    // NOTE: /chat/core sets emitReasoning — callers MUST run the reply through
    // stripInlineReasoning() or the raw <REASONING> tag leaks into the bubble.
    function hwChatRoute() {
      return isProPlan() ? '/chat' : '/chat/core';
    }
    // Shared by every AI-facing system prompt (Home chat, Marketing, workspace
    // Alfred chat) so the model is told the site's ACTUAL current UI language
    // (from BatLang.lang / BatLang.LANGS) instead of relying purely on
    // inferring language from the user's message text — which is unreliable
    // for short/ambiguous messages (e.g. a single word) or when prior history
    // is in a different language. Kept as a strong default with an explicit
    // override clause so a user who deliberately writes in another language
    // (e.g. practicing English while the UI is in Arabic) is still followed.
    function currentUiLanguageInstruction() {
      const entry = (window.BatLang && BatLang.LANGS || []).find(function (l) { return l.code === BatLang.lang; });
      const name = entry ? entry.label : 'English';
      // Reasoning-language directive deliberately leads as a short, standalone,
      // imperative sentence (not buried after the response-language rules like
      // before) — testing whether position/directness within the prompt affects
      // whether gpt-oss-120b's internal reasoning_content channel (BAT 1.2/1.4
      // Core, /chat/core) actually follows it, since the old wording (same
      // instruction, but appended last after several unrelated paragraphs) was
      // observed NOT being followed for that channel even though the final
      // visible answer did follow it. See audit note in getChatSystem() below
      // for why this whole block was also moved to the very front of the
      // general-mode prompt.
      return "LANGUAGE — READ FIRST: Think in " + name + ". This includes your internal reasoning/chain-of-thought, not just your final answer — never think in English by default. " +
        "Respond in " + name + " by default too. If the user's message is clearly written in a different language than that, think AND respond in the language they actually wrote in instead. " +
        "Judge this by the message's OVERALL dominant language, not by isolated tokens — a short embedded technical term or English loanword (e.g. \"md\", \"PDF\", \"API\", \"URL\") does NOT change the dominant language of an otherwise non-English sentence. " +
        "Example: the Arabic message \"\u0634\u0648 \u0647\u0648 \u062a\u0635\u062f\u064a\u0631 \u0627\u0644\u0645\u062d\u0627\u062f\u062b\u0629 md\u061f\" is Arabic overall despite containing the English word \"md\" — reply (and reason) in Arabic, not English. " +
        "Phrase your reply the way a native speaker naturally would — never a literal word-for-word translation. Only use that language's own script; never a stray character from another script (Chinese, Cyrillic, etc.), even one.";
    }
    function getChatSystem() {
      const modelName = CHAT_MODEL_NAMES[selectedModel] || 'Bat AI 1.2 PRIME';
      // Extra reinforcement appended only for Flash: smaller/faster models are
      // more prone to dropping the <CLARIFY> wrapper tags and emitting the bare
      // JSON object as plain text instead. Prime/Core don't need this — keeping
      // it Flash-only avoids bloating the prompt (and the cached prefix) for
      // models that already follow the format reliably.
      const _clarifyStrict = selectedModel === 'BAT 1.2 Flash'
        ? ' STRICT FORMAT — this applies to you specifically: the <CLARIFY>...</CLARIFY> wrapper tags around the JSON are mandatory, not optional. Never output the JSON object by itself without the surrounding <CLARIFY> and </CLARIFY> tags, and never describe the question in plain prose instead of using the tag.'
        : '';
      // Same Flash-only reinforcement pattern as _clarifyStrict, for the
      // trailing <STEPS> progress tag (see PROGRESS STEPS instruction below).
      const _stepsStrict = selectedModel === 'BAT 1.2 Flash'
        ? ' STRICT FORMAT for <STEPS>: this applies to you specifically — the <STEPS>...</STEPS> wrapper tags around the JSON are mandatory. Never output the steps JSON without both surrounding tags, and never render the steps as plain prose.'
        : '';
      const _today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const _dateLine = `CURRENT DATE: Today is ${_today}. Your training data has a knowledge cutoff and may not reflect very recent events (political changes, elections, leadership transitions, world news, sports results, etc. that happened after your training). When asked about such topics, share what you know from training and add a brief honest note that your information may be outdated — never claim to know the current year if the user asks directly, just state today's date above.`;

      // Personalization: the user's own "About Me" bio plus short facts BatNXT has
      // quietly remembered from past messages (opt-in, see memoryEnabled). Empty
      // when the user is logged out, has nothing saved, or has memory turned off.
      let _memoryBlock = '';
      if (currentUser && (currentAboutMe || (userMemories && userMemories.length))) {
        const _facts = (userMemories || []).slice(0, 20).map(m => `- ${m.content}`).join('\n');
        _memoryBlock = `\n\nWHAT YOU KNOW ABOUT THIS USER (use naturally when relevant — don't recite it as a list unless asked to):${currentAboutMe ? `\nAbout them: ${currentAboutMe}` : ''}${_facts ? `\nRemembered facts:\n${_facts}` : ''}`;
      }

      // Account/plan info: real, live data so the AI can answer plan/credit
      // questions directly and accurately, instead of deflecting. Never let
      // the model imply it's being reached through an external API/platform.
      let _accountBlock = '';
      if (currentUser) {
        const _planLabel = PLAN_LABELS[currentPlan] || currentPlan || 'Free';
        const _credsLabel = PLAN_CREDIT_LABELS[currentPlan] || '';
        _accountBlock = `\n\nACCOUNT & PLAN QUESTIONS:
- If the user asks about their plan, subscription, tier, or credits, answer directly and confidently using this real data — never say you don't have access to it and never say it "depends on the platform or service you're using to access me" or anything implying you're reached through an external API/platform/integration. You simply know this because it's the user's BatNXT account.
- Current plan: ${_planLabel} (${_credsLabel})
- Credits remaining right now: ${currentCredits}
- How the credit window works: it is NOT a fixed daily/weekly reset — the countdown starts the moment the user sends their first message after their previous window ended, and it refills automatically once that window's time is up. If asked "when do my credits reset/renew", explain it this way, not as a fixed clock time.
- For anything about upgrading or exact pricing, briefly mention they can check the Upgrade/Settings page in the app.`;
      }

      // Dynamic tail: everything that varies between calls (today's date, the
      // user's remembered facts, live plan/credit numbers) lives here and ONLY
      // here, appended at the very end of the prompt. This keeps the entire
      // instructional block above it byte-identical across calls, which lets
      // providers that do prefix/context caching reuse it instead of
      // reprocessing the same static instructions on every single message.
      const _dynamicTail = `\n\n${_dateLine}${_memoryBlock}${_accountBlock}`;

      // ── DEFAULT: general-purpose assistant whenever NO build type is selected.
      //    Answers ANY topic (programming, math, science, health, advice, etc.),
      //    never steers toward building, and never emits <IMPROVED_PROMPT>.
      if (!selectedType) {
        // LANGUAGE RULES moved to lead the prompt (was previously last, right
        // before _dynamicTail) — testing whether prompt position affects
        // whether gpt-oss-120b's internal reasoning channel (BAT 1.2/1.4 Core)
        // follows the reasoning-language clause inside it, after a live report
        // of English-language reasoning shown to an Arabic-UI user despite the
        // clause already existing (just buried after several paragraphs).
        return `You are BatNXT AI — a warm, respectful, and knowledgeable general-purpose assistant.

${currentUiLanguageInstruction()}

TONE: Warm, kind, and positive, like a helpful teammate — never blunt, cold, or dismissive. Brief is fine, just keep it warm. Write clear, natural, grammatically correct sentences.

RESPONSE LENGTH DISCIPLINE (strict): match reply length to the question's actual complexity — never pad, over-explain, or add unrequested extra detail. A simple greeting or casual check-in ("hi", "hey", "كيفك", "شو أخبارك", "صباح الخير", "good morning") gets exactly ONE short, warm sentence back — nothing else, no capability list, no follow-up question unless the user actually asked one. Save longer, detailed answers only for questions that genuinely need that depth (technical, multi-part, or explicitly asking for detail).

IDENTITY:
- Who/what are you ("من أنت", "who are you"): say you're BatNXT AI, a helpful assistant, in 1-2 warm sentences.
- What model/engine ("شو نموذجك", "what model are you"): answer with exactly "${modelName}". Never name Groq, Llama, OpenAI, or any other underlying provider — "${modelName}" is the only name you ever give.

WHAT YOU DO: Answer ANY question — programming, math, science, health, history, writing, advice, general knowledge, everyday conversation, anything. You're a full general assistant, not limited to building things. Give accurate, clear, genuinely helpful answers at the right depth, with examples when useful. Put code in fenced Markdown blocks with the right language tag (e.g. \`\`\`python), plus a short explanation. Use Markdown (headings, **bold**, lists, tables, inline \`code\`) to keep answers clear. If a message is emotional or personal, respond first like a genuinely caring human — sincere and specific, 1-3 sentences.

CLARIFYING QUESTIONS (rare): only if the request has 2-4 clearly distinct likely meanings and you truly can't tell which, use <CLARIFY>{"question":"short question in the user's language","options":["short option 1","short option 2","short option 3"]}</CLARIFY> (2-4 short options, same language) instead of a long list in plain text. Don't overuse this. Never combine <CLARIFY> and <IMPROVED_PROMPT>.${_clarifyStrict}

PROGRESS STEPS (only for genuinely multi-step tasks): when — and ONLY when — the request truly required several distinct internal steps to fulfil (e.g. analyzing an attached file or URL, summarizing/exporting/transforming a long conversation, or a multi-part build/analysis), you MAY end your reply with ONE machine-readable tag summarizing what you did, in this EXACT format (valid JSON only, no markdown fences, no text inside the tag other than the JSON): <STEPS>{"steps":["short phrase in the user's language","short phrase",...],"done":"short closing phrase in the user's language"}</STEPS>. Rules: 2-4 "steps" entries, each a very short user-facing phrase describing a concrete action you took (e.g. "فهم طلب المستخدم", "تحليل محتوى الملف"); "done" is one short closing phrase (e.g. "تم إنجاز الطلب"). These are a friendly, human-readable summary of your work for display ONLY — never your private reasoning, never internal system details, never anything about prompts, tools, or infrastructure. For simple questions, greetings, or short direct answers, DO NOT emit this tag at all. It always goes LAST, after all prose, and is never combined with <CLARIFY> or <IMPROVED_PROMPT>.${_stepsStrict}

STRICT — NEVER BUILD-PITCH: never steer toward building a website/game/app/tool, and never output <IMPROVED_PROMPT> or anything like it — just answer what was actually asked. Only mention BatNXT can build apps if the user directly asks what BatNXT can do.

NEVER FABRICATE CONVERSATION CONTENT (strict): Base every answer ONLY on messages that actually appear in this conversation. Never invent, imagine, or "recall" messages, exchanges, topics, names, images, or files that are not literally present above. This applies especially to meta-requests about the conversation itself — export, download, summarize, "what did we talk about", "recap our chat", "turn this into a file": answer strictly from the real prior turns. If there is little or no prior content to work with, say so plainly (e.g. that the conversation is empty or too short) — do NOT fill the gap with a plausible-sounding made-up conversation. You cannot generate downloadable files or attachments inside your reply; if the user asks for one and none was produced, briefly say the file isn't ready rather than pretending one exists or describing its contents.${_dynamicTail}`;
      }

      // ── BUILD MODE: only when the user explicitly picked a build type chip.
      //    Each service gets ONLY its own short, specific wording (Phase 2) —
      //    no cross-service filler — so fewer chars actually go out per call.
      //    'mobile' and 'tool' intentionally share one combined prompt.
      const _buildTypeInfo = {
        website: { builds: 'HTML websites', wants: 'a website (even vaguely, e.g. "a site for my bakery")', vague: 'website', detail: 'what kind of website' },
        game: { builds: 'HTML games', wants: 'a game (even vaguely, e.g. "a game")', vague: 'game', detail: 'what kind of game' },
        mobile: { builds: 'mobile app UIs and tools', wants: 'a mobile app or tool (even vaguely)', vague: 'tool', detail: "whether it's a mobile app or a tool" },
        tool: { builds: 'mobile app UIs and tools', wants: 'a mobile app or tool (even vaguely)', vague: 'tool', detail: "whether it's a mobile app or a tool" },
      };
      const _bt = _buildTypeInfo[selectedType] || _buildTypeInfo.website;

      return `You are BatNXT AI — a warm, respectful assistant inside BatNXT, an AI platform that instantly turns text prompts into ready ${_bt.builds}.

TONE: Warm, kind, and positive, like a helpful teammate — never cold, blunt, or robotic. Brief is fine, just keep it warm. Write clear, natural, grammatically correct sentences.

RESPONSE LENGTH DISCIPLINE (strict): match reply length to the question's actual complexity — never pad, over-explain, or add unrequested extra detail. A simple greeting or casual check-in ("hi", "hey", "كيفك", "شو أخبارك", "صباح الخير", "good morning") gets exactly ONE short, warm sentence back — nothing else. Save longer replies only for build requests that genuinely need the detail, or questions that explicitly ask for it.

IDENTITY:
- Who/what are you ("من أنت", "مين انت", "who are you"): say you're BatNXT AI, built into BatNXT, in 1-2 warm sentences — mention BatNXT turns text prompts into ${_bt.builds}.
- What model/engine ("شو نموذجك", "ما هو نموذجك", "what model are you"): answer with exactly "${modelName}". Never name Groq, Llama, OpenAI, or any other underlying provider — "${modelName}" is the only name you ever give.

STEP 1 — CLASSIFY SILENTLY:
- BUILD REQUEST: the user wants ${_bt.wants} built or made.
- EMOTIONAL/PERSONAL: something sad, stressful, or personal — even unrelated to BatNXT.
- GENERAL/CHAT: anything else (greetings, small talk, questions about BatNXT itself).

IF EMOTIONAL/PERSONAL: respond like a caring human first — sincere and specific, 1-3 sentences. NEVER pivot to building in the same reply. Only bring up building later, and only if the user brings it up themselves.

IF GENERAL/CHAT: answer naturally in 1-4 sentences. Don't pivot to "want me to build something?" and don't output <IMPROVED_PROMPT> — unless the user's own message already hints they want something built, or they directly ask what BatNXT can do.

IF BUILD REQUEST: get to a ready build prompt fast, ideally in 1-2 exchanges.
- If the idea is clear enough (even roughly), don't ask anything else — output the improved prompt right away.
- A single-word agreement ("yes / اي / ok / sure / نعم / يلا / ابنيه") confirms the LAST idea you proposed — output the improved prompt for it immediately.
- Only if truly vague (e.g. just "${_bt.vague}" with nothing else), ask ONE clarifying question via <CLARIFY>{"question":"short question in the user's language","options":["short option 1","short option 2","short option 3"]}</CLARIFY> (2-4 short options, user's language) instead of plain text. Never combine <CLARIFY> and <IMPROVED_PROMPT> in the same reply.${_clarifyStrict}
- Keep replies to 1-3 sentences. No long explanations or lists of options.

LANGUAGE RULES (for the short conversational confirmation sentence only — NOT the <IMPROVED_PROMPT> tag, which stays English per OUTPUT FORMAT below): ${currentUiLanguageInstruction()} Phrase it the way a native speaker naturally would — never a literal word-for-word translation. Only use that language's own script; never a stray character from another script (Chinese, Cyrillic, etc.), even one.

OUTPUT FORMAT (build requests only): a short, friendly 1-sentence confirmation, then:

<IMPROVED_PROMPT>detailed English build prompt here</IMPROVED_PROMPT>

The improved prompt must be in English, detailed (3-6 sentences), and describe exactly what to build — including ${_bt.detail}, style, features, and purpose.${_dynamicTail}`;
    }

    // Safety net for when a model (mainly Flash) drops the <CLARIFY>...</CLARIFY>
    // wrapper tags and emits the bare JSON object as plain text instead. Strict
    // on purpose so it never misfires on legitimate JSON the user/assistant is
    // discussing (e.g. an API response pasted into chat): requires the ENTIRE
    // trimmed message to be a single valid JSON object with EXACTLY the two
    // expected keys, sane length bounds, and no fenced code block anywhere in it.
    function detectBareClarifyJson(text) {
      const t = (text || '').trim();
      if (!t) return null;
      if (t.indexOf('```') !== -1) return null; // never touch fenced code blocks
      if (t.length > 600) return null;
      if (t.charAt(0) !== '{' || t.charAt(t.length - 1) !== '}') return null;
      let parsed;
      try { parsed = JSON.parse(t); } catch (e) { return null; }
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
      const keys = Object.keys(parsed);
      if (keys.length !== 2 || keys.indexOf('question') === -1 || keys.indexOf('options') === -1) return null;
      if (typeof parsed.question !== 'string' || parsed.question.length < 3 || parsed.question.length > 200) return null;
      if (!Array.isArray(parsed.options) || parsed.options.length < 2 || parsed.options.length > 4) return null;
      for (let i = 0; i < parsed.options.length; i++) {
        if (typeof parsed.options[i] !== 'string' || !parsed.options[i].trim() || parsed.options[i].length > 100) return null;
      }
      return parsed;
    }

    // Anti-leak guardrail (Fix C). Loosely detects whether a message is a LONE
    // clarify-shaped JSON object that detectBareClarifyJson() rejected on bounds
    // (e.g. 5+ options, an over-long option/question) and therefore couldn't be
    // turned into a card. Deliberately looser than the strict validator (no
    // count/length caps) but still requires the ENTIRE (optionally fence-wrapped)
    // message to be a single JSON object carrying both a string `question` and an
    // array `options` — so it never fires on prose, or on real JSON the user is
    // discussing that lacks that exact shape. Used only to SUPPRESS raw JSON in
    // favour of a neutral fallback, never to fabricate a question/options.
    function looksLikeClarifyJson(text) {
      const t = (text || '').trim();
      if (!t) return false;
      const unfenced = stripJsonCodeFences(t);
      const candidate = (unfenced && unfenced !== t) ? unfenced.trim() : t;
      if (candidate.length > 800) return false;
      if (candidate.charAt(0) !== '{' || candidate.charAt(candidate.length - 1) !== '}') return false;
      let parsed;
      try { parsed = JSON.parse(candidate); } catch (e) { return false; }
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return false;
      return typeof parsed.question === 'string' && Array.isArray(parsed.options);
    }

    // Safety net for the <STEPS> progress tag (see getChatSystem's PROGRESS
    // STEPS instruction) — for when a model drops the wrapper tags and emits
    // the bare JSON object as plain text. Mirrors detectBareClarifyJson's
    // strictness: the ENTIRE trimmed message must be a single valid JSON object
    // with exactly {steps:[2-4 short strings], done:short string} and no fenced
    // code block, so it never misfires on real JSON discussed in chat.
    function detectBareStepsJson(text) {
      const t = (text || '').trim();
      if (!t) return null;
      if (t.indexOf('```') !== -1) return null;
      if (t.length > 600) return null;
      if (t.charAt(0) !== '{' || t.charAt(t.length - 1) !== '}') return null;
      let parsed;
      try { parsed = JSON.parse(t); } catch (e) { return null; }
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
      const keys = Object.keys(parsed);
      if (keys.length !== 2 || keys.indexOf('steps') === -1 || keys.indexOf('done') === -1) return null;
      if (!sanitizeStepsPayload(parsed)) return null;
      return parsed;
    }

    // Validates + normalizes a parsed <STEPS> payload (from either the tagged or
    // bare path). Returns {steps:[...], done:"..."} with trimmed, length-capped
    // strings, or null if the shape is invalid. Shared so the tag path and the
    // bare-JSON fallback enforce identical bounds.
    function sanitizeStepsPayload(obj) {
      if (!obj || typeof obj !== 'object') return null;
      if (!Array.isArray(obj.steps) || obj.steps.length < 2 || obj.steps.length > 4) return null;
      if (typeof obj.done !== 'string' || !obj.done.trim() || obj.done.length > 120) return null;
      const steps = [];
      for (let i = 0; i < obj.steps.length; i++) {
        const s = obj.steps[i];
        if (typeof s !== 'string' || !s.trim() || s.length > 120) return null;
        steps.push(s.trim());
      }
      return { steps: steps, done: obj.done.trim() };
    }

    // Analogous safety net for the Marketing tool's <MKT_SCORES>...</MKT_SCORES>
    // tag (see getMarketingSystemPrompt()) — for when a model (mainly BAT 2.2/
    // Gemma) drops the wrapper tags and emits the bare JSON object as plain
    // text instead. Strict on purpose, mirroring detectBareClarifyJson(): the
    // ENTIRE trimmed message must be a single valid JSON object with exactly
    // the expected top-level keys (2 required + up to 5 optional), sane
    // bounds on each field, and no fenced code block anywhere in it.
    const MKT_CATEGORY_VALUES = ['SEO', 'Competitors', 'Ads', 'Branding', 'Pricing', 'Ideas', 'Funnels', 'Social Media'];
    const MKT_LEVEL_VALUES = ['Low', 'Medium', 'High'];

    function detectBareMktScoresJson(text) {
      const t = (text || '').trim();
      if (!t) return null;
      if (t.indexOf('```') !== -1) return null; // never touch fenced code blocks
      if (t.length > 2400) return null; // bumped from 2000 to fit the new optional fields
      if (t.charAt(0) !== '{' || t.charAt(t.length - 1) !== '}') return null;
      let parsed;
      try { parsed = JSON.parse(t); } catch (e) { return null; }
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
      const REQUIRED = ['scores', 'recommendations'];
      const OPTIONAL = ['title', 'competition', 'growth_potential', 'category', 'tags'];
      const keys = Object.keys(parsed);
      if (!REQUIRED.every(function (k) { return keys.indexOf(k) !== -1; })) return null;
      if (!keys.every(function (k) { return REQUIRED.indexOf(k) !== -1 || OPTIONAL.indexOf(k) !== -1; })) return null;
      const scores = parsed.scores;
      if (!scores || typeof scores !== 'object' || Array.isArray(scores)) return null;
      const scoreKeys = Object.keys(scores);
      if (!scoreKeys.length || scoreKeys.length > 4) return null;
      for (let i = 0; i < scoreKeys.length; i++) {
        const v = scores[scoreKeys[i]];
        if (typeof v !== 'number' || !isFinite(v) || v < 0 || v > 100) return null;
      }
      if (!Array.isArray(parsed.recommendations) || parsed.recommendations.length < 1 || parsed.recommendations.length > 10) return null;
      for (let i = 0; i < parsed.recommendations.length; i++) {
        if (typeof parsed.recommendations[i] !== 'string' || !parsed.recommendations[i].trim() || parsed.recommendations[i].length > 300) return null;
      }
      if (parsed.title !== undefined && (typeof parsed.title !== 'string' || !parsed.title.trim() || parsed.title.length > 80)) return null;
      if (parsed.competition !== undefined && MKT_LEVEL_VALUES.indexOf(parsed.competition) === -1) return null;
      if (parsed.growth_potential !== undefined && MKT_LEVEL_VALUES.indexOf(parsed.growth_potential) === -1) return null;
      if (parsed.category !== undefined && MKT_CATEGORY_VALUES.indexOf(parsed.category) === -1) return null;
      if (parsed.tags !== undefined) {
        if (!Array.isArray(parsed.tags) || parsed.tags.length > 5) return null;
        for (let i = 0; i < parsed.tags.length; i++) {
          if (typeof parsed.tags[i] !== 'string' || !parsed.tags[i].trim() || parsed.tags[i].length > 24) return null;
        }
      }
      return parsed;
    }

    // Permissive companion to the strict validator above — applied to BOTH
    // parse paths (tag-wrapped and bare-JSON fallback) right before the
    // optional fields are used/persisted. Unlike detectBareMktScoresJson
    // (which rejects the WHOLE payload on any bad field), this only nulls out
    // individual bad/missing fields, since the tag-wrapped path's `scores`/
    // `recommendations` may already be in use even if e.g. `category` came
    // back malformed from a weaker model.
    // Case-insensitive enum lookup — normalizes the model's output (which may
    // come back as "low"/"Low "/"LOW") against the canonical-cased allowed
    // list, returning the canonical value on a match so downstream storage/
    // display always sees consistent casing.
    function mktMatchEnumCaseInsensitive(value, allowed) {
      if (typeof value !== 'string') return null;
      const v = value.trim().toLowerCase();
      for (let i = 0; i < allowed.length; i++) {
        if (allowed[i].toLowerCase() === v) return allowed[i];
      }
      return null;
    }

    function sanitizeMktScoresOptionalFields(parsed) {
      const out = { title: null, competition: null, growth_potential: null, category: null, tags: null };
      if (!parsed) return out;
      if (typeof parsed.title === 'string' && parsed.title.trim() && parsed.title.length <= 80) out.title = parsed.title.trim();
      out.competition = mktMatchEnumCaseInsensitive(parsed.competition, MKT_LEVEL_VALUES);
      out.growth_potential = mktMatchEnumCaseInsensitive(parsed.growth_potential, MKT_LEVEL_VALUES);
      out.category = mktMatchEnumCaseInsensitive(parsed.category, MKT_CATEGORY_VALUES);
      if (Array.isArray(parsed.tags)) {
        const cleanTags = parsed.tags.filter(function (t) { return typeof t === 'string' && t.trim() && t.length <= 24; }).slice(0, 5);
        if (cleanTags.length) out.tags = cleanTags;
      }
      return out;
    }

    // Fence-stripping fallback for models that wrap the <MKT_SCORES> tag's
    // JSON content in a markdown code block despite instructions not to.
    // Used only by the tag-wrapped parse path in sendMarketingMessage() as a
    // second-chance retry before giving up and setting mktScores = null.
    function stripJsonCodeFences(s) {
      let out = (s || '').trim();
      out = out.replace(/^```[a-zA-Z]*\s*/, '').replace(/```\s*$/, '');
      out = out.replace(/^`+|`+$/g, '');
      return out.trim();
    }

    // ── Chat sessions ──
    let chatSessions = JSON.parse(localStorage.getItem('batlab_chat_sessions') || '[]');
    let activeChatId = null;
    let chatHistory = [];

    function saveChatSession() {
      if (!activeChatId || chatHistory.length === 0) return;
      /* prevent duplicate unshift: always find by id first */
      const idx = chatSessions.findIndex(s => s.id === activeChatId);
      // Preserve an already-set title (the async AI-generated name, or a manual
      // rename) instead of clobbering it back to the truncated first message on
      // every save. Only fall back to first-message truncation on the first save.
      const existingTitle = idx >= 0 ? chatSessions[idx].title : null;
      const title = existingTitle
                    || chatHistory.find(m => m.role === 'user')?.content?.slice(0, 38)
                    || BatLang.t('chat.newTitle');
      const session = { id: activeChatId, title, messages: chatHistory, updatedAt: Date.now() };
      if (idx >= 0) chatSessions[idx] = session;
      else chatSessions.unshift(session);
      // keep last 20
      chatSessions = chatSessions.slice(0, 20);
      localStorage.setItem('batlab_chat_sessions', JSON.stringify(chatSessions));
      renderChatHistory();
    }

    /* ── Page-title helpers ── */
    function setPageTitle(convTitle) {
      document.title = (convTitle || 'Chat') + ' — BatNXT AI';
    }
    function resetPageTitle() {
      document.title = 'Advanced AI chatbot & Agent powered by BatNXT';
    }

    /* ── Auto-title: generate a smart name after the first AI reply ──
       Fire-and-forget: calls the worker with a 1-shot naming prompt.
       onTitle(title) is invoked once a clean title comes back.          */
    async function generateChatTitle(convMessages, onTitle) {
      try {
        // Build a compact transcript: first user turn + first assistant turn,
        // stripping CLARIFY / IMPROVED_PROMPT control blocks so a vague first
        // message (which yields a clarify question) still gets a topic title.
        const strip = (s) => (s || '')
          .replace(/<CLARIFY>[\s\S]*?<\/CLARIFY>/gi, '')
          .replace(/<IMPROVED_PROMPT>[\s\S]*?<\/IMPROVED_PROMPT>/gi, '')
          .trim();
        const list = Array.isArray(convMessages) ? convMessages : [];
        const firstUser = list.find(m => m && m.role === 'user');
        const firstAi = list.find(m => m && m.role === 'assistant');
        const transcript = [];
        if (firstUser) transcript.push({ role: 'user', content: (firstUser.content || '').toString().slice(0, 600) });
        if (firstAi) {
          const c = strip((firstAi.content || '').toString()).slice(0, 600);
          if (c) transcript.push({ role: 'assistant', content: c });
        }
        if (!transcript.length) return;
        const { res } = await gatewayFetch('/chat/title', {
          messages: transcript,
          // Marks this as a background helper call so the gateway rate-limits
          // it on its own separate lane instead of the user's real chat lane
          // (billed at a flat 0 credits — see gateway.js chat_title).
          background: true
        }, { silent: true });
        const data = await res.json();
        const raw = (data.title || '').trim();
        const title = raw.replace(/^["'""'']+|["'""'']+$/g, '').replace(/[.!?]+$/, '').trim().slice(0, 60);
        if (title) onTitle(title);
      } catch (e) { /* fail silently — title stays as first-message truncation */ }
    }

    function renderChatHistory() {
      const list = document.getElementById('chatHistoryList');
      if (!list) return;
      if (chatSessions.length === 0) {
        list.innerHTML = '<div class="sidebar-history-empty">' + BatLang.t('sidebar.historyEmpty') + '</div>';
        return;
      }
      list.innerHTML = chatSessions.map(s => {
        const active = s.id === activeChatId ? ' active-chat' : '';
        const title = escapeHtml(s.title || 'Untitled');
        return `<div class="sidebar-history-item${active}">
          <button class="shi-main" onclick="loadChatSession('${s.id}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <span class="shi-title">${title}</span>
          </button>
          <div class="shi-actions">
            <button class="shi-dots-btn" onclick="event.stopPropagation();showHistoryMenu(event,'${s.id}','chat')" title="More options">⋮</button>
          </div>
        </div>`;
      }).join('');
    }

    function renderProjectsSidebarHistory() {
      // Only explicitly-added ("Add to project") conversations show up here.
      // Targets #sidebarProjectsList (the WORKSPACE > Projects row's own
      // expandable list from the sidebar redesign) — rows reuse the exact
      // .sidebar-history-item/.shi-* markup as Chats history, plus a
      // .sp-drag-handle for reordering and .sp-pinned for the Pin context-
      // menu action, mirroring .pinned-chat's visual treatment.
      const list = document.getElementById('sidebarProjectsList');
      const emptyEl = document.getElementById('sidebarProjectsEmpty');
      if (!list) return;
      const items = getProjectLinks();
      list.querySelectorAll('.sidebar-history-item').forEach(el => el.remove());
      if (items.length === 0) {
        if (emptyEl) emptyEl.style.display = '';
        return;
      }
      if (emptyEl) emptyEl.style.display = 'none';
      const typeEmoji = { game: '🎮', website: '🌐', tool: '🛠', mobile: '📱' };
      items.forEach(item => {
        const title = item.title || 'Untitled';
        const label = escapeHtml(title.length > 28 ? title.slice(0, 28) + '…' : title);
        const emoji = typeEmoji[item.type] || '📄';
        const row = document.createElement('div');
        row.className = 'sidebar-history-item' + (item.pinned ? ' sp-pinned' : '');
        row.draggable = true;
        row.dataset.projectId = item.chatSessionId;
        row.innerHTML = `
          <span class="sp-drag-handle" title="Drag to reorder">
            <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg>
          </span>
          <button class="shi-main" onclick="openProject('${item.chatSessionId}')">
            <span aria-hidden="true">${emoji}</span>
            <span class="shi-title">${label}</span>
          </button>
          <div class="shi-actions">
            <button class="shi-dots-btn" onclick="event.stopPropagation();showHistoryMenu(event,'${item.chatSessionId}','project')" title="More options">⋮</button>
          </div>`;
        list.appendChild(row);
      });
      wireProjectsSidebarDragAndDrop(list);
      renderHomeProjectsGrid();
    }
    window.renderProjectsSidebarHistory = renderProjectsSidebarHistory;

    /* ── Home "Recent Projects" cards (Figma visual pass) ──
       Status is 100% derived from real, already-loaded data — never
       fabricated, never a new Supabase call on the home critical path:
       - "building": this exact project is the one actively streaming right
         now (homeConvBusy + homeConvSessionId, in-memory only).
       - "live": a real generation already completed for this chat (genHistory
         is loaded client-side at app init — a matching entry means
         saveGenHistory() fired post-success at least once).
       - "draft": linked to a Project, nothing generated yet. */
    function getProjectCardStatus(chatSessionId) {
      if (typeof homeConvBusy !== 'undefined' && homeConvBusy && homeConvSessionId === chatSessionId) return 'building';
      if ((genHistory || []).some(function(g) { return g.chatSessionId === chatSessionId; })) return 'live';
      return 'draft';
    }

    function renderHomeProjectsGrid() {
      const section = document.getElementById('homeProjectsSection');
      const grid = document.getElementById('homeProjectsGrid');
      if (!section || !grid) return;
      const items = getProjectLinks().slice(0, 6); // preview strip, not the full Projects page
      if (items.length === 0) { section.style.display = 'none'; grid.innerHTML = ''; return; }
      section.style.display = '';
      const typeColor = { game: '#c084fc', website: '#60a5fa', tool: '#fb923c', mobile: '#22d3ee' };
      grid.innerHTML = items.map(function(item) {
        const status = getProjectCardStatus(item.chatSessionId);
        const title = item.title || 'Untitled';
        const label = escapeHtml(title.length > 28 ? title.slice(0, 28) + '…' : title);
        // Two-letter avatar (Figma visual pass): first letter of the first
        // two words (e.g. "Neon City" → "NC"); falls back to the first two
        // letters of a single word if there's only one.
        const titleWords = title.trim().split(/\s+/).filter(Boolean);
        const initialsRaw = titleWords.length > 1
          ? titleWords[0].charAt(0) + titleWords[1].charAt(0)
          : (titleWords[0] || '?').slice(0, 2);
        const initial = escapeHtml((initialsRaw || '?').toUpperCase());
        const color = typeColor[item.type] || '#6e7f97';
        // type.* i18n values already include their own emoji prefix (e.g. "🎮 Game") — don't add a second one.
        const typeLabel = escapeHtml(BatLang.t('type.' + item.type) || item.type || '');
        const statusLabel = escapeHtml(BatLang.t('home.recent.status.' + status));
        return '<button type="button" class="home-proj-card" onclick="openProject(\'' + item.chatSessionId + '\')">' +
          '<div class="home-proj-avatar" style="background:' + color + '22;color:' + color + '">' + initial + '</div>' +
          '<div class="home-proj-body">' +
            '<div class="home-proj-title">' + label + '</div>' +
            '<div class="home-proj-type">' + typeLabel + '</div>' +
          '</div>' +
          '<span class="home-proj-status home-proj-status-' + status + '"><span class="home-proj-status-dot"></span>' + statusLabel + '</span>' +
        '</button>';
      }).join('');
    }
    window.renderHomeProjectsGrid = renderHomeProjectsGrid;

    // HTML5 drag & drop reorder for the Projects sidebar list. Projects are
    // 100% localStorage-driven (batlab_project_links array), so reordering
    // that array IS the persistence — no backend/schema change involved.
    // Pin is a separate, purely visual flag and intentionally does NOT
    // affect sort order here (order stays exactly what the user dragged).
    function wireProjectsSidebarDragAndDrop(list) {
      let draggedId = null;
      list.querySelectorAll('.sidebar-history-item').forEach(row => {
        row.addEventListener('dragstart', e => {
          draggedId = row.dataset.projectId;
          row.classList.add('sp-dragging');
          e.dataTransfer.effectAllowed = 'move';
          try { e.dataTransfer.setData('text/plain', draggedId); } catch (err) {}
        });
        row.addEventListener('dragend', () => {
          row.classList.remove('sp-dragging');
          list.querySelectorAll('.sp-drag-over').forEach(el => el.classList.remove('sp-drag-over'));
          draggedId = null;
        });
        row.addEventListener('dragover', e => {
          if (!draggedId || draggedId === row.dataset.projectId) return;
          e.preventDefault();
          e.dataTransfer.dropEffect = 'move';
          row.classList.add('sp-drag-over');
        });
        row.addEventListener('dragleave', () => row.classList.remove('sp-drag-over'));
        row.addEventListener('drop', e => {
          e.preventDefault();
          row.classList.remove('sp-drag-over');
          const targetId = row.dataset.projectId;
          if (!draggedId || draggedId === targetId) return;
          const links = getProjectLinks();
          const fromIdx = links.findIndex(l => l.chatSessionId === draggedId);
          const toIdx = links.findIndex(l => l.chatSessionId === targetId);
          if (fromIdx === -1 || toIdx === -1) return;
          const moved = links.splice(fromIdx, 1)[0];
          links.splice(toIdx, 0, moved);
          setProjectLinks(links);
          renderProjectsSidebarHistory();
        });
      });
    }

    // Renames a Project's display title (the underlying conversation title
    // is untouched — mirrors renameChatSession's prompt-based UX). Manually
    // syncs the in-memory allProjects array (same pattern as deleteProject)
    // so the full-page Projects grid doesn't show a stale title if open.
    window.renameProjectLink = function(id) {
      const links = getProjectLinks();
      const link = links.find(l => l.chatSessionId === id);
      if (!link) return;
      const newTitle = window.prompt('Rename project:', link.title || '');
      if (!newTitle || !newTitle.trim()) return;
      link.title = newTitle.trim().slice(0, 60);
      setProjectLinks(links);
      const proj = allProjects.find(p => p.chatSessionId === id);
      if (proj) proj.prompt = link.title;
      renderProjectsSidebarHistory();
      renderProjects();
    };

    // Client-side-only pin toggle for Projects — purely a visual indicator
    // (border accent + persistent actions, same as .pinned-chat). Doesn't
    // touch Supabase since projects aren't backed by chat_sessions.is_pinned,
    // and doesn't affect sort order (see wireProjectsSidebarDragAndDrop).
    window.toggleProjectPin = function(id) {
      const links = getProjectLinks();
      const link = links.find(l => l.chatSessionId === id);
      if (!link) return;
      link.pinned = !link.pinned;
      setProjectLinks(links);
      renderProjectsSidebarHistory();
    };

    // Whole-sidebar search — filters every top-level nav row (.sidebar-item,
    // scoped to #sidebarScroll so the pinned "New Chat" row above it and the
    // Profile section below it are untouched) AND the two dynamic content
    // lists (#sidebarProjectsList / #homeHistoryList) by their own text, in
    // one unified client-side pass. See .sb-search-hide / #sidebarSearchNoResults
    // in the CSS (index.html) for the corresponding styling.
    window.filterSidebar = function(query) {
      const scroll = document.getElementById('sidebarScroll');
      const noResults = document.getElementById('sidebarSearchNoResults');
      if (!scroll) return;
      const q = (query || '').trim().toLowerCase();
      let anyVisible = false;
      scroll.querySelectorAll('.sidebar-item, .sidebar-history-item').forEach(row => {
        const match = !q || row.textContent.toLowerCase().indexOf(q) !== -1;
        row.classList.toggle('sb-search-hide', !match);
        if (match) anyVisible = true;
      });
      if (noResults) noResults.style.display = (q && !anyVisible) ? 'block' : 'none';
    };

    (function() {
      const input = document.getElementById('sidebarSearchInput');
      const clearBtn = document.getElementById('sidebarSearchClear');
      if (input) input.addEventListener('input', () => window.filterSidebar(input.value));
      if (clearBtn) clearBtn.addEventListener('click', () => {
        if (input) { input.value = ''; input.focus(); }
        window.filterSidebar('');
      });
      // Cmd/Ctrl+K — the app's first global keyboard shortcut. Narrowly
      // scoped to just focusing the search input (no in-app command palette
      // to conflict with), so it only intercepts the browser's own default
      // where one exists.
      document.addEventListener('keydown', function(e) {
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
          e.preventDefault();
          if (input) { input.focus(); input.select(); }
        }
      });
    })();

    /* ── Three-dot context menu for sidebar history items ── */
    var _shiMenuEl = null;
    var _shiMenuClose = null;
    window.showHistoryMenu = function(event, id, type) {
      // Remove any existing menu
      if (_shiMenuEl) { _shiMenuEl.remove(); _shiMenuEl = null; }
      if (_shiMenuClose) { document.removeEventListener('click', _shiMenuClose); _shiMenuClose = null; }

      var btn = event.currentTarget || event.target;
      var rect = btn.getBoundingClientRect();

      // Detect if this session is pinned/read (for home + chatsview types)
      var isPinned = false;
      var _sess = null;
      if (type === 'home' || type === 'chatsview') {
        _sess = homeChatSessions.find(function(s) { return s.id === id; }) || (window.chatsViewSessions || []).find(function(s) { return s.id === id; });
        isPinned = !!(_sess && _sess.isPinned);
      } else if (type === 'project') {
        var _link = getProjectLinks().find(function(l) { return l.chatSessionId === id; });
        isPinned = !!(_link && _link.pinned);
      }
      var inProject = typeof isChatInProject === 'function' ? isChatInProject(id) : false;

      var menu = document.createElement('div');
      menu.className = 'shi-ctx-menu';

      var starIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
      var renameIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>';
      var projectIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/><line x1="12" y1="11" x2="12" y2="17"/><line x1="9" y1="14" x2="15" y2="14"/></svg>';
      var deleteIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6M9 6V4h6v2"/></svg>';
      var selectIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>';
      var readIcon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 6l-10 7L2 6"/><rect x="2" y="4" width="20" height="16" rx="2"/></svg>';

      function item(icon, label, shortcut, cls, fn) {
        var b = document.createElement('button');
        b.className = 'shi-ctx-item' + (cls ? ' ' + cls : '');
        b.innerHTML = icon + label + (shortcut ? '<span class="shi-ctx-shortcut">' + shortcut + '</span>' : '');
        b.addEventListener('click', function(e) { e.stopPropagation(); menu.remove(); _shiMenuEl = null; fn(); });
        return b;
      }
      function sep() { var d = document.createElement('div'); d.className = 'shi-ctx-sep'; return d; }

      if (type === 'home') {
        menu.appendChild(item(starIcon, isPinned ? 'Unstar' : 'Star', 'P', '', function() {
          if (typeof window.togglePinHomeChat === 'function') window.togglePinHomeChat(id);
        }));
        menu.appendChild(item(renameIcon, 'Rename', 'R', '', function() {
          if (typeof window.renameHomeChatSession === 'function') window.renameHomeChatSession(id);
        }));
        menu.appendChild(item(projectIcon, 'Add to project', '', '', function() {
          if (typeof window.addHomeChatToProject === 'function') window.addHomeChatToProject(id);
        }));
        menu.appendChild(sep());
        menu.appendChild(item(deleteIcon, 'Delete', 'D', 'danger', function() {
          if (typeof window.deleteHomeChatSession === 'function') window.deleteHomeChatSession(id);
        }));
      } else if (type === 'chatsview') {
        var _isRead = _sess ? _sess.isRead !== false : true;
        menu.appendChild(item(selectIcon, 'Select', '', '', function() {
          if (typeof window.enterChatsSelectionMode === 'function') window.enterChatsSelectionMode(id);
        }));
        menu.appendChild(item(starIcon, isPinned ? 'Unstar' : 'Star', 'P', '', function() {
          if (typeof window.togglePinHomeChat === 'function') window.togglePinHomeChat(id);
        }));
        menu.appendChild(item(readIcon, _isRead ? 'Mark as unread' : 'Mark as read', 'U', '', function() {
          if (typeof window.toggleReadHomeChat === 'function') window.toggleReadHomeChat(id);
        }));
        menu.appendChild(item(renameIcon, 'Rename', 'R', '', function() {
          if (typeof window.renameHomeChatSession === 'function') window.renameHomeChatSession(id);
        }));
        menu.appendChild(sep());
        menu.appendChild(item(deleteIcon, 'Delete', 'D', 'danger', function() {
          if (typeof window.deleteHomeChatSession === 'function') window.deleteHomeChatSession(id);
        }));
      } else if (type === 'project') {
        menu.appendChild(item(starIcon, isPinned ? 'Unpin' : 'Pin', 'P', '', function() {
          if (typeof window.toggleProjectPin === 'function') window.toggleProjectPin(id);
        }));
        menu.appendChild(item(renameIcon, 'Rename', 'R', '', function() {
          if (typeof window.renameProjectLink === 'function') window.renameProjectLink(id);
        }));
        menu.appendChild(sep());
        menu.appendChild(item(deleteIcon, 'Delete', 'D', 'danger', function() {
          if (typeof window.deleteProject === 'function') window.deleteProject(id);
        }));
      } else {
        menu.appendChild(item(renameIcon, 'Rename', 'R', '', function() {
          if (typeof window.renameChatSession === 'function') window.renameChatSession(id);
        }));
        menu.appendChild(item(projectIcon, 'Add to project', '', '', function() {
          if (typeof window.addHomeChatToProject === 'function') window.addHomeChatToProject(id);
        }));
        menu.appendChild(sep());
        menu.appendChild(item(deleteIcon, 'Delete', 'D', 'danger', function() {
          if (typeof window.deleteChatSession === 'function') window.deleteChatSession(id);
        }));
      }

      document.body.appendChild(menu);
      _shiMenuEl = menu;

      // Position menu below/above the three-dot button
      var mw = 176, mh = menu.offsetHeight || 180;
      var left = Math.min(rect.left, window.innerWidth - mw - 8);
      var top = rect.bottom + 4;
      if (top + mh > window.innerHeight - 8) top = rect.top - mh - 4;
      menu.style.left = left + 'px';
      menu.style.top  = top  + 'px';

      // Close on outside click
      _shiMenuClose = function(e) {
        if (!menu.contains(e.target)) {
          menu.remove(); _shiMenuEl = null;
          document.removeEventListener('click', _shiMenuClose); _shiMenuClose = null;
        }
      };
      setTimeout(function() { document.addEventListener('click', _shiMenuClose); }, 0);
    };

    window.renameChatSession = function(id) {
      const session = chatSessions.find(s => s.id === id);
      if (!session) return;
      const newTitle = window.prompt('Rename conversation:', session.title || '');
      if (!newTitle || !newTitle.trim()) return;
      session.title = newTitle.trim().slice(0, 60);
      localStorage.setItem('batlab_chat_sessions', JSON.stringify(chatSessions));
      renderChatHistory();
    };

    window.archiveChatSession = function(id) {
      chatSessions = chatSessions.filter(s => s.id !== id);
      localStorage.setItem('batlab_chat_sessions', JSON.stringify(chatSessions));
      if (activeChatId === id) {
        activeChatId = 'chat_' + Date.now();
        chatHistory = [];
      }
      renderChatHistory();
    };

    window.deleteChatSession = async function(id) {
      if (!await window.showConfirmDialog('Delete this conversation?', 'This cannot be undone.', 'Delete')) return;
      chatSessions = chatSessions.filter(s => s.id !== id);
      localStorage.setItem('batlab_chat_sessions', JSON.stringify(chatSessions));
      if (activeChatId === id) {
        activeChatId = 'chat_' + Date.now();
        chatHistory = [];
      }
      renderChatHistory();
      window.syncFooter();
    };

    window.loadChatSession = function(id) {
      const session = chatSessions.find(s => s.id === id);
      if (!session) return;
      activeChatId = id;
      chatHistory = [...session.messages];
      setPageTitle(session.title);
      // re-render messages (reverse infinite scroll: newest window first,
      // older pairs revealed as the user scrolls the page up to the top).
      const container = document.getElementById('chatMessages');
      // Skeleton for consistency with Home chat; localStorage is synchronous so
      // this is overwritten in the same tick (effectively invisible, no delay hack).
      renderChatSkeleton(container);
      container.innerHTML = '';
      lazySetup({
        state: chatLazyState,
        container: container,
        getHistory: function () { return chatHistory; },
        renderSlice: chatRenderSlice,
        pageScroll: true
      });
      renderChatHistory();
      showView('chat');
      window.syncFooter();
    };

    window.startNewChat = function() {
      activeChatId = 'chat_' + Date.now();
      chatHistory = [];
      resetPageTitle();
      const container = document.getElementById('chatMessages');
      lazyTeardown(chatLazyState, container);
      container.innerHTML = `
        <div class="chat-msg">
          <div class="chat-msg-avatar is-logo"><img src="image/logo website.png" alt="BatNXT"></div>
          <div class="chat-msg-bubble">
            <p>${BatLang.t('chat.greet1')}</p>
            <p style="margin-top:8px;">${BatLang.t('chat.greet2')}</p>
          </div>
        </div>`;
      renderChatHistory();
    };

    // init
    activeChatId = 'chat_' + Date.now();
    renderChatHistory();
    // Sync footer on first load (no messages yet → show footer)
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function() { window.syncFooter(); });
    } else {
      window.syncFooter();
    }

    /* ── Markdown / code rendering (z.ai-style) ────────────────────────── */
    const _copySvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
    const _checkSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
    // Download (tray-with-arrow) glyph — used by the export file card + preview.
    const _dlSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';
    // Pencil (Edit) and refresh-arrows (Regenerate) glyphs — used by the
    // Copy/Edit/Regenerate hover row on user messages (hcmBuildUserActionsRow).
    const _editSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>';
    const _regenSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>';
    // Star (outline) glyph — used by the Star toggle in the assistant
    // reactions row (Home) and the star-only row on Marketing assistant
    // replies. Filled/gold via CSS (.hcm-star-btn.active) when starred.
    const _starSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';

    // Fallback clipboard-copy helper (execCommand path) shared by the
    // code-block copy button and hcmBuildUserActionsRow's Copy action.
    function hcmFallbackCopyText(text, done) {
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      document.body.removeChild(ta); done();
    }

    /* Builds the Copy / Edit & Resend / Regenerate hover-action row shown
       under USER messages only (mirrors hcmAppendReactions()'s hover-reveal
       row built for assistant messages, and reuses the same clipboard-copy
       convention as the code-block copy button). Shared between Home chat
       and Marketing — callers close over their own history/index/DOM refs
       via the getBusyFn/onEdit/onRegenerate callbacks rather than this
       function reading any global state itself.
       - content: raw text copied by the Copy button.
       - getBusyFn(): returns true while a reply is in flight (Home:
         homeConvBusy, Marketing: marketingBusy) — Edit/Regenerate are
         disabled for the ENTIRE conversation while any turn is in flight
         (not just the message being replied to), since only one turn can
         ever be in flight at a time (single-flight guard) and allowing an
         edit/truncate of a DIFFERENT message mid-flight would race with
         the in-flight request's own reads/writes of the same history array.
       - onEdit()/onRegenerate(): no-arg callbacks, already bound to the
         right message index + DOM nodes by the caller (hcmAppend /
         marketingAppend) at creation time. */
    function hcmBuildUserActionsRow(content, getBusyFn, onEdit, onRegenerate) {
      const row = document.createElement('div');
      row.className = 'hcm-user-actions';

      function makeBtn(svg, label, gated) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'hcm-user-action-btn' + (gated ? ' hcm-user-action-gated' : '');
        b.title = label;
        b.setAttribute('aria-label', label);
        b.innerHTML = svg;
        if (gated) b.disabled = !!getBusyFn();
        return b;
      }

      const copyBtn = makeBtn(_copySvg, BatLang.t('chat.copyBtn') || 'Copy', false);
      copyBtn.addEventListener('click', function () {
        const done = function () {
          copyBtn.classList.add('copied');
          copyBtn.innerHTML = _checkSvg;
          setTimeout(function () { copyBtn.classList.remove('copied'); copyBtn.innerHTML = _copySvg; }, 1600);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(content).then(done).catch(function () { hcmFallbackCopyText(content, done); });
        } else {
          hcmFallbackCopyText(content, done);
        }
      });

      const editBtn = makeBtn(_editSvg, BatLang.t('chat.editBtn') || 'Edit & resend', true);
      editBtn.addEventListener('click', function () { if (!editBtn.disabled) onEdit(); });

      const regenBtn = makeBtn(_regenSvg, BatLang.t('chat.regenBtn') || 'Regenerate', true);
      regenBtn.addEventListener('click', function () { if (!regenBtn.disabled) onRegenerate(); });

      row.appendChild(copyBtn);
      row.appendChild(editBtn);
      row.appendChild(regenBtn);
      return row;
    }

    // Toggles the disabled state of every Edit/Regenerate button currently
    // rendered inside `containerId` — called right after homeConvBusy /
    // marketingBusy flips, so hover rows built before the flip (i.e. every
    // row already on screen) stay in sync without needing to be rebuilt.
    function hcmSetUserActionsGated(containerId, disabled) {
      const nodes = document.querySelectorAll('#' + containerId + ' .hcm-user-action-gated');
      nodes.forEach(function (b) { b.disabled = disabled; });
    }

    // Detects whether a chat message's own text is RTL (Arabic/Hebrew, etc.)
    // so each bubble can be aligned correctly regardless of the site's UI language.
    function detectTextDir(text) {
      var rtlChar = /[\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC]/;
      return rtlChar.test(String(text || '')) ? 'rtl' : 'ltr';
    }

    // Assistant reply alignment/reading-direction follows the UI LANGUAGE
    // (BatLang.lang — the same source currentUiLanguageInstruction() uses),
    // NOT the per-reply content script: Arabic UI → rtl (text on the far
    // right), any other UI language (English, Turkish, …) → ltr (far left).
    // This keeps every assistant reply on a consistent side regardless of what
    // language the model happened to answer in. User bubbles still use
    // detectTextDir() (content-based) and are intentionally left untouched.
    function uiTextDir() {
      var lang = (typeof BatLang !== 'undefined') ? BatLang.lang : 'en';
      return lang === 'ar' ? 'rtl' : 'ltr';
    }

    // Direction for the "Thought for Xs" widget specifically: unlike regular
    // assistant replies (uiTextDir() above, UI-language-based), this widget
    // must follow the ACTUAL REQUEST per-turn, since a user can ask in Arabic
    // while the UI itself is set to English. Primary signal: content of the
    // user's own prompt text (detectTextDir() — reused as-is, so Hebrew also
    // triggers rtl, which is a harmless superset here). Falls back to the UI
    // language (uiTextDir()) when the prompt carries no signal either way.
    function pickThinkingDir(promptText) {
      var contentDir = detectTextDir(promptText);
      return contentDir === 'rtl' ? 'rtl' : uiTextDir();
    }

    function renderRichText(text, isUser) {
      const raw = String(text == null ? '' : text);
      // User messages stay plain (escaped) — only the AI gets full markdown.
      if (isUser || !window.marked) {
        return '<p>' + escapeHtml(raw).replace(/\n/g, '<br>') + '</p>';
      }
      let html;
      try {
        html = window.marked.parse(raw, { gfm: true, breaks: true });
      } catch (e) {
        return '<p>' + escapeHtml(raw).replace(/\n/g, '<br>') + '</p>';
      }
      if (window.DOMPurify) {
        html = window.DOMPurify.sanitize(html, { ADD_ATTR: ['target'] });
      }
      return html;
    }

    // Detected-language → file extension map for the universal code-block
    // Download button below. Falls back to .txt for anything unrecognized
    // or unlabeled (e.g. a bare ``` fence with no language tag).
    const CODE_BLOCK_EXT_MAP = {
      html: 'html', css: 'css', js: 'js', javascript: 'js', ts: 'ts', typescript: 'ts',
      json: 'json', md: 'md', markdown: 'md', py: 'py', python: 'py', sql: 'sql',
      sh: 'sh', bash: 'sh', shell: 'sh', yml: 'yaml', yaml: 'yaml', xml: 'xml',
      java: 'java', c: 'c', cpp: 'cpp', 'c++': 'cpp', go: 'go', rust: 'rs', rs: 'rs',
      php: 'php', ruby: 'rb', rb: 'rb'
    };
    function codeBlockDownloadExt(lang) {
      return CODE_BLOCK_EXT_MAP[(lang || '').toLowerCase()] || 'txt';
    }

    function enhanceCodeBlocks(container) {
      if (!container) return;
      const blocks = container.querySelectorAll('pre > code');
      blocks.forEach(function (code) {
        const pre = code.parentElement;
        if (!pre || pre.parentElement && pre.parentElement.classList.contains('code-block')) return;

        let lang = '';
        code.classList.forEach(function (c) {
          if (c.indexOf('language-') === 0) lang = c.slice(9);
        });

        if (window.hljs) {
          try { window.hljs.highlightElement(code); } catch (e) {}
        }

        const wrap = document.createElement('div');
        wrap.className = 'code-block';
        const header = document.createElement('div');
        header.className = 'code-block-header';
        const label = document.createElement('span');
        label.className = 'code-block-lang';
        label.textContent = lang || 'text';
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'code-block-copy';
        btn.innerHTML = _copySvg + '<span>' + BatLang.t('chat.copyBtn') + '</span>';
        // Download button — icon-only (matches the file card's .ex-file-card-dl
        // style), reuses the same _dlSvg glyph and Blob+temporary-<a> download
        // mechanism already established by downloadAiMarkdown(). Placed to the
        // RIGHT of Copy (Copy stays first/primary) inside a shared actions
        // group so both buttons sit together at the header's trailing edge.
        const dlBtn = document.createElement('button');
        dlBtn.type = 'button';
        dlBtn.className = 'code-block-download';
        dlBtn.innerHTML = _dlSvg;
        dlBtn.setAttribute('aria-label', BatLang.t('chat.downloadBtn') || 'Download');
        dlBtn.title = BatLang.t('chat.downloadBtn') || 'Download';
        const actions = document.createElement('div');
        actions.className = 'code-block-actions';
        actions.appendChild(btn);
        actions.appendChild(dlBtn);
        header.appendChild(label);
        header.appendChild(actions);

        pre.parentNode.insertBefore(wrap, pre);
        wrap.appendChild(header);
        wrap.appendChild(pre);

        btn.addEventListener('click', function () {
          const done = function () {
            btn.classList.add('copied');
            btn.innerHTML = _checkSvg + '<span>' + BatLang.t('chat.copiedBtn') + '</span>';
            setTimeout(function () {
              btn.classList.remove('copied');
              btn.innerHTML = _copySvg + '<span>' + BatLang.t('chat.copyBtn') + '</span>';
            }, 1600);
          };
          const txt = code.textContent;
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(txt).then(done).catch(function () {
              const ta = document.createElement('textarea');
              ta.value = txt; document.body.appendChild(ta); ta.select();
              try { document.execCommand('copy'); } catch (e) {}
              document.body.removeChild(ta); done();
            });
          } else {
            const ta = document.createElement('textarea');
            ta.value = txt; document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta); done();
          }
        });

        dlBtn.addEventListener('click', function () {
          const ext = codeBlockDownloadExt(lang);
          const blob = new Blob([code.textContent], { type: 'text/plain' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = ext + '_batnxt.' + ext;
          document.body.appendChild(a); a.click(); a.remove();
          URL.revokeObjectURL(url);
        });
      });
    }

    function appendMsg(role, text, improvedPrompt) {
      const messages = document.getElementById('chatMessages');
      const isUser = role === 'user';
      const div = document.createElement('div');
      div.className = 'chat-msg' + (isUser ? ' user' : '');

      const avatar = document.createElement('div');
      avatar.className = 'chat-msg-avatar' + (isUser ? '' : ' is-logo');
      if (isUser) {
        avatar.textContent = document.getElementById('avatarInitials')?.textContent || 'U';
      } else {
        avatar.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      }

      const bubble = document.createElement('div');
      bubble.className = 'chat-msg-bubble' + (isUser ? '' : ' md-content');
      bubble.dir = detectTextDir(text);
      bubble.innerHTML = renderRichText(text, isUser);
      if (!isUser) enhanceCodeBlocks(bubble);

      if (improvedPrompt) {
        const btn = document.createElement('button');
        btn.className = 'apply-btn';
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> ' + BatLang.t('chat.applyBtn');
        btn.onclick = () => {
          const inp = document.getElementById('homeInput');
          if (inp) { inp.value = improvedPrompt; inp.dispatchEvent(new Event('input')); }
          showView('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
          showToast(BatLang.t('toast.promptApplied'), 'success');
        };
        bubble.appendChild(btn);
      }

      div.appendChild(avatar);
      div.appendChild(bubble);
      messages.appendChild(div);
      // chat-messages no longer has inner scroll — scroll the page instead
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    }

    // ── Clarifying-question widget (shared helpers) ──
    // Dims/disables any previous unanswered clarify card in the given container
    // as soon as a newer message is sent, so a stale widget can't be clicked later.
    function disableStaleClarify(containerId) {
      const wrap = document.getElementById(containerId);
      if (!wrap) return;
      wrap.querySelectorAll('.clarify-card:not(.answered)').forEach(card => {
        card.classList.add('stale');
      });
    }

    // Shared between Chat and Home: shows/hides the free-text "Something else"
    // row under a clarify card. Pure DOM show/hide with no view-specific logic,
    // same precedent as disableStaleClarify() above.
    window.toggleClarifyOther = function(btnEl) {
      const card = btnEl.closest('.clarify-card');
      if (!card) return;
      const row = card.querySelector('.clarify-other-row');
      if (!row) return;
      const showing = row.classList.toggle('show');
      if (showing) {
        const input = row.querySelector('.clarify-other-input');
        if (input) input.focus();
      }
    };

    function appendClarifyWidget(clarify) {
      const wrap = document.getElementById('chatMessages');
      if (!wrap) return;
      const card = document.createElement('div');
      card.className = 'clarify-card';
      const title = document.createElement('div');
      title.className = 'clarify-title';
      title.textContent = clarify.question;
      const opts = document.createElement('div');
      opts.className = 'clarify-options';
      clarify.options.forEach((opt, i) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'clarify-opt';
        btn.onclick = () => window.chatAnswerClarify(btn, opt);
        const num = document.createElement('span');
        num.className = 'clarify-opt-num';
        num.textContent = String(i + 1);
        const txt = document.createElement('span');
        txt.className = 'clarify-opt-text';
        txt.textContent = opt;
        btn.appendChild(num);
        btn.appendChild(txt);
        opts.appendChild(btn);
      });
      const skipBtn = document.createElement('button');
      skipBtn.type = 'button';
      skipBtn.className = 'clarify-opt clarify-opt-skip';
      skipBtn.textContent = BatLang.t('clarify.skip');
      skipBtn.onclick = () => window.chatAnswerClarify(skipBtn, BatLang.t('clarify.skipReply'));
      opts.appendChild(skipBtn);
      const otherToggleBtn = document.createElement('button');
      otherToggleBtn.type = 'button';
      otherToggleBtn.className = 'clarify-opt clarify-opt-other';
      otherToggleBtn.textContent = BatLang.t('clarify.other');
      otherToggleBtn.onclick = () => window.toggleClarifyOther(otherToggleBtn);
      opts.appendChild(otherToggleBtn);
      card.appendChild(title);
      card.appendChild(opts);
      const otherRow = document.createElement('div');
      otherRow.className = 'clarify-other-row';
      const otherInput = document.createElement('input');
      otherInput.type = 'text';
      otherInput.className = 'clarify-other-input';
      otherInput.placeholder = BatLang.t('clarify.otherPlaceholder');
      otherInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); window.submitClarifyOther(otherToggleBtn, otherInput); }
      });
      const otherSubmit = document.createElement('button');
      otherSubmit.type = 'button';
      otherSubmit.className = 'clarify-other-submit';
      otherSubmit.textContent = BatLang.t('clarify.otherSend');
      otherSubmit.onclick = () => window.submitClarifyOther(otherToggleBtn, otherInput);
      otherRow.appendChild(otherInput);
      otherRow.appendChild(otherSubmit);
      card.appendChild(otherRow);
      // Arrow-key navigation across all options (numbered + Skip + Something else).
      // Only acts when focus is already on a .clarify-opt button, so it never
      // hijacks arrow-key behavior while typing in the free-text input.
      card.addEventListener('keydown', (e) => {
        if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
        if (!document.activeElement || !document.activeElement.classList.contains('clarify-opt')) return;
        const focusable = Array.from(card.querySelectorAll('.clarify-opt'));
        const idx = focusable.indexOf(document.activeElement);
        if (idx === -1) return;
        e.preventDefault();
        const next = e.key === 'ArrowDown' ? (idx + 1) % focusable.length : (idx - 1 + focusable.length) % focusable.length;
        focusable[next].focus();
      });
      wrap.appendChild(card);
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    }

    // Injects the <STEPS> collapsible progress-card styles once (inject-once
    // <style> pattern, like _apStyle / _exCardStyle).
    function _ensureStepsStyles() {
      if (document.getElementById('_stepsStyle')) return;
      const s = document.createElement('style');
      s.id = '_stepsStyle';
      s.textContent = [
        '.steps-card{max-width:440px;margin:4px 0 8px;border-radius:13px;overflow:hidden;',
        'background:var(--surface2,#0f1420);border:1px solid var(--border,#1a2235);}',
        '.steps-head{display:flex;align-items:center;gap:9px;padding:9px 12px;cursor:pointer;',
        'user-select:none;transition:background .15s;}',
        '.steps-head:hover{background:var(--surface,#0b0f1a);}',
        '.steps-head-ic{flex-shrink:0;width:22px;height:22px;border-radius:6px;overflow:hidden;',
        'display:flex;align-items:center;justify-content:center;background:var(--surface,#0b0f1a);}',
        '.steps-head-ic img{width:100%;height:100%;object-fit:cover;}',
        '.steps-head-txt{flex:1;min-width:0;font-size:.8rem;font-weight:600;',
        'color:var(--text,#eef2f7);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
        '.steps-head-chevron{flex-shrink:0;color:var(--text-muted,#8892a4);',
        'transition:transform .2s;}',
        '.steps-head-chevron svg{width:15px;height:15px;display:block;}',
        '.steps-card.open .steps-head-chevron{transform:rotate(180deg);}',
        '.steps-list{display:none;flex-direction:column;gap:2px;padding:2px 12px 10px 12px;}',
        '.steps-card.open .steps-list{display:flex;}',
        '.steps-item{display:flex;align-items:center;gap:8px;padding:4px 0;',
        'font-size:.79rem;color:var(--text-muted,#8892a4);}',
        '.steps-item-ic{flex-shrink:0;width:15px;height:15px;color:var(--text-muted,#8892a4);}',
        '.steps-item-ic svg{width:15px;height:15px;display:block;}',
        '.steps-item.is-done{color:var(--text,#eef2f7);font-weight:600;}',
        '.steps-item.is-done .steps-item-ic{color:var(--green,#1f9d55);}'
      ].join('');
      document.head.appendChild(s);
    }

    // Renders a <STEPS> payload ({steps:[...], done:"..."}) as a collapsible,
    // retrospective progress card (approved Option A). Collapsed by default:
    // BatNXT icon + the "done" line + a chevron; clicking expands the full
    // step list (each with a small clock glyph) ending in the ✓ "done" row.
    // Data is model-authored display text (never raw reasoning) — see
    // getChatSystem's PROGRESS STEPS instruction. `container` is the message
    // list to render into; `beforeEl` (optional) inserts the card above that
    // element (used to place it just above the finalized reply bubble).
    const _clockSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>';
    const _chevronSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';
    function appendStepsWidget(payload, container, beforeEl) {
      const data = sanitizeStepsPayload(payload);
      if (!data || !container) return;
      _ensureStepsStyles();

      const card = document.createElement('div');
      card.className = 'steps-card';

      const head = document.createElement('div');
      head.className = 'steps-head';
      head.setAttribute('role', 'button');
      head.setAttribute('tabindex', '0');
      head.setAttribute('aria-expanded', 'false');

      const headIc = document.createElement('div');
      headIc.className = 'steps-head-ic';
      headIc.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      const headTxt = document.createElement('div');
      headTxt.className = 'steps-head-txt';
      headTxt.textContent = data.done;
      const chevron = document.createElement('div');
      chevron.className = 'steps-head-chevron';
      chevron.innerHTML = _chevronSvg;
      head.appendChild(headIc);
      head.appendChild(headTxt);
      head.appendChild(chevron);

      const list = document.createElement('div');
      list.className = 'steps-list';
      data.steps.forEach(function (label) {
        const item = document.createElement('div');
        item.className = 'steps-item';
        const ic = document.createElement('span');
        ic.className = 'steps-item-ic';
        ic.innerHTML = _clockSvg;
        const tx = document.createElement('span');
        tx.textContent = label;
        item.appendChild(ic);
        item.appendChild(tx);
        list.appendChild(item);
      });
      // Final "Done" row (✓ + closing phrase).
      const doneItem = document.createElement('div');
      doneItem.className = 'steps-item is-done';
      const doneIc = document.createElement('span');
      doneIc.className = 'steps-item-ic';
      doneIc.innerHTML = _checkSvg;
      const doneTx = document.createElement('span');
      doneTx.textContent = data.done;
      doneItem.appendChild(doneIc);
      doneItem.appendChild(doneTx);
      list.appendChild(doneItem);

      function toggle() {
        const open = card.classList.toggle('open');
        head.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
      head.addEventListener('click', toggle);
      head.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
      });

      card.appendChild(head);
      card.appendChild(list);
      if (beforeEl && beforeEl.parentNode === container) container.insertBefore(card, beforeEl);
      else container.appendChild(card);
    }

    window.chatAnswerClarify = function(btnEl, text) {
      const card = btnEl.closest('.clarify-card');
      if (card) {
        card.classList.add('answered');
        card.querySelectorAll('.clarify-opt').forEach(b => b.classList.remove('selected'));
        btnEl.classList.add('selected');
      }
      const input = document.getElementById('chatInput');
      if (input) input.value = text;
      sendChatMessage();
    };

    window.submitClarifyOther = function(otherBtn, inputEl) {
      const val = (inputEl.value || '').trim();
      if (!val) { inputEl.focus(); return; }
      window.chatAnswerClarify(otherBtn, val);
    };

    async function sendChatMessage() {
      const input = document.getElementById('chatInput');
      const msg = input.value.trim();
      if (!msg) return;
      if (!requireLogin()) return;
      input.value = '';
      input.style.height = 'auto';
      disableStaleClarify('chatMessages');
      appendMsg('user', msg, null);
      chatHistory.push({ role: 'user', content: msg });
      saveChatSession();   // save immediately so the session appears in history right away
      window.syncFooter();

      document.getElementById('chatTyping').classList.add('show');
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
      startThinkingCycle('text'); // dedicated chat view has no attachment capability — always plain text

      try {
        const { res } = await gatewayFetch(chatRoutePath(), {
          system:   getChatSystem(),
          messages: chatHistory
        });
        // Streamed text/plain, not JSON — see the note in sendHwChatMessage().
        // The old res.json() threw on every turn and fell through to the catch
        // below, so this view only ever showed toast.chatError. No onDelta is
        // passed: there's no streaming bubble here, the reply is painted once
        // via appendMsg() below (streamPlainText guards the callback, so
        // omitting it is safe). The in-band `if (data.error)` branch that used
        // to sit here is gone with it — gatewayFetch throws on any non-2xx, so
        // it was unreachable, and the catch already renders the same message.
        // chatRoutePath() can resolve to /chat/core via this view's own model
        // selector, and Core emits <REASONING> — strip it before the
        // IMPROVED_PROMPT/CLARIFY/STEPS parsing below so the tag never reaches
        // the bubble. Harmless no-op on the routes that don't emit it.
        const rawText = stripInlineReasoning(await streamPlainText(res)).trim() || '...';
        let displayText = rawText;
        let improved = null;
        const m = rawText.match(/<IMPROVED_PROMPT>([\s\S]*?)<\/IMPROVED_PROMPT>/);
        if (m) {
          // Only surface "Build Now" when a build type is selected; plain chat stays plain.
          if (selectedType) improved = m[1].trim();
          displayText = rawText.replace(/<IMPROVED_PROMPT>[\s\S]*?<\/IMPROVED_PROMPT>/, '').trim();
        }
        let clarify = null;
        const cM = rawText.match(/<CLARIFY>([\s\S]*?)<\/CLARIFY>/);
        if (cM) {
          // A: tag-wrapped path — parse the inner JSON, retrying after a fence-strip
          // (weak models sometimes wrap the JSON in ```json fences inside the tags).
          const rawTag = cM[1].trim();
          try { clarify = JSON.parse(rawTag); }
          catch (e) { try { clarify = JSON.parse(stripJsonCodeFences(rawTag)); } catch (e2) { clarify = null; } }
          displayText = displayText.replace(/<CLARIFY>[\s\S]*?<\/CLARIFY>/, '').trim();
        } else {
          // Safety net: model dropped the <CLARIFY> tags but still emitted the bare JSON.
          clarify = detectBareClarifyJson(displayText);
          // B: retry the strict detector on a fence-stripped copy (the model dropped
          // the tags AND wrapped the bare JSON in a code fence).
          if (!clarify) {
            const unfenced = stripJsonCodeFences(displayText);
            if (unfenced !== (displayText || '').trim()) clarify = detectBareClarifyJson(unfenced);
          }
          if (clarify) {
            displayText = '';
          } else if (looksLikeClarifyJson(displayText)) {
            // C: still couldn't card-ify a lone clarify-shaped JSON — suppress the
            // raw JSON and show a neutral, non-fabricated fallback instead of leaking.
            displayText = BatLang.t('chat.clarifyFallback') || '';
          }
        }
        // Trailing <STEPS> progress tag (display-only summary) — parsed out so
        // its JSON never shows, then rendered as a collapsible card above the
        // reply. Mirrors the home-chat path; keeps this view leak-safe.
        let stepsData = null;
        const sM = rawText.match(/<STEPS>([\s\S]*?)<\/STEPS>/);
        if (sM) {
          let _sp = null;
          try { _sp = JSON.parse(sM[1].trim()); }
          catch (e) { try { _sp = JSON.parse(stripJsonCodeFences(sM[1].trim())); } catch (e2) { _sp = null; } }
          stepsData = sanitizeStepsPayload(_sp);
          displayText = displayText.replace(/<STEPS>[\s\S]*?<\/STEPS>/, '').trim();
        } else {
          stepsData = detectBareStepsJson(displayText);
          if (stepsData) displayText = '';
        }
        chatHistory.push({ role: 'assistant', content: rawText });
        stopThinkingCycle();
        document.getElementById('chatTyping').classList.remove('show');
        // Steps card first (above), then the reply bubble below it.
        if (stepsData) appendStepsWidget(stepsData, document.getElementById('chatMessages'), null);
        appendMsg('assistant', displayText, improved);
        if (clarify && clarify.question && Array.isArray(clarify.options) && clarify.options.length >= 2) {
          appendClarifyWidget(clarify);
        }
        saveChatSession();
        if (isMemoryExtractionEligible(msg)) maybeExtractMemory(msg, rawText);
        // After the very first exchange, generate a smart title asynchronously.
        // Skip the (paid) AI title call for short/generic first messages — the
        // truncated-message fallback title set in saveChatSession() is already fine for those.
        if (chatHistory.filter(m => m.role === 'user').length === 1 && isTitleEligible(chatHistory[0].content)) {
          generateChatTitle(chatHistory.concat([{ role: 'assistant', content: rawText }]), function(title) {
            const s = chatSessions.find(function(x){ return x.id === activeChatId; });
            if (s) { s.title = title; localStorage.setItem('batlab_chat_sessions', JSON.stringify(chatSessions)); renderChatHistory(); }
            setPageTitle(title);
          });
        }
      } catch(err) {
        chatHistory.pop(); // don't poison history with a failed turn
        stopThinkingCycle();
        document.getElementById('chatTyping').classList.remove('show');
        const isNoCredits = err && err.message === 'no_credits';
        const isRateLimited = err && err.message === 'rate_limited';
        // gatewayFetch already surfaced the out-of-credits screen / rate-limit
        // toast for these two cases — avoid double-showing an error bubble.
        if (!isNoCredits && !isRateLimited) {
          appendMsg('assistant', BatLang.t('toast.chatError'), null);
        }
        saveChatSession();  // still save on error so the conversation isn't lost
      }
    }

    var _thinkingTimer = null;
    // Shows the content-type message immediately, switches to the "thinking"
    // message after 3s, then keeps alternating between the two at a random
    // 3-5s interval until stopThinkingCycle() is called.
    function startThinkingCycle(type) {
      clearTimeout(_thinkingTimer);
      var phase = 'initial';
      var el = document.getElementById('chatThinkingText');
      if (el) el.textContent = _statusHintText(type, phase);
      function scheduleNext(delay) {
        _thinkingTimer = setTimeout(function() {
          phase = phase === 'initial' ? 'thinking' : 'initial';
          var el = document.getElementById('chatThinkingText');
          if (el) {
            el.style.opacity = '0';
            el.style.transition = 'opacity 0.25s';
            setTimeout(function() {
              el.textContent = _statusHintText(type, phase);
              el.style.opacity = '1';
            }, 250);
          }
          scheduleNext(3000 + Math.random() * 2000);
        }, delay);
      }
      scheduleNext(3000);
    }
    function stopThinkingCycle() {
      clearTimeout(_thinkingTimer);
      _thinkingTimer = null;
    }

    document.getElementById('chatSendBtn').addEventListener('click', sendChatMessage);
    document.getElementById('chatInput').addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChatMessage(); }
    });
    document.getElementById('chatInput').addEventListener('input', function() {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 120) + 'px';
      if (typeof window.batmanCheckInput === 'function') window.batmanCheckInput(this);
    });

    /* sync home credits */
    const _origUpdate = window.updateCreditDisplay;
    window.updateCreditDisplay = function() {
      if (_origUpdate) _origUpdate();
      const hc = document.getElementById('homeCredits');
      if (hc) {
        hc.textContent = currentCredits;
        hc.style.color = currentCredits <= 0 ? 'var(--red)' : 'var(--accent)';
      }
      // Home credits indicator (near send button), zero-credits banner, and
      // the live countdown/wait text are all driven by the shared credit-window
      // engine so they stay in sync and tick live. Render immediately here
      // rather than only relying on the ticker: startCreditsTicker() is a
      // no-op once the interval is already running (the common case), so
      // without this direct call a fresh currentCredits value (e.g. right
      // after a message) could sit stale in the Settings/Billing "X / Y
      // credits" widgets for up to ~1s until the next scheduled tick.
      renderAllCreditWidgets();
      startCreditsTicker();
    };

    /* ── Home hero (z.ai-style) ── */
    function escapeHtml(s) {
      return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
        return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c];
      });
    }

    /* ── Preview iframes use sandbox="allow-scripts" (no allow-same-origin,
       intentionally — it's untrusted generated code, and adding
       allow-same-origin on a srcdoc frame would let it script its way out
       into the real BatNXT page). Without allow-same-origin the frame gets
       an opaque origin, and browsers THROW on window.localStorage /
       sessionStorage access there. Any generated game/app that touches
       localStorage (high scores, saved state, etc.) then crashes before its
       own script finishes running — which silently breaks things like a
       Start button's click listener never getting attached. This injects a
       tiny in-memory shim so that access just works instead of throwing,
       without loosening the sandbox. ── */
    var PREVIEW_STORAGE_SHIM =
      '<script>(function(){' +
      'function shim(){var m={};return{' +
        'getItem:function(k){return Object.prototype.hasOwnProperty.call(m,String(k))?m[String(k)]:null;},' +
        'setItem:function(k,v){m[String(k)]=String(v);},' +
        'removeItem:function(k){delete m[String(k)];},' +
        'clear:function(){m={};},' +
        'key:function(i){return Object.keys(m)[i]||null;},' +
        'get length(){return Object.keys(m).length;}' +
      '};}' +
      '["localStorage","sessionStorage"].forEach(function(name){' +
        'try{window[name].getItem("__t");}' +
        'catch(e){try{Object.defineProperty(window,name,{value:shim(),configurable:true});}catch(e2){}}' +
      '});' +
      '})();</script>';

    function withPreviewShim(html) {
      html = html || '';
      var m = /<head[^>]*>/i.exec(html);
      if (m) return html.slice(0, m.index + m[0].length) + PREVIEW_STORAGE_SHIM + html.slice(m.index + m[0].length);
      m = /<html[^>]*>/i.exec(html);
      if (m) return html.slice(0, m.index + m[0].length) + PREVIEW_STORAGE_SHIM + html.slice(m.index + m[0].length);
      return PREVIEW_STORAGE_SHIM + html;
    }

    /* ── "Made with BatNXT" badge (Free-tier watermark) ──
       Injected fresh at SERVE time (never baked into stored/generated HTML)
       into every runnable artifact delivered to a viewer — preview iframe,
       download, share, export, and the shown/copied source. Because the plan
       check is read live from currentPlan here, a Free user who upgrades
       later automatically loses the badge on ALL prior generations with no
       regeneration. Any paid tier (starter/pro/max) never gets it. */
    var BATNXT_BADGE_HTML = `<!-- BatNXT Badge -->
<a href="https://batnxt.com"
   target="_blank"
   rel="noopener noreferrer"
   class="batnxt-badge"
   aria-label="Made with BatNXT">
    <svg class="batnxt-icon" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2L9.8 7H5l3.8 3-1.5 5L12 12.8 16.7 15l-1.5-5L19 7h-4.8L12 2z"/>
    </svg>
    <span>Made with <strong>BatNXT</strong></span>
</a>
<style>
.batnxt-badge{
    position:fixed;
    bottom:18px;
    right:18px;
    z-index:999999;
    display:flex;
    align-items:center;
    gap:8px;
    padding:10px 14px;
    background:rgba(17,17,17,.92);
    color:#fff;
    border:1px solid rgba(255,255,255,.08);
    border-radius:999px;
    text-decoration:none;
    font-family:Inter,system-ui,-apple-system,sans-serif;
    font-size:13px;
    font-weight:500;
    backdrop-filter:blur(10px);
    box-shadow:0 8px 30px rgba(0,0,0,.25);
    transition:.25s ease;
}
.batnxt-badge:hover{
    transform:translateY(-2px) scale(1.03);
    background:#000;
    box-shadow:0 12px 40px rgba(0,0,0,.35);
}
.batnxt-icon{
    width:18px;
    height:18px;
    flex-shrink:0;
}
.batnxt-badge strong{
    color:#ffd54a;
}
@media (max-width:600px){
    .batnxt-badge{
        bottom:12px;
        right:12px;
        padding:9px 12px;
        font-size:12px;
    }
    .batnxt-icon{
        width:16px;
        height:16px;
    }
}
</style>`;

    /* Inserts the badge immediately before the last </body>. No-op for any
       paid tier, for fragments/partial streams without a </body>, and (via
       the idempotency guard) if the badge is already present — so passing
       the same html through twice never double-injects. */
    function withBatnxtBadge(html) {
      html = html || '';
      if (currentPlan !== 'free') return html;
      if (html.indexOf('class="batnxt-badge"') !== -1) return html;
      var i = html.toLowerCase().lastIndexOf('</body>');
      if (i === -1) return html;
      return html.slice(0, i) + BATNXT_BADGE_HTML + '\n' + html.slice(i);
    }

    /* ── Conversation context for build/edit requests ──
       The home chat's build flow used to treat every message as an isolated
       instruction (just "the current file" + "the new instruction"), so a
       short follow-up like "change the name" had no memory of what was asked
       a few turns earlier. This recaps the user's earlier requests in this
       same chat so edits/thinking stay connected to the whole conversation,
       not just the single latest line.
       `excludeLast`: when true, skips the most recent user turn (used when
       that turn is already the current instruction being sent separately). */
    function buildConvRecap(excludeLast) {
      if (!Array.isArray(homeConvHistory) || homeConvHistory.length === 0) return '';
      var turns = excludeLast ? homeConvHistory.slice(0, -1) : homeConvHistory.slice();
      var userMsgs = turns.filter(function (m) { return m && m.role === 'user' && m.content; })
                           .map(function (m) { return String(m.content).slice(0, 500); });
      if (userMsgs.length === 0) return '';
      // Cap to the last 8 turns so the prompt doesn't grow unbounded in long chats.
      if (userMsgs.length > 8) userMsgs = userMsgs.slice(-8);
      return '\n\nEARLIER REQUESTS IN THIS CONVERSATION (for context — most recent last):\n'
        + userMsgs.map(function (m, i) { return (i + 1) + '. ' + m; }).join('\n') + '\n';
    }

    /* ── Typewriter placeholder suggestions ── */
    var HOME_SUGGESTIONS = {
      game:    { en: 'Build me a snake game with neon colors',
                 ar: 'ابني لعبة ثعبان بألوان نيون',
                 tr: 'Neon renkli bir yılan oyunu yap' },
      website: { en: 'Build a portfolio website for a designer',
                 ar: 'ابني موقع بورتفوليو لمصمم',
                 tr: 'Bir tasarımcı için portföy sitesi yap' },
      mobile:  { en: 'Build a mobile UI for a food delivery app',
                 ar: 'ابني واجهة موبايل لتطبيق توصيل طعام',
                 tr: 'Yemek siparişi uygulaması için mobil arayüz yap' },
      tool:    { en: 'Build a unit converter tool',
                 ar: 'ابني أداة تحويل الوحدات',
                 tr: 'Birim dönüştürücü aracı yap' }
    };
    var _twTimer = null;

    function homeTypewriterPlaceholder(inp, text) {
      if (_twTimer) { clearTimeout(_twTimer); _twTimer = null; }
      inp.placeholder = '';
      var i = 0;
      var speed = 38; // ms per char
      function tick() {
        if (inp.value !== '') return; // user started typing — stop
        if (i > text.length) return;
        inp.placeholder = text.slice(0, i) + (i < text.length ? '|' : '');
        i++;
        _twTimer = setTimeout(tick, speed);
      }
      tick();
    }

    function homeClearTypewriter(inp, fallback) {
      if (_twTimer) { clearTimeout(_twTimer); _twTimer = null; }
      inp.placeholder = fallback;
    }

    // Display-only cost-preview labels next to the home build-type chips and the
    // dedicated chat view's send button — reads the local creditConfig.js
    // constants, no network request, non-blocking.
    function renderCostPreview() {
      const homeEl = document.getElementById('homeCostPreview');
      if (homeEl) {
        const service = selectedType || 'chat';
        homeEl.textContent = SERVICE_COST_INFO[service] ? formatCostPreview(service) : '';
      }
      // The dedicated chat view mirrors whichever chat model the user has
      // actually selected (Prime/Flash/Core), so its label must track
      // selectedModel and NOT stay hardcoded on base 'chat' (GLM) pricing.
      const chatEl = document.getElementById('chatCostPreview');
      if (chatEl) {
        const chatService = selectedModel === 'BAT 1.2 Flash' ? 'chat_flash'
          : selectedModel === 'BAT 1.2 Core' ? 'chat_core'
          : 'chat';
        chatEl.textContent = formatCostPreview(chatService);
      }
      // Surcharge indicator: appended to whichever preview label is present
      // when an image is currently attached (Moondream image-preprocessing
      // pipeline — see MOONDREAM_SURCHARGE_CREDITS in creditConfig.js).
      // Guarded in a try/catch because `attachedFiles` is declared further
      // down this file and isn't initialized yet at this function's very
      // first (module-init) call.
      try {
        const imageCount = attachedFiles.filter(function (f) { return f.kind === 'image'; }).length;
        if (imageCount > 0) {
          const surchargeTxt = ` (+${MOONDREAM_SURCHARGE_CREDITS * imageCount} credits for image analysis)`;
          if (homeEl && homeEl.textContent) homeEl.textContent += surchargeTxt;
          if (chatEl && chatEl.textContent) chatEl.textContent += surchargeTxt;
        }
      } catch (e) { /* attachedFiles not yet initialized — skip surcharge display */ }
    }
    window.renderCostPreview = renderCostPreview;
    renderCostPreview();

    window.setHomeType = function (value) {
      if (PRO_TYPES.includes(value) && !isProPlan()) {
        showPricingModal();
        return;
      }
      // Toggle: click active chip again to deselect
      const alreadyActive = selectedType === value;
      document.querySelectorAll('#homeChips .home-chip').forEach(function (c) {
        c.classList.toggle('active', !alreadyActive && c.dataset.value === value);
      });
      selectedType = alreadyActive ? '' : value;
      // Update placeholder — typewriter when selecting, plain text when deselecting
      const inp = document.getElementById('homeInput');
      if (inp) {
        const defaultPh = BatLang.t('home.placeholder') || 'Message BatNXT AI...';
        if (selectedType && HOME_SUGGESTIONS[selectedType]) {
          const lang = BatLang.lang || 'en';
          const suggestion = (HOME_SUGGESTIONS[selectedType][lang] || HOME_SUGGESTIONS[selectedType]['en']);
          homeTypewriterPlaceholder(inp, suggestion);
          // Stop animation if user starts typing — restore default (never "Describe…")
          inp.addEventListener('input', function _stopTw() {
            homeClearTypewriter(inp, defaultPh);
            inp.removeEventListener('input', _stopTw);
          }, { once: true });
        } else {
          // Always revert to the neutral default, never show "Describe what you want to build"
          homeClearTypewriter(inp, defaultPh);
        }
      }
      if (!alreadyActive && window._onTypeChange) window._onTypeChange(value);
      renderCostPreview();
    };

    /* ── inline generation workspace ── */
    // Credit deduction is now fully server-side (gateway reserve/settle pipeline);
    // the client no longer calls deduct_credit directly.

    function appendHwMessage(prompt, type, isEdit) {
      const msgs = document.getElementById('hwMessages');
      if (!msgs) return;
      const label = BatLang.t('type.' + type) || type;
      const tag = isEdit ? (' · ' + (BatLang.t('hw.editTag') || 'edit')) : '';
      const div = document.createElement('div');
      div.className = 'hw-msg' + (isEdit ? ' hw-msg-edit' : '');
      div.innerHTML = '<div class="hw-msg-badge">' + escapeHtml(label + tag) + '</div>' + escapeHtml(prompt);
      msgs.appendChild(div);
      msgs.scrollTop = msgs.scrollHeight;
    }

    let hwLoadingTimers = [];
    let hwLoadingStartedAt = 0;
    // The four scripted lines always finish playing by this point. We use it
    // as a floor: the real result is never revealed before this, so a very
    // fast worker response never causes a jarring instant-flash.
    const HW_LOADING_MIN_MS = 3600;
    function showHwLoading() {
      const overlay = document.getElementById('hwLoading');
      if (!overlay) return;
      overlay.classList.add('active');
      hwLoadingStartedAt = Date.now();
      const lines = [0, 1, 2, 3].map(i => document.getElementById('hwTl' + i));
      lines.forEach(l => l && l.classList.remove('show', 'done', 'hw-still-working'));
      const lastLabel = document.querySelector('#hwTl3 [data-i18n="hw.loading4"]');
      if (lastLabel) lastLabel.textContent = BatLang.t('hw.loading4') || 'Almost done...';
      hwLoadingTimers.forEach(clearTimeout);
      hwLoadingTimers = [300, 1200, 2200, 3100].map((d, i) => setTimeout(() => {
        const l = lines[i];
        if (!l) return;
        l.classList.add('show');
        if (i === 3) l.classList.add('done');
      }, d));
      // If generation is still running well past the scripted steps (long or
      // complex builds), keep the last line visibly alive instead of sitting
      // frozen on "Almost done...", and reassure the user it hasn't stalled.
      hwLoadingTimers.push(setTimeout(() => {
        const l = lines[3];
        if (!l || !overlay.classList.contains('active')) return;
        l.classList.add('hw-still-working');
        if (lastLabel) lastLabel.textContent = BatLang.t('hw.loadingLong') || 'Still working — complex builds can take a little longer...';
      }, 7000));
    }
    function hideHwLoading() {
      const overlay = document.getElementById('hwLoading');
      if (overlay) overlay.classList.remove('active');
      hwLoadingTimers.forEach(clearTimeout);
      hwLoadingTimers = [];
    }
    // Lets the caller await "the loading animation has played out for at
    // least its minimum duration" before revealing a fast result.
    function hwLoadingMinDurationWait() {
      const remaining = HW_LOADING_MIN_MS - (Date.now() - hwLoadingStartedAt);
      return remaining > 0 ? new Promise(resolve => setTimeout(resolve, remaining)) : Promise.resolve();
    }

    // Shown only when a generation fails AND there is no previous result to
    // fall back to — never leaves the preview panel blank/frozen.
    function showHwFailed(message) {
      const overlay = document.getElementById('hwFailed');
      if (!overlay) return;
      const msg = document.getElementById('hwFailedMsg');
      if (msg && message) msg.textContent = message;
      overlay.classList.add('active');
    }
    function hideHwFailed() {
      const overlay = document.getElementById('hwFailed');
      if (overlay) overlay.classList.remove('active');
    }

    let hwCurrentTab = 'preview';
    function updateHwPreviewVisibility() {
      const iframe = document.getElementById('hwPreviewIframe');
      const mobileFrame = document.getElementById('hwMobileFrame');
      const codeView = document.getElementById('hwCodeView');
      const showCode = hwCurrentTab === 'code';
      if (codeView) codeView.style.display = showCode ? 'block' : 'none';
      const isMobile = lastType === 'mobile';
      if (mobileFrame) mobileFrame.classList.toggle('active', !showCode && isMobile);
      if (iframe) iframe.style.display = (!showCode && !isMobile) ? 'block' : 'none';
    }

    function enterWorkspace() {
      const view = document.getElementById('homeView');
      if (view) view.classList.add('workspace');
      const sb = document.getElementById('sidebar');
      if (sb) sb.classList.add('collapsed');
      const ab = document.querySelector('.app-body');
      if (ab) ab.classList.add('sidebar-collapsed');
      // restore preview panel if it was closed, and reset any manual chat width
      const pp = document.getElementById('hwPreviewPanel');
      const rs = document.getElementById('hwResizer');
      if (pp) { pp.style.display = ''; }
      if (rs) { rs.style.display = ''; }
      const chat = document.querySelector('.hw-chat');
      if (chat) { chat.style.width = ''; }
      const msgs = document.getElementById('hwMessages');
      if (msgs) msgs.innerHTML = '';
      lastHTML = '';
      const iframe = document.getElementById('hwPreviewIframe');
      const mobileIframe = document.getElementById('hwPreviewIframeMobile');
      const codeView = document.getElementById('hwCodeView');
      if (iframe) iframe.srcdoc = '';
      if (mobileIframe) mobileIframe.srcdoc = '';
      if (codeView) codeView.textContent = '';
      hwCurrentTab = 'preview';
      document.querySelectorAll('.hw-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === 'preview'));
    }

    function showWorkspaceResult(html, type) {
      hideHwLoading();
      // Serve-time badge (Free tier only) — WYSIWYG: same badged HTML feeds
      // the preview iframe and the code view.
      html = withBatnxtBadge(html);
      const iframe = document.getElementById('hwPreviewIframe');
      const mobileIframe = document.getElementById('hwPreviewIframeMobile');
      if (type === 'mobile') {
        if (mobileIframe) mobileIframe.srcdoc = withPreviewShim(html);
      } else {
        if (iframe) iframe.srcdoc = withPreviewShim(html);
      }
      const codeView = document.getElementById('hwCodeView');
      if (codeView) codeView.textContent = html;
      // Reset zoom and reveal zoom controls on new result
      _hwApplyZoom(1);
      const zg = document.getElementById('hwZoomGroup');
      if (zg) zg.style.display = 'flex';
      updateHwPreviewVisibility();
    }

    /* ── File attachments (home composer) ──
       The generation worker only accepts {prompt, type}, so uploaded files are
       folded into the prompt itself: text/code files are included as context,
       and images are passed as data-URL assets the model can inline into the
       build. This lets it behave like other AI tools without a backend change. */
    const ATTACH_MAX_TEXT  = 100 * 1024;   // 100 KB per text/code file
    const ATTACH_MAX_IMAGE = 500 * 1024;   // 500 KB per image
    const ATTACH_MAX_TOTAL = 1200 * 1024;  // ~1.2 MB combined budget
    const ATTACH_MAX_IMAGE_COUNT = 10;     // max images per message (mirrors gateway.js MAX_IMAGES_PER_MESSAGE)
    let attachedFiles = []; // { name, kind: 'image'|'text', content, size }

    window.toggleAttachMenu = function (e) {
      if (e) e.stopPropagation();
      const wrap = document.getElementById('homeAttachWrap');
      const btn = document.getElementById('homeAttachBtn');
      if (!wrap) return;
      const open = wrap.classList.toggle('open');
      if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    };
    function closeAttachMenu() {
      const wrap = document.getElementById('homeAttachWrap');
      if (wrap) wrap.classList.remove('open');
      const btn = document.getElementById('homeAttachBtn');
      if (btn) btn.setAttribute('aria-expanded', 'false');
    }
    // close the attach menu on any outside click
    document.addEventListener('click', function (e) {
      const wrap = document.getElementById('homeAttachWrap');
      if (wrap && wrap.classList.contains('open') && !wrap.contains(e.target)) closeAttachMenu();
    });

    window.homeAttachOpen = function () {
      closeAttachMenu();
      const i = document.getElementById('homeFileInput');
      if (i) i.click();
    };

    /* ── Shared fetch helper: downloads a URL and adds it to attachedFiles ── */
    async function fetchAndAttach(url, fileName) {
      showToast('Fetching file…', 'success');
      try {
        const resp = await fetch(url);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const contentType = resp.headers.get('content-type') || '';
        const isImage = contentType.startsWith('image/');
        const cap = isImage ? ATTACH_MAX_IMAGE : ATTACH_MAX_TEXT;
        if (isImage) {
          const blob = await resp.blob();
          if (blob.size > cap) { showToast('File is too large', 'error'); return; }
          const totalNow = attachedFiles.reduce(function (s, f) { return s + (f.size || 0); }, 0);
          if (totalNow + blob.size > ATTACH_MAX_TOTAL) { showToast(BatLang.t('toast.filesTooMany') || 'Attachments exceed the size limit.', 'error'); return; }
          const reader = new FileReader();
          reader.onload = function () {
            attachedFiles.push({ name: fileName, kind: 'image', content: reader.result, size: blob.size });
            renderAttachments();
            showToast('File attached!', 'success');
          };
          reader.readAsDataURL(blob);
        } else {
          const text = await resp.text();
          if (text.length > cap) { showToast('File is too large', 'error'); return; }
          const totalNow = attachedFiles.reduce(function (s, f) { return s + (f.size || 0); }, 0);
          if (totalNow + text.length > ATTACH_MAX_TOTAL) { showToast(BatLang.t('toast.filesTooMany') || 'Attachments exceed the size limit.', 'error'); return; }
          attachedFiles.push({ name: fileName, kind: 'text', content: text, size: text.length });
          renderAttachments();
          showToast('File attached!', 'success');
        }
      } catch (e) {
        showToast('Could not fetch the file. The server may block direct access (CORS).', 'error');
      }
    }

    /* ── Google Drive ──
       Accepts a shareable Drive link (drive.google.com/file/d/FILE_ID/view)
       or a direct export URL. Extracts the file ID and uses the /uc export
       endpoint to build a direct download link. */
    window.homeAttachDrive = function () {
      closeAttachMenu();
      var url = window.prompt(
        'Paste a Google Drive shareable link\n(e.g. https://drive.google.com/file/d/FILE_ID/view):',
        ''
      );
      if (!url || !url.trim()) return;
      url = url.trim();
      // Extract file ID from standard Drive share link
      var idMatch = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
      if (idMatch) {
        var fileId = idMatch[1];
        var directUrl = 'https://drive.google.com/uc?export=download&id=' + fileId;
        var guessedName = 'drive-file-' + fileId.slice(0, 8);
        fetchAndAttach(directUrl, guessedName);
      } else {
        // Fall back to fetching the URL as-is
        var name = url.split('/').pop().split('?')[0] || 'drive-file';
        fetchAndAttach(url, name);
      }
    };

    /* ═══════════════════════════════════════════════════════════════
       GitHub — Connect (PAT) + full file browser
       ═══════════════════════════════════════════════════════════════ */
    (function () {
      var GH_KEY = 'batlab_gh_token';
      function ghToken()      { try { return localStorage.getItem(GH_KEY) || ''; } catch(e) { return ''; } }
      function ghSave(t)      { try { localStorage.setItem(GH_KEY, t); } catch(e) {} }
      function ghClear()      { try { localStorage.removeItem(GH_KEY); } catch(e) {} }

      /* ── inject CSS once ── */
      function ensureStyles() {
        if (document.getElementById('_ghCSS')) return;
        var s = document.createElement('style'); s.id = '_ghCSS';
        s.textContent = [
          '#_ghM{position:fixed;inset:0;z-index:9600;background:rgba(0,0,0,0.85);',
            'display:flex;align-items:center;justify-content:center;padding:24px;',
            'animation:_ghFI .18s ease;}',
          '@keyframes _ghFI{from{opacity:0;transform:scale(.97)}to{opacity:1;transform:scale(1)}}',
          '#_ghM ._B{background:var(--card,#0f1420);border:1px solid var(--border,#1a2235);',
            'border-radius:16px;width:100%;max-width:540px;max-height:88vh;',
            'display:flex;flex-direction:column;overflow:hidden;',
            'box-shadow:0 32px 80px rgba(0,0,0,0.65);}',
          '#_ghM ._H{display:flex;align-items:center;gap:10px;padding:15px 18px;',
            'border-bottom:1px solid var(--border,#1a2235);flex-shrink:0;}',
          '#_ghM ._HI{font-size:1.15rem;flex-shrink:0;}',
          '#_ghM ._HT{font-size:0.93rem;font-weight:700;color:var(--text,#eef2f7);flex:1;}',
          '#_ghM ._CL{width:28px;height:28px;border-radius:7px;background:var(--surface2,#151b2b);',
            'border:1px solid var(--border,#1a2235);color:var(--text-muted,#8892a4);cursor:pointer;',
            'display:flex;align-items:center;justify-content:center;font-size:.8rem;',
            'transition:color .15s,background .15s;}',
          '#_ghM ._CL:hover{color:var(--text,#eef2f7);background:var(--surface,#0b0f1a);}',
          '#_ghM ._BD{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:14px;}',
          '#_ghM ._BD::-webkit-scrollbar{width:4px;}',
          '#_ghM ._BD::-webkit-scrollbar-thumb{background:var(--border,#1a2235);border-radius:4px;}',
          '#_ghM p._D{font-size:.84rem;color:var(--text-secondary,#c4cdd8);line-height:1.65;margin:0;}',
          '#_ghM ._LB{font-size:.7rem;font-weight:700;color:var(--text-muted,#8892a4);',
            'text-transform:uppercase;letter-spacing:1px;margin-bottom:5px;display:block;}',
          '#_ghM input._IN{width:100%;padding:10px 13px;background:var(--surface2,#151b2b);',
            'border:1px solid var(--border,#1a2235);border-radius:9px;',
            'color:var(--text,#eef2f7);font-family:var(--font-mono,monospace);font-size:.82rem;',
            'outline:none;transition:border-color .15s;box-sizing:border-box;}',
          '#_ghM input._IN:focus{border-color:rgba(0,232,154,.5);}',
          '#_ghM input._IN::placeholder{color:var(--text-muted,#8892a4);}',
          '#_ghM ._BT{display:inline-flex;align-items:center;justify-content:center;gap:7px;',
            'padding:10px 18px;border-radius:9px;cursor:pointer;border:none;',
            'font-family:var(--font-body,"Poppins",sans-serif);font-size:.875rem;font-weight:700;',
            'transition:opacity .15s,transform .1s;}',
          '#_ghM ._BT:hover:not(:disabled){opacity:.88;transform:translateY(-1px);}',
          '#_ghM ._BT:disabled{opacity:.45;cursor:default;}',
          '#_ghM ._BT.p{background:var(--accent,#00e89a);color:#060810;',
            'box-shadow:0 4px 18px var(--accent-glow,rgba(0,232,154,.2));}',
          '#_ghM ._BT.s{background:var(--surface2,#151b2b);color:var(--text-secondary,#c4cdd8);',
            'border:1px solid var(--border,#1a2235);}',
          '#_ghM ._BT.d{background:rgba(248,113,113,.1);color:var(--red,#f87171);',
            'border:1px solid rgba(248,113,113,.25);padding:5px 11px;font-size:.75rem;}',
          '#_ghM ._RW{display:flex;gap:8px;}',
          '#_ghM ._LK{font-size:.8rem;color:var(--accent,#00e89a);text-decoration:none;',
            'display:inline-flex;align-items:center;gap:5px;}',
          '#_ghM ._LK:hover{text-decoration:underline;}',
          '#_ghM ._ER{font-size:.8rem;color:var(--red,#f87171);background:rgba(248,113,113,.08);',
            'border:1px solid rgba(248,113,113,.2);border-radius:7px;padding:9px 13px;display:none;}',
          '#_ghM ._ER.on{display:block;}',
          '#_ghM ._CB{display:flex;align-items:center;gap:9px;padding:10px 13px;',
            'background:rgba(0,232,154,.07);border:1px solid rgba(0,232,154,.2);border-radius:9px;font-size:.82rem;}',
          '#_ghM ._CD{width:8px;height:8px;border-radius:50%;background:var(--accent,#00e89a);',
            'box-shadow:0 0 8px rgba(0,232,154,.35);flex-shrink:0;}',
          '#_ghM ._CU{font-weight:700;color:var(--text,#eef2f7);flex:1;}',
          '#_ghM ._BC{display:flex;align-items:center;gap:4px;flex-wrap:wrap;',
            'font-size:.78rem;color:var(--text-muted,#8892a4);}',
          '#_ghM ._BC ._BCL{cursor:pointer;color:var(--accent,#00e89a);}',
          '#_ghM ._BC ._BCL:hover{text-decoration:underline;}',
          '#_ghM ._BC .sp{cursor:default;}',
          '#_ghM ._LS{display:flex;flex-direction:column;gap:2px;}',
          '#_ghM ._IT{display:flex;align-items:center;gap:10px;padding:9px 11px;border-radius:8px;',
            'cursor:pointer;background:none;border:none;text-align:left;width:100%;',
            'color:var(--text-secondary,#c4cdd8);font-family:var(--font-body,"Poppins",sans-serif);',
            'font-size:.84rem;transition:background .12s,color .12s;}',
          '#_ghM ._IT:hover{background:var(--surface2,#151b2b);color:var(--text,#eef2f7);}',
          '#_ghM ._IC{font-size:.95rem;flex-shrink:0;width:20px;text-align:center;}',
          '#_ghM ._NM{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
          '#_ghM ._MT{font-size:.7rem;color:var(--text-muted,#8892a4);flex-shrink:0;}',
          '#_ghM ._SP{display:flex;align-items:center;justify-content:center;',
            'padding:32px;color:var(--text-muted,#8892a4);font-size:.84rem;gap:10px;}',
          '#_ghM ._SP svg{animation:spin .75s linear infinite;width:18px;height:18px;}',
          '#_ghM ._DV{height:1px;background:var(--border-soft,rgba(255,255,255,.06));}'
        ].join('');
        document.head.appendChild(s);
      }

      function removeModal() { var m = document.getElementById('_ghM'); if (m) m.remove(); }

      function makeModal(titleText, icon) {
        ensureStyles(); removeModal();
        var ov = document.createElement('div'); ov.id = '_ghM';
        ov.addEventListener('click', function(e){ if(e.target===ov) removeModal(); });
        var box = document.createElement('div'); box.className = '_B';
        var hd = document.createElement('div'); hd.className = '_H';
        var hi = document.createElement('span'); hi.className = '_HI'; hi.textContent = icon||'⚙️';
        var ht = document.createElement('span'); ht.className = '_HT'; ht.textContent = titleText;
        var cl = document.createElement('button'); cl.type='button'; cl.className='_CL'; cl.innerHTML='✕';
        cl.addEventListener('click', removeModal);
        hd.appendChild(hi); hd.appendChild(ht); hd.appendChild(cl);
        var bd = document.createElement('div'); bd.className = '_BD';
        box.appendChild(hd); box.appendChild(bd);
        ov.appendChild(box); document.body.appendChild(ov);
        function onKey(e){ if(e.key==='Escape'){ removeModal(); document.removeEventListener('keydown',onKey); } }
        document.addEventListener('keydown', onKey);
        return bd;
      }

      function spin(bd) {
        bd.innerHTML='';
        var s=document.createElement('div'); s.className='_SP';
        s.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-.08-8.49"/></svg> Loading…';
        bd.appendChild(s);
      }

      async function ghFetch(path, tok) {
        var r = await fetch('https://api.github.com'+path, {
          headers: { 'Authorization':'token '+tok, 'Accept':'application/vnd.github.v3+json' }
        });
        if (!r.ok) throw new Error('HTTP '+r.status);
        return r.json();
      }

      /* ── Connect modal ── */
      function showConnect() {
        var bd = makeModal('Connect GitHub', '🐙');

        var desc = document.createElement('p'); desc.className='_D';
        desc.textContent = 'Connect your GitHub account to browse and import files directly from your repositories.';

        var note = document.createElement('p'); note.className='_D';
        note.innerHTML = 'Create a <strong style="color:var(--text)">Personal Access Token (classic)</strong> with <code style="background:var(--surface2);padding:1px 6px;border-radius:4px;font-size:.77rem;">repo</code> scope.';

        var lkRow = document.createElement('div');
        var lk = document.createElement('a'); lk.className='_LK';
        lk.href='https://github.com/settings/tokens/new?scopes=repo&description=BatNXT+AI';
        lk.target='_blank'; lk.rel='noopener';
        lk.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg> Create token on GitHub →';
        lkRow.appendChild(lk);

        var fg = document.createElement('div');
        var lbl = document.createElement('span'); lbl.className='_LB'; lbl.textContent='Paste your token';
        var inp = document.createElement('input'); inp.type='password'; inp.className='_IN';
        inp.placeholder='ghp_xxxxxxxxxxxxxxxxxxxx'; inp.autocomplete='off';
        fg.appendChild(lbl); fg.appendChild(inp);

        var err = document.createElement('div'); err.className='_ER';

        var row = document.createElement('div'); row.className='_RW';
        var canBtn = document.createElement('button'); canBtn.type='button'; canBtn.className='_BT s'; canBtn.textContent='Cancel';
        canBtn.addEventListener('click', removeModal);
        var conBtn = document.createElement('button'); conBtn.type='button'; conBtn.className='_BT p'; conBtn.textContent='Connect GitHub';
        conBtn.style.flex='1';

        async function doConnect() {
          var tok = inp.value.trim();
          if (!tok) { err.classList.add('on'); err.textContent='Please paste your token first.'; return; }
          conBtn.disabled=true; conBtn.textContent='Verifying…'; err.classList.remove('on');
          try {
            var r = await fetch('https://api.github.com/user', {
              headers: { 'Authorization':'token '+tok, 'Accept':'application/vnd.github.v3+json' }
            });
            if (!r.ok) throw new Error('bad');
            var user = await r.json();
            ghSave(tok); removeModal(); showBrowser(tok, user);
          } catch(e) {
            err.classList.add('on'); err.textContent='Invalid token — make sure it has "repo" scope.';
            conBtn.disabled=false; conBtn.textContent='Connect GitHub';
          }
        }
        conBtn.addEventListener('click', doConnect);
        inp.addEventListener('keydown', function(e){ if(e.key==='Enter') doConnect(); });

        row.appendChild(canBtn); row.appendChild(conBtn);
        bd.appendChild(desc); bd.appendChild(note); bd.appendChild(lkRow);
        bd.appendChild(fg); bd.appendChild(err); bd.appendChild(row);
        setTimeout(function(){ inp.focus(); }, 80);
      }

      /* ── File browser ── */
      async function showBrowser(tok, userObj) {
        if (!userObj) {
          try {
            var r = await fetch('https://api.github.com/user', {
              headers: { 'Authorization':'token '+tok, 'Accept':'application/vnd.github.v3+json' }
            });
            if (!r.ok) { ghClear(); showConnect(); return; }
            userObj = await r.json();
          } catch(e) { ghClear(); showConnect(); return; }
        }

        var bd = makeModal('GitHub — Select a file', '📂');
        var state = { repo: null, branch: null, path: '' };

        function connectedBar() {
          var bar=document.createElement('div'); bar.className='_CB';
          var dot=document.createElement('div'); dot.className='_CD';
          var un=document.createElement('span'); un.className='_CU'; un.textContent='@'+userObj.login;
          var disc=document.createElement('button'); disc.type='button'; disc.className='_BT d'; disc.textContent='Disconnect';
          disc.addEventListener('click', function(){ ghClear(); removeModal(); showToast('GitHub disconnected','success'); });
          bar.appendChild(dot); bar.appendChild(un); bar.appendChild(disc);
          return bar;
        }

        function breadcrumb(user) {
          var bc=document.createElement('div'); bc.className='_BC';
          function sep(){ var s=document.createElement('span'); s.className='sp'; s.textContent=' / '; bc.appendChild(s); }
          var rl=document.createElement('span'); rl.className='_BCL'; rl.textContent='@'+user.login;
          rl.addEventListener('click', function(){ state.repo=null; state.branch=null; state.path=''; renderRepos(); });
          bc.appendChild(rl);
          if (state.repo) {
            sep();
            var rp=document.createElement('span'); rp.className='_BCL'; rp.textContent=state.repo.name;
            rp.addEventListener('click', function(){ state.branch=null; state.path=''; renderBranches(); });
            bc.appendChild(rp);
          }
          if (state.branch) {
            sep();
            var br=document.createElement('span'); br.className='sp'; br.style.color='var(--text-muted)'; br.textContent=state.branch;
            bc.appendChild(br);
            if (state.path) {
              state.path.split('/').filter(Boolean).forEach(function(part, idx, arr) {
                sep();
                var pl=document.createElement('span'); pl.className='_BCL'; pl.textContent=part;
                var cap=arr.slice(0,idx+1).join('/');
                pl.addEventListener('click', function(){ state.path=cap; renderTree(); });
                bc.appendChild(pl);
              });
            }
          }
          return bc;
        }

        function rebuild(extraNodes) {
          bd.innerHTML='';
          bd.appendChild(connectedBar());
          bd.appendChild(breadcrumb(userObj));
          if (extraNodes) extraNodes.forEach(function(n){ bd.appendChild(n); });
        }

        async function renderRepos() {
          rebuild(); spin(bd);
          try {
            var repos = await ghFetch('/user/repos?per_page=100&sort=pushed&affiliation=owner,collaborator', tok);
            rebuild();
            if (!repos.length) { var em=document.createElement('p'); em.className='_D'; em.textContent='No repositories found.'; bd.appendChild(em); return; }
            var ls=document.createElement('div'); ls.className='_LS';
            repos.forEach(function(repo) {
              var it=document.createElement('button'); it.type='button'; it.className='_IT';
              var ic=document.createElement('span'); ic.className='_IC'; ic.textContent=repo.private?'🔒':'📁';
              var nm=document.createElement('span'); nm.className='_NM'; nm.textContent=repo.full_name;
              var mt=document.createElement('span'); mt.className='_MT'; mt.textContent=repo.language||'';
              it.appendChild(ic); it.appendChild(nm); it.appendChild(mt);
              it.addEventListener('click', function(){ state.repo=repo; state.branch=null; state.path=''; renderBranches(); });
              ls.appendChild(it);
            });
            bd.appendChild(ls);
          } catch(e) { var er=document.createElement('div'); er.className='_ER on'; er.textContent='Failed to load repos. Check your token permissions.'; bd.appendChild(er); }
        }

        async function renderBranches() {
          rebuild(); spin(bd);
          try {
            var branches = await ghFetch('/repos/'+state.repo.full_name+'/branches?per_page=100', tok);
            rebuild();
            var ls=document.createElement('div'); ls.className='_LS';
            branches.forEach(function(b) {
              var it=document.createElement('button'); it.type='button'; it.className='_IT';
              var ic=document.createElement('span'); ic.className='_IC'; ic.textContent='🌿';
              var nm=document.createElement('span'); nm.className='_NM'; nm.textContent=b.name;
              it.appendChild(ic); it.appendChild(nm);
              it.addEventListener('click', function(){ state.branch=b.name; state.path=''; renderTree(); });
              ls.appendChild(it);
            });
            bd.appendChild(ls);
          } catch(e) { var er=document.createElement('div'); er.className='_ER on'; er.textContent='Failed to load branches.'; bd.appendChild(er); }
        }

        async function renderTree() {
          rebuild(); spin(bd);
          try {
            var url='/repos/'+state.repo.full_name+'/contents/'+state.path+'?ref='+state.branch;
            var items = await ghFetch(url, tok);
            rebuild();
            if (!Array.isArray(items)) { await attachFile(items); return; }
            items.sort(function(a,b){ return a.type===b.type ? a.name.localeCompare(b.name) : a.type==='dir'?-1:1; });
            var ls=document.createElement('div'); ls.className='_LS';
            items.forEach(function(item) {
              var isDir=item.type==='dir';
              var it=document.createElement('button'); it.type='button'; it.className='_IT';
              var ic=document.createElement('span'); ic.className='_IC'; ic.textContent=isDir?'📁':'📄';
              var nm=document.createElement('span'); nm.className='_NM'; nm.textContent=item.name;
              var mt=document.createElement('span'); mt.className='_MT';
              if (!isDir) mt.textContent=item.size>1024?Math.round(item.size/1024)+' KB':item.size+' B';
              it.appendChild(ic); it.appendChild(nm); it.appendChild(mt);
              it.addEventListener('click', function(){
                if (isDir){ state.path=item.path; renderTree(); }
                else attachFile(item);
              });
              ls.appendChild(it);
            });
            bd.appendChild(ls);
          } catch(e) {
            rebuild();
            var er=document.createElement('div'); er.className='_ER on'; er.textContent='Failed to load contents: '+e.message;
            bd.appendChild(er);
          }
        }

        async function attachFile(item) {
          removeModal();
          var rawUrl='https://raw.githubusercontent.com/'+state.repo.full_name+'/'+state.branch+'/'+item.path;
          await fetchAndAttach(rawUrl, item.name);
        }

        renderRepos();
      }

      /* ── Entry point ── */
      window.homeAttachGithub = function () {
        closeAttachMenu();
        var tok = ghToken();
        if (tok) { showBrowser(tok, null); } else { showConnect(); }
      };
    })();

    /* ── GitLab ──
       Accepts a GitLab file URL (gitlab.com/user/repo/-/blob/branch/path)
       and converts it to the raw (-/raw/) equivalent. */
    window.homeAttachGitlab = function () {
      closeAttachMenu();
      var url = window.prompt(
        'Paste a GitLab file URL\n(e.g. https://gitlab.com/user/repo/-/blob/main/file.js):',
        ''
      );
      if (!url || !url.trim()) return;
      url = url.trim();
      // Convert /-/blob/ → /-/raw/
      var rawUrl = url.replace('/-/blob/', '/-/raw/');
      // Handle plain /blob/ (older-style GitLab URLs)
      if (rawUrl === url) rawUrl = url.replace('/blob/', '/raw/');
      var name = url.split('/').pop().split('?')[0] || 'gitlab-file';
      fetchAndAttach(rawUrl, name);
    };

    /* ── Dropbox ──
       Accepts a Dropbox shareable link and converts it to a direct download
       by swapping dl=0 → dl=1 and optionally the domain for public links. */
    window.homeAttachDropbox = function () {
      closeAttachMenu();
      var url = window.prompt(
        'Paste a Dropbox shareable link\n(e.g. https://www.dropbox.com/s/xxx/file.txt?dl=0):',
        ''
      );
      if (!url || !url.trim()) return;
      url = url.trim();
      // Force direct download
      var directUrl = url
        .replace('?dl=0', '?dl=1')
        .replace('&dl=0', '&dl=1');
      // Add dl=1 if no dl param present
      if (!directUrl.includes('dl=1')) {
        directUrl += (directUrl.includes('?') ? '&' : '?') + 'dl=1';
      }
      var name = url.split('?')[0].split('/').pop() || 'dropbox-file';
      fetchAndAttach(directUrl, name);
    };

    /* ── OneDrive ──
       Accepts a OneDrive shareable link or a direct download URL.
       Personal share links (1drv.ms / onedrive.live.com) often require
       authentication, so the user is asked for a direct download URL when
       available. */
    window.homeAttachOnedrive = function () {
      closeAttachMenu();
      var url = window.prompt(
        'Paste a OneDrive direct download URL\n(From OneDrive share dialog → "Copy link" then use the download variant ending in &download=1 or similar):',
        ''
      );
      if (!url || !url.trim()) return;
      url = url.trim();
      // Attempt to add download flag if not present
      var directUrl = url;
      if (!directUrl.includes('download=1') && !directUrl.includes('&download=')) {
        directUrl += (directUrl.includes('?') ? '&' : '?') + 'download=1';
      }
      var name = url.split('?')[0].split('/').pop() || 'onedrive-file';
      fetchAndAttach(directUrl, name);
    };

    /* ── Import from URL ──
       Fetches any publicly accessible URL and attaches its content.
       Works best with CORS-permissive hosts (GitHub raw, public APIs, etc.). */
    window.homeAttachUrl = function () {
      closeAttachMenu();
      var url = window.prompt('Paste the URL of the file to import:', '');
      if (!url || !url.trim()) return;
      url = url.trim();
      // Basic URL validation
      if (!/^https?:\/\//i.test(url)) {
        showToast('Please enter a valid URL starting with http:// or https://', 'error');
        return;
      }
      var name = url.split('?')[0].split('/').pop() || 'imported-file';
      fetchAndAttach(url, name);
    };

    // Captures the user's own screen via the Screen Capture API and adds it
    // as an image attachment through the same pipeline as uploaded files.
    window.homeAttachScreenshot = async function () {
      closeAttachMenu();
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        showToast('Screen capture is not supported in this browser', 'error');
        return;
      }
      let stream;
      try {
        stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      } catch (err) {
        return; // user cancelled the picker
      }
      try {
        const video = document.createElement('video');
        video.srcObject = stream;
        await video.play();
        await new Promise(function (r) { requestAnimationFrame(r); });
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 1280;
        canvas.height = video.videoHeight || 720;
        canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/png');
        stream.getTracks().forEach(function (t) { t.stop(); });
        const approxSize = Math.round(dataUrl.length * 0.75); // base64 → bytes estimate
        if (approxSize > ATTACH_MAX_IMAGE) {
          showToast('Screenshot is too large', 'error');
          return;
        }
        const totalNow = attachedFiles.reduce(function (s, f) { return s + (f.size || 0); }, 0);
        if (totalNow + approxSize > ATTACH_MAX_TOTAL) {
          showToast(BatLang.t('toast.filesTooMany') || 'Attachments exceed the size limit.', 'error');
          return;
        }
        attachedFiles.push({ name: 'Screenshot ' + new Date().toLocaleTimeString() + '.png', kind: 'image', content: dataUrl, size: approxSize });
        renderAttachments();
      } catch (err) {
        stream.getTracks().forEach(function (t) { t.stop(); });
        showToast('Could not capture the screenshot', 'error');
      }
    };

    window.homeFilesSelected = function (ev) {
      const files = Array.from(ev.target.files || []);
      ev.target.value = ''; // allow re-selecting the same file later
      // Tracked locally (not just re-reading attachedFiles.length each time)
      // because FileReader is async: several images in the same selection
      // batch would otherwise all pass the cap check before any of them is
      // actually pushed to attachedFiles.
      let pendingImageCount = attachedFiles.filter(function (f) { return f.kind === 'image'; }).length;
      files.forEach(function (file) {
        const isImage = file.type.indexOf('image/') === 0;
        const cap = isImage ? ATTACH_MAX_IMAGE : ATTACH_MAX_TEXT;
        if (file.size > cap) {
          showToast((BatLang.t('toast.fileTooBig') || '{name} is too large').replace('{name}', file.name), 'error');
          return;
        }
        if (isImage) {
          if (pendingImageCount >= ATTACH_MAX_IMAGE_COUNT) {
            showToast(BatLang.t('toast.tooManyImages') || 'You can attach up to 10 images per message.', 'error');
            return;
          }
          pendingImageCount++;
        }
        const totalNow = attachedFiles.reduce(function (s, f) { return s + (f.size || 0); }, 0);
        if (totalNow + file.size > ATTACH_MAX_TOTAL) {
          showToast(BatLang.t('toast.filesTooMany') || 'Attachments exceed the size limit.', 'error');
          return;
        }
        const reader = new FileReader();
        reader.onload = function () {
          attachedFiles.push({ name: file.name, kind: isImage ? 'image' : 'text', content: reader.result, size: file.size });
          renderAttachments();
        };
        if (isImage) reader.readAsDataURL(file); else reader.readAsText(file);
      });
    };

    window.homeRemoveAttach = function (idx) {
      attachedFiles.splice(idx, 1);
      renderAttachments();
    };

    function renderAttachments() {
      const wrap = document.getElementById('homeAttachments');
      if (typeof renderCostPreview === 'function') renderCostPreview(); // keep the image-surcharge indicator in sync
      if (!wrap) return;
      if (!attachedFiles.length) { wrap.style.display = 'none'; wrap.innerHTML = ''; return; }
      wrap.style.display = 'flex';
      wrap.innerHTML = attachedFiles.map(function (f, i) {
        // Images: larger square tile, no filename (Phase 2.1 redesign).
        // Text/code files: unchanged small chip with filename.
        if (f.kind === 'image') {
          return '<span class="home-attach-img-tile" onclick="homePreviewAttach(' + i + ')" title="Click to preview">'
            + '<img src="' + f.content + '" alt="">'
            + '<button type="button" class="home-attach-remove" onclick="event.stopPropagation();homeRemoveAttach(' + i + ')" aria-label="Remove">✕</button></span>';
        }
        return '<span class="home-attach-chip" onclick="homePreviewAttach(' + i + ')" title="Click to preview" style="cursor:pointer;">'
          + '<span class="hac-ic">📄</span>'
          + '<span class="hac-name">' + escapeHtml(f.name) + '</span>'
          + '<button type="button" class="home-attach-remove" onclick="event.stopPropagation();homeRemoveAttach(' + i + ')" aria-label="Remove">✕</button></span>';
      }).join('');
    }

    /* ── Attachment preview lightbox ── */
    window.homePreviewAttach = function (idx) {
      const f = attachedFiles[idx];
      if (!f) return;

      // Inject styles once
      if (!document.getElementById('_apStyle')) {
        const s = document.createElement('style');
        s.id = '_apStyle';
        s.textContent = [
          '#_apOverlay{position:fixed;inset:0;z-index:9500;background:rgba(0,0,0,0.88);',
          'display:flex;align-items:center;justify-content:center;padding:24px;cursor:zoom-out;',
          'animation:_apFadeIn .18s ease;}',
          '@keyframes _apFadeIn{from{opacity:0}to{opacity:1}}',
          '#_apOverlay ._apBox{position:relative;max-width:min(860px,92vw);',
          'background:var(--card,#0f1420);border:1px solid var(--border,#1a2235);',
          'border-radius:16px;overflow:hidden;box-shadow:0 32px 80px rgba(0,0,0,0.65);',
          'cursor:default;display:flex;flex-direction:column;max-height:88vh;}',
          '#_apOverlay ._apHead{display:flex;align-items:center;gap:10px;',
          'padding:12px 16px;border-bottom:1px solid var(--border,#1a2235);flex-shrink:0;}',
          '#_apOverlay ._apKindIc{font-size:1.1rem;line-height:1;flex-shrink:0;}',
          '#_apOverlay ._apName{font-size:0.85rem;font-weight:600;',
          'color:var(--text,#eef2f7);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;}',
          '#_apOverlay ._apClose{width:28px;height:28px;border-radius:7px;',
          'background:var(--surface2,#0f1420);border:1px solid var(--border,#1a2235);',
          'color:var(--text-muted,#8892a4);cursor:pointer;flex-shrink:0;',
          'display:flex;align-items:center;justify-content:center;font-size:0.8rem;',
          'transition:color .15s,background .15s;}',
          '#_apOverlay ._apClose:hover{color:var(--text,#eef2f7);background:var(--surface,#0b0f1a);}',
          '#_apOverlay ._apBody{overflow:auto;flex:1;display:flex;align-items:center;justify-content:center;}',
          '#_apOverlay ._apImg{display:block;max-width:100%;max-height:calc(88vh - 54px);',
          'object-fit:contain;}',
          '#_apOverlay ._apPre{font-family:var(--font-mono,monospace);font-size:0.78rem;',
          'color:var(--text-secondary,#c4cdd8);line-height:1.65;padding:20px 22px;',
          'white-space:pre-wrap;word-break:break-word;margin:0;width:100%;box-sizing:border-box;',
          'min-width:min(600px,80vw);}'
        ].join('');
        document.head.appendChild(s);
      }

      // Remove any existing overlay
      const old = document.getElementById('_apOverlay');
      if (old) old.remove();

      const overlay = document.createElement('div');
      overlay.id = '_apOverlay';
      overlay.addEventListener('click', function (e) { if (e.target === overlay) overlay.remove(); });

      const box = document.createElement('div');
      box.className = '_apBox';

      // Header
      const head = document.createElement('div');
      head.className = '_apHead';
      const ic = document.createElement('span');
      ic.className = '_apKindIc';
      ic.textContent = f.kind === 'image' ? '🖼' : '📄';
      const nameEl = document.createElement('span');
      nameEl.className = '_apName';
      nameEl.textContent = f.name;
      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = '_apClose';
      closeBtn.innerHTML = '✕';
      closeBtn.addEventListener('click', function () { overlay.remove(); });
      head.appendChild(ic);
      head.appendChild(nameEl);
      head.appendChild(closeBtn);

      // Body
      const body = document.createElement('div');
      body.className = '_apBody';
      if (f.kind === 'image') {
        const img = document.createElement('img');
        img.className = '_apImg';
        img.src = f.content;
        img.alt = f.name;
        body.appendChild(img);
      } else {
        const pre = document.createElement('pre');
        pre.className = '_apPre';
        pre.textContent = f.content;
        body.appendChild(pre);
      }

      box.appendChild(head);
      box.appendChild(body);
      overlay.appendChild(box);
      document.body.appendChild(overlay);

      // Close on Escape
      function onKey(e) {
        if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', onKey); }
      }
      document.addEventListener('keydown', onKey);
    };

    function buildAttachContext() {
      if (!attachedFiles.length) return '';
      let out = '\n\n=== ATTACHED FILES (provided by the user — use them as context and assets) ===\n';
      attachedFiles.forEach(function (f) {
        if (f.kind === 'image') {
          out += '\n[Image "' + f.name + '"] Embed this image where appropriate by using the following data URL as the src of an <img> tag or as a CSS background-image:\n' + f.content + '\n';
        } else {
          out += '\n[File "' + f.name + '"]\n' + f.content + '\n';
        }
      });
      out += '\n=== END ATTACHED FILES ===\n';
      return out;
    }

    // Hard cap on baseHTML (the current site being edited) sent to the
    // generator, mirrored from the same check in worker/websitegenerator.js
    // and worker/gateway.js. ~75% of the 16,000-token output ceiling
    // (chars/4 heuristic), leaving headroom for the model to actually finish
    // rewriting the file.
    const BASE_HTML_CHAR_CAP = 48000;

    /**
     * Post-generation sanity check, mirrored from worker/gateway.js's
     * isValidWebsiteOutput (duplicated per this codebase's no-shared-module
     * pattern). Catches the "coherent-looking success, garbage content"
     * failure mode that a bare `!html` check misses entirely. Applied to all
     * generation types (website/game/tool/mobile) since this is shared code.
     */
    function isValidGenerationOutput(html) {
      if (!html || html.length < 20) return { valid: false, reason: 'empty_or_too_short' };

      const head = html.slice(0, 500).toLowerCase();
      if (!/<!doctype|<html|<body/.test(head)) {
        return { valid: false, reason: 'no_html_structure_near_start' };
      }

      const tagChars = (html.match(/[<>]/g) || []).length;
      if (tagChars < html.length / 300) {
        return { valid: false, reason: 'low_tag_density' };
      }

      // The prompt's `latinRule` always forbids non-Latin scripts, so any
      // significant presence of these ranges in real output is a reliable
      // failure signal, not a false-positive risk.
      const nonLatinMatches = html.match(/[\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF\u0400-\u04FF\u0600-\u06FF\u0750-\u077F]/g) || [];
      if (nonLatinMatches.length > 30 && nonLatinMatches.length / html.length > 0.003) {
        return { valid: false, reason: 'unexpected_language_mixing' };
      }

      return { valid: true, reason: 'ok' };
    }

    let lastAttempt = null;
    async function runGeneration(prompt, type, subtype, opts) {
      opts = opts || {};
      lastAttempt = { prompt, type, subtype, opts };
      // Fire immediately so it races the /generate call below — by the time
      // the build widget is actually created (after /generate's headers
      // resolve), this is usually already settled. Bounded so a slow/failed
      // call never delays the widget's appearance (see BUILD_STEPS_TIMEOUT_MS).
      const buildStepsPromise = withTimeout(fetchBuildSteps(prompt, type), BUILD_STEPS_TIMEOUT_MS);
      hideHwFailed();
      if (!_genInChatMode) showHwLoading();
      const regenBtn = document.getElementById('hwRegenBtn');
      const dlBtn = document.getElementById('hwDownloadBtn');
      const shareBtn = document.getElementById('hwShareBtn');
      if (regenBtn) regenBtn.disabled = true;
      if (dlBtn) dlBtn.disabled = true;
      if (shareBtn) shareBtn.disabled = true;
      let buildWidget = null;
      let wsProgress = null;
      let usedTemplatePipeline = false;
      try {
        let html = '';

        // ── Fast path: Planner + Template Engine. Only for brand-new
        // website/game generations (never edits) — silently falls through to
        // the unmodified single-shot pipeline below on any failure/no-match.
        const canUseTemplates = !opts.baseHTML && (type === 'website' || type === 'game');
        if (canUseTemplates) {
          if (_genInChatMode) buildWidget = hcmCreateBuildWidget({ mode: 'template', labels: TEMPLATE_STAGE_LABELS });
          try {
            html = await tryTemplatePipeline(prompt, type, subtype, { onStage: buildWidget ? buildWidget.setStage : null });
          } catch (e) {
            html = '';
          }
          // Basic sanity check on template output too — treat a structurally
          // broken result the same as "no template match" instead of showing it.
          if (html && !isValidGenerationOutput(html).valid) html = '';
          usedTemplatePipeline = !!html;
          if (!usedTemplatePipeline && buildWidget) { buildWidget.remove(); buildWidget = null; }
        }

        if (!usedTemplatePipeline) {
        const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
        // Hard rule appended to every prompt to eliminate stray Cyrillic / non-Latin output
        const latinRule = `\n\nSTRICT OUTPUT RULE: Use ONLY Latin/English characters in every piece of visible text, label, placeholder, comment, and string inside the HTML. NEVER output Cyrillic (е, и, а, о…), Arabic, Chinese, or any non-Latin script — not even a single character. All UI copy must be in English with Latin characters only.`;
        const prefix = subtype
          ? `Type: ${cap(type)} , Style: ${cap(subtype)}\n\n`
          : `Type: ${cap(type)}\n\n`;

        // Reject an oversized edit before spending a network round-trip or a
        // credit reservation on a request the model can't realistically
        // finish rewriting within its fixed output budget (mirrors the
        // server-side caps in websitegenerator.js and gateway.js).
        if (opts.baseHTML && opts.baseHTML.length > BASE_HTML_CHAR_CAP) {
          throw new Error('base_html_too_large');
        }

        let fullPrompt;
        let baseHTMLField;
        if (opts.baseHTML) {
          // Sent as its own field (see requestBody below) for all four
          // types so each upstream worker can use an edit-aware system
          // prompt instead of nesting the whole file inside a "build new
          // from description" framing — the root cause of the
          // garbage-output-on-edit bug (originally fixed for website only,
          // now applied uniformly to game/tool/mobile as well).
          baseHTMLField = opts.baseHTML;
          fullPrompt = prefix
            + buildConvRecap(true)
            + `\nChange to apply: ${prompt}` + latinRule;
        } else {
          fullPrompt = prefix + prompt + latinRule;
        }
        if (opts.attachContext) fullPrompt += opts.attachContext;
        if (seoEnabled && type === 'website') {
          fullPrompt += `\n\nSEO REQUIREMENTS: Include a <title> tag with a concise descriptive page title, a <meta name="description"> with a compelling 150-160 character summary, Open Graph tags (og:title, og:description, og:type), a <meta name="viewport"> tag, semantic HTML5 elements (header, nav, main, section, footer), exactly one <h1>, descriptive alt attributes on every <img>, and a <link rel="canonical"> pointing to the page's own relative path. Keep all SEO tags inside <head>.`;
        }

        const requestBody = { prompt: fullPrompt, type, service: type };
        if (baseHTMLField) requestBody.baseHTML = baseHTMLField;

        // One automatic retry if the generated output fails a basic
        // structural/language sanity check — silent on success (no visible
        // sign a retry happened). If both attempts fail, the loop exits with
        // validation.valid === false and the outer code throws below, so
        // lastHTML is never overwritten with garbage (see catch block for
        // the old-result-restoring + explicit-failure-message handling).
        const MAX_ATTEMPTS = 2;
        let validation = { valid: false, reason: 'not_attempted' };
        let isStreamed = false;
        for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
          html = '';
          const { res } = await gatewayFetch('/generate', requestBody);

          // The website worker now streams raw HTML back as plain text so the
          // build can be shown progressively; other worker types still return
          // a single { html } JSON blob. Branch on the response's actual
          // Content-Type rather than assuming based on `type`.
          isStreamed = (res.headers.get('Content-Type') || '').includes('text/plain');

          if (attempt === 1) {
            // In chat mode, show a live build widget (progress bar + detected
            // "Building navigation / sections / footer…" steps) so the user sees
            // the site being built instead of a silent wait.
            if (_genInChatMode) buildWidget = hcmCreateBuildWidget({ aiSteps: await buildStepsPromise });
            // Workspace surface: for streamed website builds, show real live progress
            // (checklist card + top bar + skeleton) in place of the scripted terminal.
            else if (isStreamed) wsProgress = createWorkspaceBuildProgress(await buildStepsPromise);
          }

          if (isStreamed) {
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let lastRender = 0;
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              html += decoder.decode(value, { stream: true });
              const now = Date.now();
              if (_genInChatMode) {
                if (buildWidget && now - lastRender > 120) { buildWidget.update(html); lastRender = now; }
              } else if (now - lastRender > 80) {
                showWorkspaceResult(html, type);
                if (wsProgress) wsProgress.update(html);
                lastRender = now;
              }
            }
            html += decoder.decode();
            if (buildWidget) buildWidget.update(html);
            if (wsProgress) wsProgress.update(html);
          } else {
            const data = await res.json();
            html = data.html || data.result || '';
          }

          validation = html ? isValidGenerationOutput(html) : { valid: false, reason: 'empty' };
          if (validation.valid || attempt === MAX_ATTEMPTS) break;

          // Invalid on attempt 1: silently clear whatever partial/garbage
          // content just got progressively rendered, then retry once, with
          // the same continuous "Building…" UI (no visible interruption).
          if (!_genInChatMode) {
            const iframe = document.getElementById('hwPreviewIframe');
            const mobileIframe = document.getElementById('hwPreviewIframeMobile');
            if (type === 'mobile') { if (mobileIframe) mobileIframe.srcdoc = ''; }
            else if (iframe) iframe.srcdoc = '';
            const codeView = document.getElementById('hwCodeView');
            if (codeView) codeView.textContent = '';
          } else if (buildWidget && buildWidget.resetPreview) {
            buildWidget.resetPreview();
          }
        }

        if (!validation.valid) throw new Error('generation_invalid');
        if (buildWidget) buildWidget.setDone();
        if (wsProgress) wsProgress.setDone();

        // The build may finish generating faster than the loading animation
        // plays out — wait for it so the user always sees the full
        // "reading → building → finishing touches → almost done" sequence
        // instead of an instant flash to the result. Not needed for the
        // streamed path since real progress is already being shown live.
        if (!_genInChatMode && !isStreamed) await hwLoadingMinDurationWait();
        } // end if (!usedTemplatePipeline)

        if (!html) throw new Error('empty');
        if (usedTemplatePipeline && buildWidget) buildWidget.setDone();

        lastPrompt = prompt; lastType = type; lastSubtype = subtype; lastHTML = html;
        if (!_genInChatMode) showWorkspaceResult(html, type);
        removeHwThinking();
        appendHwAiMessage(type, !!opts.baseHTML);
      } catch (err) {
        if (!_genInChatMode) hideHwLoading();
        if (buildWidget) buildWidget.remove();
        if (wsProgress) wsProgress.remove();
        removeHwThinking();
        const isNoCredits = err && err.message === 'no_credits';
        const isRateLimited = err && err.message === 'rate_limited';
        const isTooLarge = err && err.message === 'base_html_too_large';
        const isInvalidOutput = err && err.message === 'generation_invalid';
        // gatewayFetch already surfaced the out-of-credits screen / rate-limit
        // toast for these two cases — avoid double-showing UI here.
        if (!isNoCredits && !isRateLimited && !isTooLarge) {
          showToast(BatLang.t('toast.fail'), 'error');
        } else if (isTooLarge) {
          showToast(BatLang.t('hw.editTooLarge') || 'This site is too large to edit as a whole — try a smaller, more targeted change.', 'error');
        }
        // A validation failure after the automatic retry must always tell the
        // user explicitly — never silently keep quiet just because an old
        // result exists. If there WAS a previous valid site, restore it to
        // the visible preview first, since garbage must never stay shown and
        // the old site must remain authoritative over it.
        if (isInvalidOutput && lastHTML && !_genInChatMode) {
          showWorkspaceResult(lastHTML, lastType);
        }
        // If there's no previous result to fall back to, the panel would
        // otherwise be left blank/frozen — show a clear failed state + retry.
        if (!lastHTML || isInvalidOutput) {
          if (!_genInChatMode) {
            showHwFailed(isNoCredits ? BatLang.t('hw.genFailedCredits') : BatLang.t('hw.genFailed'));
          } else {
            hcmAppend('assistant', BatLang.t(isNoCredits ? 'hw.genFailedCredits' : 'hw.genFailed') || BatLang.t('toast.fail'));
          }
        }
      } finally {
        if (regenBtn) regenBtn.disabled = false;
        if (dlBtn) dlBtn.disabled = false;
        // Enable share only when there's something to share
        if (shareBtn) shareBtn.disabled = !lastHTML;
      }
    }
    // Expose so feature-pack wrappers (Alfred, Versions, Analytics) can intercept it
    window.runGeneration = runGeneration;

    window.hwRetryGeneration = function () {
      if (!lastAttempt) return;
      runGeneration(lastAttempt.prompt, lastAttempt.type, lastAttempt.subtype, lastAttempt.opts);
    };

    // Home composer send → generate inline (validate, credits, save, run)
    /* ── Home inline chat state (vars declared early at top — only reset here) ── */
    homeConvHistory = [];
    homeConvActive = false;
    homeConvSessionId = null;

    /* Home chat sessions persist to Supabase (chat_sessions table, keyed by id/user_id),
       separate from Prompt Chat's chatSessions/batlab_chat_sessions (localStorage),
       so the two Histories never mix */
    homeChatSessions = [];

    /* Sidebar list only needs id/title/updatedAt — NOT the (potentially large)
       messages column — so the page load only pulls lightweight metadata for
       every session instead of every message of every conversation. The full
       `messages` array for a given session is fetched on demand (see
       loadHomeChatSession below) the moment the user actually opens it, and
       cached on the session object afterwards so reopening it is instant. */
    async function loadHomeChatSessions() {
      if (!currentUser) return;
      try {
        const { data, error } = await supabase.from('chat_sessions')
          .select('id, title, updated_at, is_pinned, is_read')
          .eq('user_id', currentUser.id)
          .order('updated_at', { ascending: false })
          .limit(20);
        if (error) throw error;
        homeChatSessions = (data || []).map(d => ({
          id: d.id,
          title: d.title,
          messages: null, // not loaded yet — fetched lazily on open
          updatedAt: d.updated_at ? new Date(d.updated_at).getTime() : Date.now(),
          isPinned: !!d.is_pinned,
          isRead: d.is_read !== false
        }));
        BatCache.set(BATNXT_CACHE_HOME_CHATS, homeChatSessions);
      } catch(e) {
        console.error('Failed to load home chat sessions:', e);
        homeChatSessions = [];
      }
      renderHomeChatHistory();
    }
    /* Fetches (and caches on the session object) the full messages array for
       one conversation. No-op if already loaded. Used to lazily hydrate a
       session the moment it's opened, instead of upfront for all of them. */
    async function ensureHomeChatMessagesLoaded(session) {
      if (!session || session.messages) return session;
      try {
        const { data, error } = await supabase.from('chat_sessions')
          .select('messages')
          .eq('id', session.id)
          .single();
        if (error) throw error;
        session.messages = (data && data.messages) || [];
      } catch (e) {
        console.error('Failed to load conversation messages:', e);
        session.messages = [];
      }
      return session;
    }

    /* ── Per-conversation code (XXX-XXX-XXX) ──────────────────────────
       Every home chat conversation gets its own random 9-digit code the
       moment it's created, and the page URL becomes batnxt.com/XXX-XXX-XXX
       whenever that conversation is open (batnxt.com alone = new chat).
       Stored locally (works regardless of backend schema) and mirrored
       best-effort onto the Supabase row. */
    function getChatCodeMap() {
      try { return JSON.parse(localStorage.getItem('batnxt_chat_codes') || '{}'); } catch(e) { return {}; }
    }
    function saveChatCodeMap(map) {
      try { localStorage.setItem('batnxt_chat_codes', JSON.stringify(map)); } catch(e) {}
    }
    function generateChatCodeString() {
      var part = function () { return String(Math.floor(100 + Math.random() * 900)); };
      return part() + '-' + part() + '-' + part();
    }
    /* Returns the existing code for a session, or mints + saves a new one
       (used both for brand-new chats and to retro-fill old ones that
       don't have a code yet). */
    function getOrCreateChatCode(sessionId) {
      if (!sessionId) return null;
      var map = getChatCodeMap();
      if (!map.bySession) map.bySession = {};
      if (!map.byCode) map.byCode = {};
      if (map.bySession[sessionId]) return map.bySession[sessionId];
      var code;
      do { code = generateChatCodeString(); } while (map.byCode[code]);
      map.bySession[sessionId] = code;
      map.byCode[code] = sessionId;
      saveChatCodeMap(map);
      // Best-effort mirror to Supabase — harmless no-op if the column
      // doesn't exist on the chat_sessions table.
      try { if (currentUser) supabase.from('chat_sessions').update({ code: code }).eq('id', sessionId); } catch(e) {}
      return code;
    }
    /* Looks up a session id for a chat code, first locally (localStorage
       map — instant, works offline) then, if not found, via Supabase
       (keyed by the `code` column + current user) so permalinks also
       resolve on a fresh device/incognito window. The Supabase branch is a
       harmless no-op (returns null) until the `code` column exists on
       chat_sessions — see db/schema_conversation_sharing.sql. */
    async function getSessionIdForChatCode(code) {
      var map = getChatCodeMap();
      var local = (map.byCode && map.byCode[code]) || null;
      if (local) return local;
      if (!currentUser) return null;
      try {
        var res = await supabase.from('chat_sessions')
          .select('id')
          .eq('code', code)
          .eq('user_id', currentUser.id)
          .maybeSingle();
        if (res.error || !res.data) return null;
        return res.data.id;
      } catch (e) { return null; }
    }
    /* Updates the visible URL without reloading the page.
       code === null/undefined → back to the plain domain root (new chat). */
    function setChatUrlCode(code) {
      try {
        var path = code ? ('/c/' + code) : '/';
        if (location.pathname !== path) {
          history.pushState({ chatCode: code || null }, '', path);
        }
      } catch(e) {}
    }
    var CHAT_CODE_RE = /^\/c\/(\d{3}-\d{3}-\d{3})$/;
    /* Resolves a chat code to a session (local map, then Supabase) and
       opens it. If the session isn't already in the loaded homeChatSessions
       list (e.g. it's older than the most-recent-20 cap, or this is a
       fresh device), fetches that one session directly so it can render. */
    async function resolveAndOpenChatCode(code) {
      var sessionId = await getSessionIdForChatCode(code);
      if (!sessionId) return false;
      if (!homeChatSessions.some(function (s) { return s.id === sessionId; })) {
        try {
          var res = await supabase.from('chat_sessions').select('*').eq('id', sessionId).single();
          if (res.error || !res.data) return false;
          var d = res.data;
          homeChatSessions.unshift({
            id: d.id,
            title: d.title,
            messages: d.messages || [],
            updatedAt: d.updated_at ? new Date(d.updated_at).getTime() : Date.now(),
            isPinned: !!d.is_pinned,
            isRead: d.is_read !== false
          });
        } catch (e) { return false; }
      }
      if (!homeChatSessions.some(function (s) { return s.id === sessionId; })) return false;
      window.loadHomeChatSession(sessionId);
      return true;
    }
    /* Checks the current URL for a chat code and, if the matching
       conversation can be resolved, opens it. Called once after the
       user's sessions are loaded. */
    function openChatFromUrlIfPresent() {
      var m = CHAT_CODE_RE.exec(location.pathname);
      if (!m) return false;
      return resolveAndOpenChatCode(m[1]);
    }
    window.addEventListener('popstate', function (e) {
      var m = CHAT_CODE_RE.exec(location.pathname);
      if (m) {
        resolveAndOpenChatCode(m[1]);
        return;
      }
      if (location.pathname === '/' && typeof window.startNewHomeChat === 'function') {
        window.startNewHomeChat();
      }
    });

    /* Save the current home chat to the homeChatSessions list so it
       appears under its own History in the sidebar */
    async function saveHomeConvSession() {
      if (!homeConvSessionId || homeConvHistory.length === 0 || !currentUser) return;
      const idx = homeChatSessions.findIndex(s => s.id === homeConvSessionId);
      // Preserve an already-set title (the async AI-generated name, or a manual
      // rename) instead of clobbering it back to the truncated first message on
      // every save. Only fall back to the first-message truncation when the
      // session has no title yet (the very first save).
      const existingTitle = idx >= 0 ? homeChatSessions[idx].title : null;
      const title = existingTitle
                    || homeConvHistory.find(m => m.role === 'user')?.content?.slice(0, 38)
                    || BatLang.t('chat.newTitle') || 'Home Chat';
      const session = { id: homeConvSessionId, title, messages: homeConvHistory, updatedAt: Date.now(),
        isPinned: idx >= 0 ? homeChatSessions[idx].isPinned : false, isRead: true };
      if (idx >= 0) homeChatSessions[idx] = session;
      else homeChatSessions.unshift(session);
      homeChatSessions = homeChatSessions.slice(0, 20);
      renderHomeChatHistory();
      try {
        await supabase.from('chat_sessions').upsert({
          id: homeConvSessionId,
          user_id: currentUser.id,
          title,
          messages: homeConvHistory,
          updated_at: new Date().toISOString(),
          is_read: true
        });
      } catch(e) {
        console.error('Failed to save home chat session:', e);
      }
    }

    /* Save the current Marketing conversation to the marketing_analyses table
       (mirrors saveHomeConvSession() above) — every completed turn is saved,
       not just structured/website ones, so Marketing gets full History like
       Home chat. Optional structured fields (scores/competition/growth/etc.)
       are simply null on idea-only turns. */
    let marketingAnalysisId = null;      // lazily created on first save (mirrors homeConvSessionId)
    let marketingAnalysisTitle = null;   // sticky once set — never clobbered by later saves

    function marketingDomainFromUrl(u) {
      try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return null; }
    }

    async function saveMarketingAnalysis(meta) {
      if (!marketingHistory.length || !currentUser) return;
      const isNewAnalysis = !marketingAnalysisId;
      marketingAnalysisId = marketingAnalysisId || ('mkt_' + Date.now());
      meta = meta || {};
      const firstUserMsg = marketingHistory.find(function (m) { return m.role === 'user'; });
      const firstUserText = firstUserMsg && (firstUserMsg.displayCaption != null ? firstUserMsg.displayCaption : firstUserMsg.content);
      const title = marketingAnalysisTitle
                    || meta.title
                    || (firstUserText ? firstUserText.slice(0, 60) : null)
                    || (BatLang.t('marketing.newTitle') || 'Marketing Analysis');
      marketingAnalysisTitle = title;
      const payload = {
        id: marketingAnalysisId,
        user_id: currentUser.id,
        title: title,
        messages: marketingHistory,
        updated_at: new Date().toISOString()
      };
      /* source_url/domain and the structured fields below are only ever
         produced by SOME turns (a URL/HTML/CSS turn produces them, a
         prose-only or "Go deeper" follow-up doesn't) — omit them entirely
         rather than sending null, so Postgres's upsert ON CONFLICT DO UPDATE
         leaves a previously-saved good value untouched instead of clobbering
         it with null on a later, non-qualifying turn. */
      if (meta.sourceUrl) payload.source_url = meta.sourceUrl;
      if (meta.domain) payload.domain = meta.domain;
      if (meta.scores) payload.scores = meta.scores;
      if (meta.competition) payload.competition = meta.competition;
      if (meta.growthPotential) payload.growth_potential = meta.growthPotential;
      if (meta.category) payload.category = meta.category;
      if (meta.tags) payload.tags = meta.tags;
      try {
        await supabase.from('marketing_analyses').upsert(payload);
        if (typeof mktRecentStripLoad === 'function') mktRecentStripLoad(); // refresh recent-analyses order/contents
        if (isNewAnalysis && typeof mktHistoryCountBump === 'function') mktHistoryCountBump(); // optimistic +1, no re-fetch
      } catch (e) {
        console.error('Failed to save marketing analysis:', e);
      }
    }

    /* Reset the Marketing tool back to a blank analysis — mirrors
       startNewHomeChat(). Also used by the "+ New analysis" button and by
       the History panel's card-open flow (mktHistoryOpen) before loading a
       saved thread; guarantees a genuinely separate analysis (e.g.
       batnxt.com then nike.com) in the same tab gets its own row instead of
       merging into the previous one. */
    window.startNewMarketingAnalysis = function() {
      marketingHistory = [];
      marketingAnalysisId = null;
      marketingAnalysisTitle = null;
      marketingAttachedFiles = [];
      marketingRenderAttachedFileChips();
      const messages = document.getElementById('marketingMessages');
      if (messages) messages.innerHTML = '';
      const input = document.getElementById('marketingInput');
      if (input) input.value = '';
      const urlInput = document.getElementById('marketingUrlInput');
      if (urlInput) urlInput.value = '';
      marketingRenderEmptyState();
    };

    /* ── Empty-state quick-start cards ──
       Shown only when #marketingMessages has no messages yet (fresh "New
       Analysis" state). Unlike .clarify-opt (auto-send) and .mkt-chip
       (pre-fill + auto-send), clicking a card only pre-fills #marketingInput
       and focuses it, letting the user edit before sending. Cleared the
       instant the first message is sent (see sendMarketingMessage). */
    const MARKETING_STARTERS = [
      { emoji: '🚀', labelKey: 'marketing.starterLaunchLabel', labelFallback: 'Launch Strategy', promptKey: 'marketing.starterLaunchPrompt', promptFallback: 'Help me create a launch strategy for my product or service, including target audience, positioning, and the best channels to use.', descKey: 'marketing.starterLaunchDesc', descFallback: 'Plan a go-to-market roadmap for a new product or feature', placeholderKey: 'marketing.starterLaunchPlaceholder', placeholderFallback: "Describe the product or feature you're launching..." },
      { emoji: '📈', labelKey: 'marketing.starterSeoLabel', labelFallback: 'SEO Audit', promptKey: 'marketing.starterSeoPrompt', promptFallback: "Analyze my website's SEO and give me a prioritized list of improvements to increase organic traffic.", descKey: 'marketing.starterSeoDesc', descFallback: 'Get a technical and content SEO review with prioritized fixes', placeholderKey: 'marketing.starterSeoPlaceholder', placeholderFallback: 'Paste your site URL or describe what to audit...' },
      { emoji: '💰', labelKey: 'marketing.starterPricingLabel', labelFallback: 'Pricing Strategy', promptKey: 'marketing.starterPricingPrompt', promptFallback: 'Help me design a pricing strategy for my product, including pricing tiers and psychological pricing tactics.', descKey: 'marketing.starterPricingDesc', descFallback: 'Explore pricing models and positioning for your offer', placeholderKey: 'marketing.starterPricingPlaceholder', placeholderFallback: 'Describe your product and current pricing (if any)...' },
      { emoji: '🎯', labelKey: 'marketing.starterCompetitorLabel', labelFallback: 'Competitor Analysis', promptKey: 'marketing.starterCompetitorPrompt', promptFallback: 'Analyze my top competitors and identify gaps and opportunities I can use to differentiate my business.', descKey: 'marketing.starterCompetitorDesc', descFallback: 'See how you stack up against similar products', placeholderKey: 'marketing.starterCompetitorPlaceholder', placeholderFallback: 'Name the competitors or paste their URLs...' },
      { emoji: '📢', labelKey: 'marketing.starterPlanLabel', labelFallback: 'Marketing Plan', promptKey: 'marketing.starterPlanPrompt', promptFallback: 'Create a comprehensive marketing plan for my business for the next quarter.', descKey: 'marketing.starterPlanDesc', descFallback: 'Build a full-funnel plan across channels and stages', placeholderKey: 'marketing.starterPlanPlaceholder', placeholderFallback: 'Describe your business and target audience...' },
      { emoji: '📊', labelKey: 'marketing.starterSocialLabel', labelFallback: 'Social Media Calendar', promptKey: 'marketing.starterSocialPrompt', promptFallback: 'Build me a one-month social media content calendar with post ideas and posting cadence.', descKey: 'marketing.starterSocialDesc', descFallback: 'Get a ready-to-use posting schedule and content ideas', placeholderKey: 'marketing.starterSocialPlaceholder', placeholderFallback: 'Describe your brand and posting goals...' }
    ];

    function mktBuildStarterCard(i) {
      const s = MARKETING_STARTERS[i];
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'mkt-starter-card';
      const label = (typeof BatLang !== 'undefined' && BatLang.t(s.labelKey)) || s.labelFallback;
      const emojiSpan = document.createElement('span');
      emojiSpan.className = 'mkt-starter-emoji';
      emojiSpan.textContent = s.emoji;
      const labelSpan = document.createElement('span');
      labelSpan.className = 'mkt-starter-label';
      labelSpan.textContent = label;
      const desc = (typeof BatLang !== 'undefined' && BatLang.t(s.descKey)) || s.descFallback;
      const descSpan = document.createElement('span');
      descSpan.className = 'mkt-starter-sub';
      descSpan.textContent = desc;
      card.appendChild(emojiSpan);
      card.appendChild(labelSpan);
      card.appendChild(descSpan);
      card.onclick = function() { window.marketingUseStarter(i); };
      return card;
    }

    function marketingRenderEmptyState() {
      const wrap = document.getElementById('marketingMessages');
      if (!wrap || wrap.children.length) return; // only render into a genuinely empty panel
      const grid = document.createElement('div');
      grid.className = 'mkt-starter-grid';
      grid.id = 'marketingStarterGrid';
      MARKETING_STARTERS.forEach(function(s, i) { grid.appendChild(mktBuildStarterCard(i)); });
      wrap.appendChild(grid);
    }

    function marketingClearEmptyState() {
      const grid = document.getElementById('marketingStarterGrid');
      if (grid) grid.remove();
    }

    window.marketingUseStarter = function(i) {
      const s = MARKETING_STARTERS[i];
      if (!s) return;
      const input = document.getElementById('marketingInput');
      if (!input) return;
      input.value = (typeof BatLang !== 'undefined' && BatLang.t(s.promptKey)) || s.promptFallback;
      input.placeholder = (typeof BatLang !== 'undefined' && BatLang.t(s.placeholderKey)) || s.placeholderFallback;
      input.focus();

      const defaultPlaceholder = (typeof BatLang !== 'undefined' && BatLang.t('marketing.placeholder')) || 'Describe your idea, or paste a link / upload a file below...';
      const revertPlaceholder = function() {
        input.placeholder = defaultPlaceholder;
        input.removeEventListener('input', revertPlaceholder);
      };
      input.addEventListener('input', revertPlaceholder);
    };

    // Render on initial page load — the panel starts empty in the markup.
    (function () {
      const ready = function() { marketingRenderEmptyState(); mktSuggestionsInit(); };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
      else ready();
    })();

    /* ── Smart Suggestions (local keyword heuristics) ──
       While the empty state is showing, a debounced watcher on
       #marketingInput checks the typed text against a small keyword/pattern
       list mapped only to the 6 existing MARKETING_STARTERS (no 7th
       "Funnel Analysis" card — growth-intent phrasing maps to Marketing
       Plan). On ≥1 match, the static 6-card grid is swapped for a compact
       2-3 item suggestion row (same #marketingStarterGrid container, reused
       click behavior via marketingUseStarter). Zero matches (including an
       empty field) falls back to the full static grid. Purely local pattern
       matching — no model call. */
    const MKT_SUGGESTION_PATTERNS = [
      { index: 1, re: /https?:\/\/|\b[a-z0-9-]+\.(com|net|org|io|co|app|dev)\b/i },                          // SEO Audit — URL/domain
      { index: 3, re: /\b(competitor|competitors|vs\.?|compare|comparison|alternative|alternatives)\b/i },   // Competitor Analysis
      { index: 2, re: /\b(price|pricing|cost|costs|tier|tiers)\b/i },                                        // Pricing Strategy
      { index: 0, re: /\b(launch|release|go[- ]to[- ]market|gtm|new product)\b/i },                          // Launch Strategy
      { index: 5, re: /\b(social|instagram|tiktok|facebook|twitter|post|posts|content calendar)\b/i },       // Social Media Calendar
      { index: 4, re: /\b(grow|growth|funnel|conversion|acquisition|campaign|strategy)\b/i }                 // Marketing Plan — general growth intent
    ];

    function mktBuildSuggestionChip(i) {
      const s = MARKETING_STARTERS[i];
      const label = (typeof BatLang !== 'undefined' && BatLang.t(s.labelKey)) || s.labelFallback;
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'mkt-suggestion-chip';
      chip.textContent = s.emoji + ' ' + label;
      chip.onclick = function() { window.marketingUseStarter(i); };
      return chip;
    }

    function mktSuggestionsMatch(text) {
      const matches = [];
      MKT_SUGGESTION_PATTERNS.forEach(function(p) {
        if (p.re.test(text) && matches.indexOf(p.index) === -1) matches.push(p.index);
      });
      return matches.slice(0, 3);
    }

    function mktSuggestionsRender(grid, indices) {
      grid.innerHTML = '';
      if (indices.length) {
        grid.classList.remove('mkt-starter-grid');
        grid.classList.add('mkt-suggestion-row');
        indices.forEach(function(i) { grid.appendChild(mktBuildSuggestionChip(i)); });
      } else {
        grid.classList.remove('mkt-suggestion-row');
        grid.classList.add('mkt-starter-grid');
        MARKETING_STARTERS.forEach(function(s, i) { grid.appendChild(mktBuildStarterCard(i)); });
      }
    }

    var _mktSuggestTimer = null;

    function mktSuggestionsInit() {
      const input = document.getElementById('marketingInput');
      if (!input || input._mktSuggestBound) return;
      input._mktSuggestBound = true;
      input.addEventListener('input', function() {
        clearTimeout(_mktSuggestTimer);
        _mktSuggestTimer = setTimeout(function() {
          const grid = document.getElementById('marketingStarterGrid');
          if (!grid) return; // empty state no longer showing (first message already sent)
          mktSuggestionsRender(grid, mktSuggestionsMatch(input.value || ''));
        }, 450);
      });
    }

    /* ── Project links: a chat only becomes a Project once explicitly added
       here (never automatically). Stored locally so it works regardless of
       the generations table schema. ── */
    function getProjectLinks() {
      try { return JSON.parse(localStorage.getItem('batlab_project_links') || '[]'); } catch(e) { return []; }
    }
    function setProjectLinks(links) {
      try { localStorage.setItem('batlab_project_links', JSON.stringify(links)); } catch(e) {}
    }
    function isChatInProject(chatSessionId) {
      return getProjectLinks().some(function(l) { return l.chatSessionId === chatSessionId; });
    }

    let _lastHomeHistoryHtml = null; // render-guard: skip redundant innerHTML replaces when data is unchanged
    let _homeHistoryExpanded = false; // "Show all" in-place expand state for the Recent chat sidebar list
    /* How many Recent chat rows the collapsed list shows before "Show all".
       Note this is also exactly how many homeChatSessions ever holds — both
       loadHomeChatSessions()'s .limit(20) and saveHomeChatSession()'s
       .slice(0, 20) cap it there — so a full collapsed list means "there may
       be more on the server", which is what the "Show all" guard below uses.
       Raising this past 20 would need those two caps raised to match. */
    const HOME_HISTORY_COLLAPSED = 20;
    function _pinnedFirstSort(a, b) {
      return (b.isPinned ? 1 : 0) - (a.isPinned ? 1 : 0);
    }
    // Collapses/expands the "Recent chat" list under the Recent chat label
    // (click to hide the conversation list, click again to reveal it).
    window.toggleHomeHistory = function() {
      const list = document.getElementById('homeHistoryList');
      const toggle = document.getElementById('homeHistoryToggle');
      if (!list || !toggle) return;
      const open = list.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    };

    window.toggleHomeHistoryExpanded = async function() {
      _homeHistoryExpanded = !_homeHistoryExpanded;
      renderHomeChatHistory();
      if (_homeHistoryExpanded && (!chatsViewSessions || !chatsViewSessions.length)) {
        await loadChatsViewSessions();
        renderHomeChatHistory(); // repaint with the full list once it arrives
      }
    };
    function renderHomeChatHistory() {
      const list = document.getElementById('homeHistoryList');
      if (!list) return;
      if (homeChatSessions.length === 0) {
        const emptyHtml = '<div class="sidebar-history-empty">' + BatLang.t('sidebar.historyEmpty') + '</div>';
        if (emptyHtml === _lastHomeHistoryHtml) return;
        _lastHomeHistoryHtml = emptyHtml;
        list.classList.remove('expanded');
        list.innerHTML = emptyHtml;
        fadeInSwap(list);
        return;
      }
      // sort: pinned first, then by recency (original order)
      var _sorted = homeChatSessions.slice().sort(_pinnedFirstSort);
      var _fullList = (_homeHistoryExpanded && chatsViewSessions && chatsViewSessions.length)
        ? chatsViewSessions.slice().sort(_pinnedFirstSort)
        : _sorted;
      var _visible = _homeHistoryExpanded ? _fullList : _sorted.slice(0, HOME_HISTORY_COLLAPSED);
      var _totalCount = _fullList.length;
      /* Collapsed, _fullList IS homeChatSessions, which is itself capped at
         HOME_HISTORY_COLLAPSED — so `_totalCount > HOME_HISTORY_COLLAPSED`
         could never be true and the button would never appear. A *full*
         collapsed list is the signal that more may exist server-side; only
         then is it worth offering the fetch. Expanded, always offer "Show
         less" so the list can never get stuck open. */
      var _showToggle = _homeHistoryExpanded || _totalCount >= HOME_HISTORY_COLLAPSED;
      const _html = _visible.map(s => {
        const active = s.id === homeConvSessionId ? ' active-chat' : '';
        const isPinned = !!s.isPinned;
        const showUnread = s.isRead === false && s.id !== homeConvSessionId;
        const title = escapeHtml(s.title || 'Untitled');
        return `<div class="sidebar-history-item${active}${isPinned ? ' pinned-chat' : ''}">
          <button class="shi-main" onclick="loadHomeChatSession('${s.id}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <span class="shi-title">${isPinned ? '📌 ' : ''}${title}</span>
            ${showUnread ? '<span class="shi-unread-dot" title="Unread"></span>' : ''}
          </button>
          <div class="shi-actions">
            <button class="shi-dots-btn" onclick="event.stopPropagation();showHistoryMenu(event,'${s.id}','home')" title="More options">⋮</button>
          </div>
        </div>`;
      }).join('') + (_showToggle
        ? `<button class="sidebar-show-all-btn" onclick="toggleHomeHistoryExpanded()">${_homeHistoryExpanded ? BatLang.t('sidebar.showLess') : BatLang.t('sidebar.showAllChats')}</button>`
        : '');
      if (_html === _lastHomeHistoryHtml) return;
      _lastHomeHistoryHtml = _html;
      list.classList.toggle('expanded', _homeHistoryExpanded);
      list.innerHTML = _html;
      fadeInSwap(list);
    }

    /* ── Home breadcrumb: reflects real nav state, never fabricated ──
       Default "New Project" when no active home conversation; the real
       (truncated) session title once one exists — mirrors the truncation
       convention used by renderProjectsSidebarHistory(). */
    function updateHomeBreadcrumb() {
      const el = document.getElementById('homeBreadcrumbCurrent');
      if (!el) return;
      let title = null;
      if (homeConvActive && homeConvSessionId) {
        const session = homeChatSessions.find(function(s) { return s.id === homeConvSessionId; })
          || (chatsViewSessions || []).find(function(s) { return s.id === homeConvSessionId; });
        if (session && session.title) title = session.title;
      }
      if (title) {
        el.textContent = title.length > 28 ? title.slice(0, 28) + '…' : title;
        el.removeAttribute('data-i18n'); // stop setLang() overwriting it with the default label
      } else {
        el.setAttribute('data-i18n', 'breadcrumb.newProject');
        el.textContent = BatLang.t('breadcrumb.newProject');
      }
    }
    window.updateHomeBreadcrumb = updateHomeBreadcrumb;

    /* ── Pin / unpin (Star / Unstar) a home-chat session — synced via DB (is_pinned) ── */
    window.togglePinHomeChat = async function(id) {
      const session = homeChatSessions.find(s => s.id === id) || (window.chatsViewSessions || []).find(s => s.id === id);
      if (!session) return;
      session.isPinned = !session.isPinned;
      renderHomeChatHistory();
      if (typeof renderChatsList === 'function') renderChatsList();
      try { await supabase.from('chat_sessions').update({ is_pinned: session.isPinned }).eq('id', id); }
      catch(e) { console.error('Failed to toggle pin:', e); }
    };

    /* ── Mark / unmark a home-chat session as read ── */
    window.toggleReadHomeChat = async function(id) {
      const session = homeChatSessions.find(s => s.id === id) || (window.chatsViewSessions || []).find(s => s.id === id);
      if (!session) return;
      session.isRead = !session.isRead;
      renderHomeChatHistory();
      if (typeof renderChatsList === 'function') renderChatsList();
      try { await supabase.from('chat_sessions').update({ is_read: session.isRead }).eq('id', id); }
      catch(e) { console.error('Failed to toggle read state:', e); }
    };

    /* ── Add to project: the ONLY way a conversation becomes a Project.
       Nothing is added automatically just by chatting or generating. ── */
    window.addHomeChatToProject = function(id) {
      const session = homeChatSessions.find(function(s) { return s.id === id; })
        || (chatsViewSessions || []).find(function(s) { return s.id === id; });
      if (!session) return;
      if (isChatInProject(id)) {
        showToast(BatLang.t('toast.alreadyInProject'), 'info');
        return;
      }
      // Borrow a type/prompt from a matching generation (if any) just for display; falls back gracefully.
      const gen = (genHistory || []).find(function(g) { return g.chatSessionId === id; });
      const links = getProjectLinks();
      links.unshift({
        chatSessionId: id,
        title: session.title || (gen && gen.prompt) || 'Untitled',
        type: (gen && gen.type) || 'website',
        ts: Date.now()
      });
      setProjectLinks(links);
      showToast(BatLang.t('toast.addedToProject'), 'success');
      renderHomeChatHistory();
      renderProjectsSidebarHistory();
      const projectsView = document.getElementById('projectsView');
      if (projectsView && projectsView.style.display !== 'none') renderProjects();
    };

    /* ── Open a project: reopens its linked conversation in the full chat view ── */
    window.openProject = function(chatSessionId) {
      if (homeChatSessions.some(function(s) { return s.id === chatSessionId; })) {
        window.loadHomeChatSession(chatSessionId);
        return;
      }
      // homeChatSessions may not have loaded yet (e.g. deep link) — try a refresh first.
      Promise.resolve(loadHomeChatSessions()).then(function() {
        if (homeChatSessions.some(function(s) { return s.id === chatSessionId; })) {
          window.loadHomeChatSession(chatSessionId);
        } else {
          showToast(BatLang.t('toast.chatError'), 'error');
        }
      });
    };

    /* Reset the inline home chat back to a blank conversation */
    window.startNewHomeChat = function() {
      homeConvSessionId = null;
      homeConvHistory = [];
      homeConvActive = false;
      lastHTML = ''; lastPrompt = ''; lastType = ''; lastSubtype = '';
      resetPageTitle();
      const homeView = document.getElementById('homeView');
      if (homeView) homeView.classList.remove('hcm-active');
      const convWrap = document.getElementById('homeConvWrap');
      if (convWrap) convWrap.classList.remove('active');
      const container = document.getElementById('homeConvMessages');
      if (container) container.innerHTML = '';
      lazyTeardown(homeLazyState, container);
      const inp = document.getElementById('homeInput');
      if (inp) { inp.value = ''; inp.dispatchEvent(new Event('input')); }
      setChatUrlCode(null);
      renderHomeChatHistory();
      showView('home');
      window.syncFooter();
    };

    window.loadHomeChatSession = async function(id) {
      const session = homeChatSessions.find(s => s.id === id);
      if (!session) return;
      if (session.isRead === false) {
        session.isRead = true;
        renderHomeChatHistory();
        if (typeof renderChatsList === 'function') renderChatsList();
        try { await supabase.from('chat_sessions').update({ is_read: true }).eq('id', id); }
        catch(e) { console.error('Failed to mark chat as read:', e); }
      }
      homeConvSessionId = id;
      setPageTitle(session.title);
      homeConvActive = true;
      const homeView = document.getElementById('homeView');
      if (homeView) homeView.classList.add('hcm-active');
      // Reading an existing conversation isn't the "New Chat" screen, so drop
      // the green "selected" state from the New Chat nav item.
      const homeNav = document.getElementById('sidebarHome');
      if (homeNav) homeNav.classList.remove('active');
      const convWrap = document.getElementById('homeConvWrap');
      if (convWrap) convWrap.classList.add('active');
      // Every conversation — old or new — gets a code; retro-generate one
      // here if this session predates the feature.
      setChatUrlCode(getOrCreateChatCode(id));
      const container = document.getElementById('homeConvMessages');
      // Messages aren't fetched until a conversation is actually opened (the
      // sidebar list only ever loads id/title/updatedAt) — show a skeleton while
      // that single-session Supabase fetch resolves (cleared before the real render).
      renderChatSkeleton(container);
      await ensureHomeChatMessagesLoaded(session);
      // The user may have clicked a different conversation while this was
      // in flight — bail out so we don't render stale messages over it.
      if (homeConvSessionId !== id) return;
      homeConvHistory = [...session.messages];
      await loadStarredSetForSession('home', id);
      if (homeConvSessionId !== id) return;
      if (container) container.innerHTML = '';
      // Reverse infinite scroll: render only the most recent window and reveal
      // older pairs on scroll-to-top. hcmRenderSlice reproduces the per-message
      // rebuild (thinking block + bubble + saved generation card) for a range.
      if (container) {
        lazySetup({
          state: homeLazyState,
          container: container,
          getHistory: function () { return homeConvHistory; },
          renderSlice: hcmRenderSlice,
          pageScroll: false
        });
        container.scrollTop = container.scrollHeight;
      }
      renderHomeChatHistory();
      showView('home');
      window.syncFooter();
      // ── Preview sync: if this session had a generation, reopen the preview
      // drawer immediately so the user sees the output without needing to click the card again.
      const lastGen = homeConvHistory.slice().reverse().find(m => m.role === 'assistant' && m.gen && m.gen.html);
      if (lastGen) {
        // Restore generation state so a follow-up message in this session
        // edits its existing build instead of starting a brand-new one.
        lastHTML = lastGen.gen.html;
        lastType = lastGen.gen.type || '';
        lastPrompt = ''; lastSubtype = '';
        if (lastType) {
          selectedType = lastType;
          document.querySelectorAll('#homeChips .home-chip').forEach(c => {
            c.classList.toggle('active', c.dataset.value === lastType);
          });
          renderCostPreview();
        }
        // Small delay lets the DOM settle before opening the drawer.
        setTimeout(function () {
          if (typeof window.hcmOpenPreview === 'function') {
            window.hcmOpenPreview(lastGen.gen.html, lastGen.gen.type || 'project');
          }
        }, 80);
      } else {
        lastHTML = ''; lastType = ''; lastPrompt = ''; lastSubtype = '';
      }
    };

    window.renameHomeChatSession = async function(id) {
      const session = homeChatSessions.find(s => s.id === id);
      if (!session || !currentUser) return;
      const newTitle = window.prompt('Rename conversation:', session.title || '');
      if (!newTitle || !newTitle.trim()) return;
      session.title = newTitle.trim().slice(0, 60);
      renderHomeChatHistory();
      updateHomeBreadcrumb();
      renderHomeProjectsGrid();
      try {
        await supabase.from('chat_sessions').update({ title: session.title }).eq('id', id);
      } catch(e) {
        console.error('Failed to rename home chat session:', e);
      }
    };

    window.deleteHomeChatSession = async function(id) {
      if (!await window.showConfirmDialog('Delete this conversation?', 'This cannot be undone.', 'Delete')) return;
      homeChatSessions = homeChatSessions.filter(s => s.id !== id);
      if (homeConvSessionId === id) {
        homeConvSessionId = null;
        homeConvHistory = [];
        homeConvActive = false;
      }
      renderHomeChatHistory();
      window.syncFooter();
      if (!currentUser) return;
      try {
        await supabase.from('chat_sessions').delete().eq('id', id);
      } catch(e) {
        console.error('Failed to delete home chat session:', e);
      }
    };

    // This runs at module-parse time, before auth has resolved and before any
    // fetch has run — homeChatSessions is always [] here. Painting the real
    // "No conversations yet" empty-state at this point is wrong (that's the
    // original flash bug). Show cached data instantly if we have it, else a
    // skeleton placeholder; loadHomeChatSessions() repaints with live data
    // once auth/fetch resolve.
    (function () {
      const cached = BatCache.get(BATNXT_CACHE_HOME_CHATS);
      if (Array.isArray(cached) && cached.length > 0) {
        homeChatSessions = cached;
        renderHomeChatHistory();
      } else {
        renderHomeHistorySkeleton();
      }
    })();

    function hcmAppend(role, text, userPrompt, images, index, msgId) {
      const wrap = document.getElementById('homeConvMessages');
      if (!wrap) return;
      const isUser = role === 'user';
      // Defensive render-time safety net: strip any leaked <REASONING>…
      // </REASONING> from assistant text before it's ever painted. Live/error
      // text reaching here is already clean (generate-time strip), so this is
      // a no-op for it — but hcmRenderSlice() feeds raw OLD persisted
      // Supabase/localStorage content straight through as `m.content`, and
      // that history predates the generate-time fix. Idempotent + identical
      // regex/logic to the generate-time strip.
      if (!isUser && text) {
        text = text.replace(/<REASONING>[\s\S]*?<\/REASONING>/g, '');
        const _rOpenIdx = text.indexOf('<REASONING>');
        if (_rOpenIdx !== -1) text = text.slice(0, _rOpenIdx);
      }
      const div = document.createElement('div');
      div.className = 'hcm-msg' + (isUser ? ' user' : '');
      if (isUser && index != null) div.dataset.msgIndex = index;
      if (msgId) div.dataset.msgId = msgId;
      const av = document.createElement('div');
      av.className = 'hcm-avatar' + (isUser ? '' : ' is-logo');
      if (isUser) {
        av.textContent = document.getElementById('avatarInitials')?.textContent || 'U';
      } else {
        av.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      }
      const bubble = document.createElement('div');
      bubble.className = 'hcm-bubble' + (isUser ? '' : ' md-content');
      // Assistant replies align to the UI language (uiTextDir); user bubbles
      // keep content-based direction (detectTextDir).
      bubble.dir = isUser ? detectTextDir(text) : uiTextDir();
      // Text first — but skip entirely for image-only bubbles (empty caption)
      // so no blank <p> is rendered under the thumbnail.
      const _txt = (text == null ? '' : String(text));
      if (_txt.trim() !== '') {
        bubble.innerHTML = renderRichText(text, isUser);
        if (!isUser) enhanceCodeBlocks(bubble);
      }
      // Image grid (user turns only): rendered ABOVE the text, each thumbnail
      // reusing the existing Settings > Library lightbox (openLibraryPreview).
      // Inserted AFTER the text is set so the per-thumbnail click listeners
      // aren't wiped by innerHTML re-parsing. The images are already in-memory
      // data: URLs (or, post-migration, remote URLs), so no fetch is needed.
      if (isUser && Array.isArray(images) && images.length) {
        const grid = document.createElement('div');
        grid.className = 'hcm-image-grid';
        images.forEach(function (url) {
          const img = document.createElement('img');
          img.src = url;
          img.className = 'hcm-image-thumb';
          img.alt = 'Attached image';
          img.addEventListener('click', function () { openLibraryPreview(url); });
          grid.appendChild(img);
        });
        bubble.insertBefore(grid, bubble.firstChild);
      }
      div.appendChild(av);
      div.appendChild(bubble);
      // Add reaction buttons on AI messages only
      if (!isUser) {
        hcmAppendReactions(div, userPrompt, msgId);
      } else if (index != null) {
        // Copy/Edit/Regenerate hover row (user messages only) — index is
        // this message's position in homeConvHistory, closed over here so
        // the click handlers stay correct even after later truncations
        // change what index some OTHER, later-created row starts with.
        div.appendChild(hcmBuildUserActionsRow(_txt, function () { return homeConvBusy; },
          function () { hcmStartEditUserMessage(index, div, bubble); },
          function () { hcmRegenerateUserMessage(index); }));
      }
      wrap.appendChild(div);
      wrap.scrollTop = wrap.scrollHeight;
    }

    function hcmAppendBuildBtn(prompt) {
      const wrap = document.getElementById('homeConvMessages');
      if (!wrap) return;
      const div = document.createElement('div');
      div.className = 'hcm-build-row';
      div.innerHTML = '<button class="hcm-build-btn" onclick="hcmTriggerBuild(' + JSON.stringify(prompt) + ')">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:15px;height:15px">' +
        '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>' +
        (window.currentLang === 'ar' ? ' ابنِ الآن ✦' : ' Build Now ✦') +
        '</button>';
      wrap.appendChild(div);
      wrap.scrollTop = wrap.scrollHeight;
    }

    function hcmAppendClarify(clarify) {
      const wrap = document.getElementById('homeConvMessages');
      if (!wrap) return;
      const card = document.createElement('div');
      card.className = 'clarify-card';
      // Carries forward whether the ORIGINAL prompt that produced this card
      // was substantive (see homeConvGetReply's _wantThinking), so answering
      // it — even with a short/generic reply like "Skip" — still shows the
      // "Thought for Xs" widget for the follow-up turn. Persisted on the
      // clarify object itself so it survives a reload too.
      card.dataset.wasSubstantive = clarify.wasSubstantive ? '1' : '0';
      // Lets hcmAnswerClarify find this exact assistant message back in
      // homeConvHistory to persist the answered state (see there).
      card.dataset.msgId = clarify.msgId || '';
      // Reload rebuild of an already-answered card: render it pre-locked
      // (the .answered CSS dims/disables options) instead of pristine and
      // re-clickable, so a reload can't submit a second, conflicting answer.
      if (clarify.answered) card.classList.add('answered');
      const title = document.createElement('div');
      title.className = 'clarify-title';
      title.textContent = clarify.question;
      const opts = document.createElement('div');
      opts.className = 'clarify-options';
      clarify.options.forEach((opt, i) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'clarify-opt';
        if (clarify.answered && clarify.answeredWith === opt) btn.classList.add('selected');
        btn.onclick = () => window.hcmAnswerClarify(btn, opt);
        const num = document.createElement('span');
        num.className = 'clarify-opt-num';
        num.textContent = String(i + 1);
        const txt = document.createElement('span');
        txt.className = 'clarify-opt-text';
        txt.textContent = opt;
        btn.appendChild(num);
        btn.appendChild(txt);
        opts.appendChild(btn);
      });
      const skipBtn = document.createElement('button');
      skipBtn.type = 'button';
      skipBtn.className = 'clarify-opt clarify-opt-skip';
      skipBtn.textContent = BatLang.t('clarify.skip');
      if (clarify.answered && clarify.answeredWith === BatLang.t('clarify.skipReply')) skipBtn.classList.add('selected');
      skipBtn.onclick = () => window.hcmAnswerClarify(skipBtn, BatLang.t('clarify.skipReply'));
      opts.appendChild(skipBtn);
      const otherToggleBtn = document.createElement('button');
      otherToggleBtn.type = 'button';
      otherToggleBtn.className = 'clarify-opt clarify-opt-other';
      otherToggleBtn.textContent = BatLang.t('clarify.other');
      otherToggleBtn.onclick = () => window.toggleClarifyOther(otherToggleBtn);
      opts.appendChild(otherToggleBtn);
      card.appendChild(title);
      card.appendChild(opts);
      const otherRow = document.createElement('div');
      otherRow.className = 'clarify-other-row';
      const otherInput = document.createElement('input');
      otherInput.type = 'text';
      otherInput.className = 'clarify-other-input';
      otherInput.placeholder = BatLang.t('clarify.otherPlaceholder');
      otherInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); window.hcmSubmitClarifyOther(otherToggleBtn, otherInput); }
      });
      const otherSubmit = document.createElement('button');
      otherSubmit.type = 'button';
      otherSubmit.className = 'clarify-other-submit';
      otherSubmit.textContent = BatLang.t('clarify.otherSend');
      otherSubmit.onclick = () => window.hcmSubmitClarifyOther(otherToggleBtn, otherInput);
      otherRow.appendChild(otherInput);
      otherRow.appendChild(otherSubmit);
      card.appendChild(otherRow);
      // Arrow-key navigation across all options (numbered + Skip + Something else).
      // Only acts when focus is already on a .clarify-opt button, so it never
      // hijacks arrow-key behavior while typing in the free-text input.
      card.addEventListener('keydown', (e) => {
        if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
        if (!document.activeElement || !document.activeElement.classList.contains('clarify-opt')) return;
        const focusable = Array.from(card.querySelectorAll('.clarify-opt'));
        const idx = focusable.indexOf(document.activeElement);
        if (idx === -1) return;
        e.preventDefault();
        const next = e.key === 'ArrowDown' ? (idx + 1) % focusable.length : (idx - 1 + focusable.length) % focusable.length;
        focusable[next].focus();
      });
      wrap.appendChild(card);
      wrap.scrollTop = wrap.scrollHeight;
    }

    window.hcmAnswerClarify = function(btnEl, text) {
      // Guard against duplicate turns: ignore the click if a reply is already
      // streaming, or if this card was already answered. The chosen option
      // stays visually highlighted but must not re-fire homeConvSend on a
      // second click (the .answered CSS now also blocks pointer events on it).
      if (homeConvBusy) return;
      const card = btnEl.closest('.clarify-card');
      let wasSubstantive = false;
      if (card) {
        if (card.classList.contains('answered')) return;
        wasSubstantive = card.dataset.wasSubstantive === '1';
        card.classList.add('answered');
        card.querySelectorAll('.clarify-opt').forEach(b => b.classList.remove('selected'));
        btnEl.classList.add('selected');
        // Persist the answered state onto the saved message itself (not just
        // the live DOM's .answered class) so a reload rebuilds this card
        // locked instead of pristine and re-clickable.
        const msgId = card.dataset.msgId;
        if (msgId) {
          const m = homeConvHistory.find(h => h.role === 'assistant' && h.clarify && h.msgId === msgId);
          if (m) {
            m.clarify.answered = true;
            m.clarify.answeredWith = text;
            saveHomeConvSession();
          }
        }
      }
      homeConvSend(text, undefined, undefined, undefined, wasSubstantive);
    };

    window.hcmSubmitClarifyOther = function(otherBtn, inputEl) {
      const val = (inputEl.value || '').trim();
      if (!val) { inputEl.focus(); return; }
      window.hcmAnswerClarify(otherBtn, val);
    };

    window.hcmTriggerBuild = async function(prompt) {
      // Don't tear down the conversation if generation can't actually start
      // yet: homeGoGenerate() bails when homeConvBusy, so wiping first would
      // strand the build (conversation cleared, nothing generated). Bail here
      // — the still-visible Build button lets the user retry once the reply
      // that's in flight finishes.
      if (homeConvBusy) return;
      // Pick best type from prompt text
      const p = prompt.toLowerCase();
      let type = 'website';
      if (p.includes('game') || p.includes('لعبة')) type = 'game';
      else if (p.includes('mobile') || p.includes('app') || p.includes('تطبيق')) type = 'mobile';
      else if (p.includes('tool') || p.includes('أداة') || p.includes('اداة')) type = 'tool';
      // Set prompt in composer and trigger generation
      const inp = document.getElementById('homeInput');
      if (inp) { inp.value = prompt; inp.dispatchEvent(new Event('input')); }
      // Set type
      selectedType = type;
      document.querySelectorAll('#homeChips .home-chip').forEach(c => {
        c.classList.toggle('active', c.dataset.value === type);
      });
      renderCostPreview();
      // Save the home chat conversation to History before wiping it
      await saveHomeConvSession();
      // Exit chatbot mode visually
      const homeView = document.getElementById('homeView');
      if (homeView) homeView.classList.remove('hcm-active');
      const convWrap = document.getElementById('homeConvWrap');
      if (convWrap) convWrap.classList.remove('active');
      homeConvActive = false;
      homeConvHistory = [];
      // Keep homeConvSessionId intact through generation so the resulting
      // project can be linked back to this conversation, then clear it after.
      await window.homeGoGenerate();
      homeConvSessionId = null;
    };

    var _homeThinkingTimer = null;
    // The currently-active inline "thinking → streaming" bubble row (see
    // hcmBeginAssistantStreamingBubble() below), or null when no chat/build
    // turn is in flight. Tracked at module scope (not passed through
    // homeConvBeginUserTurn()'s return value) because homeConvGetReply() and
    // the build-flow send handler both need to reach the same bubble across
    // an intervening `await` (e.g. classifyBuildIntent()).
    var _homeStreamingBubbleRow = null;

    /* Creates the inline "thinking → streaming" bubble directly inside
       #homeConvMessages (same .hcm-msg / .hcm-avatar.is-logo / .hcm-bubble
       structure hcmAppend() builds for a real assistant reply), instead of
       the old floating #homeConvTyping indicator that lived outside the
       message list and couldn't visually morph into the reply. Reuses the
       existing .hcm-typing/.hcm-typing-dots/#homeConvTypingText markup+CSS
       as-is, so startHomeThinkingCycle()/stopHomeThinkingCycle()/
       _statusHintText() (which target #homeConvTypingText purely by id)
       keep working unchanged. */
    function hcmBeginAssistantStreamingBubble() {
      const wrap = document.getElementById('homeConvMessages');
      if (!wrap) return null;
      const row = document.createElement('div');
      row.className = 'hcm-msg';
      const av = document.createElement('div');
      av.className = 'hcm-avatar is-logo is-thinking';
      av.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      const bubble = document.createElement('div');
      bubble.className = 'hcm-bubble md-content';
      // Assistant stream: align to UI language from the first frame so the
      // "thinking..." indicator sits on the correct side.
      bubble.dir = uiTextDir();
      bubble.innerHTML =
        '<div class="hcm-typing show">' +
          '<div class="hcm-typing-dots"><span></span><span></span><span></span></div>' +
          '<span class="hcm-typing-text" id="homeConvTypingText">BatNXT is thinking...</span>' +
        '</div>';
      row.appendChild(av);
      row.appendChild(bubble);
      wrap.appendChild(row);
      wrap.scrollTop = wrap.scrollHeight;
      _homeStreamingBubbleRow = row;
      return row;
    }

    /* Discards the streaming bubble outright (no reply text was ever shown
       in it) — used for the build flow (its own hcmCreateBuildWidget() takes
       over) and the out-of-credits bail-out. The old code just hid the
       floating #homeConvTyping indicator in these cases; now there's a real
       bubble in the message list that needs to be removed instead. */
    function hcmRemoveStreamingBubble() {
      if (_homeStreamingBubbleRow && _homeStreamingBubbleRow.parentNode) {
        _homeStreamingBubbleRow.parentNode.removeChild(_homeStreamingBubbleRow);
      }
      _homeStreamingBubbleRow = null;
    }

    // Shows the content-type message immediately, switches to the "thinking"
    // message after 3s, then keeps alternating between the two at a random
    // 3-5s interval until stopHomeThinkingCycle() is called.
    function startHomeThinkingCycle(type) {
      clearTimeout(_homeThinkingTimer);
      var phase = 'initial';
      var el = document.getElementById('homeConvTypingText');
      if (el) el.textContent = _statusHintText(type, phase);
      function scheduleNext(delay) {
        _homeThinkingTimer = setTimeout(function() {
          phase = phase === 'initial' ? 'thinking' : 'initial';
          var el = document.getElementById('homeConvTypingText');
          if (el) {
            el.style.opacity = '0';
            el.style.transition = 'opacity 0.25s';
            setTimeout(function() {
              el.textContent = _statusHintText(type, phase);
              el.style.opacity = '1';
            }, 250);
          }
          scheduleNext(3000 + Math.random() * 2000);
        }, delay);
      }
      scheduleNext(3000);
    }
    function stopHomeThinkingCycle() {
      clearTimeout(_homeThinkingTimer);
      _homeThinkingTimer = null;
    }

    // Guards the home composer's send button: only one request (chat reply)
    // can be in flight at a time. While busy, the button becomes a Stop
    // control instead of being simply disabled.
    let homeConvBusy = false;
    let homeConvAbortController = null;
    window.homeStopChatGenerating = function () {
      if (homeConvAbortController) {
        try { homeConvAbortController.abort(); } catch (e) {}
      }
    };
    // Dispatcher wired to the send button's onclick: sends a new message when
    // idle, or stops the in-flight reply when busy.
    window.homeSendOrStop = function (evt) {
      if (homeConvBusy) {
        window.homeStopChatGenerating();
        return;
      }
      window.homeSendClickFx(evt);
      window.homeGoGenerate();
    };
    const HOME_SEND_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
    const HOME_STOP_ICON = '<svg viewBox="0 0 24 24" width="16" height="16"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>';
    function setHomeSendBtnBusy(busy) {
      const btn = document.getElementById('homeSendBtn');
      if (!btn) return;
      btn.classList.toggle('is-stop', busy);
      btn.disabled = false; // stays clickable in both states (busy = Stop)
      btn.setAttribute('aria-label', busy ? 'Stop generating' : 'Forge Project');
      btn.innerHTML = busy ? HOME_STOP_ICON : HOME_SEND_ICON;
    }

    /* Activates chat mode (if needed) and appends the user's turn to the UI +
       history immediately — used so the message is visible right away, before
       any classification/generation delay, instead of only after it resolves. */
    function homeConvBeginUserTurn(prompt, images, type) {
      disableStaleClarify('homeConvMessages');
      const hasImages = Array.isArray(images) && images.length > 0;
      if (!homeConvActive) {
        homeConvActive = true;
        homeConvSessionId = homeConvSessionId || ('hcm_' + Date.now());
        const homeView = document.getElementById('homeView');
        if (homeView) homeView.classList.add('hcm-active');
        const convWrap = document.getElementById('homeConvWrap');
        if (convWrap) convWrap.classList.add('active');
        // Give this conversation its own code + URL: batnxt.com/XXX-XXX-XXX
        setChatUrlCode(getOrCreateChatCode(homeConvSessionId));
      }
      // Image-only sends (no typed text) render just the thumbnail(s) — no
      // caption chip. The stored/sent content stays the real (possibly empty)
      // prompt so the backend's default-question fallback for Moondream keeps
      // working. The images (base64 data-URLs) are persisted on the message so
      // they survive a reload. NOTE for a future Option-B migration: swap these
      // data-URLs for uploaded R2/Storage URLs here and the render path stays
      // identical (hcmAppend just does img.src = url either way).
      hcmAppend('user', prompt, undefined, images, homeConvHistory.length);
      homeConvHistory.push({ role: 'user', content: prompt, images: hasImages ? images : undefined, msgId: mintMsgId() });
      window.syncFooter();
      hcmBeginAssistantStreamingBubble();
      startHomeThinkingCycle(type || (hasImages ? 'image' : 'text'));
      const msgs = document.getElementById('homeConvMessages');
      if (msgs) msgs.scrollTop = msgs.scrollHeight;
    }

    async function homeConvSend(prompt, images, type, imageNames, forceWantThinking) {
      // Defense-in-depth: never start a new turn while one is already in
      // flight (callers like hcmAnswerClarify also guard, but this covers any
      // other entry point).
      if (homeConvBusy) return;
      homeConvBeginUserTurn(prompt, images, type);
      await homeConvGetReply(prompt, images, imageNames, forceWantThinking);
    }

    // Trailing sentinel streamChatReply() (worker/worker.js) appends to a
    // likely-truncated reply's stream — never shown to the user, stripped
    // here (and held back mid-stream, see hcmStripTruncationSentinel below)
    // to surface a small "response was cut short" note instead.
    const BATNXT_TRUNCATED_SENTINEL = '\n<!--BATNXT_TRUNCATED-->';

    /* Strips a fully-arrived truncation sentinel from the end of `text`, or
       — if only a leading fragment of it has streamed in so far (still
       arriving char-by-character) — holds that fragment back too, so the
       raw HTML-comment marker is never flashed on screen mid-stream. */
    function hcmStripTruncationSentinel(text) {
      if (text.slice(-BATNXT_TRUNCATED_SENTINEL.length) === BATNXT_TRUNCATED_SENTINEL) {
        return { text: text.slice(0, -BATNXT_TRUNCATED_SENTINEL.length), truncated: true };
      }
      const maxLen = Math.min(text.length, BATNXT_TRUNCATED_SENTINEL.length - 1);
      for (let i = 1; i <= maxLen; i++) {
        const suffix = text.slice(text.length - i);
        if (BATNXT_TRUNCATED_SENTINEL.indexOf(suffix) === 0) {
          return { text: text.slice(0, text.length - i), truncated: false };
        }
      }
      return { text: text, truncated: false };
    }

    /* getChatSystem() guarantees <IMPROVED_PROMPT>/<CLARIFY> only ever
       appear as a TRAILING block after a short plain-text sentence, never
       combined, never mid-message — so mid-stream display only needs to
       hold back a trailing (possibly still-being-typed) tag, never scan for
       tags anywhere else in the text. Fully-closed tag blocks are always
       stripped too (their content is raw prompt/JSON text, parsed
       separately once the stream ends — never meant to be shown). */
    function hcmSafeStreamText(raw) {
      let text = String(raw || '');
      // <REASONING>…</REASONING> is emitted first by bat 1.2 Core (see worker.js
      // emitReasoning). Strip it from the visible bubble — the reasoning is routed
      // into the "Thought for Xs" widget separately (extractInlineReasoning below).
      // While it's still open (no close yet) the openIdx branch returns '' since it
      // sits at the head of the stream, so no reasoning ever flashes in the bubble.
      text = text.replace(/<REASONING>[\s\S]*?<\/REASONING>/g, '');
      text = text.replace(/<IMPROVED_PROMPT>[\s\S]*?<\/IMPROVED_PROMPT>/g, '');
      text = text.replace(/<CLARIFY>[\s\S]*?<\/CLARIFY>/g, '');
      text = text.replace(/<STEPS>[\s\S]*?<\/STEPS>/g, '');
      const openIdx = text.search(/<(REASONING|IMPROVED_PROMPT|CLARIFY|STEPS)>/);
      if (openIdx !== -1) return text.slice(0, openIdx);
      // Hold back a trailing partial tag-open still streaming in
      // character-by-character (e.g. "<REAS", "<IMPR", "<CLA", "<STE") so it's never flashed.
      const tags = ['<REASONING>', '<IMPROVED_PROMPT>', '<CLARIFY>', '<STEPS>'];
      const maxLen = Math.min(text.length, 18);
      for (let i = 1; i <= maxLen; i++) {
        const suffix = text.slice(text.length - i);
        if (tags.some(function (t) { return t.indexOf(suffix) === 0; })) {
          return text.slice(0, text.length - i);
        }
      }
      return text;
    }

    /* Extracts the inline <REASONING>…</REASONING> block bat 1.2 Core streams at
       the head of a reply (see worker.js emitReasoning). Returns the reasoning
       captured so far — whether or not the closing tag has arrived yet — so the
       "Thought for Xs" widget can update live as it streams; returns '' when the
       stream carries no reasoning tag (all other models, or Core producing none,
       in which case the widget honestly degrades to a timing-only chip). */
    function extractInlineReasoning(raw) {
      const text = String(raw || '');
      const open = text.indexOf('<REASONING>');
      if (open === -1) return '';
      const start = open + '<REASONING>'.length;
      const close = text.indexOf('</REASONING>', start);
      return (close === -1 ? text.slice(start) : text.slice(start, close));
    }

    /* Counterpart to extractInlineReasoning(): returns the reply with the
       inline <REASONING>…</REASONING> block REMOVED, for the plain views that
       have no "Thought for Xs" widget to route it into (workspace chat, the
       sidebar Prompt Chat, the pre-gen thinking blurb) and would otherwise
       paint the raw tag as literal text. Factored out of the identical
       two-step idiom already inlined in homeConvGetReply() (~:6379) and
       sendMarketingMessage() (~:7853):
         1. drop every complete tag pair;
         2. drop an opened-but-never-closed tag through to the end — a stream
            cut off mid-reasoning (token/length limit hit before the closing
            tag arrived), mirroring hcmSafeStreamText's open-without-close
            handling. */
    function stripInlineReasoning(raw) {
      let text = String(raw || '').replace(/<REASONING>[\s\S]*?<\/REASONING>/g, '');
      const open = text.indexOf('<REASONING>');
      if (open !== -1) text = text.slice(0, open);
      return text;
    }

    // Marketing-only variant of hcmSafeStreamText. In addition to CLARIFY/
    // IMPROVED_PROMPT, it strips/holds-back the trailing <MKT_SCORES>{...}
    // </MKT_SCORES> structured-output tag so its raw JSON never flashes on
    // screen while the reply is still streaming (the parsed scores are rendered
    // as gauges only after the stream completes — see sendMarketingMessage).
    // Kept separate from hcmSafeStreamText so Home chat streaming is untouched.
    function marketingSafeStreamText(raw) {
      let text = hcmSafeStreamText(raw);
      text = text.replace(/<MKT_SCORES>[\s\S]*?<\/MKT_SCORES>/g, '');
      const openIdx = text.indexOf('<MKT_SCORES>');
      if (openIdx !== -1) return text.slice(0, openIdx);
      // Hold back a trailing partial "<MKT_SCORES" still streaming in
      // character-by-character so a half-open tag is never flashed.
      const tag = '<MKT_SCORES>';
      const maxLen = Math.min(text.length, tag.length);
      for (let i = 1; i <= maxLen; i++) {
        const suffix = text.slice(text.length - i);
        if (tag.indexOf(suffix) === 0) return text.slice(0, text.length - i);
      }
      return text;
    }

    /* Reads a streamed plain-text Response body (see streamChatReply() in
       worker/worker.js) into a growing string, invoking `onDelta` with the
       accumulated text so far on a throttle (mirrors the existing pump
       pattern in runGeneration() for streamed website HTML) instead of on
       every single chunk, so callers aren't re-running marked.parse()/
       DOMPurify.sanitize() dozens of times a second. Returns the final,
       complete text (also passed to one last, un-throttled `onDelta` call). */
    async function streamPlainText(res, onDelta, throttleMs) {
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      const delay = throttleMs || 80;
      let acc = '';
      let lastEmit = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += decoder.decode(value, { stream: true });
        const now = Date.now();
        if (onDelta && now - lastEmit > delay) {
          onDelta(acc);
          lastEmit = now;
        }
      }
      acc += decoder.decode();
      if (onDelta) onDelta(acc);
      return acc;
    }

    /* Renders the reaction-buttons row (👍👎🔄) hcmAppend() normally builds
       for assistant messages — factored out so the streaming bubble (built
       by hcmBeginAssistantStreamingBubble(), not hcmAppend()) can get the
       same row once its reply finishes streaming in. */
    function hcmAppendReactions(row, prompt, msgId) {
      if (prompt) row.dataset.userPrompt = prompt;
      const reactions = document.createElement('div');
      reactions.className = 'hcm-reactions';

      const starBtn = hcmMakeStarBtn('home', msgId, function () { return homeConvSessionId; }, 'assistant',
        function () { const b = row.querySelector('.hcm-bubble'); return b ? b.textContent : ''; },
        getHomeConvTitle);
      reactions.appendChild(starBtn);

      const regenBtn = document.createElement('button');
      regenBtn.type = 'button';
      regenBtn.className = 'hcm-reaction-btn';
      regenBtn.setAttribute('aria-label', 'Regenerate');
      regenBtn.textContent = '🔄';
      regenBtn.addEventListener('click', function() {
        regenBtn.style.transform = 'rotate(360deg)';
        regenBtn.style.transition = 'transform 0.5s ease';
        setTimeout(function() { regenBtn.style.transform = ''; }, 500);
        var promptToResend = row.dataset.userPrompt;
        if (promptToResend && typeof homeConvSend === 'function') {
          homeConvSend(promptToResend);
        }
      });
      reactions.appendChild(regenBtn);

      row.appendChild(reactions);
    }

    /* ── Live model-status controller (top-bar #homeModelStatus) ─────────
       Drives the indicator through ready → thinking → streaming → latency →
       ready, or → retry on a real error. A monotonically increasing sequence
       id (_modelStatusSeq) lets a newer turn ignore late status updates from
       an older, superseded request. Retry re-runs the last home turn via the
       same homeConvSend() path the 🔄 reaction uses. Timing is measured
       client-side with performance.now(). */
    var _modelStatusSeq = 0;
    var _modelStatusFadeTimer = null;
    var _lastHomeTurn = null; // { prompt, images } — remembered for the Retry state

    function setModelStatus(state, meta) {
      var slot = document.getElementById('homeModelStatus');
      if (!slot) return;
      meta = meta || {};
      if (_modelStatusFadeTimer) { clearTimeout(_modelStatusFadeTimer); _modelStatusFadeTimer = null; }

      var label;
      if (state === 'thinking')       label = BatLang.t('status.thinking');
      else if (state === 'streaming') label = BatLang.t('status.streaming');
      else if (state === 'retry')     label = BatLang.t('status.retry');
      else if (state === 'latency')   label = '\u26A1 ' + (meta.totalMs != null ? meta.totalMs + 'ms' : '');
      else { state = 'ready';         label = BatLang.t('status.ready'); }

      slot.className = 'home-model-status is-' + state;
      slot.onclick = null;
      slot.onkeydown = null;
      slot.removeAttribute('role');
      slot.removeAttribute('tabindex');
      slot.removeAttribute('title');

      // Rebuild children via textContent (never innerHTML) so a translation
      // string can't inject markup.
      slot.textContent = '';
      var dot = document.createElement('span'); dot.className = 'hms-dot';
      var txt = document.createElement('span'); txt.className = 'hms-text'; txt.textContent = label;
      slot.appendChild(dot); slot.appendChild(txt);
      slot.setAttribute('aria-label', label);

      if (state === 'retry') {
        slot.setAttribute('role', 'button');
        slot.setAttribute('tabindex', '0');
        slot.onclick = retryLastHomeTurn;
        slot.onkeydown = function (e) {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); retryLastHomeTurn(); }
        };
      } else if (state === 'latency') {
        if (meta.ttftMs != null) slot.setAttribute('title', 'First token: ' + meta.ttftMs + 'ms');
        _modelStatusFadeTimer = setTimeout(function () { setModelStatus('ready'); }, 2000);
      }
    }

    function retryLastHomeTurn() {
      if (homeConvBusy || !_lastHomeTurn) return; // ignore retry-of-retry while a turn is in flight
      setModelStatus('ready');                    // homeConvSend() will flip it back to thinking
      homeConvSend(_lastHomeTurn.prompt, _lastHomeTurn.images, undefined, _lastHomeTurn.imageNames);
    }

    /* Fetches and renders the assistant's chat reply for a turn that's
       already been appended to the UI/history via homeConvBeginUserTurn.
       `images` (optional): an array of base64 data-URLs (up to 10) for
       attached images — forwarded to the chat route for Moondream
       preprocessing (see applyImagePreprocessing() in worker/worker.js).
       The reply now streams in token-by-token (see streamChatReply() in
       worker/worker.js) directly into the "thinking" bubble
       homeConvBeginUserTurn() already created via
       hcmBeginAssistantStreamingBubble() — it morphs in place into the
       final reply instead of a separate bubble appearing once the whole
       reply is ready. */
    async function homeConvGetReply(prompt, images, imageNames, forceWantThinking) {
      const msgs = document.getElementById('homeConvMessages');
      const streamRow = _homeStreamingBubbleRow;
      const streamBubble = streamRow ? streamRow.querySelector('.hcm-bubble') : null;
      const streamAvatar = streamRow ? streamRow.querySelector('.hcm-avatar') : null;

      homeConvBusy = true;
      homeConvAbortController = new AbortController();
      setHomeSendBtnBusy(true);
      hcmSetUserActionsGated('homeConvMessages', true);
      renderHomeProjectsGrid();

      // Reasoning-depth tier picked by the user via the Effort selector.
      // Independent from the Memory toggle — see effort/memory gating below.
      let effortLevel = 'Medium';
      try { effortLevel = localStorage.getItem('batlab_effort') || 'Medium'; } catch (e) {}

      let firstTokenSeen = false;
      let liveText = ''; // updated on every streamed tick, incl. mid-abort

      // ── "Thought for Xs" reasoning widget ──
      // Gated to substantive requests (isSubstantiveForThinking) and skipped on
      // Low effort (Low is the cost-minimized tier — it already skips memory/
      // title background calls, so it skips this nicety too). Two honest paths:
      //   • Core (bat 1.2 Core) surfaces its OWN real reasoning inline via the
      //     <REASONING> tag streamed ahead of the answer (see worker.js).
      //   • Every other model makes one real, flat-0 /chat/reason call first.
      // Never fabricates: if no reasoning is captured, the widget degrades to a
      // timing-only chip (see hcmCreateThinkingWidget honest-degrade).
      // A clarify-answer's own text (e.g. a short option label, or "Skip") is
      // often too short/generic to pass isSubstantiveForThinking on its own —
      // forceWantThinking carries forward that the ORIGINAL prompt which
      // produced the clarify card already qualified, so the widget still
      // shows for this follow-up reply (see hcmAnswerClarify).
      const _wantThinking = effortLevel !== 'Low' && (isSubstantiveForThinking(prompt) || !!forceWantThinking);
      const _isCoreModel = (selectedModel === 'BAT 1.2 Core');
      let _thinkWidget = null;   // live Core widget (inline path)
      let _thinkDone = false;    // Core widget already finalized?
      let _thinkData = null;     // {text, secs} captured for persistence/reload
      let _thinkWidgetEl = null; // widget DOM node (both paths) for error cleanup

      // Top-bar status + client-side latency timing. _mySeq guards against a
      // late-resolving older turn stomping a newer one's status.
      var _mySeq = ++_modelStatusSeq;
      _lastHomeTurn = { prompt: prompt, images: images, imageNames: imageNames };
      var tSend = 0, tFirstToken = 0, tDone = 0;

      try {
        // Send only {role, content} to the chat API — strip any local-only
        // metadata (e.g. the `gen` file snapshot) so restored sessions don't
        // ship large HTML blobs to the gateway. `images` (if attached) rides
        // alongside as an array (up to 10) — the worker runs all of them
        // through Moondream in parallel before the main chat model sees the
        // text (Sequential Pipeline).
        // Non-Core substantive: run the real flat-0 background reasoning first so
        // the "Thought for Xs" widget shows genuine thinking above the reply
        // before the answer streams (serial "thinking → answering" UX). The call
        // is a cheap fast model and never blocks/charges the real reply — flat-0,
        // silent, and self-degrading on failure (see runThinkingReasoning).
        if (_wantThinking && !_isCoreModel) {
          _thinkData = await runThinkingReasoning({ prompt: prompt, containerId: 'homeConvMessages', beforeEl: streamRow });
          _thinkWidgetEl = _thinkData && _thinkData.el;
        }
        tSend = performance.now();
        setModelStatus('thinking');
        // Core substantive: create the live widget now — it fills from the inline
        // <REASONING> deltas during streaming (below) and finalizes the instant
        // the visible answer begins.
        if (_wantThinking && _isCoreModel && msgs) {
          _thinkWidget = hcmCreateThinkingWidget('homeConvMessages');
          if (_thinkWidget && _thinkWidget.el && streamRow && streamRow.parentNode === msgs) {
            msgs.insertBefore(_thinkWidget.el, streamRow);
          }
          _thinkWidgetEl = _thinkWidget && _thinkWidget.el;
        }
        const { res } = await gatewayFetch(chatRoutePath(), Object.assign({
          system: getChatSystem(),
          messages: homeConvHistory.map(function (m) { return { role: m.role, content: m.content }; }),
          effort: effortLevel
        }, (Array.isArray(images) && images.length)
             ? { images: images, imageNames: (Array.isArray(imageNames) ? imageNames : []) }
             : {}), { signal: homeConvAbortController.signal });

        let rawText = await streamPlainText(res, function (acc) {
          liveText = acc;
          // Core inline reasoning → feed the live widget, then finalize it the
          // moment the visible answer starts (reasoning always precedes it).
          if (_thinkWidget) {
            const _rz = extractInlineReasoning(acc);
            if (_rz) _thinkWidget.setText(_rz);
            if (!_thinkDone) {
              const _vis = hcmSafeStreamText(hcmStripTruncationSentinel(acc).text);
              if (_vis && _vis.trim()) {
                _thinkDone = true;
                const _rs = _thinkWidget.setDone(); // degrades to timing-only if _rz empty
                _thinkData = { text: _rz, secs: (_rs || 1) };
              }
            }
          }
          if (!firstTokenSeen && acc) {
            firstTokenSeen = true;
            tFirstToken = performance.now();
            if (_mySeq === _modelStatusSeq) setModelStatus('streaming');
            if (streamAvatar) streamAvatar.classList.remove('is-thinking');
            stopHomeThinkingCycle();
          }
          if (streamBubble) {
            const safe = hcmSafeStreamText(hcmStripTruncationSentinel(acc).text);
            streamBubble.dir = uiTextDir();
            streamBubble.innerHTML = renderRichText(safe, false) + '<span class="hcm-cursor"></span>';
            if (msgs) msgs.scrollTop = msgs.scrollHeight;
          }
        });
        tDone = performance.now();

        // Core widget never finalized (e.g. a pure CLARIFY/IMPROVED_PROMPT reply
        // with no visible answer, or a reasoning-only stream): finalize now so it
        // doesn't spin. Degrades to a timing-only chip when no reasoning was seen.
        if (_thinkWidget && !_thinkDone) {
          _thinkDone = true;
          const _rs = _thinkWidget.setDone();
          _thinkData = { text: extractInlineReasoning(rawText), secs: (_rs || 1) };
        }

        const stripped = hcmStripTruncationSentinel(rawText);
        rawText = stripped.text;
        const wasTruncated = stripped.truncated;

        // Strip inline <REASONING>…</REASONING> unconditionally — independent
        // of the "Thought for Xs" widget gating above (_wantThinking), which
        // only controls whether the widget is SHOWN, never whether the raw
        // tag is removed from the reply. extractInlineReasoning() has already
        // captured the reasoning text into _thinkData by this point (both the
        // Core live-widget path at streaming time and the finalize fallback
        // above), so this is purely cleanup: without it, a gated-out reply
        // (isSubstantiveForThinking === false) would leak the raw tag straight
        // into the visible bubble, Supabase persistence, reload rendering, and
        // memory/title generation, since none of those ever ran the strip.
        rawText = rawText.replace(/<REASONING>[\s\S]*?<\/REASONING>/g, '');
        // Truncated-stream safety net: an opened-but-never-closed tag (stream
        // cut off mid-reasoning, e.g. hit token/length limit before the close
        // tag arrived) — drop from the open tag to the end, mirroring
        // hcmSafeStreamText's own open-without-close handling.
        const _reasonOpenIdx = rawText.indexOf('<REASONING>');
        if (_reasonOpenIdx !== -1) rawText = rawText.slice(0, _reasonOpenIdx);

        // Extract improved prompt if present
        const ipMatch = rawText.match(/<IMPROVED_PROMPT>([\s\S]*?)<\/IMPROVED_PROMPT>/);
        // Only surface "Build Now" when a build type is selected; plain chat stays plain.
        const improvedPrompt = (ipMatch && selectedType) ? ipMatch[1].trim() : null;
        let displayText = rawText.replace(/<IMPROVED_PROMPT>[\s\S]*?<\/IMPROVED_PROMPT>/, '').trim();
        // Extract clarifying-question widget if present
        let clarify = null;
        const cM = rawText.match(/<CLARIFY>([\s\S]*?)<\/CLARIFY>/);
        if (cM) {
          // A: tag-wrapped path — parse the inner JSON, retrying after a fence-strip
          // (weak models sometimes wrap the JSON in ```json fences inside the tags).
          const rawTag = cM[1].trim();
          try { clarify = JSON.parse(rawTag); }
          catch (e) { try { clarify = JSON.parse(stripJsonCodeFences(rawTag)); } catch (e2) { clarify = null; } }
          displayText = displayText.replace(/<CLARIFY>[\s\S]*?<\/CLARIFY>/, '').trim();
        } else {
          // Safety net: model dropped the <CLARIFY> tags but still emitted the bare JSON.
          clarify = detectBareClarifyJson(displayText);
          // B: retry the strict detector on a fence-stripped copy (the model dropped
          // the tags AND wrapped the bare JSON in a code fence).
          if (!clarify) {
            const unfenced = stripJsonCodeFences(displayText);
            if (unfenced !== (displayText || '').trim()) clarify = detectBareClarifyJson(unfenced);
          }
          if (clarify) {
            displayText = '';
          } else if (looksLikeClarifyJson(displayText)) {
            // C: still couldn't card-ify a lone clarify-shaped JSON — suppress the
            // raw JSON and show a neutral, non-fabricated fallback instead of leaking.
            displayText = BatLang.t('chat.clarifyFallback') || '';
          }
        }
        // Extract the trailing <STEPS> progress tag (if present) — a model-
        // authored, display-only summary of the work (never raw reasoning).
        // Parsed out here so its JSON never shows; rendered as a collapsible
        // card above the reply after the bubble is finalized (see below).
        let stepsData = null;
        const sM = rawText.match(/<STEPS>([\s\S]*?)<\/STEPS>/);
        if (sM) {
          let _sp = null;
          try { _sp = JSON.parse(sM[1].trim()); }
          catch (e) { try { _sp = JSON.parse(stripJsonCodeFences(sM[1].trim())); } catch (e2) { _sp = null; } }
          stepsData = sanitizeStepsPayload(_sp);
          displayText = displayText.replace(/<STEPS>[\s\S]*?<\/STEPS>/, '').trim();
        } else {
          // Safety net: tags dropped but bare steps JSON emitted as plain text.
          stepsData = detectBareStepsJson(displayText);
          if (stepsData) displayText = '';
        }
        const _asstMsg = { role: 'assistant', content: rawText, msgId: mintMsgId() };
        // Persist the "Thought for Xs" widget so it survives a reload (rebuilt via
        // hcmAppendSavedThinking). Empty text is kept when secs>0 so the honest
        // timing-only chip is faithfully restored too.
        if (_thinkData && _thinkData.secs) _asstMsg.think = { text: _thinkData.text || '', secs: _thinkData.secs };
        // Persist the parsed clarify object too (same gate as the live
        // hcmAppendClarify() call below) so a reload can rebuild the
        // interactive card instead of re-showing the raw tag/JSON as text.
        if (clarify && clarify.question && Array.isArray(clarify.options) && clarify.options.length >= 2) {
          // Stamp before persisting/appending — the live hcmAppendClarify()
          // call below reads the same object reference, so this covers both
          // the live card and the reload rebuild (hcmRenderSlice) with one write.
          clarify.wasSubstantive = _wantThinking;
          // msgId lets hcmAnswerClarify find this exact message back in
          // homeConvHistory later to persist the answered state (see there),
          // so a reload can't offer the card up for re-answering.
          clarify.msgId = _asstMsg.msgId;
          _asstMsg.clarify = clarify;
        }
        homeConvHistory.push(_asstMsg);
        saveHomeConvSession();   // ← persist to sidebar History after every reply
        // Low effort always skips memory-related calls and the (paid) title-
        // generation call, regardless of the Memory toggle — this is Low's own
        // cost-minimization rule, separate from the toggle's on/off logic used
        // at Medium/High. The truncated-message fallback title already covers
        // this case, so there's no functional loss.
        if (effortLevel !== 'Low' && isMemoryExtractionEligible(prompt)) maybeExtractMemory(prompt, rawText);
        // After the very first exchange, generate a smart title asynchronously.
        // Free (0-credit /chat/title route), so it runs at every effort level;
        // only pure greetings/small-talk are skipped (isTitleEligible), where the
        // truncated-message fallback title set in saveHomeConvSession() is fine.
        if (homeConvHistory.filter(m => m.role === 'user').length === 1 && isTitleEligible(homeConvHistory[0].content)) {
          generateChatTitle(homeConvHistory.concat([{ role: 'assistant', content: rawText }]), async function(title) {
            const s = homeChatSessions.find(function(x){ return x.id === homeConvSessionId; });
            if (s) {
              s.title = title;
              renderHomeChatHistory();
              updateHomeBreadcrumb();
              try { await supabase.from('chat_sessions').update({ title }).eq('id', homeConvSessionId); } catch(e){}
            }
            setPageTitle(title);
          });
        }
        if (streamAvatar) streamAvatar.classList.remove('is-thinking');
        stopHomeThinkingCycle();
        // Finalize the streaming bubble into a real assistant message: drop
        // the cursor, render the fully-parsed display text (tags already
        // stripped above), run code-block enhancement once (not per-tick,
        // unlike the throttled mid-stream renders above), and append the
        // reaction-buttons row hcmAppend() would normally add.
        if (streamRow && streamBubble) {
          if (displayText) {
            streamBubble.dir = uiTextDir();
            streamBubble.innerHTML = renderRichText(displayText, false);
            if (wasTruncated) {
              const note = document.createElement('div');
              note.className = 'hcm-truncated-note';
              note.textContent = BatLang.t('chat.truncatedNote');
              streamBubble.appendChild(note);
            }
            enhanceCodeBlocks(streamBubble);
            hcmAppendReactions(streamRow, prompt, (homeConvHistory[homeConvHistory.length - 1] || {}).msgId);
          } else {
            // Nothing visible to show (e.g. a pure <CLARIFY>/<IMPROVED_PROMPT>
            // reply) — remove the now-empty bubble instead of leaving a blank row.
            streamRow.remove();
          }
        } else if (displayText) {
          // Fallback for the rare case the streaming bubble wasn't found.
          hcmAppend('assistant', displayText, prompt, undefined, undefined, (homeConvHistory[homeConvHistory.length - 1] || {}).msgId);
        }
        _homeStreamingBubbleRow = null;
        // Progress-steps card: rendered ABOVE the reply bubble (insert before
        // streamRow when it's still in the list), matching the "steps → answer"
        // layout. Display-only summary — see appendStepsWidget / <STEPS>.
        if (stepsData && msgs) {
          appendStepsWidget(stepsData, msgs, (streamRow && streamRow.parentNode === msgs) ? streamRow : null);
        }
        // Show Build Now button if improved prompt detected
        if (improvedPrompt) {
          hcmAppendBuildBtn(improvedPrompt);
        }
        if (clarify && clarify.question && Array.isArray(clarify.options) && clarify.options.length >= 2) {
          hcmAppendClarify(clarify);
        }
        // A tall clarify card appended right after a short "Thought for Xs"
        // widget would otherwise get force-scrolled straight to the very
        // bottom, pushing the (now finished) widget above the visible top
        // edge the instant the card renders — looks like it vanished. Keep
        // the widget in view in that case; normal replies keep the usual
        // scroll-to-bottom behavior.
        if (_thinkWidgetEl && _thinkWidgetEl.isConnected && clarify) {
          _thinkWidgetEl.scrollIntoView({ block: 'start' });
        } else if (msgs) {
          msgs.scrollTop = msgs.scrollHeight;
        }
        // Flash the response latency, then it self-fades back to "Ready".
        if (_mySeq === _modelStatusSeq) {
          setModelStatus('latency', {
            totalMs: Math.max(1, Math.round(tDone - tSend)),
            ttftMs: tFirstToken ? Math.round(tFirstToken - tSend) : null
          });
        }
      } catch(err) {
        stopHomeThinkingCycle();
        // The turn failed/aborted before persisting a reply — drop any reasoning
        // widget so it isn't left orphaned above a missing/incomplete answer
        // (nothing was written to history, so it wouldn't survive a reload anyway).
        if (_thinkWidgetEl) { try { _thinkWidgetEl.remove(); } catch(e){} }
        const isNoCredits = err && err.message === 'no_credits';
        const isRateLimited = err && err.message === 'rate_limited';
        if (err && err.name === 'AbortError') {
          // User pressed Stop — unlike before streaming, text may already be
          // visible on screen, so keep whatever streamed in so far in place
          // (just drop the cursor/spinner) instead of discarding it. Still
          // don't poison history with the unanswered turn, though, so a
          // retry/regenerate doesn't get confused by a half reply.
          if (streamRow && streamBubble) {
            if (streamAvatar) streamAvatar.classList.remove('is-thinking');
            const safe = hcmSafeStreamText(hcmStripTruncationSentinel(liveText).text);
            if (safe) {
              streamBubble.dir = uiTextDir();
              streamBubble.innerHTML = renderRichText(safe, false);
              enhanceCodeBlocks(streamBubble);
            } else {
              streamRow.remove();
            }
          }
          _homeStreamingBubbleRow = null;
          homeConvHistory.pop();
          // Stop is not an error — return the indicator straight to Ready.
          if (_mySeq === _modelStatusSeq) setModelStatus('ready');
        } else if (isNoCredits || isRateLimited) {
          // gatewayFetch already surfaced the out-of-credits screen / rate-limit
          // toast for these two cases — avoid double-showing an error bubble.
          hcmRemoveStreamingBubble();
          homeConvHistory.pop();
          // These have their own dedicated UI and retrying won't help right
          // now, so fall back to Ready rather than a misleading Retry.
          if (_mySeq === _modelStatusSeq) setModelStatus('ready');
        } else {
          hcmRemoveStreamingBubble();
          hcmAppend('assistant', BatLang.t('toast.chatError'), prompt);
          // A real failure (network / generation) — offer a clickable Retry.
          if (_mySeq === _modelStatusSeq) setModelStatus('retry');
        }
        saveHomeConvSession();   // still save so nothing is lost
      }

      homeConvBusy = false;
      homeConvAbortController = null;
      setHomeSendBtnBusy(false);
      hcmSetUserActionsGated('homeConvMessages', false);
      renderHomeProjectsGrid();
    }

    /* Swaps a user bubble's rendered content for an inline edit textarea
       (Edit & Resend). Cancel restores the original bubble HTML; Save also
       restores the original bubble (nothing existing is removed or changed)
       and sends the edited text as a brand-new user turn appended at the end
       of the conversation, via the normal send pipeline (hcmCommitEdit). */
    function hcmStartEditUserMessage(index, div, bubble) {
      if (homeConvBusy) return;
      const entry = homeConvHistory[index];
      if (!entry || entry.role !== 'user') return;
      const originalHTML = bubble.innerHTML;

      bubble.innerHTML = '';
      const wrap = document.createElement('div');
      wrap.className = 'hcm-edit-wrap';
      const ta = document.createElement('textarea');
      ta.className = 'hcm-edit-textarea';
      ta.value = entry.content || '';
      const actions = document.createElement('div');
      actions.className = 'hcm-edit-actions';
      const cancelBtn = document.createElement('button');
      cancelBtn.type = 'button';
      cancelBtn.className = 'hcm-edit-btn';
      cancelBtn.textContent = BatLang.t('chat.cancelBtn') || 'Cancel';
      cancelBtn.addEventListener('click', function () { bubble.innerHTML = originalHTML; });
      const saveBtn = document.createElement('button');
      saveBtn.type = 'button';
      saveBtn.className = 'hcm-edit-btn primary';
      saveBtn.textContent = BatLang.t('chat.saveResendBtn') || 'Save & resend';
      saveBtn.addEventListener('click', function () {
        const newText = ta.value.trim();
        if (!newText) return;
        bubble.innerHTML = originalHTML; // leave the original message untouched
        hcmCommitEdit(newText, entry.images);
      });
      actions.appendChild(cancelBtn);
      actions.appendChild(saveBtn);
      wrap.appendChild(ta);
      wrap.appendChild(actions);
      bubble.appendChild(wrap);
      ta.focus();
      ta.setSelectionRange(ta.value.length, ta.value.length);
    }

    /* Commits an Edit & Resend (append-only): sends the edited text as a
       brand-new user turn at the END of the conversation — exactly as if the
       user typed and sent it fresh. Nothing existing is truncated, removed,
       or replaced; the original message stays put and a new one appears at
       the end. The original images ride along so the resent turn matches. */
    function hcmCommitEdit(newText, images) {
      if (homeConvBusy) return;
      homeConvSend(newText, images, undefined, undefined);
    }

    /* Regenerate (append-only): resends the original, unchanged user text as
       a brand-new user turn at the END of the conversation — exactly as if
       the user typed and sent it fresh right now. Nothing existing is
       touched, removed, or replaced. */
    function hcmRegenerateUserMessage(index) {
      if (homeConvBusy) return;
      const entry = homeConvHistory[index];
      if (!entry || entry.role !== 'user') return;
      homeConvSend(entry.content, entry.images, undefined, undefined);
    }

    /* ── Marketing view ──────────────────────────────────────────────────
       Standalone composer/model-routing/system-prompt/send logic for the
       Marketing tool (see plan). Deliberately does NOT call chatRoutePath(),
       getChatSystem(), or touch homeConvHistory/selectedModel/selectedType —
       it has its own history array, model state, and system prompt so it
       can't affect the existing Home chat/build flow. */

    const MARKETING_ATTACH_MAX_BYTES = 5 * 1024 * 1024; // 5MB — mirrors /marketing/extract's server-side cap
    const MARKETING_ALLOWED_EXT = ['pdf', 'docx', 'html', 'htm', 'css', 'md', 'txt', 'csv', 'xlsx', 'odt'];
    // Max number of files attachable to a single Marketing message (cumulative
    // across multiple attach-clicks). Each file is still extracted/billed
    // independently via its own /marketing/extract call — see plan.
    const MARKETING_ATTACH_MAX_FILES = 8;
    // Extensions read as plain text client-side and inlined directly into the
    // prompt, bypassing the /marketing/extract network call entirely (unlike
    // .html/.htm, which still go through server-side extraction/toMarkdown()).
    const MARKETING_TEXT_EXT = ['css', 'md', 'txt'];
    // Large .html/.htm attachments take long enough server-side (toMarkdown())
    // that they can occasionally trip Cloudflare's non-configurable edge timeout
    // (408). Warn the user at attach time — non-blocking, the file still attaches.
    const MARKETING_LARGE_HTML_BYTES = 180 * 1024; // ~180KB

    // True when the analysis target is a real website source (a live URL, or an
    // attached .html/.htm/.css file) — the trigger for requesting structured
    // <MKT_SCORES> output from the model (see plan). Other attachment types
    // (pdf/doc/docx/xlsx/odt) and idea-only briefs stay prose-only.
    function isWebsiteSource(url, attachedFiles) {
      if (url) return true;
      if (!attachedFiles || !attachedFiles.length) return false;
      return attachedFiles.some(function (f) { return /\.(html?|css)$/i.test(f.name || ''); });
    }

    // Small per-extension emoji used for both the pending-attachment chips and
    // the sent-message attachment cards (see MARKETING_ALLOWED_EXT).
    function marketingFileIcon(ext) {
      const MARKETING_FILE_ICONS = {
        pdf: '📕', docx: '📝', odt: '📃', md: '📑', txt: '📄',
        html: '🌐', htm: '🌐', css: '🎨', csv: '📈', xlsx: '📊'
      };
      return MARKETING_FILE_ICONS[ext] || '📄';
    }

    window.selectMarketingModel = function selectMarketingModel(model) {
      if (!modelAllowed(model)) { showPricingModal(); return; }
      marketingSelectedModel = model;
      const ecoBtn = document.getElementById('marketingModelEcoBtn');
      const primeBtn = document.getElementById('marketingModelPrimeBtn');
      if (ecoBtn) ecoBtn.classList.toggle('active-filter', model === 'BAT 2.2');
      if (primeBtn) primeBtn.classList.toggle('active-filter', model === 'BAT 2.2 Prime');
      updateMarketingCostPreview();
    }

    // Keeps BAT 2.2 Prime's lock icon in sync with the user's plan (Starter
    // can use BAT 2.2 but not Prime), and falls back to BAT 2.2 if a
    // previously-selected Prime is no longer accessible (e.g. plan
    // downgraded mid-session). Mirrors syncModelLockUI() above - the
    // fallback is done INLINE (not via window.selectMarketingModel()),
    // because this can run from the page-load IIFE before that
    // window.selectMarketingModel assignment further down the file has
    // executed yet.
    function syncMarketingModelLockUI() {
      const ecoBtn = document.getElementById('marketingModelEcoBtn');
      const primeBtn = document.getElementById('marketingModelPrimeBtn');
      if (primeBtn) primeBtn.classList.toggle('locked', !modelAllowed('BAT 2.2 Prime'));
      if (!modelAllowed(marketingSelectedModel)) {
        marketingSelectedModel = 'BAT 2.2';
        if (ecoBtn) ecoBtn.classList.toggle('active-filter', true);
        if (primeBtn) primeBtn.classList.toggle('active-filter', false);
        if (typeof updateMarketingCostPreview === 'function') updateMarketingCostPreview();
      }
    }
    window.syncMarketingModelLockUI = syncMarketingModelLockUI;

    // Mirrors chatRoutePath() above, for the separate "BAT 2.2" model family:
    // BAT 2.2 (eco) hits the new Gemma-backed /chat/marketing-eco route;
    // BAT 2.2 Prime reuses the existing Kimi-backed /chat route as-is (zero
    // backend routing change needed for that tier).
    function marketingChatRoutePath() {
      return marketingSelectedModel === 'BAT 2.2' ? '/chat/marketing-eco' : '/chat';
    }

    function updateMarketingCostPreview() {
      const el = document.getElementById('marketingCostPreview');
      if (!el) return;
      const service = marketingSelectedModel === 'BAT 2.2' ? 'chat_marketing_eco' : 'chat_marketing_prime';
      el.textContent = SERVICE_COST_INFO[service] ? formatCostPreview(service) : '';
    }

    // Fully standalone system prompt — intentionally NOT routed through
    // getChatSystem() (see plan) so build-mode / general-chat prompt logic
    // is never touched by this feature.
    // `structuredMode` (see isWebsiteSource()) asks the model to append a
    // machine-readable <MKT_SCORES> tag after its normal prose analysis,
    // mirroring the existing <CLARIFY> tag convention used by the Home chat.
    function getMarketingSystemPrompt(structuredMode, model) {
      const _today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const _structuredBlock = structuredMode ? `

Since this is a website analysis (a URL or an HTML/CSS source was provided), after your normal prose analysis, ALSO end your reply with a single machine-readable tag in this exact format (no markdown fences, no extra text inside the tag, valid JSON only):
<MKT_SCORES>{"title":"<short 3-8 word title for this analysis, in the user's language>","scores":{"uiux":<integer 0-100>,"seo":<integer 0-100>,"performance":<integer 0-100>,"marketing_readiness":<integer 0-100>},"competition":"<Low|Medium|High>","growth_potential":"<Low|Medium|High>","category":"<one of: SEO, Competitors, Ads, Branding, Pricing, Ideas, Funnels, Social Media>","tags":["<short tag, in the user's language>","<short tag, in the user's language>"],"recommendations":["<short actionable recommendation, in the user's language>","<short actionable recommendation, in the user's language>","<short actionable recommendation, in the user's language>"]}</MKT_SCORES>
- "title" is a short, human-readable label for this specific analysis (e.g. "batnxt.com — Website & SEO Review"), suitable for a history list — not a restatement of these instructions.
- "uiux" scores the site's UI/UX quality (layout, clarity, accessibility, visual design).
- "seo" scores its SEO fundamentals (titles, meta tags, headings, semantic structure, content quality) based only on what's visible in the provided content.
- "performance" scores technical/perceived performance signals inferable from the markup and assets alone (asset weight, render-blocking patterns, image optimization, script placement) — do not fabricate real device or network metrics you cannot observe.
- "marketing_readiness" scores how conversion-ready the page is: clarity of the value proposition, strength/visibility of calls-to-action, and presence of trust signals.
- "competition" is your qualitative estimate of how competitive this site's market/niche appears to be — exactly one of Low, Medium, or High.
- "growth_potential" is your qualitative estimate of the site's growth potential given its current state — exactly one of Low, Medium, or High.
- "category" classifies the PRIMARY focus of this analysis — exactly one of: SEO, Competitors, Ads, Branding, Pricing, Ideas, Funnels, Social Media.
- "tags" is a flat array of 1-5 short (1-3 word) freeform labels relevant to this analysis.
- "recommendations" is a flat array of 3-5 short, concrete, actionable improvement suggestions.
- Every free-text string in this JSON — "title", each "tags" entry, and especially every "recommendations" entry — MUST be written in the same language as your prose analysis above (the user's language), not English by default. Recommendations are user-facing analysis content, not internal labels — treat their language requirement exactly like the rest of your reply.
- This tag is never shown to the user as-is — it is parsed out of your reply — so it must appear exactly once, at the very end, after all prose.` : '';
      // BAT 2.2 (Gemma) is prone to dropping wrapper tags around JSON — mirrors
      // the `_clarifyStrict` reinforcement used for BAT 1.2 Flash in getChatSystem().
      const _mktStrict = (structuredMode && model === 'BAT 2.2')
        ? ' STRICT FORMAT — this applies to you specifically: the <MKT_SCORES>...</MKT_SCORES> wrapper tags around the JSON are mandatory, not optional. Never output the JSON object by itself without the surrounding <MKT_SCORES> and </MKT_SCORES> tags, and never describe the scores in plain prose instead of using the tag.'
        : '';
      // BAT 2.2 (Gemma) is also prone to defaulting to the language of the
      // extracted reference content (e.g. English site markup) instead of the
      // UI-language instruction above, especially when the user typed no text
      // of their own. Repeating the instruction again at the very end — the
      // same "say it twice for Gemma" pattern as `_mktStrict` above — makes
      // correct behavior consistent rather than probabilistic.
      const _mktLangStrict = (model === 'BAT 2.2')
        ? ' LANGUAGE REMINDER — this applies to you specifically: the extracted reference content below (if any) is third-party source material, not the user\u2019s own words, and its language must NOT influence what language you reply in. Follow the interface-language instruction above regardless of what language the extracted content or URL happens to be in.'
        : '';
      return `You are a senior marketing strategist and analyst inside BatNXT's "Marketing" tool.
CURRENT DATE: Today is ${_today}.

Your job: given a short brief, and optionally the extracted text/markdown content of a website or document the user attached, produce a clear, actionable marketing analysis. Depending on what's asked, this may include: target audience, positioning, key messaging, strengths/weaknesses, suggested channels, content ideas, or a short campaign outline.

Guidelines:
- If reference content (from a URL or uploaded file) is included below, ground your analysis in it — quote or point to specific parts when relevant, don't invent facts about the source that aren't there.
- Content extracted from a URL or an HTML/document upload is auto-converted to markdown before reaching you. This conversion ALWAYS strips <script> and <style> content and all inline styling — this happens whether the original page has rich CSS or none, so you have no way to tell which case you're in. NEVER claim a page "has no CSS/styling" or judge visual design quality from extracted HTML/URL content — you structurally cannot see it. If asked about visual design/UI polish from a URL or HTML upload, say plainly that styling can't be assessed from the extracted content, and confine your observations to what the markdown actually preserves (heading structure, body copy, links, image alt text, meta tags, structured data). Exception: if the user separately attaches a .css file, its content appears in full below and reflects real styling — analyze that directly.
- Beyond that limitation, engage with the extracted content like an analyst doing a real audit, not by summarizing or quoting it back. Actively call out concrete, verifiable gaps: a missing or empty meta description, no page title, no clear H1/heading hierarchy, no visible call-to-action text or link, images with no alt text, thin body copy, or no structured data (JSON-LD). State these as findings ("No meta description was found, which will hurt how this page's link preview appears in search results and shares") rather than describing the extracted text itself.
- Be concise and structured (headings/bullet points), avoid filler.
- If the user's brief is too vague to give a useful answer, ask ONE clarifying question instead of guessing.
- ${currentUiLanguageInstruction()} The language of any extracted reference content (from a URL or uploaded file) does NOT indicate the user's own language preference — that content is third-party source material, not something the user wrote. Only the user's own typed message (if any) can trigger the override to a different language described above; extracted content alone never does.${_structuredBlock}${_mktStrict}${_mktLangStrict}`;
    }

    window.marketingAttachFile = function marketingAttachFile() {
      const input = document.getElementById('marketingFileInput');
      if (input) input.click();
    };

    // Lightweight client-side magic-byte / text-sanity check, run before we
    // accept a file — catches corrupted or mislabeled uploads (e.g. a .txt
    // renamed to .pdf) that the extension check alone can't. Fails open on
    // read errors (returns true) so a browser quirk never blocks a
    // legitimate upload; the server-side /marketing/extract validation is
    // still the authoritative check either way.
    async function marketingCheckFileSignature(file, ext) {
      try {
        if (ext === 'pdf' || ext === 'doc' || ext === 'docx' || ext === 'xlsx' || ext === 'odt') {
          const header = new Uint8Array(await file.slice(0, 8).arrayBuffer());
          const hex = Array.prototype.map.call(header, function (b) { return b.toString(16).padStart(2, '0'); }).join('');
          if (ext === 'pdf') return hex.indexOf('25504446') === 0; // %PDF
          if (ext === 'doc') return hex.indexOf('d0cf11e0a1b11ae1') === 0; // legacy OLE header
          return hex.indexOf('504b0304') === 0; // docx/xlsx/odt are zip-based (PK\x03\x04)
        }
        // html/htm/css/csv: lenient text-sanity heuristic — no null bytes,
        // and the sample decodes as valid UTF-8.
        const sample = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
        if (sample.indexOf(0) !== -1) return false;
        try {
          new TextDecoder('utf-8', { fatal: true }).decode(sample);
        } catch (e) {
          return false;
        }
        return true;
      } catch (e) {
        return true;
      }
    }

    // Reads a single File as text or base64, resolving once marketingAttachedFiles
    // has the new entry pushed. Used by marketingFileSelected()'s per-file loop.
    function marketingReadAttachFile(file, ext) {
      return new Promise(function (resolve) {
        if (MARKETING_TEXT_EXT.indexOf(ext) !== -1) {
          // .css bypasses /marketing/extract entirely — read as plain text and
          // inline it directly into the prompt (see isWebsiteSource() / plan).
          const reader = new FileReader();
          reader.onload = function () {
            marketingAttachedFiles.push({ name: file.name, text: String(reader.result || ''), size: file.size });
            resolve();
          };
          reader.onerror = function () {
            showToast(BatLang.t('toast.chatError'), 'error');
            resolve();
          };
          reader.readAsText(file);
        } else {
          const reader = new FileReader();
          reader.onload = function () {
            // reader.result is a "data:<mime>;base64,<data>" URL — strip the prefix.
            const b64 = String(reader.result).split(',')[1] || '';
            marketingAttachedFiles.push({ name: file.name, base64: b64, size: file.size });
            resolve();
          };
          reader.onerror = function () {
            showToast(BatLang.t('toast.chatError'), 'error');
            resolve();
          };
          reader.readAsDataURL(file);
        }
      });
    }

    window.marketingFileSelected = async function marketingFileSelected(event) {
      const input = event && event.target;
      const files = input && input.files ? Array.from(input.files) : [];
      if (!files.length) return;

      const remainingSlots = MARKETING_ATTACH_MAX_FILES - marketingAttachedFiles.length;
      if (remainingSlots <= 0) {
        showToast(BatLang.t('marketing.maxFilesReached') || 'You can attach up to 8 files.', 'error');
        if (input) input.value = '';
        return;
      }
      const toProcess = files.slice(0, remainingSlots);
      if (files.length > toProcess.length) {
        showToast(BatLang.t('marketing.maxFilesReached') || 'You can attach up to 8 files.', 'error');
      }

      for (const file of toProcess) {
        const ext = (file.name.split('.').pop() || '').toLowerCase();
        if (MARKETING_ALLOWED_EXT.indexOf(ext) === -1) {
          showToast(BatLang.t('marketing.badFileTypeGeneric') || "Sorry, this file type isn't supported yet", 'error');
          continue;
        }
        if (file.size > MARKETING_ATTACH_MAX_BYTES) {
          showToast((BatLang.t('marketing.fileTooLargeNamed') || '{name} is too large (max 5MB).').replace('{name}', file.name), 'error');
          continue;
        }
        const sigOk = await marketingCheckFileSignature(file, ext);
        if (!sigOk) {
          showToast(BatLang.t('marketing.badFileTypeGeneric') || "Sorry, this file type isn't supported yet", 'error');
          continue;
        }
        // Non-blocking heads-up: large HTML can be slow to extract server-side and
        // may hit Cloudflare's edge timeout. File is still attached below.
        if ((ext === 'html' || ext === 'htm') && file.size > MARKETING_LARGE_HTML_BYTES) {
          showToast((BatLang.t('marketing.largeHtmlWarnNamed') || 'Large HTML file "{name}" may take longer to process and can occasionally time out.').replace('{name}', file.name), 'warning');
        }
        await marketingReadAttachFile(file, ext);
      }

      marketingRenderAttachedFileChips();
      if (input) input.value = '';
    };

    // Renders the pending-attachment chip list in the composer, one chip per
    // marketingAttachedFiles entry, each with a click-to-preview name and a
    // per-file remove button.
    function marketingRenderAttachedFileChips() {
      const wrap = document.getElementById('marketingAttachedFileChips');
      if (!wrap) return;
      wrap.innerHTML = '';
      marketingAttachedFiles.forEach(function (f, i) {
        const ext = (f.name.split('.').pop() || '').toLowerCase();
        const chip = document.createElement('span');
        chip.className = 'mkt-file-chip';
        const nameEl = document.createElement('span');
        nameEl.className = 'mkt-file-chip-name';
        nameEl.textContent = marketingFileIcon(ext) + ' ' + f.name;
        nameEl.onclick = function () { window.marketingPreviewAttach(marketingAttachedFiles[i]); };
        const rmBtn = document.createElement('button');
        rmBtn.type = 'button';
        rmBtn.className = 'mkt-file-chip-remove';
        rmBtn.innerHTML = '✕';
        rmBtn.setAttribute('aria-label', 'Remove ' + f.name);
        rmBtn.onclick = function (e) { e.stopPropagation(); window.marketingRemoveAttachedFile(i); };
        chip.appendChild(nameEl);
        chip.appendChild(rmBtn);
        wrap.appendChild(chip);
      });
    }

    window.marketingRemoveAttachedFile = function marketingRemoveAttachedFile(index) {
      marketingAttachedFiles.splice(index, 1);
      marketingRenderAttachedFileChips();
    };

    // Builds the attachment-card list shown inside a sent user message bubble
    // (Feature 2 — see plan). One .mkt-file-card per attached file.
    function marketingBuildFileCardList(attachments) {
      const list = document.createElement('div');
      list.className = 'mkt-file-card-list';
      attachments.forEach(function (f) {
        const ext = (f.name.split('.').pop() || (f.ext || '')).toLowerCase();
        const card = document.createElement('div');
        card.className = 'mkt-file-card';
        // Close over this file's own snapshot object (attachments is the
        // slice() taken at send time), so preview still works after the live
        // marketingAttachedFiles array is cleared post-send. Reopened
        // conversations (mktHistoryOpen) only ever pass lightweight
        // {name, ext} metadata — no .text/.base64 — since the full file
        // content is intentionally never persisted, so those cards render
        // as static/non-interactive instead of wiring up a dead-end preview.
        const hasContent = f.text != null || f.base64 != null;
        if (hasContent) {
          card.style.cursor = 'pointer';
          card.title = BatLang.t('marketing.previewTitle') || 'Attached file';
          card.onclick = function () { window.marketingPreviewAttach(f); };
        }
        const icon = document.createElement('span');
        icon.className = 'mkt-file-card-icon';
        icon.textContent = marketingFileIcon(ext);
        const info = document.createElement('div');
        info.className = 'mkt-file-card-info';
        const nm = document.createElement('div');
        nm.className = 'mkt-file-card-name';
        nm.textContent = f.name;
        const tp = document.createElement('div');
        tp.className = 'mkt-file-card-type';
        tp.textContent = BatLang.t('marketing.fileLabel') || 'File';
        info.appendChild(nm);
        info.appendChild(tp);
        card.appendChild(icon);
        card.appendChild(info);
        list.appendChild(card);
      });
      return list;
    }

    function marketingAppend(role, text, attachments, index, msgId) {
      const wrap = document.getElementById('marketingMessages');
      if (!wrap) return;
      const isUser = role === 'user';
      // Defensive render-time safety net (mirrors hcmAppend's): strip any
      // leaked <REASONING>…</REASONING> before painting. Not currently a live
      // bug for Marketing (Gemma never emits it), but marketingRenderHistory()
      // feeds raw OLD persisted content straight through, so this stays a
      // permanent belt-and-suspenders for both surfaces.
      if (!isUser && text) {
        text = text.replace(/<REASONING>[\s\S]*?<\/REASONING>/g, '');
        const _rOpenIdx = text.indexOf('<REASONING>');
        if (_rOpenIdx !== -1) text = text.slice(0, _rOpenIdx);
      }
      const div = document.createElement('div');
      div.className = 'hcm-msg' + (isUser ? ' user' : '');
      if (isUser && index != null) div.dataset.msgIndex = index;
      if (msgId) div.dataset.msgId = msgId;
      const av = document.createElement('div');
      av.className = 'hcm-avatar' + (isUser ? '' : ' is-logo');
      if (isUser) {
        av.textContent = document.getElementById('avatarInitials')?.textContent || 'U';
      } else {
        av.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      }
      const bubble = document.createElement('div');
      bubble.className = 'hcm-bubble' + (isUser ? '' : ' md-content');
      bubble.dir = detectTextDir(text);
      if (isUser && attachments && attachments.length) {
        bubble.appendChild(marketingBuildFileCardList(attachments));
      }
      if (text) {
        const textWrap = document.createElement('div');
        textWrap.innerHTML = renderRichText(text, isUser);
        bubble.appendChild(textWrap);
      }
      if (!isUser) enhanceCodeBlocks(bubble);
      div.appendChild(av);
      div.appendChild(bubble);
      if (isUser && index != null) {
        // Copy/Edit/Regenerate hover row (user messages only) — index is
        // this message's position in marketingHistory, closed over here so
        // the click handlers stay correct after later truncations.
        div.appendChild(hcmBuildUserActionsRow(text || '', function () { return marketingBusy; },
          function () { marketingStartEditUserMessage(index, div, bubble); },
          function () { marketingRegenerateUserMessage(index); }));
      } else if (!isUser) {
        marketingAppendStarRow(div, msgId);
      }
      wrap.appendChild(div);
      wrap.scrollTop = wrap.scrollHeight;
      return div;
    }

    // Maps a score axis key (as emitted by the model in <MKT_SCORES>) to its
    // i18n label key and the "go deeper" follow-up phrase sent verbatim when
    // its chip is clicked (mirrors chatAnswerClarify's own-label-as-answer
    // convention — see window.marketingGoDeeper below).
    const MARKETING_SCORE_AXES = {
      uiux: { labelKey: 'marketing.scoreUiux', fallback: 'UI/UX', goDeeperKey: 'marketing.goDeeperUiux', goDeeperFallback: 'Go deeper on the UI/UX analysis' },
      seo: { labelKey: 'marketing.scoreSeo', fallback: 'SEO', goDeeperKey: 'marketing.goDeeperSeo', goDeeperFallback: 'Go deeper on the SEO analysis' },
      performance: { labelKey: 'marketing.scorePerformance', fallback: 'Performance', goDeeperKey: 'marketing.goDeeperPerformance', goDeeperFallback: 'Go deeper on the performance analysis' },
      marketing_readiness: { labelKey: 'marketing.scoreReadiness', fallback: 'Marketing readiness', goDeeperKey: 'marketing.goDeeperReadiness', goDeeperFallback: 'Go deeper on marketing readiness' }
    };
    function marketingScoreColor(v) {
      if (v >= 80) return 'var(--accent)';
      if (v >= 50) return '#f5a623';
      return 'var(--red)';
    }
    // Renders the CSS-only score gauges + recommendations list + one "Go
    // deeper" follow-up chip per axis, appended as a sibling row after the
    // assistant bubble — mirrors appendClarifyWidget()'s DOM-building style.
    function appendMarketingScoresWidget(scores, recommendations) {
      const wrap = document.getElementById('marketingMessages');
      if (!wrap || !scores) return;
      const card = document.createElement('div');
      card.className = 'mkt-scores-card';

      // Overall Score summary — computed client-side as the average of
      // whichever axes are present (not model-emitted), so it stays
      // consistent with the per-axis gauges below and works unchanged for
      // older saved rows that only have uiux/seo.
      const presentAxes = Object.keys(MARKETING_SCORE_AXES).filter(function (a) { return typeof scores[a] === 'number'; });
      if (presentAxes.length) {
        const overall = Math.round(presentAxes.reduce(function (sum, a) { return sum + scores[a]; }, 0) / presentAxes.length);
        const overallCard = document.createElement('div');
        overallCard.className = 'mkt-overall-card';
        const overallValue = document.createElement('div');
        overallValue.className = 'mkt-overall-value';
        overallValue.textContent = String(overall);
        overallValue.style.color = marketingScoreColor(overall);
        const overallLabel = document.createElement('div');
        overallLabel.className = 'mkt-overall-label';
        overallLabel.textContent = BatLang.t('marketing.overallScore') || 'Overall Score';
        overallCard.appendChild(overallValue);
        overallCard.appendChild(overallLabel);
        card.appendChild(overallCard);
      }

      const gauges = document.createElement('div');
      gauges.className = 'mkt-gauges';
      Object.keys(MARKETING_SCORE_AXES).forEach(function (axis) {
        if (typeof scores[axis] !== 'number') return;
        const meta = MARKETING_SCORE_AXES[axis];
        const v = Math.max(0, Math.min(100, Math.round(scores[axis])));
        const color = marketingScoreColor(v);
        const gauge = document.createElement('div');
        gauge.className = 'mkt-gauge';
        const ring = document.createElement('div');
        ring.className = 'mkt-gauge-ring';
        ring.style.background = 'conic-gradient(' + color + ' ' + (v * 3.6) + 'deg, rgba(255,255,255,0.08) 0deg)';
        const hole = document.createElement('div');
        hole.className = 'mkt-gauge-hole';
        hole.textContent = String(v);
        ring.appendChild(hole);
        const label = document.createElement('div');
        label.className = 'mkt-gauge-label';
        label.textContent = BatLang.t(meta.labelKey) || meta.fallback;
        gauge.appendChild(ring);
        gauge.appendChild(label);
        gauges.appendChild(gauge);
      });
      card.appendChild(gauges);

      if (recommendations && recommendations.length) {
        const recTitle = document.createElement('div');
        recTitle.className = 'mkt-rec-title';
        recTitle.textContent = BatLang.t('marketing.recommendations') || 'Recommendations';
        card.appendChild(recTitle);
        const recList = document.createElement('ul');
        recList.className = 'mkt-rec-list';
        recommendations.forEach(function (r) {
          const li = document.createElement('li');
          li.textContent = r;
          recList.appendChild(li);
        });
        card.appendChild(recList);
      }

      const chips = document.createElement('div');
      chips.className = 'mkt-chips';
      Object.keys(MARKETING_SCORE_AXES).forEach(function (axis) {
        if (typeof scores[axis] !== 'number') return;
        const meta = MARKETING_SCORE_AXES[axis];
        const chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'mkt-chip';
        chip.textContent = BatLang.t(meta.goDeeperKey) || meta.goDeeperFallback;
        chip.onclick = function () { window.marketingGoDeeper(axis, chip); };
        chips.appendChild(chip);
      });
      card.appendChild(chips);

      wrap.appendChild(card);
      wrap.scrollTop = wrap.scrollHeight;
    }

    // Follow-up chip handler — mirrors window.chatAnswerClarify's exact
    // pattern: set the chip's own label text as the literal message sent,
    // mark the card answered (greying out remaining chips), and reuse the
    // entire existing send pipeline. This turn has no url/qualifying
    // attachment, so isWebsiteSource() naturally returns false and the reply
    // stays prose-only (no re-triggered gauges) while still having full
    // score context via marketingHistory's stored raw text.
    window.marketingGoDeeper = function marketingGoDeeper(axis, btnEl) {
      const meta = MARKETING_SCORE_AXES[axis];
      if (!meta) return;
      const card = btnEl && btnEl.closest('.mkt-scores-card');
      if (card) {
        card.classList.add('answered');
        card.querySelectorAll('.mkt-chip').forEach(function (b) { b.classList.remove('selected'); });
        if (btnEl) btnEl.classList.add('selected');
      }
      const text = BatLang.t(meta.goDeeperKey) || meta.goDeeperFallback;
      const input = document.getElementById('marketingInput');
      if (input) input.value = text;
      _marketingGoDeeperPending = true;
      window.sendMarketingMessage();
    };

    // Text-decodable attachment extensions for the preview lightbox below —
    // matches the plan's "text-decodable types" list (html/htm/css/csv).
    // Note this is broader than MARKETING_TEXT_EXT, which only covers
    // extensions read as text client-side pre-send; html/htm/csv are still
    // sent as base64 (see marketingFileSelected) but can still be decoded
    // for a read-only preview here.
    const MARKETING_PREVIEWABLE_TEXT_EXT = ['html', 'htm', 'css', 'csv'];
    function marketingBase64ToText(b64) {
      try {
        const bytes = Uint8Array.from(atob(b64), function (c) { return c.charCodeAt(0); });
        return new TextDecoder('utf-8').decode(bytes);
      } catch (e) {
        return '';
      }
    }
    // Click-to-preview lightbox for the currently attached Marketing file —
    // adapted from homePreviewAttach()'s overlay structure/behavior, using
    // the ._mktAp* CSS classes (index.html) instead of injecting styles.
    // Text-decodable types get a read-only text preview; binary types get a
    // simple name/size info card (no PDF/DOCX rendering).
    // Takes a file OBJECT (not an index) so it works from both the pending
    // composer chips (which resolve marketingAttachedFiles[i] at click time)
    // AND the sent-message cards (which close over their own snapshot object).
    // Indexing the live array here would break sent cards, since that array is
    // emptied right after send (see sendMarketingMessage).
    window.marketingPreviewAttach = function marketingPreviewAttach(f) {
      if (!f) return;
      const ext = (f.name.split('.').pop() || '').toLowerCase();
      const isTextPreview = MARKETING_PREVIEWABLE_TEXT_EXT.indexOf(ext) !== -1;
      const isHtmlPreview = (ext === 'html' || ext === 'htm');
      const text = isTextPreview ? (f.text != null ? f.text : marketingBase64ToText(f.base64 || '')) : '';

      const old = document.getElementById('_mktApOverlay');
      if (old) old.remove();

      const overlay = document.createElement('div');
      overlay.id = '_mktApOverlay';
      overlay.className = '_mktApOverlay';
      overlay.addEventListener('click', function (e) { if (e.target === overlay) overlay.remove(); });

      const box = document.createElement('div');
      box.className = '_mktApBox';

      const head = document.createElement('div');
      head.className = '_mktApHead';
      const nameEl = document.createElement('span');
      nameEl.textContent = f.name;
      head.appendChild(nameEl);

      const actions = document.createElement('div');
      actions.className = '_mktApHeadActions';

      // Copy button — only for text-decodable previews. Reuses the exact
      // icon-swap/clipboard/revert pattern from enhanceCodeBlocks()'s code
      // block copy button (_copySvg/_checkSvg, 1600ms revert).
      if (isTextPreview) {
        const copyBtn = document.createElement('button');
        copyBtn.type = 'button';
        copyBtn.className = '_mktApCopyBtn';
        copyBtn.innerHTML = _copySvg + '<span>' + BatLang.t('chat.copyBtn') + '</span>';
        copyBtn.addEventListener('click', function () {
          const done = function () {
            copyBtn.classList.add('copied');
            copyBtn.innerHTML = _checkSvg + '<span>' + BatLang.t('chat.copiedBtn') + '</span>';
            setTimeout(function () {
              copyBtn.classList.remove('copied');
              copyBtn.innerHTML = _copySvg + '<span>' + BatLang.t('chat.copyBtn') + '</span>';
            }, 1600);
          };
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done).catch(function () {
              const ta = document.createElement('textarea');
              ta.value = text; document.body.appendChild(ta); ta.select();
              try { document.execCommand('copy'); } catch (e) {}
              document.body.removeChild(ta); done();
            });
          } else {
            const ta = document.createElement('textarea');
            ta.value = text; document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta); done();
          }
        });
        actions.appendChild(copyBtn);
      }

      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = '_mktApCloseBtn';
      closeBtn.innerHTML = '✕';
      closeBtn.setAttribute('aria-label', 'Close');
      closeBtn.addEventListener('click', function () { overlay.remove(); });
      actions.appendChild(closeBtn);
      head.appendChild(actions);

      const body = document.createElement('div');
      body.className = '_mktApBody';
      if (isHtmlPreview) {
        // Code/Preview tab strip at the top of the body. Preview renders the
        // raw HTML in a sandboxed iframe (allow-same-origin only, no
        // allow-scripts — user-supplied HTML is never executed as script).
        const tabs = document.createElement('div');
        tabs.className = '_mktApTabs';
        const codeTab = document.createElement('button');
        codeTab.type = 'button';
        codeTab.className = '_mktApTab active';
        codeTab.textContent = BatLang.t('marketing.previewCodeTab') || 'Code';
        const previewTab = document.createElement('button');
        previewTab.type = 'button';
        previewTab.className = '_mktApTab';
        previewTab.textContent = BatLang.t('marketing.previewLiveTab') || 'Preview';
        tabs.appendChild(codeTab);
        tabs.appendChild(previewTab);
        body.appendChild(tabs);

        const pre = document.createElement('pre');
        pre.className = '_mktApPre';
        pre.textContent = text;
        body.appendChild(pre);

        const frame = document.createElement('iframe');
        frame.className = '_mktApFrame';
        frame.setAttribute('sandbox', 'allow-same-origin');
        frame.style.display = 'none';
        body.appendChild(frame);

        codeTab.addEventListener('click', function () {
          codeTab.classList.add('active');
          previewTab.classList.remove('active');
          pre.style.display = '';
          frame.style.display = 'none';
        });
        previewTab.addEventListener('click', function () {
          previewTab.classList.add('active');
          codeTab.classList.remove('active');
          pre.style.display = 'none';
          frame.style.display = '';
          if (!frame.getAttribute('srcdoc')) frame.setAttribute('srcdoc', text);
        });
      } else if (isTextPreview) {
        const pre = document.createElement('pre');
        pre.className = '_mktApPre';
        pre.textContent = text;
        body.appendChild(pre);
      } else {
        const info = document.createElement('div');
        info.className = '_mktApInfo';
        info.textContent = (BatLang.t('marketing.previewTitle') || 'Attached file') + ': ' + f.name
          + (typeof f.size === 'number' ? ' (' + formatBytes(f.size) + ')' : '');
        body.appendChild(info);
      }

      box.appendChild(head);
      box.appendChild(body);
      overlay.appendChild(box);
      document.body.appendChild(overlay);

      function onKey(e) {
        if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', onKey); }
      }
      document.addEventListener('keydown', onKey);
    };

    // Maps the specific error strings /marketing/extract's deny() can surface
    // to localized, actionable messages. These arrive as err.message because
    // gatewayFetch throws Error(body.error) for any non-2xx response (see its
    // `if (!res.ok)` branch), so the catch block below sees the exact server
    // wording. Anything unrecognized (a chat-phase 'generation_failed', a
    // network error, etc.) falls through to the generic fallback.
    const MARKETING_EXTRACT_ERROR_KEYS = {
      'Unsupported file type': 'marketing.errUnsupportedType',
      'That file is too large': 'marketing.errFileTooLarge',
      'Invalid URL': 'marketing.errInvalidUrl',
      'Could not fetch that URL': 'marketing.errUrlFetch',
      'That URL redirects elsewhere and cannot be fetched directly': 'marketing.errUrlRedirect',
      'Could not extract content from that source': 'marketing.errExtract'
    };
    function marketingErrorText(rawMsg) {
      const key = rawMsg && MARKETING_EXTRACT_ERROR_KEYS[rawMsg];
      if (key) {
        const t = BatLang.t(key);
        if (t && t !== key) return t;
      }
      // Generalized fallback for messages we don't have a specific mapping
      // for. Internal error codes (e.g. 'no_credits', 'network_error',
      // 'generation_failed') are single snake_case tokens not meant for
      // display, so only surface unmapped text that looks like an actual
      // human-readable sentence (contains a space, isn't raw JSON, and is
      // reasonably short) — this covers future/unmapped deny() reasons from
      // /marketing/extract, including internal binding errors (e.g. the
      // Zod-style messages env.AI.toMarkdown() can throw), without ever
      // dumping raw JSON or internal codes to the user.
      if (rawMsg && typeof rawMsg === 'string') {
        const trimmed = rawMsg.trim();
        const looksLikeJson = trimmed.startsWith('{') || trimmed.startsWith('[');
        if (trimmed && !looksLikeJson && / /.test(trimmed) && trimmed.length <= 200) {
          return trimmed;
        }
      }
      return BatLang.t('marketing.extractFailed') || BatLang.t('toast.chatError');
    }

    // ── Marketing send/stop button + thinking-cycle (mirrors Home) ─────────
    // Only one marketing request can be in flight at a time. While busy, the
    // send button becomes a red Stop control (see setMarketingSendBtnBusy)
    // that aborts the in-flight reply, mirroring Home's homeConvAbortController
    // pattern — see homeConvGetReply().
    let marketingAbortController = null;
    window.marketingStopGenerating = function () {
      if (marketingAbortController) {
        try { marketingAbortController.abort(); } catch (e) {}
      }
    };
    // Dispatcher wired to the send button's onclick: sends a new message when
    // idle, or stops the in-flight reply when busy (mirrors homeSendOrStop).
    window.marketingSendOrStop = function () {
      if (marketingBusy) {
        window.marketingStopGenerating();
        return;
      }
      window.sendMarketingMessage();
    };
    const MARKETING_SEND_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
    // Red square (color supplied by .chat-send-btn.is-stop → var(--red)).
    const MARKETING_STOP_ICON = '<svg viewBox="0 0 24 24" width="16" height="16"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>';
    function setMarketingSendBtnBusy(busy) {
      const btn = document.getElementById('marketingSendBtn');
      if (!btn) return;
      btn.classList.toggle('is-stop', busy);
      btn.disabled = false; // stays clickable in both states (busy = Stop)
      btn.setAttribute('aria-label', busy ? 'Stop generating' : 'Send');
      btn.innerHTML = busy ? MARKETING_STOP_ICON : MARKETING_SEND_ICON;
    }

    // Contextual "thinking" status text for the marketing streaming bubble.
    // en + ar only for this pass (per approved scope) — any other UI language
    // falls back to English.
    //  - phase 'initial'   → up-front context line for `type`, shown while the
    //                        extraction phase (URL fetch / file read) is in
    //                        flight.
    //  - phase 'streaming' → shown once the real generation request has been
    //                        sent, before the first token arrives. Structured
    //                        (URL/HTML/CSS) turns cycle through report-stage
    //                        phrases; other turns keep the original generic
    //                        two-line alternation.
    function marketingStatusText(type, phase, stepIndex, structured) {
      const lang = (typeof BatLang !== 'undefined') ? BatLang.lang : 'en';
      const TYPE_MSG = {
        url:    { en: 'Fetching and reading the website...',           ar: 'جاري جلب الموقع وقراءته...' },
        file:   { en: 'Reading your file and understanding it...',     ar: 'جاري قراءة ملفك وفهمه...' },
        files:  { en: 'Reading your files and understanding them...',  ar: 'جاري قراءة ملفاتك وفهمها...' },
        deeper: { en: 'Digging deeper into the analysis...',           ar: 'جاري التعمق في التحليل...' },
        idea:   { en: 'Understanding and reading your request...',     ar: 'جاري فهم طلبك وقراءته...' },
        export: { en: 'Preparing your conversation file...',           ar: 'جاري تجهيز ملف محادثتك...' }
      };
      // Staged, report-aware phrases for structured (website/HTML/CSS)
      // turns — cycled while waiting for the model's first streamed token.
      const STRUCTURED_STEPS = [
        { en: 'Analyzing SEO...',              ar: 'جاري تحليل السيو...' },
        { en: 'Finding competitors...',         ar: 'جاري البحث عن المنافسين...' },
        { en: 'Building report...',             ar: 'جاري إعداد التقرير...' },
        { en: 'Generating recommendations...',  ar: 'جاري إعداد التوصيات...' }
      ];
      // Original generic alternation, kept for non-structured (idea-only /
      // plain document) turns where "Analyzing SEO..." etc. wouldn't apply.
      const GENERIC_STEPS = [
        { en: 'Building your marketing breakdown...', ar: 'جاري إعداد تحليلك التسويقي...' },
        { en: 'BatNXT is thinking...',                 ar: 'BatNXT يفكر...' }
      ];
      let entry;
      if (phase === 'streaming') {
        const steps = structured ? STRUCTURED_STEPS : GENERIC_STEPS;
        entry = steps[(stepIndex || 0) % steps.length];
      } else {
        entry = TYPE_MSG[type] || TYPE_MSG.idea;
      }
      return entry[lang] || entry.en;
    }
    var _marketingThinkingTimer = null;
    // Phase 1 (extraction): shows the up-front context line for `type` and
    // holds it steady. Extraction (a URL fetch or file read) is typically a
    // few seconds, so a single clear line ("Fetching and reading the
    // website...") reads better than flipping to a generic line mid-fetch.
    // Call marketingAdvanceThinkingPhase() once the real generation request
    // is sent to move into phase 2 (staged streaming-wait text).
    function startMarketingThinkingCycle(type) {
      clearTimeout(_marketingThinkingTimer);
      _marketingThinkingTimer = null;
      var el = document.getElementById('marketingTypingText');
      if (el) el.textContent = marketingStatusText(type, 'initial');
    }
    // Phase 2 (streaming-wait): the real generation request has been sent but
    // no token has arrived yet — cycle through staged phrases (SEO →
    // competitors → report → recommendations for structured/website turns;
    // the original generic two-line alternation otherwise) every 3-5s, with
    // the same fade transition as before, until stopMarketingThinkingCycle()
    // fires on the first streamed token (unchanged call sites/behavior).
    function marketingAdvanceThinkingPhase(structured) {
      clearTimeout(_marketingThinkingTimer);
      var step = 0;
      function showStep() {
        var el = document.getElementById('marketingTypingText');
        if (el) {
          el.style.opacity = '0';
          el.style.transition = 'opacity 0.25s';
          setTimeout(function () {
            el.textContent = marketingStatusText(null, 'streaming', step, structured);
            el.style.opacity = '1';
          }, 250);
        }
        step++;
      }
      function scheduleNext() {
        _marketingThinkingTimer = setTimeout(function () {
          showStep();
          scheduleNext();
        }, 3000 + Math.random() * 2000);
      }
      showStep();
      scheduleNext();
    }
    function stopMarketingThinkingCycle() {
      clearTimeout(_marketingThinkingTimer);
      _marketingThinkingTimer = null;
    }

    // Creates the inline "thinking → streaming" bubble inside #marketingMessages
    // (same .hcm-msg / .hcm-avatar.is-logo / .hcm-bubble structure marketingAppend
    // builds), reusing Home's .hcm-typing markup + #...TypingText id convention so
    // startMarketingThinkingCycle()/marketingStatusText() can target it by id.
    function marketingBeginThinkingBubble() {
      const wrap = document.getElementById('marketingMessages');
      if (!wrap) return null;
      const row = document.createElement('div');
      row.className = 'hcm-msg';
      const av = document.createElement('div');
      av.className = 'hcm-avatar is-logo is-thinking';
      av.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      const bubble = document.createElement('div');
      bubble.className = 'hcm-bubble md-content';
      bubble.innerHTML =
        '<div class="hcm-typing show">' +
          '<div class="hcm-typing-dots"><span></span><span></span><span></span></div>' +
          '<span class="hcm-typing-text" id="marketingTypingText">BatNXT is thinking...</span>' +
        '</div>';
      row.appendChild(av);
      row.appendChild(bubble);
      wrap.appendChild(row);
      wrap.scrollTop = wrap.scrollHeight;
      return row;
    }

    window.sendMarketingMessage = async function sendMarketingMessage() {
      if (marketingBusy) return;
      const input = document.getElementById('marketingInput');
      const urlInput = document.getElementById('marketingUrlInput');
      const prompt = (input && input.value || '').trim();
      const rawUrl = (urlInput && urlInput.value || '').trim();
      // Most users type a bare domain ("batnxt.com") with no protocol — the
      // server's /marketing/extract validates with `new URL()`, which throws
      // "Invalid URL" for a schemeless string. Default to https:// so a bare
      // domain resolves the way a user typing it into a browser address bar
      // would expect; leave anything that already has a scheme untouched.
      const url = rawUrl && !/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(rawUrl) ? 'https://' + rawUrl : rawUrl;
      // Snapshot before clearing marketingAttachedFiles further down.
      const attachedFiles = marketingAttachedFiles.slice();
      if (!prompt && !url && !attachedFiles.length) return;

      // Explicit conversation-export request — mirrors Home's AI-driven
      // exporter (shares buildExportSystemPrompt/formatTranscriptBody/
      // appendExportFileCard/startExportAnalyzingCard with Home). Skipped if
      // a URL or attachment is present (the user likely means to analyze
      // that source, not export the conversation).
      if (!url && !attachedFiles.length && marketingHistory.length > 0 && detectExportRequest(prompt)) {
        const exFormat = detectExportFormat(prompt);
        const exFullTranscript = detectFullTranscriptRequest(prompt);
        if (input) input.value = '';
        marketingClearEmptyState();
        marketingAppend('user', prompt, undefined, marketingHistory.length);
        marketingHistory.push({ role: 'user', content: prompt, msgId: mintMsgId() });
        const exStreamRow = marketingBeginThinkingBubble();
        startMarketingThinkingCycle('export');
        marketingExportConversationViaAI(exFormat, exFullTranscript, exStreamRow);
        return;
      }

      // URL or an .html/.htm/.css attachment = a real website source — ask the
      // model for structured <MKT_SCORES> output on this turn (see plan).
      const structuredMode = isWebsiteSource(url, attachedFiles);

      // Pick the up-front thinking-status context line for this turn. A
      // go-deeper follow-up (set by window.marketingGoDeeper) wins; otherwise
      // it's url > multi-file > single-file > idea-only.
      const thinkType = _marketingGoDeeperPending ? 'deeper'
        : url ? 'url'
        : attachedFiles.length > 1 ? 'files'
        : attachedFiles.length === 1 ? 'file'
        : 'idea';
      _marketingGoDeeperPending = false;

      marketingBusy = true;
      marketingAbortController = new AbortController();
      setMarketingSendBtnBusy(true);
      marketingSetUserActionsGated('marketingMessages', true);

      marketingClearEmptyState();
      let userDisplay = prompt || url || '';
      if (prompt && url) userDisplay = prompt + '\n\n' + url;
      marketingAppend('user', userDisplay, attachedFiles, marketingHistory.length);
      if (input) input.value = '';
      if (urlInput) urlInput.value = '';
      marketingAttachedFiles = [];
      marketingRenderAttachedFileChips();

      // Create the "thinking → streaming" bubble up-front (before extraction)
      // so the contextual status text shows immediately, then start the cycle.
      let streamRow = marketingBeginThinkingBubble();
      const streamAvatar = streamRow ? streamRow.querySelector('.hcm-avatar') : null;
      startMarketingThinkingCycle(thinkType);

      try {
        // Each attached file is validated/extracted independently via
        // Promise.allSettled — one file's extraction failure only rejects that
        // file (toast + skip), it does not abort the whole send. A URL failure
        // still aborts the whole send (throws below) since there's only one
        // URL slot per message.
        let extractedParts = [];
        if (url) {
          const { res: exRes } = await gatewayFetch('/marketing/extract', { url: url }, { signal: marketingAbortController.signal });
          const exData = await exRes.json();
          if (exData.error) throw new Error(exData.error);
          extractedParts.push(exData.markdown || '');
        }
        if (attachedFiles.length) {
          const results = await Promise.allSettled(attachedFiles.map(async function (f) {
            // .css (and any other MARKETING_TEXT_EXT type) was already read as
            // plain text client-side — inline it directly, no /marketing/extract
            // round-trip needed (see isWebsiteSource() / plan).
            if (f.text != null) return { name: f.name, markdown: f.text };
            const { res: exRes } = await gatewayFetch('/marketing/extract', {
              fileBase64: f.base64,
              fileName: f.name
            }, { signal: marketingAbortController.signal });
            const exData = await exRes.json();
            if (exData.error) throw new Error(exData.error);
            return { name: f.name, markdown: exData.markdown || '' };
          }));
          results.forEach(function (r, i) {
            if (r.status === 'fulfilled') {
              extractedParts.push('--- ' + r.value.name + ' ---\n' + r.value.markdown);
            } else {
              // .html/.htm extraction failures are almost always Cloudflare's edge
              // timeout on a heavy toMarkdown() — retrying the same file won't help,
              // so give an honest, specific message instead of "please try again".
              const failedName = attachedFiles[i].name;
              const failedExt = (failedName.split('.').pop() || '').toLowerCase();
              const timedOut = failedExt === 'html' || failedExt === 'htm';
              const msg = timedOut
                ? (BatLang.t('marketing.fileTimedOutNamed') || '{name} was too large or complex to process in time.')
                : (BatLang.t('marketing.fileExtractFailedNamed') || "Couldn't process {name}. Please try again.");
              showToast(msg.replace('{name}', failedName), 'error');
            }
          });
        }
        const extracted = extractedParts.join('\n\n');

        let combinedPrompt = prompt;
        if (extracted) {
          combinedPrompt = (prompt ? prompt + '\n\n' : '') + '--- Extracted content (auto-converted to markdown; scripts/styling are always stripped by this conversion, whether or not the source had any) ---\n' + extracted;
        }

        // content keeps the full extracted markdown (unchanged) so follow-up
        // turns still have complete context sent to the model. displayCaption
        // and attachments are lightweight (no file bytes/text) and exist only
        // so mktHistoryOpen() can re-render the original bubble + file card on
        // reopen without dumping the raw markdown as visible text (see plan).
        marketingHistory.push({
          role: 'user',
          content: combinedPrompt,
          displayCaption: userDisplay,
          attachments: attachedFiles.map(function (f) {
            return { name: f.name, ext: (f.name.split('.').pop() || '').toLowerCase() };
          }),
          msgId: mintMsgId()
        });
      } catch (err) {
        marketingHandleReplyError(err, streamRow, null, streamAvatar, document.getElementById('marketingMessages'), '', url);
        marketingBusy = false;
        marketingAbortController = null;
        setMarketingSendBtnBusy(false);
        marketingSetUserActionsGated('marketingMessages', false);
        return;
      }

      // Extraction (if any) succeeded and the user's turn is now in
      // marketingHistory — hand off to the shared reply-fetch tail (also
      // used, without an extraction phase, by Regenerate).
      await marketingGetReply(thinkType, structuredMode, url, streamRow, userDisplay);
    };

    // Marketing's AI-driven conversation exporter — a full parallel to
    // Home's exportConversationViaAI (kept as a separate flow function per
    // the codebase's Home/Marketing convention: stateful flows aren't
    // shared, only the pure helpers underneath are). Uses Marketing's own
    // busy/abort/gating primitives and marketingHistory array, but shares
    // buildExportSystemPrompt/formatTranscriptBody/startExportAnalyzingCard/
    // appendExportFileCard/downloadConversationMarkdown/exportConversationAsPdf
    // with Home. `streamRow` is the "thinking" bubble created by the caller
    // (marketingBeginThinkingBubble) just before this was invoked.
    async function marketingExportConversationViaAI(format, fullTranscript, streamRow) {
      marketingBusy = true;
      setMarketingSendBtnBusy(true);
      hcmSetUserActionsGated('marketingMessages', true);
      marketingAbortController = new AbortController();
      const analyzing = startExportAnalyzingCard(streamRow && streamRow.querySelector('.hcm-bubble'));
      try {
        // marketingHistory now ends with the user's raw export request
        // (pushed by the caller) — excluded from both paths below.
        const priorHistory = marketingHistory.slice(0, -1);
        let body;
        if (fullTranscript) {
          // Full-transcript opt-in: no AI call — same Analyzing-card/file-card/
          // persistence flow as the AI-summary path, synchronously-built body.
          body = formatTranscriptBody(priorHistory);
          if (!body) throw new Error('empty_export');
        } else {
          const messages = priorHistory
            .map(function (m) { return { role: m.role, content: (m.displayCaption != null ? m.displayCaption : m.content) }; })
            .concat([{ role: 'user', content: EXPORT_USER_INSTRUCTION }]);
          const { res } = await gatewayFetch('/chat/export', {
            system: buildExportSystemPrompt(),
            messages: messages
          }, { signal: marketingAbortController.signal });
          const data = await res.json();
          body = (data.markdown || '').trim();
          // Strip a whole-body code fence if a weaker model wrapped everything in ```.
          const fenced = body.match(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```$/i);
          if (fenced) body = fenced[1].trim();
          if (!body) throw new Error('empty_export');
        }
        analyzing.stop();
        stopMarketingThinkingCycle();
        if (streamRow && streamRow.parentNode) streamRow.parentNode.removeChild(streamRow);
        // Bug 1 fix: streamRow (just removed above) was the only thing
        // hosting the Analyzing card — re-add it as a standalone, persistent
        // collapsed/expandable card (same one marketingRenderHistory's
        // analyzingSteps branch recreates on reload) so live matches reload.
        hcmAppendSavedAnalyzingCard('marketingMessages');
        // Persist the Analyzing-card marker AND the actual file body/format
        // inline (same inline-persistence pattern as Home) so the
        // interactive file card survives a reload, not just its shell
        // (restored via marketingRenderHistory's exportBody branch).
        marketingHistory.push({
          role: 'assistant',
          content: BatLang.t('export.ready') || '',
          analyzingSteps: true,
          exportBody: body,
          exportFormat: format,
          msgId: mintMsgId()
        });
        await saveMarketingAnalysis({});
        appendExportFileCard('marketingMessages', marketingHistory, body, format);
      } catch (err) {
        analyzing.stop();
        stopMarketingThinkingCycle();
        if (streamRow && streamRow.parentNode) streamRow.parentNode.removeChild(streamRow);
        const m = err && err.message;
        if (err && err.name === 'AbortError') {
          // User pressed Stop — nothing to export, no error to show.
        } else if (m === 'no_credits' || m === 'rate_limited' || m === 'weekly_cap_reached' ||
                   m === 'lifetime_cap_reached' ||
                   m === 'banned' || m === 'recharge_on_cooldown' || m === 'not_authenticated') {
          // These already have their own dedicated UI (surfaced by gatewayFetch).
        } else {
          if (typeof showToast === 'function') showToast('⚠️ تعذّر التصدير الذكي — تم تصدير نسخة أساسية بدلاً منه.', 'info');
          if (format === 'pdf') exportConversationAsPdf(marketingHistory);
          else downloadConversationMarkdown(marketingHistory);
        }
      } finally {
        marketingBusy = false;
        marketingAbortController = null;
        setMarketingSendBtnBusy(false);
        hcmSetUserActionsGated('marketingMessages', false);
      }
    }

    // Shared error handling for a Marketing turn's extraction OR AI-call
    // phase (both call this identically — the original code didn't
    // distinguish between the two either). On abort: preserves any partial
    // streamed text as a real reply, or (nothing streamed yet, e.g. aborted
    // mid-extraction) drops the empty bubble and pops the unanswered user
    // turn. On a genuine error: drops the bubble, pops the unanswered user
    // turn, and shows an error bubble (unless gatewayFetch already surfaced
    // its own no-credits/rate-limit UI).
    function marketingHandleReplyError(err, streamRow, streamBubble, streamAvatar, streamWrap, liveText, urlForSave) {
      stopMarketingThinkingCycle();
      if (streamAvatar) streamAvatar.classList.remove('is-thinking');
      if (err && err.name === 'AbortError') {
        const safe = streamBubble ? marketingSafeStreamText(hcmStripTruncationSentinel(liveText || '').text) : '';
        if (streamBubble && safe) {
          streamBubble.dir = detectTextDir(safe);
          streamBubble.innerHTML = renderRichText(safe, false);
          enhanceCodeBlocks(streamBubble);
          if (streamWrap) streamWrap.scrollTop = streamWrap.scrollHeight;
          marketingHistory.push({ role: 'assistant', content: hcmStripTruncationSentinel(liveText || '').text, msgId: mintMsgId() });
          saveMarketingAnalysis({ sourceUrl: urlForSave || null, domain: urlForSave ? marketingDomainFromUrl(urlForSave) : null });
          if (streamRow) marketingAppendStarRow(streamRow, marketingHistory[marketingHistory.length - 1].msgId);
        } else {
          if (streamRow && streamRow.parentNode) streamRow.parentNode.removeChild(streamRow);
          if (marketingHistory.length && marketingHistory[marketingHistory.length - 1].role === 'user') marketingHistory.pop();
        }
      } else {
        if (streamRow && streamRow.parentNode) streamRow.parentNode.removeChild(streamRow);
        if (marketingHistory.length && marketingHistory[marketingHistory.length - 1].role === 'user') marketingHistory.pop();
        const isNoCredits = err && err.message === 'no_credits';
        const isRateLimited = err && err.message === 'rate_limited';
        if (!isNoCredits && !isRateLimited) {
          marketingAppend('assistant', marketingErrorText(err && err.message));
        }
      }
    }

    /* Fetches and renders a Marketing assistant reply for a turn that's
       already been appended to marketingHistory (content fully baked —
       any extraction already done and stored). Used both by the normal
       send flow (sendMarketingMessage, after extraction+push) and by
       Regenerate (which skips extraction entirely). Mirrors
       homeConvGetReply's split from its send/begin-turn wrapper.
       `streamRow` is the already-created "thinking" bubble (from
       marketingBeginThinkingBubble()); the caller is also responsible for
       marketingBusy/marketingAbortController/setMarketingSendBtnBusy/
       marketingSetUserActionsGated being set to the busy state before
       calling this — it resets all four, unconditionally, at the end. */
    async function marketingGetReply(thinkType, structuredMode, urlForSave, streamRow, shortPrompt) {
      const streamBubble = streamRow ? streamRow.querySelector('.hcm-bubble') : null;
      const streamAvatar = streamRow ? streamRow.querySelector('.hcm-avatar') : null;
      const streamWrap = document.getElementById('marketingMessages');
      let liveText = ''; // updated on every streamed tick, incl. mid-abort
      let firstTokenSeen = false;
      // "Thought for Xs" indicator (Marketing is always a non-Core model, so it
      // always uses the flat-0 background reasoning path — never inline). Gate on
      // the SHORT typed prompt, not the giant combinedPrompt with extracted
      // markdown, so a bare URL analysis with no idea text still gates sensibly.
      let _thinkData = null, _thinkWidgetEl = null;
      const _wantThinking = isSubstantiveForThinking(shortPrompt || '');

      try {
        // The real generation request is about to be sent — move the status
        // line into phase 2 (staged streaming-wait text) here, the true
        // extraction→streaming boundary (a no-op UX-wise for Regenerate,
        // which has no extraction phase to transition from).
        marketingAdvanceThinkingPhase(structuredMode);

        // Real background reasoning (flat-0) before the answer starts — surfaces
        // a genuine "Thought for Xs" chip above the reply. Honest-degrades to a
        // timing-only chip if the model returns nothing (never fabricated).
        if (_wantThinking) {
          _thinkData = await runThinkingReasoning({ prompt: shortPrompt, containerId: 'marketingMessages', beforeEl: streamRow });
          _thinkWidgetEl = _thinkData && _thinkData.el;
        }

        const { res } = await gatewayFetch(marketingChatRoutePath(), {
          system: getMarketingSystemPrompt(structuredMode, marketingSelectedModel),
          messages: marketingHistory.map(function (m) { return { role: m.role, content: m.content }; })
        }, { signal: marketingAbortController.signal });
        // /chat and /chat/marketing-eco stream plain text (see streamChatReply()
        // in worker/worker.js). Build the assistant bubble up-front and update it
        // progressively as tokens arrive — mirroring the Home chat's streaming
        // bubble — instead of buffering the whole stream and rendering once
        // (which made the reply pop in all at once).
        let rawText = await streamPlainText(res, function (acc) {
          liveText = acc; // captured so the catch can preserve partial text on abort
          if (!firstTokenSeen && acc) {
            firstTokenSeen = true;
            stopMarketingThinkingCycle();
            if (streamAvatar) streamAvatar.classList.remove('is-thinking');
          }
          if (!streamBubble) return;
          const safe = marketingSafeStreamText(hcmStripTruncationSentinel(acc).text);
          streamBubble.dir = detectTextDir(safe);
          streamBubble.innerHTML = renderRichText(safe, false) + '<span class="hcm-cursor"></span>';
          if (streamWrap) streamWrap.scrollTop = streamWrap.scrollHeight;
        }, 40);
        // Safety: an empty reply never fires the first-token transition above,
        // so stop the cycle and clear the thinking avatar here regardless.
        stopMarketingThinkingCycle();
        if (streamAvatar) streamAvatar.classList.remove('is-thinking');
        const stripped = hcmStripTruncationSentinel(rawText);
        rawText = stripped.text || '...';
        // Defensive strip (belt-and-suspenders): Marketing's model (Gemma via
        // /chat/marketing-eco) never emits inline <REASONING> — only bat 1.2
        // Core does — so this isn't a live bug here today. Kept identical to
        // Home's finalize strip in case that ever changes, so persistence/
        // display never silently regress.
        rawText = rawText.replace(/<REASONING>[\s\S]*?<\/REASONING>/g, '');
        const _reasonOpenIdxMkt = rawText.indexOf('<REASONING>');
        if (_reasonOpenIdxMkt !== -1) rawText = rawText.slice(0, _reasonOpenIdxMkt);
        const _asstMsg = { role: 'assistant', content: rawText, msgId: mintMsgId() };
        // Persist the reasoning chip so it re-renders on reload (see
        // marketingRenderHistory). secs>0 alone restores a timing-only chip.
        if (_thinkData && _thinkData.secs) _asstMsg.think = { text: _thinkData.text || '', secs: _thinkData.secs };
        marketingHistory.push(_asstMsg);

        // Parse the <MKT_SCORES> tag (if present) out of the raw reply — the
        // tag itself is never shown to the user, only the prose before it.
        // marketingHistory above already stored the unstripped rawText, so a
        // follow-up "Go deeper" turn still has full score context available.
        let displayText = rawText;
        let mktScores = null;
        const scoresMatch = rawText.match(/<MKT_SCORES>([\s\S]*?)<\/MKT_SCORES>/);
        if (scoresMatch) {
          const rawTag = scoresMatch[1].trim();
          try {
            mktScores = JSON.parse(rawTag);
          } catch (e) {
            // Fallback: some models wrap the tag's JSON in a markdown code
            // fence despite instructions not to — strip common fence forms
            // and retry once before giving up.
            try { mktScores = JSON.parse(stripJsonCodeFences(rawTag)); }
            catch (e2) { mktScores = null; }
          }
          displayText = displayText.replace(/<MKT_SCORES>[\s\S]*?<\/MKT_SCORES>/, '').trim();
        } else {
          // Safety net: model dropped the <MKT_SCORES> tags but still emitted
          // the bare JSON (mirrors detectBareClarifyJson's fallback convention).
          mktScores = detectBareMktScoresJson(displayText);
          if (mktScores) displayText = '';
        }
        const mktMeta = sanitizeMktScoresOptionalFields(mktScores);

        // Finalize: drop the streaming cursor, render the fully-parsed text once,
        // and run code-block enhancement (once — not per tick, like Home's finalizer).
        if (streamBubble) {
          streamBubble.dir = detectTextDir(displayText);
          streamBubble.innerHTML = renderRichText(displayText, false);
          enhanceCodeBlocks(streamBubble);
          if (streamWrap) streamWrap.scrollTop = streamWrap.scrollHeight;
          if (streamRow) marketingAppendStarRow(streamRow, marketingHistory[marketingHistory.length - 1].msgId);
        } else {
          marketingAppend('assistant', displayText, undefined, undefined, marketingHistory[marketingHistory.length - 1].msgId);
        }
        if (mktScores && mktScores.scores) {
          appendMarketingScoresWidget(mktScores.scores, mktScores.recommendations || []);
        }
        saveMarketingAnalysis({
          sourceUrl: urlForSave || null,
          domain: urlForSave ? marketingDomainFromUrl(urlForSave) : null,
          scores: (mktScores && mktScores.scores) || null,
          title: mktMeta.title,
          competition: mktMeta.competition,
          growthPotential: mktMeta.growth_potential,
          category: mktMeta.category,
          tags: mktMeta.tags
        });
      } catch (err) {
        // The reply failed/aborted — nothing was pushed to marketingHistory, so
        // remove the orphan "Thought for Xs" chip to stay consistent with reload.
        if (_thinkWidgetEl) { try { _thinkWidgetEl.remove(); } catch (e) {} }
        marketingHandleReplyError(err, streamRow, streamBubble, streamAvatar, streamWrap, liveText, urlForSave);
      }

      marketingBusy = false;
      marketingAbortController = null;
      setMarketingSendBtnBusy(false);
      marketingSetUserActionsGated('marketingMessages', false);
    }

    // ── Build-intent pre-filter (call-site only) ───────────────────────────
    // classifyBuildIntent() below already has its own exact-full-message
    // chatRe fast path, but that only matches literal greetings — short
    // conversational replies that aren't in chatRe (e.g. "طيب لا") still fall
    // through to a paid /chat classification call. This widens the phrase
    // list checked BEFORE classifyBuildIntent() is even called.
    //
    // Deliberately NO word-count threshold here (unlike isMemoryExtractionEligible):
    // short messages can be totally valid build/edit commands (e.g. "غيّر اللون",
    // "احذف الزر"), so we only skip the call on an EXACT phrase match, never on
    // length alone. classifyBuildIntent()'s own logic/chatRe is left untouched.
    const BUILD_INTENT_EXTRA_CHAT_PHRASES = [
      // Arabic short conversational replies (yes/no/later/not now/done, etc.)
      'طيب لا', 'لا لا', 'لأ', 'لأه', 'مش الحين', 'مش هلق', 'مش دلوقتي', 'بعدين',
      'خلص', 'خلاص', 'مافي داعي', 'ولا يهمك', 'يلا تمام', 'ايوا', 'ايوة',
      'اه تمام', 'ماشي تمام', 'حاضر', 'كفاية كذا', 'بس كذا', 'مش لازم',
      // English short conversational replies
      'not now', 'no thanks', 'no thank you', 'never mind', 'nevermind', 'nah',
      'nope', 'not yet', "that's fine", 'thats fine', "that's all", 'thats all',
      "that's it", 'thats it', 'skip it', 'leave it', "i'm good", 'im good'
    ];

    function isBuildIntentPrefilterChat(rawMsg) {
      const text = String(rawMsg || '').trim();
      if (!text) return false;
      const normalized = text
        .replace(/^[\s"'“”‘’.,!?؟…]+|[\s"'“”‘’.,!?؟…]+$/g, '')
        .toLowerCase();
      return MEMORY_FILTER_COMMON_PHRASES.indexOf(normalized) !== -1
        || BUILD_INTENT_EXTRA_CHAT_PHRASES.indexOf(normalized) !== -1;
    }

    // Decide whether a home-composer message (with a build type selected) is an
    // actual build/edit request or just conversation (greeting, question, thanks…).
    // Returns 'build' or 'chat'. A fast multilingual heuristic handles the obvious
    // small-talk cases for free; anything ambiguous is classified by the existing
    // lightweight chat worker. Falls back safely if that call fails.
    async function classifyBuildIntent(prompt, type) {
      var p = (prompt || '').trim();
      if (!p) return 'chat';
      // Fast path: obvious greetings / meta questions / acknowledgements (EN + AR).
      var chatRe = /^(hi|hey+|hello|yo|sup|thanks|thank you|thx|ok|okay|cool|nice|great|how are you|how's it going|who are you|what are you|what can you (do|build|make)|good (morning|afternoon|evening|night)|مرحبا|أهلا|اهلا|هلا|كيفك|شلونك|شكرا|شكراً|مين انت|من انت|شو بتعمل|وش تسوي|صباح الخير|مساء الخير)\b[\s!.,؟?…]*$/i;
      if (chatRe.test(p)) return 'chat';
      // Ambiguous → ask the lightweight worker to classify in one word.
      try {
        var sys = 'You are an intent classifier for an AI builder app. The user currently has the "'
          + type + '" build mode selected. Earlier messages (if any) are conversation context — '
          + 'the LAST user message is the one to classify. Decide if that last message is a request to '
          + 'BUILD or edit a ' + type + ' (a real spec, feature, or change to make — including short '
          + 'follow-ups like "change the name" or "make it faster" that refer back to something built '
          + 'earlier in this conversation), or just CHAT (greeting, small talk, a question, thanks, or '
          + 'anything not asking to build/modify something). '
          + 'Reply with exactly one word: BUILD or CHAT.';
        var ctxTurns = (Array.isArray(homeConvHistory) ? homeConvHistory.slice(0, -1) : []).slice(-6);
        var msgs = ctxTurns.map(function (m) { return { role: m.role, content: String(m.content || '').slice(0, 600) }; });
        msgs.push({ role: 'user', content: p });
        var { res } = await gatewayFetch(bgChatRoute(), { system: sys, messages: msgs }, { silent: true });
        // Streamed text/plain, not JSON — see the note in sendHwChatMessage().
        // The old res.json() threw on every call into the catch below, so the
        // classifier never actually classified anything: every ambiguous prompt
        // silently fell through to the length heuristic at the end of this
        // function. That heuristic is the last-resort offline default only — it
        // must not be the normal path, which is what this fixes.
        // bgChatRoute() resolves to /chat/core for Free (and for anyone on the
        // Core selector), which emits <REASONING>; the reasoning text routinely
        // contains both words ("...is this a BUILD or CHAT request..."), so
        // stripping it first is what makes the indexOf checks below meaningful
        // rather than a coin flip on whichever word appears first.
        var out = stripInlineReasoning(await streamPlainText(res)).toUpperCase();
        if (out.indexOf('BUILD') !== -1) return 'build';
        if (out.indexOf('CHAT') !== -1) return 'chat';
      } catch (e) { /* classifier unavailable → fall through to heuristic default */ }
      // Default when unsure and offline: treat only longer prompts as build requests.
      return p.length > 25 ? 'build' : 'chat';
    }

    // Tactile feedback for the send button: ripple + a tiny, dependency-free blip.
    window.homeSendClickFx = function (evt) {
      var btn = document.getElementById('homeSendBtn');
      if (!btn) return;
      var rect = btn.getBoundingClientRect();
      var ripple = document.createElement('span');
      ripple.className = 'home-send-ripple';
      var size = Math.max(rect.width, rect.height);
      ripple.style.width = ripple.style.height = size + 'px';
      var x = (evt && evt.clientX ? evt.clientX - rect.left : rect.width / 2) - size / 2;
      var y = (evt && evt.clientY ? evt.clientY - rect.top : rect.height / 2) - size / 2;
      ripple.style.left = x + 'px';
      ripple.style.top = y + 'px';
      btn.appendChild(ripple);
      setTimeout(function () { if (ripple.parentNode) ripple.parentNode.removeChild(ripple); }, 520);

      try {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (AC) {
          var ctx = window._homeSendAudioCtx || (window._homeSendAudioCtx = new AC());
          var osc = ctx.createOscillator();
          var gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(880, ctx.currentTime);
          osc.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.08);
          gain.gain.setValueAtTime(0.05, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.14);
          osc.connect(gain).connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.15);
        }
      } catch (e) { /* audio not critical, fail silently */ }
    };

    /* ── Conversation export (MD / PDF) ──────────────────────────────────────
       Detects an explicit user request to export the current chat as a file.
       PRIMARY path (exportConversationViaAI): sends the whole conversation to
       the user's currently-selected chat model for a professional Markdown
       *summary*, billed as a normal message via the same reserve/settle
       pipeline. FALLBACK path (the local build* functions below): a raw,
       AI-free transcript dump, used automatically only on a genuine network/
       generation failure so an explicit export request never dead-ends.
       See conversation 2026-07-23 for the full detection-design rationale. */
    const EXPORT_ACTION_RE = /\b(export|download)\b|صدّر|صدر|تصدير|نزّل|نزل|حمّل|حمل|اعطيني|أعطيني|طلعلي|طلّعلي/i;
    const EXPORT_TARGET_RE = /\b(conversation|chat|history|file)\b|المحادثة|المحادثه|الشات|ملف/i;
    // Bare export filename (e.g. "conversation.md", "chat.pdf") — treated as
    // an export request on its own even with no action verb, since naming
    // the file IS the request.
    const EXPORT_FILENAME_RE = /\b(conversation|chat|محادثة|المحادثة)\.(md|pdf|txt)\b/i;
    function detectExportRequest(text) {
      const trimmed = (text || '').trim();
      if (!trimmed || trimmed.length > 100) return false;
      if (trimmed.indexOf('```') !== -1) return false;
      if (EXPORT_FILENAME_RE.test(trimmed)) return true;
      return EXPORT_ACTION_RE.test(trimmed) && EXPORT_TARGET_RE.test(trimmed);
    }
    function detectExportFormat(text) {
      return /\bpdf\b/i.test(text) ? 'pdf' : 'md';
    }
    function deriveExportTitle(history) {
      const firstUser = history.find(function (m) { return m.role === 'user' && m.content; });
      if (!firstUser) return 'محادثة BatNXT';
      const t = firstUser.content.trim();
      return t.length > 60 ? t.slice(0, 60) + '…' : t;
    }
    // Formats a single stored message for export. Deliberately reads
    // `displayCaption` when present (Marketing user turns store the full
    // extracted webpage/file markdown in `content` for AI context, but only
    // the short typed caption in `displayCaption` — using raw `content`
    // there would dump huge extracted markdown into the transcript) and
    // falls back to `content` otherwise (unchanged behavior for Home, which
    // has no `displayCaption` field). Also reads `images` (count only, no
    // raw base64/filenames are embedded). `gen.html` and `think` are never
    // read here, which is what keeps them out of the export by construction.
    function formatMessageForExport(msg) {
      const lines = [];
      if (Array.isArray(msg.images) && msg.images.length) {
        lines.push(msg.images.length === 1 ? '[📎 صورة مرفقة]' : '[📎 ' + msg.images.length + ' صور مرفقة]');
      }
      lines.push((msg.displayCaption != null ? msg.displayCaption : msg.content) || '');
      return lines.join('\n');
    }
    // Consistent, polished timestamp for every export header — one fixed format
    // (localized long date + 24h time, never a 12h/24h mix). Maps the current
    // UI language to a matching locale so the month/word order reads naturally.
    function formatExportTimestamp() {
      const localeMap = { ar: 'ar', tr: 'tr-TR', en: 'en-GB' };
      const lang = (typeof BatLang !== 'undefined') ? BatLang.lang : 'en';
      const locale = localeMap[lang] || 'en-GB';
      try {
        return new Date().toLocaleString(locale, {
          year: 'numeric', month: 'long', day: 'numeric',
          hour: '2-digit', minute: '2-digit', hour12: false
        });
      } catch (e) {
        return new Date().toLocaleString();
      }
    }
    // Builds just the per-message transcript body (no title/date header) —
    // used both by buildConversationMarkdown's header+body combo below and,
    // standalone, as the synchronous "full transcript" opt-in body fed into
    // the same appendExportFileCard/downloadAiMarkdown path the AI-summary
    // flow uses (see exportConversationViaAI), so the header stays owned by
    // whichever function is prepending it — no double title/date.
    function formatTranscriptBody(history) {
      const parts = [];
      history.forEach(function (msg, i) {
        if (msg.role === 'user' && i > 0) { parts.push('---', ''); }
        parts.push(msg.role === 'assistant' ? '## Assistant' : '## User', formatMessageForExport(msg), '');
      });
      return parts.join('\n');
    }
    function buildConversationMarkdown(history) {
      const title = deriveExportTitle(history);
      const dateStr = formatExportTimestamp();
      const header = ['# ' + title, '_تم التصدير: ' + dateStr + '_', '', '---', ''];
      return header.join('\n') + '\n' + formatTranscriptBody(history);
    }
    function buildConversationHtml(history) {
      const title = escapeHtml(deriveExportTitle(history));
      const dateStr = escapeHtml(formatExportTimestamp());
      let body = '';
      history.forEach(function (msg, i) {
        if (msg.role === 'user' && i > 0) body += '<hr>';
        const heading = msg.role === 'assistant' ? 'Assistant' : 'User';
        body += '<h2>' + heading + '</h2><pre>' + escapeHtml(formatMessageForExport(msg)) + '</pre>';
      });
      return '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' + title + '</title>' +
        '<style>body{font-family:sans-serif;max-width:720px;margin:40px auto;padding:0 20px;line-height:1.6;}' +
        'h1{font-size:22px;}h2{font-size:16px;margin-top:24px;color:#333;}hr{margin:24px 0;border:none;border-top:1px solid #ddd;}' +
        'pre{white-space:pre-wrap;font-size:14px;font-family:inherit;}</style></head><body>' +
        '<h1>' + title + '</h1><div style="color:#888;font-size:12px;">تم التصدير: ' + dateStr + '</div>' + body + '</body></html>';
    }
    function downloadConversationMarkdown(history) {
      const md = buildConversationMarkdown(history || homeConvHistory);
      const blob = new Blob([md], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'batnxt-chat-' + Date.now() + '.md';
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
      if (typeof showToast === 'function') showToast('✅ تم تصدير المحادثة', 'success');
    }
    // ── Real client-side PDF export (html2pdf.js, lazy-loaded) ──────────────
    // The library (~380KB) is only pulled in the first time a user actually
    // asks for a PDF, then cached on window.html2pdf for the session. On any
    // failure (blocked CDN, offline, render error) we honestly degrade to the
    // original hidden-iframe window.print() path so the user can still "Save
    // as PDF" manually — export never hard-fails.
    let _html2pdfPromise = null;
    function ensureHtml2Pdf() {
      if (window.html2pdf) return Promise.resolve(window.html2pdf);
      if (_html2pdfPromise) return _html2pdfPromise;
      _html2pdfPromise = new Promise(function (resolve, reject) {
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/html2pdf.js@0.10.2/dist/html2pdf.bundle.min.js';
        s.async = true;
        s.onload = function () {
          if (window.html2pdf) { resolve(window.html2pdf); }
          else { _html2pdfPromise = null; reject(new Error('html2pdf missing after load')); }
        };
        s.onerror = function () { _html2pdfPromise = null; reject(new Error('html2pdf load failed')); };
        document.head.appendChild(s);
      });
      return _html2pdfPromise;
    }

    // Strip filesystem-hostile characters from a would-be PDF filename and
    // clamp length; falls back to a generic name if nothing usable remains.
    function _sanitizeExportFilename(name) {
      let n = String(name == null ? '' : name)
        .replace(/[\\/:*?"<>|\u2026]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (!n) n = 'batnxt-chat';
      if (n.length > 80) n = n.slice(0, 80).trim();
      return n;
    }

    // Honest-degrade path: the pre-existing hidden-iframe print approach.
    function _printHtmlFallback(html) {
      const ifr = document.createElement('iframe');
      ifr.style.cssText = 'position:fixed;opacity:0;width:1px;height:1px;top:-9999px;';
      document.body.appendChild(ifr);
      ifr.contentDocument.open();
      ifr.contentDocument.write(html);
      ifr.contentDocument.close();
      setTimeout(function () {
        try { ifr.contentWindow.print(); } catch (e2) {}
        setTimeout(function () { if (ifr.parentNode) ifr.parentNode.removeChild(ifr); }, 3000);
      }, 600);
      if (typeof showToast === 'function') showToast('🖨️ تعذّر إنشاء PDF مباشرة — فُتح مربع الطباعة، احفظ كـ PDF من هناك.', 'info');
    }

    // Core generator: renders a full HTML doc string into a real downloadable
    // PDF via html2pdf. Builds an off-screen container (fixed 720px, white bg,
    // dark text) carrying over the doc's inline <style> so headings/pre/code
    // keep their look; dir is applied at the container so shaped Arabic RTL
    // and mixed AR/EN read correctly (html2pdf rasterizes already-shaped
    // browser HTML — the whole reason we picked it over jsPDF).
    async function _renderHtmlToPdf(fullHtml, filename, dir) {
      let html2pdf;
      try { html2pdf = await ensureHtml2Pdf(); }
      catch (e) { _printHtmlFallback(fullHtml); return; }
      let container = null;
      try {
        const doc = new DOMParser().parseFromString(fullHtml, 'text/html');
        container = document.createElement('div');
        container.setAttribute('dir', dir || 'ltr');
        container.style.cssText = 'position:absolute;left:-99999px;top:0;width:720px;' +
          'background:#ffffff;color:#111;padding:24px;box-sizing:border-box;' +
          "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;line-height:1.7;";
        doc.querySelectorAll('style').forEach(function (s) {
          const st = document.createElement('style');
          st.textContent = s.textContent;
          container.appendChild(st);
        });
        const bodyWrap = document.createElement('div');
        bodyWrap.innerHTML = doc.body ? doc.body.innerHTML : fullHtml;
        container.appendChild(bodyWrap);
        document.body.appendChild(container);
        await html2pdf().set({
          margin: [24, 24, 24, 24],
          filename: filename,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true, backgroundColor: '#ffffff' },
          jsPDF: { unit: 'pt', format: 'a4', orientation: 'portrait' },
          pagebreak: { mode: ['css', 'legacy'] }
        }).from(container).save();
        if (typeof showToast === 'function') showToast('✅ تم حفظ ملف PDF', 'success');
      } catch (e) {
        _printHtmlFallback(fullHtml);
      } finally {
        if (container && container.parentNode) container.parentNode.removeChild(container);
      }
    }

    function exportConversationAsPdf(history) {
      const hist = history || homeConvHistory;
      const html = buildConversationHtml(hist);
      const title = deriveExportTitle(hist);
      _renderHtmlToPdf(html, _sanitizeExportFilename(title) + '.pdf', detectTextDir(title));
    }

    // ── Starred messages (shared: Home + Marketing) ─────────────────────────
    // Lightweight per-message identity + star/unstar persistence. Every
    // message pushed to homeConvHistory/marketingHistory gets a mintMsgId()
    // stamp so a star survives Edit/Regenerate's truncate-and-rebuild (which
    // would otherwise shift array indices out from under an index-based
    // star). Starring is a direct client-Supabase insert/delete against
    // `starred_messages` (RLS owner-scoped) — mirrors how Marketing History
    // reads/writes `marketing_analyses` directly; no worker route involved.
    function mintMsgId() {
      return 'm_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }

    // Per-source cache of the currently-open session's starred msgIds, so
    // the reactions/star row can synchronously light up the right button on
    // render without a per-message round-trip. Populated via
    // loadStarredSetForSession() right before a conversation/analysis is
    // rendered (loadHomeChatSession, mktHistoryOpen). A sessionId mismatch
    // (e.g. a brand-new, never-opened-from-history conversation) simply
    // reads as "no stars yet", which is always correct.
    var _starredMsgIdSets = { home: null, marketing: null };
    var _starredSessionIds = { home: null, marketing: null };

    async function loadStarredSetForSession(source, sessionId) {
      if (!currentUser || !sessionId) {
        _starredMsgIdSets[source] = new Set();
        _starredSessionIds[source] = sessionId || null;
        return;
      }
      let res;
      try {
        res = await supabase
          .from('starred_messages')
          .select('msg_id')
          .eq('user_id', currentUser.id)
          .eq('source', source)
          .eq('session_id', sessionId);
      } catch (e) {
        console.error('Failed to load starred messages for session:', e);
        res = null;
      }
      _starredMsgIdSets[source] = new Set(((res && res.data) || []).map(function (r) { return r.msg_id; }));
      _starredSessionIds[source] = sessionId;
    }

    function isMsgStarred(source, sessionId, msgId) {
      return !!(msgId && sessionId && _starredSessionIds[source] === sessionId &&
        _starredMsgIdSets[source] && _starredMsgIdSets[source].has(msgId));
    }

    // Toggles one message's starred state. Optimistic UI update with
    // revert-on-failure (matches the rest of the app's Supabase-write
    // conventions). getSessionId/getSnippet/getTitle are lazy (called at
    // click-time, not build-time) so a long-lived button always stars using
    // the CURRENT session/content rather than a stale closure.
    async function toggleStarMessage(btn, source, msgId, getSessionId, role, getSnippet, getTitle) {
      if (!currentUser || !msgId) return;
      const sessionId = getSessionId();
      if (!sessionId) return;
      const nowActive = !btn.classList.contains('active');
      btn.classList.toggle('active', nowActive);
      if (_starredSessionIds[source] !== sessionId || !_starredMsgIdSets[source]) {
        _starredMsgIdSets[source] = new Set();
        _starredSessionIds[source] = sessionId;
      }
      if (nowActive) _starredMsgIdSets[source].add(msgId);
      else _starredMsgIdSets[source].delete(msgId);
      try {
        if (nowActive) {
          const res = await supabase.from('starred_messages').insert({
            user_id: currentUser.id,
            source: source,
            session_id: sessionId,
            msg_id: msgId,
            role: role || null,
            content_snippet: (getSnippet() || '').slice(0, 300),
            title: getTitle() || null
          });
          if (res.error) throw res.error;
        } else {
          const res = await supabase.from('starred_messages').delete()
            .eq('user_id', currentUser.id).eq('source', source)
            .eq('session_id', sessionId).eq('msg_id', msgId);
          if (res.error) throw res.error;
        }
      } catch (e) {
        console.error('Failed to toggle star:', e);
        btn.classList.toggle('active', !nowActive);
        if (nowActive) _starredMsgIdSets[source].delete(msgId);
        else _starredMsgIdSets[source].add(msgId);
      }
    }

    // Builds the ⭐ star toggle button — shared by Home's reactions row and
    // Marketing's (new, star-only) reactions row. Disabled (no click
    // listener) when msgId is missing, which only happens for messages
    // saved before this feature shipped (no msgId to key a star by).
    function hcmMakeStarBtn(source, msgId, getSessionId, role, getSnippet, getTitle) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'hcm-reaction-btn hcm-star-btn';
      btn.innerHTML = _starSvg;
      btn.setAttribute('aria-label', BatLang.t('chat.starBtn') || 'Star message');
      if (!msgId) {
        btn.disabled = true;
        btn.title = BatLang.t('chat.starUnavailable') || 'Unavailable for older messages';
        return btn;
      }
      btn.title = BatLang.t('chat.starBtn') || 'Star message';
      if (isMsgStarred(source, getSessionId(), msgId)) btn.classList.add('active');
      btn.addEventListener('click', function () {
        toggleStarMessage(btn, source, msgId, getSessionId, role, getSnippet, getTitle);
      });
      return btn;
    }

    function getHomeConvTitle() {
      const s = homeChatSessions.find(function (x) { return x.id === homeConvSessionId; });
      return (s && s.title) || null;
    }

    // Star-only reactions row for Marketing assistant replies (Marketing had
    // no reactions row at all before this feature — purely additive).
    function marketingAppendStarRow(container, msgId) {
      const reactions = document.createElement('div');
      reactions.className = 'hcm-reactions';
      reactions.appendChild(hcmMakeStarBtn('marketing', msgId, function () { return marketingAnalysisId; }, 'assistant',
        function () { const b = container.querySelector('.hcm-bubble'); return b ? b.textContent : ''; },
        function () { return marketingAnalysisTitle; }));
      container.appendChild(reactions);
    }

    // ── AI-driven export (redesign) ─────────────────────────────────────────
    // Detects an explicit "full transcript" opt-in phrase alongside an
    // export request (e.g. "export the full transcript, don't summarize" /
    // "المحادثة كاملة بدون تلخيص"). When present, exportConversationViaAI
    // skips the AI summarization call entirely and builds the body
    // synchronously via formatTranscriptBody() instead — still delivered
    // through the same Analyzing-card/file-card UI for consistency (see
    // exportConversationViaAI). Deliberately narrow: plain "كاملة"/"whole"
    // alone is normal phrasing for "export the whole conversation" (i.e. all
    // of it, still summarized) — NOT a request for a raw, unsummarized dump —
    // so it must NOT opt into this path on its own (was causing near-verbatim
    // exports for phrasing that only meant "the entire conversation").
    const EXPORT_FULL_RE = /\b(full|complete|entire|whole|verbatim|raw)\s+(transcript|copy|text)\b|بدون تلخيص|من غير تلخيص|بدون اختصار|النص الكامل/i;
    function detectFullTranscriptRequest(text) {
      return EXPORT_FULL_RE.test((text || '').trim());
    }
    // System instruction for the AI-summary path: turn the whole conversation
    // into a genuinely CONDENSED Markdown summary (not a verbatim transcript,
    // and not a turn-by-turn restatement of every message either — that's
    // the separate full-transcript opt-in above). Uses the same cheap
    // /chat/export route regardless of the user's selected chat model.
    function buildExportSystemPrompt() {
      return 'You are a professional document formatter. You will be given a full conversation between a user and an AI assistant. ' +
        'Your job is to CONDENSE it into a short, synthesized summary — never reproduce the dialogue turn-by-turn, and never restate messages in their original form. ' +
        'Structure the output as: ' +
        '1) a short title-style heading (##) capturing the overall topic; ' +
        '2) a concise narrative summary (a few sentences to a few short paragraphs) written in your own words, describing what was discussed and accomplished overall — not a recap of each individual message; ' +
        '3) if there are concrete decisions, action items, or key facts worth listing separately, a short "**Key Points**" bullet list (only if genuinely useful — skip it for simple conversations); ' +
        '4) preserve any code blocks the user explicitly asked to keep, verbatim, but nothing else verbatim. ' +
        'Compress and synthesize — do not restate every question and answer. A 50-message conversation should read as a short brief, not a 50-paragraph reformatted transcript. ' +
        'Drop greetings, filler, repeated clarification loops, and off-topic tangents entirely. ' +
        currentUiLanguageInstruction() + ' ' +
        'Output ONLY the Markdown body — no preamble, no meta commentary, no surrounding code fences, ' +
        'and do NOT add your own top-level (#) title beyond the one heading described above (the date line is added separately).';
    }
    const EXPORT_USER_INSTRUCTION =
      'Summarize and organize the entire conversation above into clean, professional Markdown as instructed. Output only the Markdown body.';

    // Prepends the consistent header (title + timestamp) to the AI-generated
    // Markdown body and triggers a .md download. `title`/`dateStr` are optional
    // snapshots captured at generation time (see appendExportFileCard) so a
    // later download click stays consistent even if homeConvHistory has since
    // changed; when omitted they're derived live (original auto-download path).
    function downloadAiMarkdown(body, title, dateStr) {
      const _title = title != null ? title : deriveExportTitle(homeConvHistory);
      const _date = dateStr != null ? dateStr : formatExportTimestamp();
      const md = '# ' + _title + '\n_' + _date + '_\n\n---\n\n' + body + '\n';
      const blob = new Blob([md], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'batnxt-chat-' + Date.now() + '.md';
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
      if (typeof showToast === 'function') showToast('✅ تم تصدير المحادثة', 'success');
    }
    // Renders the AI-generated Markdown body to HTML (reusing renderRichText)
    // under the same consistent header, then opens print-to-PDF via a hidden iframe.
    // `title`/`dateStr` optional snapshots — see downloadAiMarkdown above.
    function exportAiMarkdownAsPdf(body, title, dateStr) {
      const rawTitle = title != null ? title : deriveExportTitle(homeConvHistory);
      const safeTitle = escapeHtml(rawTitle);
      const safeDate = escapeHtml(dateStr != null ? dateStr : formatExportTimestamp());
      const bodyHtml = (typeof renderRichText === 'function')
        ? renderRichText(body, false)
        : ('<pre>' + escapeHtml(body) + '</pre>');
      const html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' + safeTitle + '</title>' +
        '<style>body{font-family:sans-serif;max-width:720px;margin:40px auto;padding:0 20px;line-height:1.7;}' +
        'h1{font-size:24px;margin-bottom:4px;}h2{font-size:17px;margin-top:26px;color:#222;}' +
        'h3{font-size:15px;color:#333;}hr{margin:20px 0;border:none;border-top:1px solid #ddd;}' +
        'code{background:#f4f4f4;padding:1px 5px;border-radius:4px;font-size:13px;}' +
        'pre{white-space:pre-wrap;background:#f7f7f7;padding:12px;border-radius:8px;font-size:13px;}' +
        '.export-date{color:#888;font-size:12px;margin-bottom:8px;}</style></head><body>' +
        '<h1>' + safeTitle + '</h1><div class="export-date">' + safeDate + '</div><hr>' + bodyHtml + '</body></html>';
      _renderHtmlToPdf(html, _sanitizeExportFilename(rawTitle) + '.pdf', detectTextDir(body));
    }

    // Injects the export file-card + text-preview lightbox styles once. Mirrors
    // the inject-once <style> pattern used by homePreviewAttach()'s '_apStyle'.
    function _ensureExportCardStyles() {
      if (document.getElementById('_exCardStyle')) return;
      const s = document.createElement('style');
      s.id = '_exCardStyle';
      s.textContent = [
        /* ── file card in the chat bubble ── */
        '.ex-file-card{display:flex;align-items:center;gap:12px;max-width:420px;',
        'margin:6px 0 2px;padding:11px 13px;border-radius:14px;cursor:pointer;',
        'background:var(--surface2,#0f1420);border:1px solid var(--border,#1a2235);',
        'transition:border-color .15s,background .15s,transform .12s;}',
        '.ex-file-card:hover{border-color:var(--accent,#5b8cff);background:var(--surface,#0b0f1a);}',
        '.ex-file-card:active{transform:scale(.99);}',
        '.ex-file-card-icon{flex-shrink:0;width:34px;height:34px;border-radius:9px;',
        'display:flex;align-items:center;justify-content:center;color:#fff;',
        'background:linear-gradient(135deg,#5b8cff,#7a5bff);}',
        '.ex-file-card-icon svg{width:19px;height:19px;}',
        '.ex-file-card-info{flex:1;min-width:0;}',
        '.ex-file-card-name{font-size:.86rem;font-weight:600;color:var(--text,#eef2f7);',
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
        '.ex-file-card-meta{font-size:.72rem;color:var(--text-muted,#8892a4);margin-top:2px;}',
        '.ex-file-card-dl{flex-shrink:0;width:32px;height:32px;border-radius:8px;',
        'display:flex;align-items:center;justify-content:center;cursor:pointer;',
        'background:transparent;border:1px solid var(--border,#1a2235);',
        'color:var(--text-muted,#8892a4);transition:color .15s,background .15s,border-color .15s;}',
        '.ex-file-card-dl:hover{color:#fff;background:var(--accent,#5b8cff);border-color:var(--accent,#5b8cff);}',
        '.ex-file-card-dl svg{width:16px;height:16px;}',
        /* ── text preview lightbox ── */
        '#_txpOverlay{position:fixed;inset:0;z-index:9600;background:rgba(0,0,0,0.88);',
        'display:flex;align-items:center;justify-content:center;padding:24px;',
        'animation:_txpFade .18s ease;}',
        '@keyframes _txpFade{from{opacity:0}to{opacity:1}}',
        '#_txpOverlay ._txpBox{position:relative;width:min(760px,94vw);max-height:88vh;',
        'display:flex;flex-direction:column;border-radius:16px;overflow:hidden;',
        'background:var(--card,#0f1420);border:1px solid var(--border,#1a2235);',
        'box-shadow:0 32px 80px rgba(0,0,0,0.65);}',
        '#_txpOverlay ._txpHead{display:flex;align-items:center;gap:10px;flex-shrink:0;',
        'padding:12px 14px;border-bottom:1px solid var(--border,#1a2235);}',
        '#_txpOverlay ._txpName{flex:1;min-width:0;font-size:.85rem;font-weight:600;',
        'color:var(--text,#eef2f7);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
        '#_txpOverlay ._txpBtn{display:inline-flex;align-items:center;gap:6px;',
        'padding:6px 11px;border-radius:8px;font-size:.76rem;font-weight:600;cursor:pointer;',
        'background:var(--surface2,#0f1420);border:1px solid var(--border,#1a2235);',
        'color:var(--text-muted,#8892a4);transition:color .15s,background .15s,border-color .15s;}',
        '#_txpOverlay ._txpBtn:hover{color:#fff;background:var(--accent,#5b8cff);border-color:var(--accent,#5b8cff);}',
        '#_txpOverlay ._txpBtn.copied{color:#fff;background:var(--green,#1f9d55);border-color:var(--green,#1f9d55);}',
        '#_txpOverlay ._txpBtn svg{width:15px;height:15px;}',
        '#_txpOverlay ._txpClose{width:30px;height:30px;padding:0;justify-content:center;font-size:.9rem;}',
        '#_txpOverlay ._txpBody{overflow:auto;flex:1;padding:20px 24px;',
        'color:var(--text,#eef2f7);line-height:1.7;}',
        '#_txpOverlay ._txpBody h1{font-size:1.35rem;margin:0 0 4px;}',
        '#_txpOverlay ._txpDate{font-size:.72rem;color:var(--text-muted,#8892a4);',
        'margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid var(--border,#1a2235);}'
      ].join('');
      document.head.appendChild(s);
    }

    // Read-only lightbox preview for the AI-exported Markdown. Renders the body
    // via renderRichText (per approved decision — rendered, not raw) under the
    // same title+date header used by the file itself, with in-panel Copy and
    // Download buttons that read from the SAME captured content the card holds.
    // Generalizes marketingPreviewAttach()'s overlay/Copy pattern; adds Download.
    function openTextFilePreview(opts) {
      _ensureExportCardStyles();
      const title = opts.title || 'Conversation';
      const dateStr = opts.dateStr || '';
      const body = opts.body || '';
      const format = opts.format || 'md';

      const old = document.getElementById('_txpOverlay');
      if (old) old.remove();

      const overlay = document.createElement('div');
      overlay.id = '_txpOverlay';
      overlay.addEventListener('click', function (e) { if (e.target === overlay) overlay.remove(); });
      document.addEventListener('keydown', function _esc(e) {
        if (e.key === 'Escape') { overlay.remove(); document.removeEventListener('keydown', _esc); }
      });

      const box = document.createElement('div');
      box.className = '_txpBox';

      const head = document.createElement('div');
      head.className = '_txpHead';
      const nameEl = document.createElement('span');
      nameEl.className = '_txpName';
      nameEl.textContent = title;
      head.appendChild(nameEl);

      // Copy — reuses the exact icon-swap/clipboard/revert pattern from
      // marketingPreviewAttach()/enhanceCodeBlocks() (1600ms revert).
      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.className = '_txpBtn';
      copyBtn.innerHTML = _copySvg + '<span>' + (BatLang.t('chat.copyBtn') || 'Copy') + '</span>';
      copyBtn.addEventListener('click', function () {
        const copyText = '# ' + title + '\n_' + dateStr + '_\n\n---\n\n' + body + '\n';
        const done = function () {
          copyBtn.classList.add('copied');
          copyBtn.innerHTML = _checkSvg + '<span>' + (BatLang.t('chat.copiedBtn') || 'Copied') + '</span>';
          setTimeout(function () {
            copyBtn.classList.remove('copied');
            copyBtn.innerHTML = _copySvg + '<span>' + (BatLang.t('chat.copyBtn') || 'Copy') + '</span>';
          }, 1600);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(copyText).then(done).catch(function () {
            const ta = document.createElement('textarea');
            ta.value = copyText; document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta); done();
          });
        } else {
          const ta = document.createElement('textarea');
          ta.value = copyText; document.body.appendChild(ta); ta.select();
          try { document.execCommand('copy'); } catch (e) {}
          document.body.removeChild(ta); done();
        }
      });
      head.appendChild(copyBtn);

      // Download — same captured body/title/date snapshot the card holds.
      const dlBtn = document.createElement('button');
      dlBtn.type = 'button';
      dlBtn.className = '_txpBtn';
      dlBtn.innerHTML = _dlSvg + '<span>' + (BatLang.t('chat.downloadBtn') || 'Download') + '</span>';
      dlBtn.addEventListener('click', function () {
        if (format === 'pdf') exportAiMarkdownAsPdf(body, title, dateStr);
        else downloadAiMarkdown(body, title, dateStr);
      });
      head.appendChild(dlBtn);

      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = '_txpBtn _txpClose';
      closeBtn.innerHTML = '✕';
      closeBtn.setAttribute('aria-label', 'Close');
      closeBtn.addEventListener('click', function () { overlay.remove(); });
      head.appendChild(closeBtn);

      const bodyEl = document.createElement('div');
      bodyEl.className = '_txpBody';
      const h1 = document.createElement('h1');
      h1.textContent = title;
      bodyEl.appendChild(h1);
      if (dateStr) {
        const dt = document.createElement('div');
        dt.className = '_txpDate';
        dt.textContent = dateStr;
        bodyEl.appendChild(dt);
      }
      const content = document.createElement('div');
      content.dir = (typeof detectTextDir === 'function') ? detectTextDir(body) : 'auto';
      content.innerHTML = (typeof renderRichText === 'function')
        ? renderRichText(body, false)
        : ('<pre>' + escapeHtml(body) + '</pre>');
      bodyEl.appendChild(content);

      box.appendChild(head);
      box.appendChild(bodyEl);
      overlay.appendChild(box);
      document.body.appendChild(overlay);
    }

    // Delivers the AI-exported Markdown as an interactive, session-only file
    // card inside the chat (per approved redesign) instead of an instant auto-
    // download. The generated body + a title/timestamp snapshot are captured in
    // this closure (in-memory only — no Supabase/R2, not restored after reload
    // except via the exportBody/exportFormat marker fields, which re-call this
    // same function — see hcmRenderSlice/marketingRenderHistory), and feed BOTH
    // the quick-download icon and the preview's Copy/Download. Structure mirrors
    // hcmAppendFileCard(). Shared by Home (containerId 'homeConvMessages',
    // history homeConvHistory) and Marketing (containerId 'marketingMessages',
    // history marketingHistory) — the two surfaces' own history arrays are
    // passed in rather than hardcoded so this one function serves both.
    function appendExportFileCard(containerId, history, body, format) {
      const wrap = document.getElementById(containerId);
      if (!wrap) return;
      _ensureExportCardStyles();
      const title = deriveExportTitle(history);
      const dateStr = formatExportTimestamp();
      const isPdf = format === 'pdf';
      const fileName = isPdf ? (title + '.pdf') : (title + '.md');

      // Short assistant lead-in bubble (context for the card below it).
      const row = document.createElement('div');
      row.className = 'hcm-msg';
      const av = document.createElement('div');
      av.className = 'hcm-avatar is-logo';
      av.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      const bubble = document.createElement('div');
      bubble.className = 'hcm-bubble';
      const lead = document.createElement('div');
      lead.textContent = BatLang.t('export.ready') || '\u2705 \u062c\u0647\u0651\u0632\u062a ملف محادثتك \u2014 اضغط للمعاينة أو نزّله مباشرة.';
      bubble.appendChild(lead);

      const card = document.createElement('div');
      card.className = 'ex-file-card';
      card.title = BatLang.t('export.previewHint') || '\u0627\u0636\u063a\u0637 \u0644\u0644\u0645\u0639\u0627\u064a\u0646\u0629';

      const icon = document.createElement('div');
      icon.className = 'ex-file-card-icon';
      icon.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>';

      const info = document.createElement('div');
      info.className = 'ex-file-card-info';
      const nm = document.createElement('div');
      nm.className = 'ex-file-card-name';
      nm.textContent = fileName;
      const meta = document.createElement('div');
      meta.className = 'ex-file-card-meta';
      meta.textContent = (isPdf ? 'PDF' : 'Markdown') + ' \u00b7 ' + (BatLang.t('export.previewHint') || '\u0627\u0636\u063a\u0637 \u0644\u0644\u0645\u0639\u0627\u064a\u0646\u0629');
      info.appendChild(nm);
      info.appendChild(meta);

      const dl = document.createElement('button');
      dl.type = 'button';
      dl.className = 'ex-file-card-dl';
      dl.setAttribute('aria-label', BatLang.t('chat.downloadBtn') || 'Download');
      dl.innerHTML = _dlSvg;
      // Quick download — must NOT also open the preview, so stop propagation.
      dl.addEventListener('click', function (e) {
        e.stopPropagation();
        if (isPdf) exportAiMarkdownAsPdf(body, title, dateStr);
        else downloadAiMarkdown(body, title, dateStr);
      });

      card.appendChild(icon);
      card.appendChild(info);
      card.appendChild(dl);
      // Click anywhere else on the card → open the rendered preview.
      card.addEventListener('click', function () {
        openTextFilePreview({ title: title, dateStr: dateStr, body: body, format: format });
      });

      bubble.appendChild(card);
      row.appendChild(av);
      row.appendChild(bubble);
      wrap.appendChild(row);
      wrap.scrollTop = wrap.scrollHeight;
    }

    // Illustrative "conversion code" shown when the Analyzing card is expanded
    // (approved Part A redesign) — purely cosmetic, no real execution/sandbox
    // ever runs this. Reads as a plausible pandoc-style Markdown conversion
    // script; kept short and representative rather than exact, since its only
    // job is visual polish consistent with real code blocks elsewhere in the app.
    const EXPORT_CODE_SNIPPET = 'import re\n' +
      'from datetime import datetime\n\n' +
      'def convert_to_markdown(conversation: list[dict]) -> str:\n' +
      '    """Format a chat transcript into a clean Markdown document."""\n' +
      '    sections = []\n' +
      '    for turn in conversation:\n' +
      '        role = "User" if turn["role"] == "user" else "Assistant"\n' +
      '        text = re.sub(r"\\s+", " ", turn["content"]).strip()\n' +
      '        sections.append(f"## {role}\\n{text}\\n")\n\n' +
      '    body = "\\n".join(sections)\n' +
      '    return pandoc.convert(body, to="markdown", extra_args=["--wrap=none"])\n\n' +
      'markdown_doc = convert_to_markdown(messages)\n' +
      'save_file("conversation.md", markdown_doc)';
    // Builds the fake Python/pandoc code block by handing a real <pre><code>
    // element to the REAL enhanceCodeBlocks() — reuses its exact DOM/CSS/hljs
    // highlighting/copy-button machinery instead of re-implementing it, so the
    // block is pixel-identical to genuine code blocks elsewhere in the app.
    function _buildExportCodeBlock() {
      const wrap = document.createElement('div');
      // The whole app's code-block styling (flex header, Copy+Download actions
      // group, dark theme, syntax colors) is scoped under `.md-content` in
      // index.html. enhanceCodeBlocks() below builds the correct shared markup
      // (both buttons), but without a `.md-content` ancestor NONE of those
      // rules apply here — so the header/actions collapse to block flow (Copy's
      // icon+label stack under the language label, Download renders unstyled/
      // invisible). Tagging the wrap `.md-content` makes this a genuine,
      // fully-styled code block that automatically matches every other one and
      // inherits any future code-block styling changes — no isolated CSS patch.
      wrap.className = 'md-content';
      const pre = document.createElement('pre');
      const code = document.createElement('code');
      code.className = 'language-python';
      code.textContent = EXPORT_CODE_SNIPPET;
      pre.appendChild(code);
      wrap.appendChild(pre);
      enhanceCodeBlocks(wrap);
      return wrap;
    }

    // Decorative "Analyzed"-style narration shown inside the streaming bubble
    // while exportConversationViaAI() is in flight (approved redesign,
    // inspired by ChatGPT's collapsible code-interpreter narration). This is
    // DELIBERATELY 100% client-authored — zero model involvement — unlike
    // <STEPS>/<CLARIFY>. The export flow always performs the same fixed
    // sequence regardless of conversation content, so there's no need for the
    // model to author these labels, and doing so would require relaxing
    // buildExportSystemPrompt()'s strict "Markdown body only" contract for no
    // real benefit. Terminal-styled card (dark/monospace, mirrors the
    // .code-block look used for code snippets — see _ensureAnalyzingCardStyles
    // below); the collapsed header still cycles through the 4 real/truthful
    // stage labels, but expanding it now shows the illustrative Python/pandoc
    // snippet above (approved redesign — purely visual, no real execution).
    // APPENDED alongside the existing .hcm-typing indicator inside the same
    // bubble (sequential display, approved) — startHomeThinkingCycle('export')
    // keeps running in parallel, this card does not replace it. Collapsed by
    // default (glyph + cycling stage label + chevron). Cycles on a local timer
    // kept in sync with the real in-flight request. Returns { stop() } so the
    // caller can clear the timer before the bubble row itself is removed.
    const EXPORT_ANALYZE_STAGES = ['export.stage1', 'export.stage2', 'export.stage3', 'export.stage4'];
    function startExportAnalyzingCard(bubbleEl) {
      if (!bubbleEl) return { stop: function () {} };
      _ensureAnalyzingCardStyles();

      const card = document.createElement('div');
      card.className = 'an-card';

      const head = document.createElement('div');
      head.className = 'an-head';
      head.setAttribute('role', 'button');
      head.setAttribute('tabindex', '0');
      head.setAttribute('aria-expanded', 'false');
      const headGlyph = document.createElement('span');
      headGlyph.className = 'an-head-glyph';
      headGlyph.textContent = '$';
      const headTxt = document.createElement('span');
      headTxt.className = 'an-head-txt';
      const chevron = document.createElement('div');
      chevron.className = 'an-head-chevron';
      chevron.innerHTML = _chevronSvg;
      head.appendChild(headGlyph);
      head.appendChild(headTxt);
      head.appendChild(chevron);

      const list = document.createElement('div');
      list.className = 'an-list';
      list.appendChild(_buildExportCodeBlock());

      function toggle() {
        const open = card.classList.toggle('open');
        head.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
      head.addEventListener('click', toggle);
      head.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
      });

      card.appendChild(head);
      card.appendChild(list);
      // Appended below the existing .hcm-typing markup already inside
      // bubbleEl — must NOT wipe it (sequential display, approved).
      bubbleEl.appendChild(card);

      let idx = 0;
      function setLabel() { headTxt.textContent = BatLang.t(EXPORT_ANALYZE_STAGES[idx]) || ''; }
      setLabel();
      const timer = setInterval(function () {
        idx = (idx + 1) % EXPORT_ANALYZE_STAGES.length;
        setLabel();
      }, 1800);

      return { stop: function () { clearInterval(timer); } };
    }

    // Injects the terminal-styled Analyzing-card CSS once (inject-once
    // <style> pattern, like _ensureStepsStyles/_ensureExportCardStyles).
    // Mirrors index.html's .code-block look (dark bg #282c34, border
    // #2b313c, header #1e222a, monospace font) instead of the chat-bubble
    // .steps-card style, per the approved "terminal, not fake code" request.
    function _ensureAnalyzingCardStyles() {
      if (document.getElementById('_anCardStyle')) return;
      const s = document.createElement('style');
      s.id = '_anCardStyle';
      s.textContent = [
        // flex-shrink:0 is REQUIRED: this card is a direct child of the
        // .home-conv-messages flex column, and its overflow:hidden gives it an
        // automatic flex min-height of 0 — so in a long conversation (content
        // taller than the container) the column would shrink it to ~3px (just
        // its borders), making it read as a thin divider / "vanish" (Bug 3
        // root cause). Pinning flex-shrink:0 keeps its natural height; the
        // container scrolls instead of squashing the card.
        '.an-card{max-width:440px;margin:8px 0 2px;border-radius:10px;overflow:hidden;',
        'flex-shrink:0;background:#282c34;border:1px solid #2b313c;font-family:var(--font-mono);}',
        '.an-head{display:flex;align-items:center;gap:8px;padding:7px 12px;cursor:pointer;',
        'user-select:none;background:#1e222a;border-bottom:1px solid #2b313c;transition:background .15s;}',
        '.an-head:hover{background:#242832;}',
        '.an-head-glyph{flex-shrink:0;font-size:.78rem;color:#5b8cff;font-weight:700;}',
        '.an-head-txt{flex:1;min-width:0;font-size:.74rem;font-weight:500;letter-spacing:.02em;',
        'color:#8b98ab;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
        '.an-head-chevron{flex-shrink:0;color:#8b98ab;transition:transform .2s;}',
        '.an-head-chevron svg{width:13px;height:13px;display:block;}',
        '.an-card.open .an-head-chevron{transform:rotate(180deg);}',
        '.an-list{display:none;flex-direction:column;gap:3px;padding:8px 12px 10px;}',
        '.an-card.open .an-list{display:flex;}',
        '.an-item{display:flex;align-items:baseline;gap:7px;font-size:.76rem;',
        'line-height:1.5;color:#6b7686;}',
        '.an-item-glyph{flex-shrink:0;color:#4a5261;}',
        '.an-item.is-done{color:#abb2bf;}',
        '.an-item.is-done .an-item-glyph{color:#3fb950;}'
      ].join('');
      document.head.appendChild(s);
    }

    /* Main export entry point. Sends the whole conversation to the cheap
       /chat/export route (or, if `fullTranscript` is set, skips the AI call
       entirely and builds the body synchronously — see formatTranscriptBody),
       shows the "Analyzed" narration card meanwhile, then delivers the
       Markdown as an interactive file card. Billed at the flat chat_export
       rate (never the user's selected Prime/Core/Flash model). Silent local
       fallback ONLY on genuine network/generation failure — never on
       out-of-credits / rate-limit / abort (own UI). */
    async function exportConversationViaAI(format, fullTranscript) {
      homeConvBusy = true;
      setHomeSendBtnBusy(true);
      hcmSetUserActionsGated('homeConvMessages', true);
      homeConvAbortController = new AbortController();
      renderHomeProjectsGrid();
      // The streaming bubble was already created by homeConvBeginUserTurn()
      // (called just before this, in homeGoGenerate) — reuse it via the
      // module-scope row instead of creating a second one, so the Analyzing
      // card is appended below the SAME "BatNXT is thinking..." indicator
      // (sequential display, approved) rather than a separate bubble.
      const streamRow = _homeStreamingBubbleRow;
      const analyzing = startExportAnalyzingCard(streamRow && streamRow.querySelector('.hcm-bubble'));
      try {
        // homeConvHistory now ends with the user's raw export request (pushed
        // by homeConvBeginUserTurn, so it's visible in chat) — excluded from
        // both paths below, same as before this turn started being recorded.
        const priorHistory = homeConvHistory.slice(0, -1);
        let body;
        if (fullTranscript) {
          // Full-transcript opt-in: no AI call — routed through the SAME
          // Analyzing-card/file-card/persistence flow as the AI-summary path
          // below for UI consistency, just with a synchronously-built body.
          body = formatTranscriptBody(priorHistory);
          if (!body) throw new Error('empty_export');
        } else {
          const messages = priorHistory
            .map(function (m) { return { role: m.role, content: m.content }; })
            .concat([{ role: 'user', content: EXPORT_USER_INSTRUCTION }]);
          const { res } = await gatewayFetch('/chat/export', {
            system: buildExportSystemPrompt(),
            messages: messages
          }, { signal: homeConvAbortController.signal });
          const data = await res.json();
          body = (data.markdown || '').trim();
          // Strip a whole-body code fence if a weaker model wrapped everything in ```.
          const fenced = body.match(/^```(?:markdown|md)?\s*\n([\s\S]*?)\n```$/i);
          if (fenced) body = fenced[1].trim();
          if (!body) throw new Error('empty_export'); // treat blank as a failure → fallback
        }
        analyzing.stop();
        stopHomeThinkingCycle();
        hcmRemoveStreamingBubble();
        // Bug 1 fix: the streaming bubble just removed above was the ONLY
        // thing hosting the Analyzing card (it was appended inside that
        // bubble by startExportAnalyzingCard) — so without this call the
        // card vanishes the moment the live turn completes. Re-add it as a
        // standalone, persistent, collapsed/expandable card (identical to
        // the one hcmRenderSlice's analyzingSteps branch recreates on
        // reload) so the live view matches the reloaded view.
        hcmAppendSavedAnalyzingCard('homeConvMessages');
        // Persist the Analyzing-card marker AND the actual file body/format
        // inline (small text — same inline-persistence pattern as base64
        // images, see homeConvBeginUserTurn) so the interactive file card
        // itself survives a reload too, not just the card's empty shell
        // (restored via hcmRenderSlice's exportBody branch below).
        homeConvHistory.push({
          role: 'assistant',
          content: BatLang.t('export.ready') || '',
          analyzingSteps: true,
          exportBody: body,
          exportFormat: format,
          msgId: mintMsgId()
        });
        saveHomeConvSession();
        // Delivery: interactive session-only file card (preview + Copy/Download)
        // instead of an instant auto-download (approved redesign). The generated
        // body is captured in the card's closure — see appendExportFileCard.
        appendExportFileCard('homeConvMessages', homeConvHistory, body, format);
        // Frame the newest Analyzed card together with its file card instead of
        // resting on the absolute bottom (live path only — the reload path has
        // its own final scroll-to-bottom in lazySetup).
        hcmScrollAnalyzingCardIntoView('homeConvMessages');
      } catch (err) {
        analyzing.stop();
        stopHomeThinkingCycle();
        hcmRemoveStreamingBubble();
        const m = err && err.message;
        if (err && err.name === 'AbortError') {
          // User pressed Stop — nothing to export, no error to show.
        } else if (m === 'no_credits' || m === 'rate_limited' || m === 'weekly_cap_reached' ||
                   m === 'lifetime_cap_reached' ||
                   m === 'banned' || m === 'recharge_on_cooldown' || m === 'not_authenticated') {
          // These already have their own dedicated UI (surfaced by gatewayFetch)
          // and must NOT be bypassed by the free local export.
        } else {
          // Genuine network/generation failure — silent local fallback so an
          // explicit export request never dead-ends.
          if (typeof showToast === 'function') showToast('⚠️ تعذّر التصدير الذكي — تم تصدير نسخة أساسية بدلاً منه.', 'info');
          if (format === 'pdf') exportConversationAsPdf(homeConvHistory);
          else downloadConversationMarkdown(homeConvHistory);
        }
      } finally {
        homeConvBusy = false;
        homeConvAbortController = null;
        setHomeSendBtnBusy(false);
        hcmSetUserActionsGated('homeConvMessages', false);
        renderHomeProjectsGrid();
      }
    }

    window.homeGoGenerate = async function () {
      if (homeConvBusy) return; // AI is busy — ignore new sends until it's free
      const inp = document.getElementById('homeInput');
      const prompt = (inp && inp.value ? inp.value : '').trim();
      const hasAttachment = attachedFiles.length > 0;
      if (!prompt && !hasAttachment) { if (inp) inp.focus(); return; }
      if (!requireLogin()) return;

      // No type selected → chatbot mode
      if (!selectedType) {
        // Explicit conversation-export request — routed to the AI-driven
        // exporter (a professional Markdown summary), which falls back to a
        // local raw dump only on failure. Skipped if an attachment is present
        // (the user likely means to discuss/send that attachment, not export).
        if (!hasAttachment && homeConvActive && homeConvHistory.length > 0 && detectExportRequest(prompt)) {
          const exFormat = detectExportFormat(prompt);
          const exFullTranscript = detectFullTranscriptRequest(prompt);
          if (inp) { inp.value = ''; inp.style.height = 'auto'; }
          // Approved redesign: the export request is now a real, visible turn
          // (user bubble + history push) instead of a silent trigger — reuses
          // homeConvBeginUserTurn() so it also (re)starts
          // startHomeThinkingCycle('export'), giving the sequential
          // "thinking..." + Analyzing-card display requested.
          homeConvBeginUserTurn(prompt, [], 'export');
          exportConversationViaAI(exFormat, exFullTranscript);
          return;
        }
        if (inp) { inp.value = ''; inp.style.height = 'auto'; }
        // Preserve attached images (if any, up to ATTACH_MAX_IMAGE_COUNT) for
        // the Moondream preprocessing pipeline before clearing the composer's
        // attachment state.
        const chatImageFiles = attachedFiles.filter(function (f) { return f.kind === 'image'; });
        const chatImages = chatImageFiles.map(function (f) { return f.content; });
        // Parallel array of original filenames (index-aligned with chatImages) —
        // persisted alongside each image in the Library (see persistLibraryImage).
        const chatImageNames = chatImageFiles.map(function (f) { return f.name; });
        const chatAttType = chatImages.length ? 'image' : (attachedFiles.some(function (f) { return f.kind === 'text'; }) ? 'file' : 'text');
        attachedFiles = []; renderAttachments();
        await homeConvSend(prompt, chatImages, chatAttType, chatImageNames);
        return;
      }

      let type = selectedType;
      if (PRO_TYPES.includes(type) && !isProPlan()) {
        type = 'game';
        window.setHomeType('game');
        showPricingModal();
        return;
      }

      // ── Show the message + clear the composer immediately — don't leave the
      //    user staring at their own unsent text while intent classification
      //    (a worker round-trip) runs in the background. ──
      if (inp) { inp.value = ''; inp.style.height = 'auto'; inp.dispatchEvent(new Event('input')); }
      const btn = document.getElementById('homeSendBtn');
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<svg style="animation:spin .75s linear infinite;width:18px;height:18px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-.08-8.49"/></svg>';
      }
      _genInChatMode = true;
      const attachmentType = attachedFiles.some(function (f) { return f.kind === 'image'; }) ? 'image'
        : attachedFiles.some(function (f) { return f.kind === 'text'; }) ? 'file' : 'text';
      // Images here are for bubble DISPLAY only (Phase 2.2) — this is the
      // build/generate flow, which never forwarded attachments to Moondream
      // even under the old single-image code (see homeConvGetReply(prompt)
      // below, which intentionally omits them).
      const attachedImagesForDisplay = attachedFiles.filter(function (f) { return f.kind === 'image'; }).map(function (f) { return f.content; });
      homeConvBeginUserTurn(prompt, attachedImagesForDisplay, attachmentType);

      // Intent gate: a selected build type must NOT force every message into file
      // generation. Attachments always imply "build"; otherwise classify the text —
      // greetings / questions / small-talk are answered in chat (no credit spent),
      // and only genuine build requests run the generator. (The message is
      // already visible above, so this no longer looks like a stuck send.)
      // Widened phrase pre-filter runs first (free) to catch short conversational
      // replies chatRe misses, before spending a call on classifyBuildIntent().
      const intent = attachedFiles.length ? 'build'
        : isBuildIntentPrefilterChat(prompt) ? 'chat'
        : await classifyBuildIntent(prompt, type);
      if (intent === 'chat') {
        attachedFiles = []; renderAttachments();
        await homeConvGetReply(prompt);   // reply only — the turn was already appended above
        return;
      }

      if (currentCredits <= 0) {
        showUpgradeModal();
        hcmRemoveStreamingBubble();
        stopHomeThinkingCycle();
        homeConvHistory.pop(); // no reply given — don't poison history
        saveHomeConvSession();
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
        }
        return;
      }

      const subtype = sessionStorage.getItem('batlab_subtype') || '';
      const attachContext = buildAttachContext();
      const convMsgsEl = document.getElementById('homeConvMessages');
      // The build flow shows its own progress via hcmCreateBuildWidget()
      // (appended separately by runGeneration() in chat mode) — the
      // "thinking" bubble homeConvBeginUserTurn() created has served its
      // purpose and isn't needed once the build widget takes over.
      hcmRemoveStreamingBubble();

      // File analysis trace (only if files were attached to this message)
      if (attachedFiles.length) {
        await runFileAnalysisTrace(attachedFiles.slice()); // snapshot before it's cleared later
      }

      // Thinking analysis before generation (capture reasoning so it can be
      // saved with the turn and restored when the chat is re-opened later)
      const _thinkResult = await runPreGenAnalysis(prompt, type);

      // If a build already exists for this chat, treat the follow-up as an
      // iterative edit instead of generating a brand-new file from scratch.
      const editingExisting = !!lastHTML;
      const genOpts = Object.assign({}, editingExisting ? { baseHTML: lastHTML } : {}, attachContext ? { attachContext } : {});

      await saveGenHistory(prompt, type, subtype, homeConvSessionId || null);
      await runGeneration(prompt, type, subtype, genOpts);

      stopHomeThinkingCycle();
      if (convMsgsEl) convMsgsEl.scrollTop = convMsgsEl.scrollHeight;

      // Record the build turn in chat history (with the generated HTML attached)
      // so it restores correctly from the sidebar, exactly like a normal reply.
      // (On failure, runGeneration already appended an error bubble to the chat.)
      if (lastHTML) {
        homeConvHistory.push({
          role: 'assistant',
          content: editingExisting ? ('Applied your changes to the ' + type + '.') : ('Generated your ' + type + '.'),
          think: (_thinkResult && _thinkResult.text) ? { text: _thinkResult.text, secs: _thinkResult.secs } : null,
          gen: { html: lastHTML, type: type, fileName: type + '.html', label: editingExisting ? 'Updated file' : 'Generated file' },
          msgId: mintMsgId()
        });
        saveHomeConvSession();
        // Skip the (paid) AI title call for short/generic first messages — the
        // truncated-message fallback title set in saveHomeConvSession() is already fine for those.
        if (homeConvHistory.filter(m => m.role === 'user').length === 1 && isMemoryExtractionEligible(homeConvHistory[0].content)) {
          generateChatTitle(homeConvHistory[0].content, prompt, async function (title) {
            const s = homeChatSessions.find(function (x) { return x.id === homeConvSessionId; });
            if (s) {
              s.title = title;
              renderHomeChatHistory();
              updateHomeBreadcrumb();
              try { await supabase.from('chat_sessions').update({ title }).eq('id', homeConvSessionId); } catch (e) {}
            }
            setPageTitle(title);
          });
        }
      } else {
        homeConvHistory.pop(); // remove the unanswered user turn so history isn't poisoned
        saveHomeConvSession();
      }

      attachedFiles = [];
      renderAttachments();

      if (btn) {
        btn.disabled = false;
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
      }
    };

    window.hwSwitchTab = function (tab) {
      hwCurrentTab = tab;
      // Scope to workspace panel only (not the hcm preview drawer which also uses .hw-tab)
      const hwPanel = document.getElementById('hwPreviewPanel');
      const tabRoot = hwPanel || document;
      tabRoot.querySelectorAll('.hw-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
      // Hide zoom controls in code view; show in preview view
      const zg = document.getElementById('hwZoomGroup');
      if (zg && zg.style.display !== 'none') {
        zg.style.visibility = (tab === 'preview') ? 'visible' : 'hidden';
      }
      // Show floating copy button only when viewing code
      const copyOverlay = document.getElementById('hwCopyOverlay');
      if (copyOverlay) copyOverlay.style.display = (tab === 'code') ? '' : 'none';
      updateHwPreviewVisibility();
    };

    // Copy the current code view content to clipboard
    window.hwCopyCode = function () {
      const codeView = document.getElementById('hwCodeView');
      if (!codeView || !codeView.textContent.trim()) return;
      const btn = document.getElementById('hwCopyCodeBtn');
      const originalHTML = btn ? btn.innerHTML : '';
      navigator.clipboard.writeText(codeView.textContent).then(function () {
        if (btn) {
          btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg><span>Copied!</span>';
          setTimeout(function () { btn.innerHTML = originalHTML; }, 2000);
        }
        showToast(BatLang.t('toast.codeCopied') || 'Code copied!', 'success');
      }).catch(function () {
        showToast(BatLang.t('toast.shareFail') || 'Copy failed', 'error');
      });
    };

    window.hwDownload = function () {
      if (!lastHTML) return;
      const blob = new Blob([withBatnxtBadge(lastHTML)], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `batnxt-${lastType || 'project'}-${Date.now()}.html`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    };

    // Share the generated result as a self-contained link (base64 data URL).
    // Works with no backend: the whole page is encoded into the URL so it opens anywhere.
    window.hwShare = async function () {
      if (!lastHTML) return;
      // Serve-time badge (Free tier only) — the shared link IS the delivered
      // artifact, so badge it once for both the data-URL and the fallback tab.
      const shareHTML = withBatnxtBadge(lastHTML);
      let link;
      try {
        // encode as UTF-8 safe base64 data URL
        const b64 = btoa(unescape(encodeURIComponent(shareHTML)));
        link = 'data:text/html;charset=utf-8;base64,' + b64;
      } catch (e) {
        showToast(BatLang.t('toast.shareFail'), 'error');
        return;
      }
      const title = `BatNXT ${lastType || 'project'}`;
      // Prefer native share sheet when available (mobile / supported browsers)
      if (navigator.share) {
        try {
          await navigator.share({ title, text: title, url: link });
          return;
        } catch (err) {
          if (err && err.name === 'AbortError') return; // user cancelled, no error toast
          // fall through to clipboard
        }
      }
      try {
        await navigator.clipboard.writeText(link);
        showToast(BatLang.t('toast.linkCopied'), 'success');
      } catch (err) {
        // last-resort fallback: open the generated page in a new tab
        const w = window.open();
        if (w) { w.document.open(); w.document.write(shareHTML); w.document.close(); }
        else showToast(BatLang.t('toast.shareFail'), 'error');
      }
    };

    // ── Preview Zoom (hw workspace panel) ──
    let hwZoomLevel = 1;
    const _hwZoomSteps = [0.5, 0.75, 1, 1.25, 1.5, 2];

    function _hwApplyZoom(level) {
      hwZoomLevel = level;
      const isMobile = lastType === 'mobile';
      const iframe = isMobile
        ? document.getElementById('hwPreviewIframeMobile')
        : document.getElementById('hwPreviewIframe');
      if (iframe) {
        if (level > 1) {
          const pct = (100 / level).toFixed(3) + '%';
          iframe.style.width = pct;
          iframe.style.height = pct;
          iframe.style.transform = 'scale(' + level + ')';
          iframe.style.transformOrigin = 'top left';
        } else {
          iframe.style.width = '100%';
          iframe.style.height = '100%';
          iframe.style.transform = level < 1 ? 'scale(' + level + ')' : '';
          iframe.style.transformOrigin = 'top center';
        }
      }
      const lbl = document.getElementById('hwZoomLabel');
      if (lbl) lbl.textContent = Math.round(level * 100) + '%';
      const idx = _hwZoomSteps.indexOf(level);
      const btnIn = document.getElementById('hwZoomIn');
      const btnOut = document.getElementById('hwZoomOut');
      if (btnIn) btnIn.disabled = idx >= _hwZoomSteps.length - 1;
      if (btnOut) btnOut.disabled = idx <= 0;
    }

    window.hwZoomIn = function () {
      const idx = _hwZoomSteps.indexOf(hwZoomLevel);
      if (idx < _hwZoomSteps.length - 1) _hwApplyZoom(_hwZoomSteps[idx + 1]);
    };
    window.hwZoomOut = function () {
      const idx = _hwZoomSteps.indexOf(hwZoomLevel);
      if (idx > 0) _hwApplyZoom(_hwZoomSteps[idx - 1]);
    };
    window.hwZoomReset = function () { _hwApplyZoom(1); };

    // ── Preview Zoom (hcm drawer panel) ──
    let hcmZoomLevel = 1;
    const _hcmZoomSteps = [0.5, 0.75, 1, 1.25, 1.5, 2];

    function _hcmApplyZoom(level) {
      hcmZoomLevel = level;
      const iframe = document.getElementById('hcmPreviewIframe');
      if (iframe) {
        if (level > 1) {
          const pct = (100 / level).toFixed(3) + '%';
          iframe.style.width = pct;
          iframe.style.height = pct;
          iframe.style.transform = 'scale(' + level + ')';
          iframe.style.transformOrigin = 'top left';
        } else {
          iframe.style.width = '100%';
          iframe.style.height = '100%';
          iframe.style.transform = level < 1 ? 'scale(' + level + ')' : '';
          iframe.style.transformOrigin = 'top center';
        }
      }
      const lbl = document.getElementById('hcmZoomLabel');
      if (lbl) lbl.textContent = Math.round(level * 100) + '%';
      const idx = _hcmZoomSteps.indexOf(level);
      const btnIn = document.getElementById('hcmZoomIn');
      const btnOut = document.getElementById('hcmZoomOut');
      if (btnIn) btnIn.disabled = idx >= _hcmZoomSteps.length - 1;
      if (btnOut) btnOut.disabled = idx <= 0;
    }

    window.hcmZoomIn = function () {
      const idx = _hcmZoomSteps.indexOf(hcmZoomLevel);
      if (idx < _hcmZoomSteps.length - 1) _hcmApplyZoom(_hcmZoomSteps[idx + 1]);
    };
    window.hcmZoomOut = function () {
      const idx = _hcmZoomSteps.indexOf(hcmZoomLevel);
      if (idx > 0) _hcmApplyZoom(_hcmZoomSteps[idx - 1]);
    };
    window.hcmZoomReset = function () { _hcmApplyZoom(1); };

    window.hwFollowupSend = async function () {
      const inp = document.getElementById('hwFollowupInput');
      const prompt = (inp && inp.value ? inp.value : '').trim();
      if (!prompt) return;
      if (!requireLogin()) return;
      const type = lastType || 'game';
      if (inp) { inp.value = ''; inp.style.height = 'auto'; }

      const intent = detectHwIntent(prompt);

      // ── casual question: answer via chat without generating ──
      if (intent === 'chat') {
        appendHwUserChatMsg(prompt);
        appendHwThinking();
        const reply = await sendHwChatMessage(prompt);
        removeHwThinking();
        if (reply) appendHwChatReply(reply);
        return;
      }

      // ── edit / generate intent ──
      if (currentCredits <= 0) { showUpgradeModal(); return; }
      const editing = !!lastHTML;
      appendHwThinking();
      await saveGenHistory(prompt, type, lastSubtype);
      await runGeneration(prompt, type, lastSubtype, editing ? { baseHTML: lastHTML } : {});
    };

    // The sidebar's default and collapsed-rail widths live in CSS as the
    // --sb-width / --sb-rail custom properties (see the "Sidebar scale" block
    // in index.html's :root) so the whole panel can be rescaled from one place.
    // Because the handlers below write an *inline* width — which outranks the
    // stylesheet — they have to read the variables back rather than hardcode
    // px, otherwise collapsing/expanding would silently snap the sidebar to a
    // stale size. Reading it live also picks up the ≤1100px tablet override.
    function sbVar(name, fallback) {
      const v = parseFloat(
        getComputedStyle(document.documentElement).getPropertyValue(name)
      );
      return isFinite(v) && v > 0 ? v : fallback;
    }

    // Custom drag-resized sidebar width (px), or null to use the CSS default
    // (--sb-width). Set by the drag handler below; re-applied/cleared here so
    // collapsing always snaps to the fixed --sb-rail regardless of it.
    let sidebarCustomWidth = null;

    window.toggleSidebar = function () {
      const sb = document.getElementById('sidebar');
      const ab = document.querySelector('.app-body');
      const rs = document.getElementById('sidebarResizer');
      if (!sb) return;
      const isCollapsed = sb.classList.toggle('collapsed');
      if (ab) ab.classList.toggle('sidebar-collapsed', isCollapsed);
      if (isCollapsed) {
        sb.style.width = '';
        if (ab) ab.style.paddingLeft = '';
        if (rs) rs.style.left = sbVar('--sb-rail', 48) + 'px';
      } else {
        const w = sidebarCustomWidth || sbVar('--sb-width', 176);
        sb.style.width = w + 'px';
        if (ab) ab.style.paddingLeft = w + 'px';
        if (rs) rs.style.left = w + 'px';
      }
    };

    // ── sidebar resize handle: drag left/right to resize (clamped between
    // a floor and a ceiling — dragging never collapses it all the way);
    // a plain click (no movement) on the handle toggles collapse, same as
    // the dedicated toggle button. ──────────────────────────────────────
    (function () {
      const resizer = document.getElementById('sidebarResizer');
      const sb = document.getElementById('sidebar');
      const ab = document.querySelector('.app-body');
      if (!resizer || !sb) return;

      // Drag bounds, kept in proportion to the --sb-width default (176px) at
      // roughly 0.8x / 1.6x. The floor must stay at or below the narrowest
      // default any breakpoint uses (144px on the 861–1100px tablet override)
      // or the sidebar could never be dragged back to its own default width.
      const MIN_W = 140;   // px — floor while dragging; full collapse (--sb-rail) is click-only
      const MAX_W = 288;   // px — ceiling while dragging
      const CLICK_SLOP = 4; // px of movement below which mouseup counts as a click, not a drag

      let startX = 0, startW = 0, dragging = false, moved = false, rafId = null;

      function applyWidth(clientX) {
        const newW = Math.max(MIN_W, Math.min(startW + (clientX - startX), MAX_W));
        sidebarCustomWidth = newW;
        sb.style.width = newW + 'px';
        if (ab) ab.style.paddingLeft = newW + 'px';
        resizer.style.left = newW + 'px';
      }

      function startDrag(clientX) {
        if (sb.classList.contains('collapsed')) return false;
        dragging = true;
        moved = false;
        startX = clientX;
        startW = sb.getBoundingClientRect().width;
        sb.classList.add('resizing');
        if (ab) ab.classList.add('sidebar-resizing');
        resizer.classList.add('dragging');
        document.body.style.userSelect = 'none';
        document.body.style.cursor = 'col-resize';
        return true;
      }

      function moveDrag(clientX) {
        if (!dragging) return;
        if (!moved && Math.abs(clientX - startX) > CLICK_SLOP) moved = true;
        if (!moved) return;
        if (rafId) cancelAnimationFrame(rafId);
        rafId = requestAnimationFrame(function () { applyWidth(clientX); });
      }

      function stopDrag() {
        if (!dragging) return;
        dragging = false;
        rafId = null;
        sb.classList.remove('resizing');
        if (ab) ab.classList.remove('sidebar-resizing');
        resizer.classList.remove('dragging');
        document.body.style.userSelect = '';
        document.body.style.cursor = '';
        if (!moved) window.toggleSidebar(); // plain click == toggle button
      }

      resizer.addEventListener('mousedown', function (e) { e.preventDefault(); startDrag(e.clientX); });
      document.addEventListener('mousemove', function (e) { moveDrag(e.clientX); });
      document.addEventListener('mouseup', stopDrag);
      document.addEventListener('mouseleave', stopDrag);

      resizer.addEventListener('touchstart', function (e) {
        if (e.touches.length !== 1) return;
        startDrag(e.touches[0].clientX);
      }, { passive: true });
      document.addEventListener('touchmove', function (e) {
        if (!dragging || e.touches.length !== 1) return;
        moveDrag(e.touches[0].clientX);
      }, { passive: true });
      document.addEventListener('touchend', stopDrag);
      document.addEventListener('touchcancel', stopDrag);
    })();

    // Mobile off-canvas sidebar drawer: on ≤860px the sidebar becomes a
    // bottom icon tab bar (see CSS), so this opens it as a full drawer
    // instead, via the hamburger button in .nav / backdrop / close (X) btn.
    window.toggleMobileSidebar = function (force) {
      const open = typeof force === 'boolean' ? force : !document.body.classList.contains('mobile-sidebar-open');
      document.body.classList.toggle('mobile-sidebar-open', open);
    };
    (function setupMobileSidebarDrawer() {
      function ready() {
        // Delegate on the whole sidebar (not just #sidebarScroll): "New Chat"
        // is pinned OUTSIDE the scroll area, so listening only on the scroll
        // area would miss its taps on mobile.
        const scroll = document.getElementById('sidebar');
        if (scroll) {
          scroll.addEventListener('click', function (e) {
            if (e.target.closest('.sidebar-item, .sidebar-sub-item, .sidebar-history-item')) {
              window.toggleMobileSidebar(false);
            }
          });
          // Wheel-anywhere: #sidebarScroll is the sidebar's only scrollable
          // region, but users expect the wheel to scroll it no matter where the
          // pointer sits in the sidebar (over the pinned "New Chat" button, the
          // "Menu" label or the profile too). Forward the delta to it whenever the
          // event isn't already over it. When it IS over it, native scrolling
          // handles it, so we don't intercept (avoids double-scroll).
          scroll.addEventListener('wheel', function (e) {
            const area = document.getElementById('sidebarScroll');
            if (!area) return;
            if (e.target.closest && e.target.closest('#sidebarScroll')) return;
            if (area.scrollHeight <= area.clientHeight) return; // nothing to scroll
            // Normalise line/page delta modes to pixels for consistent speed.
            const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? area.clientHeight : 1;
            area.scrollTop += e.deltaY * unit;
            e.preventDefault();
          }, { passive: false });
        }
        window.addEventListener('resize', function () {
          if (window.innerWidth > 860) window.toggleMobileSidebar(false);
        });
        window.addEventListener('keydown', function (e) {
          if (e.key === 'Escape') window.toggleMobileSidebar(false);
        });
      }
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
      else ready();
    })();

    window.hwNewChat = function () {
      removeHwThinking();
      const view = document.getElementById('homeView');
      if (view) view.classList.remove('workspace');
      const sb = document.getElementById('sidebar');
      if (sb) sb.classList.remove('collapsed');
      const ab = document.querySelector('.app-body');
      if (ab) ab.classList.remove('sidebar-collapsed');
      const msgs = document.getElementById('hwMessages');
      if (msgs) msgs.innerHTML = '';
      const inp = document.getElementById('homeInput');
      if (inp) { inp.value = ''; inp.style.height = 'auto'; inp.focus(); }
      const followup = document.getElementById('hwFollowupInput');
      if (followup) followup.value = '';
      hideHwLoading();
      hideHwFailed();
    };

    /* ── preview toggle (close / restore) ── */
    window.hwTogglePreview = function () {
      const pp = document.getElementById('hwPreviewPanel');
      const rs = document.getElementById('hwResizer');
      const chat = document.querySelector('.hw-chat');
      if (!pp) return;
      const isHidden = pp.style.display === 'none';
      if (isHidden) {
        pp.style.display = '';
        if (rs) rs.style.display = '';
        if (chat) chat.style.width = '';
      } else {
        pp.style.display = 'none';
        if (rs) rs.style.display = 'none';
        if (chat) chat.style.width = '100%';
      }
    };

    /* ── hw-chat thinking bubble ── */
    var _hwThinkingEl = null;
    var _hwThinkingTimer = null;
    // Multi-agent "AI factory" sequence — purely presentational; runs on its
    // own timer independent of actual generation latency, and is torn down
    // by removeHwThinking() whenever the real result arrives.
    var _hwForgeSteps = [
      { icon: '🧠', label: 'AI Architect — planning structure' },
      { icon: '🎨', label: 'AI Designer — composing UI' },
      { icon: '💻', label: 'AI Developer — writing code' },
      { icon: '🔒', label: 'Security AI — hardening output' },
      { icon: '🚀', label: 'Deployment AI — finalizing build' },
    ];
    function appendHwThinking() {
      if (_genInChatMode) return; // HCM typing indicator is used instead
      removeHwThinking();
      var msgs = document.getElementById('hwMessages');
      if (!msgs) return;

      var el = document.createElement('div');
      el.className = 'hw-forge';
      el.setAttribute('data-hw-thinking', '1');
      el.innerHTML =
        '<div class="hw-forge-title"><span class="hw-forge-title-dot"></span>Initializing Workspace</div>' +
        '<div class="hw-forge-bar-track"><div class="hw-forge-bar-fill" id="hwForgeBarFill"></div></div>' +
        '<div class="hw-forge-steps" id="hwForgeSteps">' +
        _hwForgeSteps.map(function (s, i) {
          return '<div class="hw-forge-step" data-step="' + i + '">' +
            '<span class="hw-forge-step-icon"><span>' + s.icon + '</span></span>' +
            '<span>' + s.label + '</span></div>';
        }).join('') +
        '</div>';
      msgs.appendChild(el);
      msgs.scrollTop = msgs.scrollHeight;
      _hwThinkingEl = el;

      var fill = el.querySelector('#hwForgeBarFill');
      var stepEls = el.querySelectorAll('.hw-forge-step');
      var idx = 0;

      function activate(i) {
        stepEls.forEach(function (node, ni) {
          node.classList.toggle('is-active', ni === i);
          node.classList.toggle('is-done', ni < i);
        });
        if (fill) fill.style.width = Math.round(((i + 1) / _hwForgeSteps.length) * 92) + '%';
      }
      activate(0);

      _hwThinkingTimer = setInterval(function () {
        idx++;
        if (idx >= _hwForgeSteps.length) {
          // Hold on the last step (mostly-full bar) until removeHwThinking()
          // is called when the real generation actually resolves.
          clearInterval(_hwThinkingTimer);
          _hwThinkingTimer = null;
          return;
        }
        activate(idx);
      }, 1600);
    }
    function removeHwThinking() {
      clearInterval(_hwThinkingTimer);
      _hwThinkingTimer = null;
      if (!_hwThinkingEl) return;

      var el = _hwThinkingEl;
      _hwThinkingEl = null;

      // Complete all steps instantly
      var fill = el.querySelector('#hwForgeBarFill');
      if (fill) fill.style.width = '100%';
      el.querySelectorAll('.hw-forge-step').forEach(function (n) {
        n.classList.add('is-done');
        n.classList.remove('is-active');
      });

      // After a brief pause, collapse into a clickable "N actions" summary row
      setTimeout(function () {
        if (!el.parentNode) return;

        // Build icon chips from the first 3 steps
        var iconsHtml = _hwForgeSteps.slice(0, 3).map(function (s) {
          return '<span class="hw-forge-summary-icon">' + s.icon + '</span>';
        }).join('');

        var summary = document.createElement('div');
        summary.className = 'hw-forge-summary';
        summary.innerHTML =
          '<div class="hw-forge-summary-icons">' + iconsHtml + '</div>' +
          '<span class="hw-forge-summary-label">' + _hwForgeSteps.length + ' actions</span>' +
          '<svg class="hw-forge-summary-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
               'stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
            '<polyline points="18 15 12 9 6 15"/>' +
          '</svg>';

        // Insert summary before the steps list so it acts as a toggle header
        el.insertBefore(summary, el.firstChild);
        el.classList.add('is-done'); // hides title/bar, shows summary, hides steps

        summary.addEventListener('click', function () {
          el.classList.toggle('is-open');
          var msgs = document.getElementById('hwMessages');
          if (msgs) msgs.scrollTop = msgs.scrollHeight;
        });
      }, 500);
    }

    /* ── AI summary message after generation ── */
    function appendHwAiMessage(type, isEdit) {
      if (_genInChatMode) { appendGenResultToChat(type, isEdit); return; }
      var msgs = document.getElementById('hwMessages');
      if (!msgs) return;
      var typeLabel = (BatLang.t('type.' + type) || type || 'build');
      var text = isEdit
        ? 'Done! Applied your changes to the ' + typeLabel + '. Let me know if you\'d like to tweak anything else.'
        : 'All set! I\'ve created your ' + typeLabel + '. You can see it in the preview on the right.';
      var div = document.createElement('div');
      div.className = 'hw-ai-msg';
      div.innerHTML = '<div class="hw-ai-badge"><span class="hw-ai-badge-dot"></span>BatNXT AI</div>' + escapeHtml(text);
      msgs.appendChild(div);
      msgs.scrollTop = msgs.scrollHeight;
      appendHwFileCard(type, isEdit);
    }

    /* ── Clickable file card shown after generation ── */
    function appendHwFileCard(type, isEdit) {
      var msgs = document.getElementById('hwMessages');
      if (!msgs) return;
      var fileName = (type || 'build') + '.html';
      var label = isEdit ? 'Updated file' : 'Generated file';
      var div = document.createElement('div');
      div.className = 'hw-file-card';
      div.title = 'Click to open preview';
      div.innerHTML =
        '<div class="hw-file-card-icon">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>' +
        '</div>' +
        '<div class="hw-file-card-info">' +
          '<div class="hw-file-card-name">' + escapeHtml(fileName) + '</div>' +
          '<div class="hw-file-card-meta">' + escapeHtml(label) + ' · click to preview</div>' +
        '</div>' +
        '<div class="hw-file-card-btn">VIEW →</div>';
      div.addEventListener('click', function () {
        var pp = document.getElementById('hwPreviewPanel');
        var rs = document.getElementById('hwResizer');
        var chat = document.querySelector('.hw-chat');
        if (pp && pp.style.display === 'none') {
          pp.style.display = '';
          if (rs) rs.style.display = '';
          if (chat) chat.style.width = '';
        }
        if (window.hwSwitchTab) window.hwSwitchTab('preview');
      });
      msgs.appendChild(div);
      msgs.scrollTop = msgs.scrollHeight;
    }

    /* ── In-chat generation result (used when _genInChatMode is true) ── */
    /* Build a clickable "click to preview" file card and append it to `wrap`.
       Shared by the live generation flow (appendGenResultToChat) and the
       history-restore flow (loadHomeChatSession) so a restored card behaves
       exactly like a freshly-generated one. `html` is snapshotted onto the
       card's click handler so it keeps showing the right build even after a
       later generation overwrites the global lastHTML. */
    function hcmAppendFileCard(wrap, fileName, label, html, type) {
      if (!wrap) return;
      var card = document.createElement('div');
      card.className = 'hw-file-card hcm-file-card';
      card.title = 'Click to preview';
      card.style.cursor = 'pointer';
      card.innerHTML =
        '<div class="hw-file-card-icon">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>' +
        '</div>' +
        '<div class="hw-file-card-info">' +
          '<div class="hw-file-card-name">' + escapeHtml(fileName) + '</div>' +
          '<div class="hw-file-card-meta">' + escapeHtml(label) + ' · click to preview</div>' +
        '</div>' +
        '<div class="hw-file-card-btn">VIEW →</div>';
      var htmlSnapshot = html || '';
      var typeSnapshot = type;
      card.addEventListener('click', function () {
        if (htmlSnapshot) window.hcmOpenPreview(htmlSnapshot, typeSnapshot);
      });
      wrap.appendChild(card);
    }

    function appendGenResultToChat(type, isEdit) {
      var wrap = document.getElementById('homeConvMessages');
      if (!wrap) return;
      var typeLabel = (BatLang.t('type.' + type) || type || 'build');
      var text = isEdit
        ? 'Done! Applied your changes to the ' + typeLabel + '. Click the file to preview it, or ask for more tweaks.'
        : 'Your ' + typeLabel + ' is ready! Click the file to preview it.';
      // AI bubble
      var aiDiv = document.createElement('div');
      aiDiv.className = 'hcm-msg';
      var av = document.createElement('div');
      av.className = 'hcm-avatar is-logo';
      av.innerHTML = '<img src="image/logo website.png" alt="BatNXT">';
      var bubble = document.createElement('div');
      bubble.className = 'hcm-bubble';
      bubble.textContent = text;
      aiDiv.appendChild(av);
      aiDiv.appendChild(bubble);
      wrap.appendChild(aiDiv);
      // File card (click → preview drawer)
      var fileName = (type || 'build') + '.html';
      var label = isEdit ? 'Updated file' : 'Generated file';
      var htmlSnapshot = (typeof lastHTML !== 'undefined') ? lastHTML : '';
      hcmAppendFileCard(wrap, fileName, label, htmlSnapshot, type);
      wrap.scrollTop = wrap.scrollHeight;
    }

    /* ── Click-to-preview drawer (opened from an in-chat file card) ──
       Reuses the already-generated HTML; coexists with the home chat instead of
       switching into the full workspace split view. */
    var hcmPreviewHTML = '';
    var hcmPreviewType = '';

    window.hcmOpenPreview = function (html, type) {
      hcmPreviewHTML = html || '';
      hcmPreviewType = type || 'project';
      var drawer = document.getElementById('hcmPreviewDrawer');
      var frame = document.getElementById('hcmPreviewIframe');
      var code = document.getElementById('hcmCodeView');
      if (!drawer) return;
      // Serve-time badge (Free tier only) applied fresh at each read site;
      // hcmPreviewHTML itself stays raw.
      var badged = withBatnxtBadge(hcmPreviewHTML);
      if (frame) frame.srcdoc = withPreviewShim(badged);
      if (code) code.textContent = badged;
      // Reset zoom whenever drawer opens with new content
      _hcmApplyZoom(1);
      hcmSwitchPreviewTab('preview');
      drawer.classList.add('open');
      drawer.setAttribute('aria-hidden', 'false');
    };

    window.hcmClosePreview = function () {
      var drawer = document.getElementById('hcmPreviewDrawer');
      if (!drawer) return;
      drawer.classList.remove('open');
      drawer.setAttribute('aria-hidden', 'true');
    };

    window.hcmSwitchPreviewTab = function (tab) {
      var drawer = document.getElementById('hcmPreviewDrawer');
      var copyBtn = document.getElementById('hcmCopyBtn');
      if (!drawer) return;
      var showCode = tab === 'code';
      drawer.classList.toggle('show-code', showCode);
      drawer.querySelectorAll('.hw-tab').forEach(function (t) {
        t.classList.toggle('active', t.dataset.htab === tab);
      });
      // Copy only makes sense while viewing the code.
      if (copyBtn) copyBtn.style.display = showCode ? '' : 'none';
      // Hide zoom controls in code view
      var zg = document.getElementById('hcmZoomGroup');
      if (zg) zg.style.visibility = showCode ? 'hidden' : 'visible';
    };

    window.hcmPreviewDownload = function () {
      if (!hcmPreviewHTML) return;
      var blob = new Blob([withBatnxtBadge(hcmPreviewHTML)], { type: 'text/html' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'batnxt-' + (hcmPreviewType || 'project') + '-' + Date.now() + '.html';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    };

    window.hcmPreviewCopy = function () {
      if (!hcmPreviewHTML) return;
      // WYSIWYG: copy the same badged source the viewer sees (Free tier only).
      var copyHTML = withBatnxtBadge(hcmPreviewHTML);
      var done = function () {
        try { showToast(BatLang.t('toast.copied') || 'Copied to clipboard', 'success'); } catch (e) {}
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(copyHTML).then(done).catch(function () {
          try { showToast('Copy failed', 'error'); } catch (e) {}
        });
      } else {
        // Fallback for insecure contexts without the async clipboard API.
        var ta = document.createElement('textarea');
        ta.value = copyHTML;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        ta.remove();
      }
    };

    // Decorative for now (per request): the share/live button is visual only.
    window.hcmPreviewShare = function () {
      try { showToast(BatLang.t('toast.shareSoon') || 'Live sharing is coming soon', 'success'); } catch (e) {}
    };

    /* ── Pre-generation / reasoning thinking widget ──
       Generalized (2026-07-24) to power the "Thought for Xs" indicator across
       BOTH the build flow (runPreGenAnalysis, Home) and the substantive-reply
       flow (Home chat + Marketing). `containerId` selects the surface
       (#homeConvMessages | #marketingMessages); defaults to Home so existing
       build callers pass nothing and behave identically.

       Honest-degrade contract: if the widget finishes with NO captured
       reasoning text (e.g. Core produced no reasoning delta, or the background
       /chat/reason call failed), setDone() collapses it into a bodyless,
       non-expandable "Thought for Xs" chip — a real timing badge, never
       fabricated thinking text. */
    function hcmCreateThinkingWidget(containerId, promptText) {
      var wrap = document.getElementById(containerId || 'homeConvMessages');
      if (!wrap) return null;
      var isAr = window.currentLang === 'ar';
      var el = document.createElement('div');
      var dir = pickThinkingDir(promptText);
      el.dir = dir;
      el.style.textAlign = dir === 'rtl' ? 'right' : 'left';
      el.className = 'hcm-thinking hcm-thinking--active open';
      el.innerHTML =
        '<div class="hcm-thinking-header">' +
          '<span class="hcm-thinking-icon">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:13px;height:13px"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>' +
          '</span>' +
          '<span class="hcm-thinking-label hcm-tl-active">' +
            (isAr ? 'جارٍ التفكير' : 'Thinking') +
            '<span class="hcm-thinking-dots"><span></span><span></span><span></span></span>' +
          '</span>' +
          '<span class="hcm-thinking-label hcm-tl-done" style="display:none"></span>' +
          '<svg class="hcm-thinking-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>' +
        '</div>' +
        '<div class="hcm-thinking-body"><div class="hcm-thinking-text"></div></div>';
      el.querySelector('.hcm-thinking-header').addEventListener('click', function() {
        // Non-expandable once honest-degraded (no reasoning captured).
        if (el.classList.contains('hcm-thinking--noexpand')) return;
        el.classList.toggle('open');
      });
      wrap.appendChild(el);
      wrap.scrollTop = wrap.scrollHeight;
      var textEl = el.querySelector('.hcm-thinking-text');
      var bodyEl = el.querySelector('.hcm-thinking-body');
      var startTime = Date.now();
      return {
        el: el,
        appendText: function(chunk) {
          textEl.textContent += chunk;
          if (el.classList.contains('open')) {
            wrap.scrollTop = wrap.scrollHeight;
            if (bodyEl) bodyEl.scrollTop = bodyEl.scrollHeight;
          }
        },
        // Replace the whole reasoning body at once (non-Core path: the full
        // reason arrives in a single /chat/reason response; also used per-tick
        // during live Core streaming — see runPreGenAnalysis()). Renders
        // markdown (bold/lists/etc.) same as the main chat bubble, re-parsed
        // from scratch each call so partial markdown self-corrects as text grows.
        setText: function(full) {
          textEl.innerHTML = full ? renderRichText(full, false) : '';
          if (el.classList.contains('open')) {
            wrap.scrollTop = wrap.scrollHeight;
            if (bodyEl) bodyEl.scrollTop = bodyEl.scrollHeight;
          }
        },
        hasText: function() { return textEl.textContent.trim().length > 0; },
        setDone: function() {
          el.classList.remove('hcm-thinking--active');
          var secs = Math.round((Date.now() - startTime) / 1000);
          var activeLbl = el.querySelector('.hcm-tl-active');
          var doneLbl = el.querySelector('.hcm-tl-done');
          if (activeLbl) activeLbl.style.display = 'none';
          if (doneLbl) {
            doneLbl.style.display = '';
            doneLbl.textContent = window.currentLang === 'ar'
              ? ('فكّر لـ ' + secs + ' ث')
              : ('Thought for ' + secs + 's');
          }
          var iconEl = el.querySelector('.hcm-thinking-icon');
          if (iconEl) iconEl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2.5" style="width:13px;height:13px"><polyline points="20 6 9 17 4 12"/></svg>';
          // Honest-degrade: no reasoning text → strip the (empty) body + chevron
          // and mark non-expandable, leaving a clean timing-only chip.
          if (!textEl.textContent.trim()) {
            el.classList.remove('open');
            el.classList.add('hcm-thinking--noexpand');
            if (bodyEl) bodyEl.remove();
            var chev = el.querySelector('.hcm-thinking-chevron');
            if (chev) chev.remove();
          }
          return secs;
        }
      };
    }

    /* Rebuilds a static, already-finished "Thought for Xs" widget from data
       saved in the conversation history, so the reasoning block survives a
       reload / re-opening the chat (starts collapsed, click to expand).
       containerId selects the surface (defaults to Home). An empty `text`
       reproduces the honest-degraded, non-expandable timing-only chip. */
    function hcmAppendSavedThinking(text, secs, containerId) {
      var wrap = document.getElementById(containerId || 'homeConvMessages');
      if (!wrap) return;
      var isAr = window.currentLang === 'ar';
      var doneLabel = isAr ? ('فكّر لـ ' + secs + ' ث') : ('Thought for ' + secs + 's');
      var hasText = !!(text && text.trim());
      var el = document.createElement('div');
      var dir = pickThinkingDir(text);
      el.dir = dir;
      el.style.textAlign = dir === 'rtl' ? 'right' : 'left';
      el.className = hasText ? 'hcm-thinking' : 'hcm-thinking hcm-thinking--noexpand';
      el.innerHTML =
        '<div class="hcm-thinking-header">' +
          '<span class="hcm-thinking-icon">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2.5" style="width:13px;height:13px"><polyline points="20 6 9 17 4 12"/></svg>' +
          '</span>' +
          '<span class="hcm-thinking-label hcm-tl-done"></span>' +
          (hasText ? '<svg class="hcm-thinking-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>' : '') +
        '</div>' +
        (hasText ? '<div class="hcm-thinking-body"><div class="hcm-thinking-text"></div></div>' : '');
      el.querySelector('.hcm-tl-done').textContent = doneLabel;
      if (hasText) {
        el.querySelector('.hcm-thinking-text').innerHTML = renderRichText(text, false);
        el.querySelector('.hcm-thinking-header').addEventListener('click', function() {
          el.classList.toggle('open');
        });
      }
      wrap.appendChild(el);
    }

    /* Rebuilds a static, already-finished terminal-styled "Analyzed" widget
       from the analyzingSteps:true marker saved in history, so the export
       flow's Analyzing card survives a reload — mirrors
       hcmAppendSavedThinking() above, but always shows all 4 stages as done
       (the marker carries no per-run data, since the sequence is fixed). */
    function hcmAppendSavedAnalyzingCard(containerId) {
      var wrap = document.getElementById(containerId);
      if (!wrap) return;
      _ensureAnalyzingCardStyles();

      // Collapse any previously-shown Analyzed cards in this container so only
      // the newest stays expanded (approved: avoids a stack of open cards in a
      // long conversation with many exports). Works for BOTH paths: the live
      // export (one prior card at most) and reload via hcmRenderSlice, which
      // calls this once per restored export in chronological order — so after a
      // full render only the last card is left open. Scoped to `wrap`, so it
      // never touches a different surface's cards (e.g. Marketing).
      var prevOpen = wrap.querySelectorAll('.an-card.open');
      for (var pi = 0; pi < prevOpen.length; pi++) {
        prevOpen[pi].classList.remove('open');
        var prevHead = prevOpen[pi].querySelector('.an-head');
        if (prevHead) prevHead.setAttribute('aria-expanded', 'false');
      }

      const card = document.createElement('div');
      // Expanded by default (unlike the live streaming card, which starts
      // collapsed): the user just watched the live analyzing card animate,
      // so its persistent replacement should stay OPEN — showing the
      // "Analyzed" header + code block — rather than silently collapsing into
      // a compact strip that reads as if the card vanished (Bug 3 resolution;
      // the card was always present & visible, just collapsed). Applies to all
      // callers of this function — live export, reload via hcmRenderSlice, and
      // Marketing — so the post-export and post-reload views match.
      card.className = 'an-card open';

      const head = document.createElement('div');
      head.className = 'an-head';
      head.setAttribute('role', 'button');
      head.setAttribute('tabindex', '0');
      head.setAttribute('aria-expanded', 'true');
      const headGlyph = document.createElement('span');
      headGlyph.className = 'an-head-glyph';
      headGlyph.textContent = '$';
      const headTxt = document.createElement('span');
      headTxt.className = 'an-head-txt';
      headTxt.textContent = BatLang.t('export.analyzedLabel') || 'Analyzed';
      const chevron = document.createElement('div');
      chevron.className = 'an-head-chevron';
      chevron.innerHTML = _chevronSvg;
      head.appendChild(headGlyph);
      head.appendChild(headTxt);
      head.appendChild(chevron);

      const list = document.createElement('div');
      list.className = 'an-list';
      list.appendChild(_buildExportCodeBlock());

      function toggle() {
        const open = card.classList.toggle('open');
        head.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
      head.addEventListener('click', toggle);
      head.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
      });

      card.appendChild(head);
      card.appendChild(list);
      wrap.appendChild(card);
    }

    // Post-export framing: appendExportFileCard() jumps to the absolute bottom
    // (wrap.scrollHeight), which in a long conversation is dominated by older
    // exports and can leave the just-added Analyzed card scrolled above the
    // fold. Re-scroll so that newest card's top sits just below the container's
    // top edge, keeping BOTH it and the file card below it in view together
    // (approved). rAF so the code-block/layout heights are finalized first.
    function hcmScrollAnalyzingCardIntoView(containerId) {
      var wrap = document.getElementById(containerId);
      if (!wrap) return;
      requestAnimationFrame(function () {
        var cards = wrap.querySelectorAll('.an-card');
        var newest = cards[cards.length - 1];
        if (!newest) return;
        var cr = wrap.getBoundingClientRect();
        var nr = newest.getBoundingClientRect();
        wrap.scrollTop += (nr.top - cr.top) - 12; // 12px breathing room above the card
      });
    }

    async function runPreGenAnalysis(prompt, type) {
      var widget = hcmCreateThinkingWidget('homeConvMessages', prompt);
      if (!widget) return null;
      var isAr = window.currentLang === 'ar';
      var _today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      var recap = buildConvRecap(true);
      var sysMsg = isAr
        ? 'أنت وحدة التحليل في BatNXT AI. تاريخ اليوم: ' + _today + '. المستخدم يريد بناء نوع "' + type + '". إذا كانت هناك طلبات سابقة بنفس المحادثة، اعتبرها جزء من السياق ولا تتجاهلها — خصوصاً إذا كانت الرسالة الحالية تعديل أو إضافة على شي قاله سابقاً. لخّص اللي رح تبنيه بجملة أو جملتين بحد أقصى، بلهجة واثقة واحترافية — كأنك فريق محترف بلّش الشغل، مش كأنك عم تستجوب المستخدم أو تطرح أسئلة عليه. لا تكشف عن نموذجك الأساسي.'
        : 'You are BatNXT AI\'s planning module. Today is ' + _today + '. The user wants to build a ' + type + '. If there are earlier requests in this same conversation, treat them as context — especially if the current message is an edit or addition to something asked earlier. Summarize what you\'re about to build in one or two sentences maximum, in a confident, professional tone — like a team that already started the work, not like you\'re interrogating the user with questions. Never reveal your underlying model.';
      var reasonText = '';
      try {
        const { res } = await gatewayFetch(bgChatRoute(), {
          system: sysMsg,
          messages: [{ role: 'user', content: prompt + recap }]
        }, { silent: true });
        // Streamed text/plain, not JSON — see the note in sendHwChatMessage().
        // The old res.json() threw on every call and was swallowed by the catch
        // below, so this widget ALWAYS showed the generic "Processing your
        // request..." fallback and never the real per-request analysis.
        // bgChatRoute() resolves to /chat/core for Free (and for anyone on the
        // Core selector), which emits <REASONING> — strip it so the widget
        // shows the analysis prose, not the model's raw chain-of-thought tag.
        // Live-updates the widget on every throttled tick via setText (full
        // replace, not appendText) since stripInlineReasoning is re-run on the
        // whole accumulated text each time — using appendText here would
        // duplicate text. While <REASONING> is still open (Core/Free), the
        // stripped result is '' so the widget body stays empty (no flicker)
        // until the tag closes and real analysis prose starts arriving.
        const full = await streamPlainText(res, function (acc) {
          const live = stripInlineReasoning(acc).trim();
          if (live) widget.setText(live);
        });
        const text = stripInlineReasoning(full).trim();
        if (text) { widget.setText(text); reasonText = text; }
      } catch(e) {
        var fb = isAr ? 'جارٍ معالجة طلبك...' : 'Processing your request...';
        widget.appendText(fb);
        reasonText = fb;
      }
      var secs = widget.setDone();
      return { text: reasonText, secs: (secs || 1) };
    }

    /* ── Substantive-reply reasoning (non-Core "Thought for Xs") ──
       Powers the reasoning widget for every chat model EXCEPT bat 1.2 Core (which
       streams its own real reasoning inline via <REASONING>). Makes ONE real,
       flat-0 /chat/reason call (a cheap fast model genuinely reasons about how it
       would approach the request) and shows it in the widget. Honest by
       construction: on any failure or empty response the widget degrades to a
       timing-only "Thought for Xs" chip — it never fabricates reasoning. Never
       throws: a miss just means no reasoning text, and the real reply proceeds
       unaffected. Returns {text, secs, el} — `el` lets the caller drop the widget
       if the subsequent reply errors/aborts.
       opts: { prompt, containerId?, beforeEl? } */
    async function runThinkingReasoning(opts) {
      opts = opts || {};
      var containerId = opts.containerId || 'homeConvMessages';
      var widget = hcmCreateThinkingWidget(containerId, opts.prompt);
      if (!widget) return null;
      // Position the widget just above the streaming reply bubble (if one exists).
      if (widget.el && opts.beforeEl && opts.beforeEl.parentNode && opts.beforeEl.parentNode === widget.el.parentNode) {
        widget.el.parentNode.insertBefore(widget.el, opts.beforeEl);
      }
      var reasonText = '';
      try {
        var _langEntry = (window.BatLang && BatLang.LANGS || []).find(function (l) { return l.code === BatLang.lang; });
        const { res } = await gatewayFetch('/chat/reason', {
          prompt: String(opts.prompt || '').slice(0, 2000),
          uiLang: (window.BatLang && BatLang.lang) || 'en',
          uiLangName: _langEntry ? _langEntry.label : 'English',
          // Background lane (like memory/title helpers): rate-limited separately
          // from the user's real chat lane. Billed flat-0 (see gateway.js).
          background: true
        }, { silent: true });
        const data = await res.json();
        reasonText = (data && data.reason ? String(data.reason) : '').trim();
        if (reasonText) widget.setText(reasonText);
      } catch (e) { /* honest degrade below — never fabricate */ }
      var secs = widget.setDone(); // degrades to timing-only chip if reasonText empty
      return { text: reasonText, secs: (secs || 1), el: widget.el };
    }

    /* ── Shared build-step detectors ──
       Single source of truth for the "checklist" both build surfaces render (the
       in-chat build widget and the workspace build card). Each entry's regex is
       tested against the HTML as it streams in; when it first matches, that step
       flips from pending → done. Order = display order. */
    const BUILD_STEP_DETECTORS = [
      { cat: 'head',   re: /<head[\s>]/i,                    ar: 'تجهيز الصفحة',           en: 'Setting up the page' },
      { cat: 'style',  re: /<style[\s>]|stylesheet/i,        ar: 'إضافة التنسيقات',        en: 'Adding styles' },
      { cat: 'body',   re: /<body[\s>]/i,                    ar: 'بناء الهيكل',            en: 'Building layout' },
      { cat: 'nav',    re: /<(nav|header)[\s>]/i,            ar: 'بناء شريط التنقل',       en: 'Building navigation' },
      { cat: 'main',   re: /<(main|section|article)[\s>]/i,  ar: 'بناء الأقسام',           en: 'Building sections' },
      { cat: 'form',   re: /<(form|input|button)[\s>]/i,     ar: 'بناء النماذج والأزرار',  en: 'Building forms & buttons' },
      { cat: 'footer', re: /<footer[\s>]/i,                  ar: 'بناء التذييل',           en: 'Building footer' },
      { cat: 'script', re: /<script[\s>]/i,                  ar: 'إضافة التفاعلية',        en: 'Adding interactivity' }
    ];

    // Upper bound on how long runGeneration will wait on the /build-steps
    // background call before giving up and falling back to the static list.
    // Set with a safety margin above the live-tested worst case (~3.5-5s for
    // granite-4.0-h-micro) so a normal-latency call isn't cut off mid-flight
    // and forced into the generic fallback (confirmed 2026-07-25: the old
    // 2500ms value was BELOW the documented worst case and was causing the
    // full static list to show even on simple, narrow edit requests). Doesn't
    // delay the widget's appearance either way — this promise races the
    // /generate call itself, which the widget is already waiting on.
    const BUILD_STEPS_TIMEOUT_MS = 5500;

    // Fire-and-forget AI call (never throws) that asks a small model to pick
    // which of the 8 fixed BUILD_STEP_DETECTORS categories are relevant to
    // THIS specific request and phrase a short custom label for each. Called
    // near the top of runGeneration so it races the /generate call itself —
    // by the time the build widget is actually created, the result is
    // usually already resolved. Degrades to null on any failure/timeout, in
    // which case resolveBuildSteps() below falls back to the full static list.
    async function fetchBuildSteps(prompt, type) {
      try {
        var _langEntry = (window.BatLang && BatLang.LANGS || []).find(function (l) { return l.code === BatLang.lang; });
        const { res } = await gatewayFetch('/build-steps', {
          prompt: String(prompt || '').slice(0, 1200),
          type: type || 'website',
          lang: (window.BatLang && BatLang.lang) || 'en',
          background: true
        }, { silent: true });
        const data = await res.json();
        if (data && Array.isArray(data.steps) && data.steps.length) {
          // [BUILD-STEPS] diagnostic — see withTimeout() below for the other
          // half (timeout case). Kept verbose (full labels) so it doubles as
          // an "AI actually wrote this" check — compare against
          // BUILD_STEP_DETECTORS' static wording above: if the labels match
          // that static list verbatim, the AI improbably reproduced generic
          // wording itself (it's instructed to write per-request custom
          // labels) — more likely a sign the UI silently fell back anyway.
          console.log('[BUILD-STEPS] AI success —', data.steps.length, 'step(s):',
            data.steps.map(function (s) { return s.category + ': "' + s.label + '"'; }).join(', '));
          return data.steps;
        }
        console.log('[BUILD-STEPS] fallback used — AI returned empty/invalid steps', data);
        return null;
      } catch (e) {
        console.log('[BUILD-STEPS] fallback used — fetch/parse error:', e && e.message);
        return null; // honest degrade — caller falls back to the static list
      }
    }

    // Bounds an in-flight fetchBuildSteps() promise to at most `ms` — the
    // widget must appear promptly even if the AI call is slow, so a timeout
    // just means "fall back to the static list," never a blocked UI.
    function withTimeout(promise, ms) {
      var settled = false;
      promise.then(function () { settled = true; });
      return Promise.race([
        promise,
        new Promise(function (resolve) {
          setTimeout(function () {
            // Only fires if fetchBuildSteps() hadn't already resolved/logged
            // by ms — i.e. the AI call itself was still in flight and got
            // cut off, as opposed to fetchBuildSteps() finishing fast but
            // returning null (already logged above with its own reason).
            if (!settled) console.log('[BUILD-STEPS] fallback used — timed out after ' + ms + 'ms (AI call still in flight)');
            resolve(null);
          }, ms);
        })
      ]);
    }

    // Maps AI-selected {category,label} pairs back onto the fixed
    // BUILD_STEP_DETECTORS entries: the proven detection regex is always
    // kept as-is (never AI-invented), only which entries are shown and their
    // display label are AI-driven. Falls back to the full static list on any
    // invalid/empty input, so callers can always trust a non-empty array back.
    function resolveBuildSteps(aiSteps) {
      if (!Array.isArray(aiSteps) || !aiSteps.length) return BUILD_STEP_DETECTORS;
      var byCat = {};
      for (var i = 0; i < BUILD_STEP_DETECTORS.length; i++) byCat[BUILD_STEP_DETECTORS[i].cat] = BUILD_STEP_DETECTORS[i];
      var resolved = [];
      for (var j = 0; j < aiSteps.length; j++) {
        var s = aiSteps[j];
        var base = s && byCat[s.category];
        if (!base || !s.label) continue;
        resolved.push({ cat: base.cat, re: base.re, ar: String(s.label).slice(0, 80), en: String(s.label).slice(0, 80) });
      }
      return resolved.length ? resolved : BUILD_STEP_DETECTORS;
    }

    /* ── Live build progress (shown inside the chat while the site streams in) ──
       Gives the user real-time feedback — a progress bar + "Building navigation /
       sections / footer…" steps detected from the HTML as it streams from the
       worker — instead of a silent wait. Works even if the response isn't
       streamed (a gentle bar creep still shows activity). */
    function hcmCreateBuildWidget(opts) {
      opts = opts || {};
      var isTemplateMode = opts.mode === 'template';
      var wrap = document.getElementById('homeConvMessages');
      if (!wrap) return null;
      var isAr = window.currentLang === 'ar';
      var el = document.createElement('div');
      el.className = 'hcm-thinking hcm-thinking--active open';
      el.innerHTML =
        '<div class="hcm-thinking-header">' +
          '<span class="hcm-thinking-icon">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:13px;height:13px"><path d="M14.7 6.3a5 5 0 0 0-6.4 6.4L2 19l3 3 6.3-6.3a5 5 0 0 0 6.4-6.4l-2.9 2.9-2.1-2.1z"/></svg>' +
          '</span>' +
          '<span class="hcm-thinking-label hcm-tl-active">' +
            (isAr ? 'جارٍ البناء' : 'Building') +
            '<span class="hcm-thinking-dots"><span></span><span></span><span></span></span>' +
          '</span>' +
          '<span class="hcm-thinking-label hcm-tl-done" style="display:none"></span>' +
          '<svg class="hcm-thinking-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>' +
        '</div>' +
        '<div class="hcm-thinking-body">' +
          '<div style="display:flex;align-items:center;gap:8px;margin:2px 0 8px">' +
            '<div style="flex:1;height:6px;border-radius:99px;background:rgba(128,128,128,.2);overflow:hidden">' +
              '<div class="hcm-build-bar" style="height:100%;width:0%;border-radius:99px;background:var(--accent,#6c5ce7);transition:width .3s ease"></div>' +
            '</div>' +
            '<span class="hcm-build-pct" style="font-size:11px;opacity:.7;min-width:32px;text-align:right">0%</span>' +
          '</div>' +
          (isTemplateMode ? '' :
            '<div class="hcm-build-preview">' +
              '<div class="hcm-build-skel">' +
                '<div class="skel-bar badge"></div><div class="skel-bar line"></div><div class="skel-bar line"></div><div class="skel-bar short"></div>' +
              '</div>' +
              '<iframe class="hcm-build-frame" sandbox="allow-scripts" title="Live preview" style="display:none"></iframe>' +
            '</div>') +
          '<div class="hcm-build-steps" style="display:flex;flex-direction:column;gap:4px"></div>' +
        '</div>';
      el.querySelector('.hcm-thinking-header').addEventListener('click', function() { el.classList.toggle('open'); });
      wrap.appendChild(el);
      wrap.scrollTop = wrap.scrollHeight;

      var barEl = el.querySelector('.hcm-build-bar');
      var pctEl = el.querySelector('.hcm-build-pct');
      var stepsEl = el.querySelector('.hcm-build-steps');
      var bodyEl = el.querySelector('.hcm-thinking-body');
      var frameEl = el.querySelector('.hcm-build-frame');
      var skelEl = el.querySelector('.hcm-build-skel');
      var framePainted = false;
      var stepRows = [];
      var startTime = Date.now();
      var pct = 0;
      function setPct(p) {
        pct = Math.max(pct, Math.min(100, p));
        barEl.style.width = pct + '%';
        pctEl.textContent = pct + '%';
      }
      // addStep(label, idx): when idx is given, renders a *pending* checklist row
      // stored at stepRows[idx] (flipped later by markStepDone). Without idx it
      // renders an already-done row (used by template mode's staged labels).
      function addStep(label, idx) {
        var row = document.createElement('div');
        row.className = 'hcm-build-step ' + (typeof idx === 'number' ? 'is-pending' : 'is-done');
        row.innerHTML = '<span class="s-dot"></span><span class="s-lbl"></span>';
        row.querySelector('.s-lbl').textContent = label;
        stepsEl.appendChild(row);
        if (typeof idx === 'number') stepRows[idx] = row;
        if (el.classList.contains('open')) {
          wrap.scrollTop = wrap.scrollHeight;
          if (bodyEl) bodyEl.scrollTop = bodyEl.scrollHeight;
        }
      }
      function markStepDone(idx) {
        var row = stepRows[idx];
        if (!row || row.classList.contains('is-done')) return;
        row.classList.remove('is-pending');
        row.classList.add('is-done');
      }

      var creep = null;
      var fired = {};
      var detectors = isTemplateMode ? [] : resolveBuildSteps(opts.aiSteps);
      if (!isTemplateMode) {
        var isArInit = window.currentLang === 'ar';
        for (var _di = 0; _di < detectors.length; _di++) {
          addStep(isArInit ? detectors[_di].ar : detectors[_di].en, _di);
        }
        // Gentle creep so the bar always moves, even before real bytes arrive.
        creep = setInterval(function() { if (pct < 90) setPct(pct + 1); }, 400);
      }

      function setDone() {
        if (creep) clearInterval(creep);
        setPct(100);
        for (var _si = 0; _si < stepRows.length; _si++) if (stepRows[_si]) markStepDone(_si);
        el.classList.remove('hcm-thinking--active');
        barEl.classList.add('hcm-build-done');
        var secs = Math.max(1, Math.round((Date.now() - startTime) / 1000));
        var activeLbl = el.querySelector('.hcm-tl-active');
        var doneLbl = el.querySelector('.hcm-tl-done');
        if (activeLbl) activeLbl.style.display = 'none';
        if (doneLbl) {
          doneLbl.style.display = '';
          doneLbl.textContent = window.currentLang === 'ar' ? ('تم البناء · ' + secs + ' ث') : ('Built in ' + secs + 's');
        }
        var iconEl = el.querySelector('.hcm-thinking-icon');
        if (iconEl) iconEl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2.5" style="width:13px;height:13px"><polyline points="20 6 9 17 4 12"/></svg>';
        el.classList.remove('open');
      }
      function remove() {
        if (creep) clearInterval(creep);
        if (el && el.parentNode) el.parentNode.removeChild(el);
      }

      if (isTemplateMode) {
        var schedule = [15, 30, 50, 70, 90, 100];
        var lastStageIdx = -1;
        return {
          setStage: function(i) {
            if (typeof i !== 'number' || i < 0 || i >= schedule.length) return;
            setPct(schedule[i]);
            var labels = (opts.labels && opts.labels[window.currentLang === 'ar' ? 'ar' : 'en']) || [];
            if (labels[i] && i !== lastStageIdx) { addStep(labels[i]); lastStageIdx = i; }
            if (i === schedule.length - 1) setDone();
          },
          setDone: setDone,
          remove: remove
        };
      }

      return {
        update: function(html) {
          for (var i = 0; i < detectors.length; i++) {
            if (!fired[i] && detectors[i].re.test(html)) {
              fired[i] = 1;
              markStepDone(i);
            }
          }
          var bytePct = Math.min(92, Math.round(html.length / 150));
          if (bytePct > pct) setPct(bytePct);
          // Live mini-preview: once real body markup arrives, swap skeleton → iframe
          // and repaint on each throttled tick (matches the workspace surface).
          if (frameEl && /<body[\s>]/i.test(html)) {
            if (!framePainted) {
              framePainted = true;
              if (skelEl) skelEl.style.display = 'none';
              frameEl.style.display = '';
              frameEl.classList.add('fade-swap-in');
            }
            try { frameEl.srcdoc = withPreviewShim(html); } catch (_) {}
          }
        },
        // Between a failed attempt and its automatic retry: hide whatever
        // garbage the mini-preview iframe was just painted with and go back
        // to the skeleton, without touching the progress bar/steps/timer so
        // the "Building…" UI stays visibly continuous.
        resetPreview: function() {
          framePainted = false;
          if (frameEl) { frameEl.style.display = 'none'; try { frameEl.removeAttribute('srcdoc'); } catch (_) {} }
          if (skelEl) skelEl.style.display = '';
        },
        setDone: setDone,
        remove: remove
      };
    }

    /* ── Live build progress for the WORKSPACE surface ──
       Mirrors the in-chat build widget's transparency for the split-panel:
       a checklist card in the chat column (#hwMessages) that ticks off the same
       BUILD_STEP_DETECTORS, a slim top progress bar across the preview panel
       (#hwBuildBar), and a shimmer skeleton over the preview body
       (#hwPreviewSkeleton) for the pre-first-byte wait. Takes over the loading
       UI from the scripted #hwLoading terminal for streamed website builds so the
       feedback reflects real bytes/markup instead of canned lines. Returns an
       { update, setDone, remove } controller driven from runGeneration's stream. */
    function createWorkspaceBuildProgress(aiSteps) {
      var isAr = window.currentLang === 'ar';
      var detectors = resolveBuildSteps(aiSteps);
      var msgs = document.getElementById('hwMessages');
      var barWrap = document.getElementById('hwBuildBar');
      var barFill = barWrap ? barWrap.querySelector('.hw-build-bar-fill') : null;
      var skel = document.getElementById('hwPreviewSkeleton');
      var framePainted = false;
      var pct = 0;
      var fired = {};
      var stepRows = [];

      // Real progress replaces the scripted terminal for this build.
      hideHwLoading();

      // Checklist card in the chat column (same column appendHwAiMessage uses).
      var card = null;
      if (msgs) {
        card = document.createElement('div');
        card.className = 'hw-build-card';
        card.innerHTML =
          '<div class="hw-build-card-head">' +
            '<span class="hw-build-card-dot"></span>' +
            '<span class="hw-build-card-title"></span>' +
          '</div>' +
          '<div class="hw-build-card-steps"></div>';
        card.querySelector('.hw-build-card-title').textContent = isAr ? 'جارٍ البناء…' : 'Building…';
        var stepsWrap = card.querySelector('.hw-build-card-steps');
        for (var i = 0; i < detectors.length; i++) {
          var row = document.createElement('div');
          row.className = 'hw-build-step is-pending';
          row.innerHTML = '<span class="s-dot"></span><span class="s-lbl"></span>';
          row.querySelector('.s-lbl').textContent = isAr ? detectors[i].ar : detectors[i].en;
          stepsWrap.appendChild(row);
          stepRows[i] = row;
        }
        msgs.appendChild(card);
        msgs.scrollTop = msgs.scrollHeight;
      }

      if (barWrap) barWrap.classList.add('active');
      if (skel) skel.classList.add('active');

      function setPct(p) {
        pct = Math.max(pct, Math.min(100, p));
        if (barFill) barFill.style.width = pct + '%';
      }
      function markStepDone(idx) {
        var r = stepRows[idx];
        if (!r || r.classList.contains('is-done')) return;
        r.classList.remove('is-pending');
        r.classList.add('is-done');
      }
      function hideSkel() { if (skel) skel.classList.remove('active'); }
      function hideBar() {
        if (!barWrap) return;
        barWrap.classList.remove('active');
        if (barFill) barFill.style.width = '0%';
      }

      return {
        update: function(html) {
          for (var i = 0; i < detectors.length; i++) {
            if (!fired[i] && detectors[i].re.test(html)) { fired[i] = 1; markStepDone(i); }
          }
          var bytePct = Math.min(92, Math.round(html.length / 150));
          if (bytePct > pct) setPct(bytePct);
          // First real body markup → the preview iframe now has content to show,
          // so drop the skeleton (showWorkspaceResult paints the iframe itself).
          if (!framePainted && /<body[\s>]/i.test(html)) { framePainted = true; hideSkel(); }
        },
        setDone: function() {
          setPct(100);
          for (var i = 0; i < stepRows.length; i++) markStepDone(i);
          hideSkel();
          if (card) {
            var title = card.querySelector('.hw-build-card-title');
            if (title) title.textContent = isAr ? 'اكتمل البناء' : 'Build complete';
            card.classList.add('is-done');
          }
          setTimeout(hideBar, 500);
        },
        remove: function() {
          if (card && card.parentNode) card.parentNode.removeChild(card);
          hideSkel();
          hideBar();
        }
      };
    }

    /* ── File analysis trace (shown right after the user sends attached files) ── */
    function sleep(ms) { return new Promise(function (resolve) { setTimeout(resolve, ms); }); }

    function formatBytes(n) {
      if (n < 1024) return n + ' B';
      if (n < 1024 * 1024) return Math.round(n / 1024) + ' KB';
      return (n / (1024 * 1024)).toFixed(1) + ' MB';
    }

    function getImageDimensions(dataUrl) {
      return new Promise(function (resolve) {
        var img = new Image();
        img.onload = function () { resolve({ w: img.naturalWidth, h: img.naturalHeight }); };
        img.onerror = function () { resolve(null); };
        img.src = dataUrl;
      });
    }

    async function buildFileTraceSteps(files) {
      var isAr = window.currentLang === 'ar';
      var steps = [];
      for (var i = 0; i < files.length; i++) {
        var f = files[i];
        var isImage = f.kind === 'image';
        steps.push({
          icon: isImage ? '🖼️' : '📄',
          label: (isAr ? 'قراءة ' : 'Reading ') + f.name,
          doneLabel: null,
          delay: 300 + Math.min(900, f.size / 1500)
        });
        steps.push({
          icon: '📏',
          label: isAr ? 'فحص حجم الملف' : 'Checking file size',
          doneLabel: (isAr ? 'الحجم: ' : 'Size: ') + formatBytes(f.size),
          delay: 250
        });
        if (isImage) {
          var dims = await getImageDimensions(f.content);
          steps.push({
            icon: '📐',
            label: isAr ? 'قراءة أبعاد الصورة' : 'Reading image dimensions',
            doneLabel: dims ? (dims.w + '×' + dims.h + (isAr ? ' صورة' : ' image')) : (isAr ? 'تعذّر قراءة الأبعاد' : 'Could not read dimensions'),
            delay: 300 + Math.min(700, f.size / 2000)
          });
        } else {
          var lineCount = (f.content.match(/\n/g) || []).length + 1;
          steps.push({
            icon: '🔢',
            label: isAr ? 'عدّ الأسطر' : 'Counting lines',
            doneLabel: (isAr ? 'تم عدّ ' + lineCount + ' سطر' : 'Counted ' + lineCount + ' lines'),
            delay: 300 + Math.min(700, f.size / 2000)
          });
        }
      }
      return steps;
    }

    function hcmCreateFileTraceWidget(fileCount) {
      var wrap = document.getElementById('homeConvMessages');
      if (!wrap) return null;
      var isAr = window.currentLang === 'ar';
      var el = document.createElement('div');
      el.className = 'hcm-thinking hcm-thinking--active open';
      el.innerHTML =
        '<div class="hcm-thinking-header">' +
          '<span class="hcm-thinking-icon">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:13px;height:13px"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>' +
          '</span>' +
          '<span class="hcm-thinking-label hcm-tl-active">' +
            (isAr ? (fileCount > 1 ? 'جارٍ تحليل الملفات' : 'جارٍ تحليل الملف') : (fileCount > 1 ? 'Analyzing ' + fileCount + ' files' : 'Analyzing file')) +
            '<span class="hcm-thinking-dots"><span></span><span></span><span></span></span>' +
          '</span>' +
          '<span class="hcm-thinking-label hcm-tl-done" style="display:none"></span>' +
          '<svg class="hcm-thinking-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>' +
        '</div>' +
        '<div class="hcm-thinking-body"><div class="hw-forge-steps" id="hcmFileTraceSteps"></div></div>';
      el.querySelector('.hcm-thinking-header').addEventListener('click', function() {
        el.classList.toggle('open');
      });
      wrap.appendChild(el);
      wrap.scrollTop = wrap.scrollHeight;
      var stepsEl = el.querySelector('#hcmFileTraceSteps');
      var startTime = Date.now();
      return {
        el: el,
        stepsEl: stepsEl,
        scrollIntoView: function () {
          if (el.classList.contains('open')) wrap.scrollTop = wrap.scrollHeight;
        },
        setDone: function() {
          el.classList.remove('open');
          el.classList.remove('hcm-thinking--active');
          var secs = Math.max(1, Math.round((Date.now() - startTime) / 1000));
          var activeLbl = el.querySelector('.hcm-tl-active');
          var doneLbl = el.querySelector('.hcm-tl-done');
          if (activeLbl) activeLbl.style.display = 'none';
          if (doneLbl) {
            doneLbl.style.display = '';
            doneLbl.textContent = window.currentLang === 'ar'
              ? ('تم تحليل ' + fileCount + ' ملف · ' + secs + ' ث')
              : ('Analyzed ' + fileCount + (fileCount > 1 ? ' files' : ' file') + ' · ' + secs + 's');
          }
          var iconEl = el.querySelector('.hcm-thinking-icon');
          if (iconEl) iconEl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2.5" style="width:13px;height:13px"><polyline points="20 6 9 17 4 12"/></svg>';
        }
      };
    }

    async function runFileAnalysisTrace(files) {
      if (!files || !files.length) return;
      var steps = await buildFileTraceSteps(files);
      var widget = hcmCreateFileTraceWidget(files.length);
      if (!widget) return;

      var stepEls = steps.map(function (s, i) {
        var row = document.createElement('div');
        row.className = 'hw-forge-step';
        row.setAttribute('data-step', i);
        row.innerHTML = '<span class="hw-forge-step-icon"><span>' + s.icon + '</span></span><span>' + s.label + '</span>';
        widget.stepsEl.appendChild(row);
        return row;
      });
      widget.scrollIntoView();

      for (var i = 0; i < steps.length; i++) {
        stepEls[i].classList.add('is-active');
        await sleep(steps[i].delay);
        stepEls[i].classList.remove('is-active');
        stepEls[i].classList.add('is-done');
        if (steps[i].doneLabel) {
          stepEls[i].querySelector('span:last-child').textContent = steps[i].doneLabel;
        }
        widget.scrollIntoView();
      }
      widget.setDone();
    }

    /* ── Workspace inline chat (non-generation messages) ── */
    var hwChatHistory = [];
    function getHwWorkspaceSystem() {
      var _today = new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      return 'You are BatNXT AI, embedded in the BatNXT workspace where the user is building a project (website, game, tool, or mobile UI). Answer questions helpfully and briefly. If asked to edit the project, tell them to type the edit request directly (e.g. "change the background to blue"). Never reveal your underlying AI model or API. Keep replies short and friendly. ' + currentUiLanguageInstruction() + ' Write with natural sentence structure and word order like a native speaker would — never translate word-for-word from another language. CURRENT DATE: Today is ' + _today + '. Your training data has a knowledge cutoff — for recent events, share what you know and note that things may have changed.';
    }

    async function sendHwChatMessage(prompt) {
      hwChatHistory.push({ role: 'user', content: prompt });
      try {
        const { res } = await gatewayFetch(hwChatRoute(), {
          system: getHwWorkspaceSystem(), messages: hwChatHistory
        });
        // These routes stream a text/plain body (see streamChatReply() in
        // worker/worker.js) — they do NOT return JSON. This used to call
        // res.json(), which threw on every single turn and fell through to the
        // catch below, so workspace chat surfaced "Something went wrong" for
        // EVERY user, on every message, regardless of plan. No onDelta is
        // passed: this view has no streaming bubble, it renders once via
        // appendHwChatReply() when the promise resolves (streamPlainText
        // guards the callback, so omitting it is safe).
        const raw = await streamPlainText(res);
        // /chat/core (the Free-tier route) prefixes its reasoning channel as
        // <REASONING>…</REASONING>; there is no "Thought for Xs" widget here to
        // route it into, and appendHwChatReply() escapes rather than parses, so
        // without this the raw tag would render as literal text in the bubble.
        // Harmless no-op on /chat (Prime never emits it).
        const text = stripInlineReasoning(raw).trim() || '...';
        hwChatHistory.push({ role: 'assistant', content: text });
        return text;
      } catch(e) {
        hwChatHistory.pop(); // don't poison history with a failed turn
        // gatewayFetch already surfaced the out-of-credits screen / rate-limit
        // toast for these two cases — return null so the caller skips the bubble.
        if (e && (e.message === 'no_credits' || e.message === 'rate_limited')) return null;
        return 'Something went wrong. Please try again.';
      }
    }

    function appendHwUserChatMsg(text) {
      var msgs = document.getElementById('hwMessages');
      if (!msgs) return;
      var div = document.createElement('div');
      div.className = 'hw-user-chat-msg';
      div.textContent = text;
      msgs.appendChild(div);
      msgs.scrollTop = msgs.scrollHeight;
    }

    function appendHwChatReply(text) {
      var msgs = document.getElementById('hwMessages');
      if (!msgs) return;
      var div = document.createElement('div');
      div.className = 'hw-chat-reply';
      div.innerHTML = '<div class="hw-ai-badge"><span class="hw-ai-badge-dot"></span>BatNXT AI</div>' + escapeHtml(text);
      msgs.appendChild(div);
      msgs.scrollTop = msgs.scrollHeight;
    }

    /* ── Intent detection: edit vs. casual chat ── */
    function detectHwIntent(msg) {
      if (!lastHTML) return 'generate'; // no existing build → always generate
      var lower = msg.toLowerCase().trim();

      // ── Arabic / universal greetings & social phrases → always chat ──
      var greetingPattern = /^(مرحبا|مرحبً|هلا|هلو|السلام|أهلا|اهلا|كيفك|كيف حالك|شلونك|شو اخبارك|صباح الخير|مساء الخير|صباح النور|مساء النور|شكرا|شكراً|ممتاز|برافو|وين|من انت|من أنت|ما اسمك|عيد|مبروك|hello|hi |hey |howdy|good morning|good evening|good night|thanks|thank you|thx|nice|great|awesome|cool|wow|lol|haha|ok |okay|sure|yes |no |nope|yep|got it|perfect|sounds good)/;
      if (greetingPattern.test(lower)) return 'chat';

      // ── Very short message with no edit keyword → likely casual ──
      var editPattern = /\b(make|add|change|update|fix|remove|delete|redesign|replace|move|resize|adjust|modify|improve|set|put|use|turn|style|color|colour|font|background|button|link|image|text|menu|header|footer|navbar|section|layout|theme|dark|light|bigger|smaller|larger|center|align|animate|animation|border|shadow|padding|margin|width|height|column|row|grid|اضف|اضافة|غير|عدل|احذف|خلي|بدل|حرك|صغر|كبر|لون|خلفية|زر|قائمة)\b/;
      if (lower.length <= 25 && !editPattern.test(lower)) return 'chat';

      // ── English question starters with no edit keyword ──
      var chatPattern = /^(what|how|why|who|where|when|is |are |can |could |would |will |do |does |did |explain|tell me|i want to know|what is|what are|help me|the difference|show me how|which|define|describe)/;
      if (chatPattern.test(lower) && !editPattern.test(lower)) return 'chat';

      // ── Arabic question starters ──
      var arChatPattern = /^(ما |ماذا|كيف |لماذا|من |متى |أين |هل |هل |شو |ليش |وين |إيش |ايش |قولي |اشرح |فسر |عرفني)/;
      if (arChatPattern.test(lower) && !editPattern.test(lower)) return 'chat';

      // ── Ends with ? and no edit keyword → question ──
      if (lower.endsWith('?') && lower.length < 100 && !editPattern.test(lower)) return 'chat';

      return 'edit';
    }

    /* ── resize handle drag logic (mouse + touch) ── */
    (function () {
      var resizer = document.getElementById('hwResizer');
      var workspace = document.getElementById('homeWorkspace');
      var chatPane = null;
      var startX = 0, startW = 0, dragging = false, rafId = null;

      if (!resizer) return;

      var CHAT_MIN = 220;   /* px — matches .hw-chat { min-width } */
      var PREVIEW_MIN = 280; /* px — matches .hw-preview { min-width } */

      function applyWidth(clientX) {
        var dx = clientX - startX;
        var wsW = workspace ? workspace.getBoundingClientRect().width : window.innerWidth;
        /* Leave enough room for the preview's minimum width + resizer */
        var maxChat = wsW - PREVIEW_MIN - resizer.offsetWidth;
        var newW = Math.max(CHAT_MIN, Math.min(startW + dx, maxChat));
        chatPane.style.width = newW + 'px';
      }

      function startDrag(clientX) {
        chatPane = document.querySelector('.hw-chat');
        if (!chatPane) return false;
        dragging = true;
        startX = clientX;
        startW = chatPane.getBoundingClientRect().width;
        chatPane.style.transition = 'none';
        resizer.classList.add('dragging');
        if (workspace) workspace.classList.add('hw-resizing');
        document.body.style.userSelect = 'none';
        document.body.style.cursor = 'col-resize';
        return true;
      }

      function moveDrag(clientX) {
        if (!dragging || !chatPane) return;
        if (rafId) cancelAnimationFrame(rafId);
        var cx = clientX;
        rafId = requestAnimationFrame(function () { applyWidth(cx); });
      }

      function stopDrag() {
        if (!dragging) return;
        dragging = false;
        rafId = null;
        resizer.classList.remove('dragging');
        if (workspace) workspace.classList.remove('hw-resizing');
        if (chatPane) chatPane.style.transition = '';
        document.body.style.userSelect = '';
        document.body.style.cursor = '';
      }

      /* ── Mouse ── */
      resizer.addEventListener('mousedown', function (e) {
        e.preventDefault();
        startDrag(e.clientX);
      });
      document.addEventListener('mousemove', function (e) { moveDrag(e.clientX); });
      document.addEventListener('mouseup', stopDrag);
      document.addEventListener('mouseleave', stopDrag);

      /* ── Touch ── */
      resizer.addEventListener('touchstart', function (e) {
        if (e.touches.length !== 1) return;
        e.preventDefault();
        startDrag(e.touches[0].clientX);
      }, { passive: false });
      document.addEventListener('touchmove', function (e) {
        if (!dragging || e.touches.length !== 1) return;
        e.preventDefault();
        moveDrag(e.touches[0].clientX);
      }, { passive: false });
      document.addEventListener('touchend', stopDrag);
      document.addEventListener('touchcancel', stopDrag);
    })();

    /* ── hcm-preview-panel resize handle drag logic (mouse + touch) ──
       Unlike .hw-chat/.hw-preview (flex siblings), .hcm-preview-panel is an
       edge-anchored (inset-inline-end:0) absolutely-positioned drawer, so we
       resize its own width directly. Drag direction depends on LTR/RTL since
       the anchored edge (and therefore the free/draggable edge) flips. */
    (function () {
      var resizer = document.getElementById('hcmResizer');
      var panel = null;
      var startX = 0, startW = 0, dragging = false, rafId = null;

      if (!resizer) return;

      var PANEL_MIN = 320; /* px */

      function isRtl() {
        return document.documentElement.getAttribute('dir') === 'rtl';
      }

      function maxWidth() {
        return Math.min(window.innerWidth * 0.94, 1400);
      }

      function applyWidth(clientX) {
        var dx = isRtl() ? (clientX - startX) : (startX - clientX);
        var newW = Math.max(PANEL_MIN, Math.min(startW + dx, maxWidth()));
        panel.style.width = newW + 'px';
      }

      function startDrag(clientX) {
        panel = document.querySelector('.hcm-preview-panel');
        if (!panel) return false;
        dragging = true;
        startX = clientX;
        startW = panel.getBoundingClientRect().width;
        panel.style.transition = 'none';
        resizer.classList.add('dragging');
        panel.classList.add('hcm-resizing');
        document.body.style.userSelect = 'none';
        document.body.style.cursor = 'col-resize';
        return true;
      }

      function moveDrag(clientX) {
        if (!dragging || !panel) return;
        if (rafId) cancelAnimationFrame(rafId);
        var cx = clientX;
        rafId = requestAnimationFrame(function () { applyWidth(cx); });
      }

      function stopDrag() {
        if (!dragging) return;
        dragging = false;
        rafId = null;
        resizer.classList.remove('dragging');
        if (panel) {
          panel.classList.remove('hcm-resizing');
          panel.style.transition = '';
        }
        document.body.style.userSelect = '';
        document.body.style.cursor = '';
      }

      /* ── Mouse ── */
      resizer.addEventListener('mousedown', function (e) {
        e.preventDefault();
        startDrag(e.clientX);
      });
      document.addEventListener('mousemove', function (e) { moveDrag(e.clientX); });
      document.addEventListener('mouseup', stopDrag);
      document.addEventListener('mouseleave', stopDrag);

      /* ── Touch ── */
      resizer.addEventListener('touchstart', function (e) {
        if (e.touches.length !== 1) return;
        e.preventDefault();
        startDrag(e.touches[0].clientX);
      }, { passive: false });
      document.addEventListener('touchmove', function (e) {
        if (!dragging || e.touches.length !== 1) return;
        e.preventDefault();
        moveDrag(e.touches[0].clientX);
      }, { passive: false });
      document.addEventListener('touchend', stopDrag);
      document.addEventListener('touchcancel', stopDrag);
    })();

    // Click a recent project -> reopen its source conversation if one is linked,
    // otherwise fall back to prefilling the home composer (user reviews, then sends)
    window.homePickRecent = function (id) {
      const item = (genHistory || []).find(function (p) { return p.id === id; });
      if (!item) return;
      if (item.chatSessionId && homeChatSessions.some(function (s) { return s.id === item.chatSessionId; })) {
        window.loadHomeChatSession(item.chatSessionId);
        return;
      }
      const inp = document.getElementById('homeInput');
      if (inp) { inp.value = item.prompt || ''; inp.dispatchEvent(new Event('input')); inp.focus(); }
      window.setHomeType(item.type);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    function renderRecentSkeleton() {
      const wrap = document.getElementById('homeRecent');
      if (!wrap) return;
      const card = '<div class="home-recent-skel"><div class="skel-bar badge"></div>' +
        '<div class="skel-bar line"></div><div class="skel-bar short"></div></div>';
      wrap.innerHTML = card + card + card;
    }
    window.renderRecentSkeleton = renderRecentSkeleton;

    /* ── Skeleton rows for #homeHistoryList (recent chat sidebar), shown
       while auth/fetch is in flight and there's no cached list to paint yet.
       .shi-skel reads the same --sb-recent-* variables as the real
       .sidebar-history-item/.shi-main rows, so swapping to real rows causes
       no layout shift — see the rule in index.html. ── */
    function renderHomeHistorySkeleton() {
      const list = document.getElementById('homeHistoryList');
      if (!list) return;
      const row = '<div class="shi-skel"><div class="shi-skel-icon"></div><div class="shi-skel-line"></div></div>';
      const rowShort = '<div class="shi-skel"><div class="shi-skel-icon"></div><div class="shi-skel-line w60"></div></div>';
      list.innerHTML = row + row + rowShort + row + rowShort;
    }
    window.renderHomeHistorySkeleton = renderHomeHistorySkeleton;

    function renderRecentHome() {
      const wrap = document.getElementById('homeRecent');
      if (!wrap) return;
      const items = (genHistory || []).slice(0, 3);
      if (items.length === 0) {
        if (recentLoadFailed) {
          wrap.innerHTML = '<div class="home-recent-failed">' +
            '<span>' + escapeHtml(BatLang.t('home.recentFailed')) + '</span>' +
            '<button type="button" class="home-recent-retry" onclick="loadGenHistory()">' + escapeHtml(BatLang.t('common.retry')) + '</button>' +
            '</div>';
        } else {
          wrap.innerHTML = '<div class="home-recent-empty">' + escapeHtml(BatLang.t('home.recentEmpty')) + '</div>';
        }
        return;
      }
      const label = {
        game: BatLang.t('type.game'), website: BatLang.t('type.website'),
        tool: BatLang.t('type.tool'), mobile: BatLang.t('type.mobile')
      };
      wrap.innerHTML = items.map(function (item) {
        return '<div class="home-recent-card" onclick="homePickRecent(\'' + item.id + '\')">' +
          '<div class="home-recent-badge">' + escapeHtml(label[item.type] || item.type) + '</div>' +
          '<div class="home-recent-prompt">' + escapeHtml(item.prompt) + '</div>' +
          '</div>';
      }).join('');
    }
    window.renderRecentHome = renderRecentHome;

    (function initHomeComposer() {
      const inp = document.getElementById('homeInput');
      if (!inp) return;
      inp.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 200) + 'px';
        if (typeof window.batmanCheckInput === 'function') window.batmanCheckInput(this);
      });
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          if (homeConvBusy) return; // AI is busy — Enter does nothing until it's free
          window.homeGoGenerate();
        }
      });
    })();

    (function initHwComposer() {
      const inp = document.getElementById('hwFollowupInput');
      if (!inp) return;
      inp.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
      });
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); window.hwFollowupSend(); }
      });
    })();

    // Re-render recent cards (and their empty-state text) on language change
    BatLang.onChange(function () {
      renderRecentHome();
      if (typeof window.refreshLangBtns === 'function') window.refreshLangBtns();
      window.updateCreditDisplay(); // refresh period label on lang change
    });

    // Init lang button states
    window.refreshLangBtns();

    /* ── Pricing → dedicated upgrade.html page ── */
    window.showPricingModal = function() {
      window.location.href = 'upgrade.html';
    };

    /* upgrade buttons route to the upgrade page */
    const _upgradeBtn = document.getElementById('upgradeBtn');
    if (_upgradeBtn) _upgradeBtn.addEventListener('click', () => {
      const um = document.getElementById('upgradeModal');
      if (um) um.classList.remove('active');
      window.location.href = 'upgrade.html';
    });
    const _upgradeFromCreditsBtn = document.getElementById('upgradeFromCreditsBtn');
    if (_upgradeFromCreditsBtn) _upgradeFromCreditsBtn.addEventListener('click', () => {
      window.location.href = 'upgrade.html';
    });

    /* ── Dynamic Type Content ── */
    const TYPE_CONTENT = {
      game: {
        en: {
          greetingSub: 'Describe your idea and get a playable HTML5 game in seconds.',
          examplesLabel: '🎮 Game ideas',
          examples: [
            '🚀 Dodge falling meteors with neon glow effects and score counter',
            '🏃 Endless runner where you jump over obstacles in a desert at sunset',
            '🎯 Click the appearing circles before they disappear — speed increases each level',
            '🧱 Stack blocks as they swing left and right — how high can you go?',
          ],
          tipsLabel: 'Tips for better games',
          tips: [
            'Mention colors, themes, or visual vibes',
            'Describe the core mechanic clearly',
            'Include difficulty or progression details',
            'You can write in Arabic or English',
          ],
        },
        ar: {
          greetingSub: 'صف فكرتك واحصل على لعبة HTML5 قابلة للعب في ثوانٍ.',
          examplesLabel: '🎮 أفكار ألعاب',
          examples: [
            '🚀 تجنّب النيازك المتساقطة مع تأثيرات توهج نيون وعداد نقاط',
            '🏃 لاعب لا نهائي يقفز فوق العقبات في صحراء عند الغروب',
            '🎯 اضغط على الدوائر الظاهرة قبل أن تختفي — السرعة تزيد مع كل مستوى',
            '🧱 كدّس الكتل وهي تتأرجح يميناً ويساراً — كم تستطيع الوصول؟',
          ],
          tipsLabel: 'نصائح لألعاب أفضل',
          tips: [
            'اذكر الألوان والقوالب البصرية التي تريدها',
            'صف الميكانيكية الأساسية للعبة بوضوح',
            'أضف تفاصيل الصعوبة والتطور في اللعبة',
            'يمكنك الكتابة بالعربية أو الإنجليزية',
          ],
        },
      },
      website: {
        en: {
          greetingSub: 'Describe your idea and get a polished, responsive site in seconds.',
          examplesLabel: '🌐 Website ideas',
          examples: [
            '🚀 SaaS landing page with hero, features list, pricing table, and dark theme',
            '💼 Developer portfolio with project cards, skills section, and contact form',
            '🛍 E-commerce product page with image gallery and add-to-cart button',
            '📊 Analytics dashboard with charts, KPI cards, and sidebar navigation',
          ],
          tipsLabel: 'Tips for better websites',
          tips: [
            'Mention sections you want (hero, features, footer)',
            'Describe color scheme or brand style',
            'Specify target audience or industry',
            'You can write in Arabic or English',
          ],
        },
        ar: {
          greetingSub: 'صف فكرتك واحصل على موقع ويب احترافي متجاوب في ثوانٍ.',
          examplesLabel: '🌐 أفكار مواقع',
          examples: [
            '🚀 صفحة هبوط SaaS مع هيرو، قائمة مميزات، جدول أسعار، وثيم داكن',
            '💼 بورتفوليو مطوّر مع بطاقات مشاريع، قسم مهارات، ونموذج تواصل',
            '🛍 صفحة منتج للتسوق مع معرض صور وزر إضافة للسلة',
            '📊 لوحة تحكم تحليلات مع رسوم بيانية وبطاقات KPI وتنقل جانبي',
          ],
          tipsLabel: 'نصائح لمواقع أفضل',
          tips: [
            'اذكر الأقسام التي تريدها (هيرو، مميزات، فوتر)',
            'صف نظام الألوان أو هوية العلامة التجارية',
            'حدد الجمهور المستهدف أو المجال',
            'يمكنك الكتابة بالعربية أو الإنجليزية',
          ],
        },
      },
      mobile: {
        en: {
          greetingSub: 'Describe your idea and get a polished, mobile-native app in seconds.',
          examplesLabel: '📱 App ideas',
          examples: [
            '💬 Social app with stories, chat bubbles, and profile cards with gradient avatars',
            '🛍 E-commerce app with product grid, cart badge, and swipeable image gallery',
            '💪 Fitness tracker with daily stats rings, workout cards, and water intake tracker',
            '💳 Finance wallet with balance card, transaction list, and send money flow',
          ],
          tipsLabel: 'Tips for better apps',
          tips: [
            'Mention screens you want (home, profile, settings)',
            'Describe navigation style (tabs, drawer, stack)',
            'Include brand colors or theme preferences',
            'You can write in Arabic or English',
          ],
        },
        ar: {
          greetingSub: 'صف فكرتك واحصل على واجهة تطبيق موبايل احترافية في ثوانٍ.',
          examplesLabel: '📱 أفكار تطبيقات',
          examples: [
            '💬 تطبيق اجتماعي مع ستوري، فقاعات دردشة، وبطاقات ملف شخصي بتدرجات لونية',
            '🛍 تطبيق تسوق مع شبكة منتجات، شارة عربة، ومعرض صور بالتمرير',
            '💪 متتبع لياقة مع حلقات إحصائيات يومية، بطاقات تمارين، ومتتبع شرب الماء',
            '💳 محفظة مالية مع بطاقة رصيد، قائمة معاملات، وتدفق إرسال الأموال',
          ],
          tipsLabel: 'نصائح لتطبيقات أفضل',
          tips: [
            'اذكر الشاشات التي تريدها (الرئيسية، الملف الشخصي، الإعدادات)',
            'صف أسلوب التنقل (تبويبات، درج، مكدس)',
            'أضف الألوان المفضلة أو تفضيلات الثيم',
            'يمكنك الكتابة بالعربية أو الإنجليزية',
          ],
        },
      },
      tool: {
        en: {
          greetingSub: 'Describe your utility and get a functional, clean-coded tool in seconds.',
          examplesLabel: '🛠 Tool ideas',
          examples: [
            '🔄 JSON formatter with syntax highlighting, minify/prettify toggle, and tree view',
            '🧮 BMI calculator with health category chart and visual progress indicator',
            '⚡ Password generator with length slider, character options, and strength meter',
            '📊 Word counter with character stats, reading time, and keyword density',
          ],
          tipsLabel: 'Tips for better tools',
          tips: [
            'Specify input types and expected output format',
            'Mention any calculations or logic needed',
            'Include visual feedback (charts, meters, colors)',
            'You can write in Arabic or English',
          ],
        },
        ar: {
          greetingSub: 'صف أداتك واحصل على أداة وظيفية بكود نظيف في ثوانٍ.',
          examplesLabel: '🛠 أفكار أدوات',
          examples: [
            '🔄 منسّق JSON مع تمييز بناء الجملة، تبديل تصغير/تجميل، وعرض شجري',
            '🧮 حاسبة BMI مع مخطط فئات الصحة ومؤشر تقدم مرئي',
            '⚡ مولّد كلمات مرور مع شريط طول، خيارات أحرف، ومقياس قوة',
            '📊 عداد كلمات مع إحصائيات أحرف، وقت القراءة، وكثافة الكلمات المفتاحية',
          ],
          tipsLabel: 'نصائح لأدوات أفضل',
          tips: [
            'حدد أنواع المدخلات وصيغة المخرجات المتوقعة',
            'اذكر أي حسابات أو منطق مطلوب',
            'أضف تغذية بصرية راجعة (رسوم بيانية، مقاييس، ألوان)',
            'يمكنك الكتابة بالعربية أو الإنجليزية',
          ],
        },
      },
    };

    function updateTypeContent(type) {
      const lang = window.currentLang || 'en';
      const content = TYPE_CONTENT[type]?.[lang] || TYPE_CONTENT[type]?.['en'];
      if (!content) return;

      // examples label (Home)
      const labelEl = document.getElementById('homeExamplesLabel');
      if (labelEl) labelEl.textContent = content.examplesLabel;

      // example prompts (Home)
      const listEl = document.getElementById('homeExamplesList');
      if (listEl) {
        listEl.innerHTML = (content.examples || []).map(function (ex) {
          return '<button type="button" class="example-prompt" onclick="homeUseExample(this)">' +
            escapeHtml(ex) + '</button>';
        }).join('');
      }
    }

    window.homeUseExample = function (btn) {
      const inp = document.getElementById('homeInput');
      if (inp) {
        inp.value = btn.textContent;
        inp.dispatchEvent(new Event('input'));
        inp.focus();
      }
    };

    // ── single entry point called whenever type changes ──
    window._onTypeChange = function(type) {
      updateTypeContent(type);
      if (window.renderSubtypes) window.renderSubtypes(type);
    };

    // Pill clicks handled in module script via _onTypeChange

    /* ── Subcategory System ── */
    // All 4 build types (game, website, mobile, tool) intentionally have no
    // subtype/style picker — SUBTYPES stays empty so renderSubtypes() always
    // hides #homeSubtypeSection.
    const SUBTYPES = {};
    
    let selectedSubtype = ''; // empty = nothing selected (optional)
    sessionStorage.setItem('batlab_subtype', '');


    window.renderSubtypes = function(type) {
      const section = document.getElementById('homeSubtypeSection');
      const lang = window.currentLang || 'en';
      const data = SUBTYPES[type]?.[lang] || SUBTYPES[type]?.['en'];
      // Types without a subtype set (e.g. website) hide the style picker entirely.
      if (!data) {
        selectedSubtype = '';
        sessionStorage.setItem('batlab_subtype', '');
        if (section) section.style.display = 'none';
        return;
      }
      if (section) section.style.display = '';

      const label = document.getElementById('homeSubtypeLabel');
      const grid  = document.getElementById('homeSubtypeGrid');
      if (!label || !grid) return;

      label.textContent = data.label;

      // reset selection when type changes
      const values = data.items.map(i => i.value);
      if (!values.includes(selectedSubtype)) {
        selectedSubtype = '';
        sessionStorage.setItem('batlab_subtype', '');
      }

      grid.innerHTML = data.items.map(item => `
        <button
          class="subtype-card ${selectedSubtype === item.value ? 'active-sub' : ''}"
          data-sub="${item.value}"
          onclick="selectSubtype('${item.value}')"
        >
          <span class="subtype-icon">${item.icon}</span>
          <span class="subtype-name">${item.name}</span>
          <span class="subtype-desc">${item.desc}</span>
        </button>`).join('');
    }

    window.selectSubtype = function(value) {
      // toggle off if clicking the already selected one
      if (selectedSubtype === value) {
        selectedSubtype = '';
        sessionStorage.setItem('batlab_subtype', '');
        document.querySelectorAll('.subtype-card').forEach(c => c.classList.remove('active-sub'));
      } else {
        selectedSubtype = value;
        sessionStorage.setItem('batlab_subtype', value);
        document.querySelectorAll('.subtype-card').forEach(c => {
          c.classList.toggle('active-sub', c.dataset.sub === value);
        });
      }
    };

    // Default to "Website" pre-selected on load (Figma visual-parity pass,
    // approved decision — was previously no default type/chatbot mode).
    // Goes through the real setHomeType() click-path so the active chip
    // class, placeholder typewriter, and cost preview all stay in sync
    // exactly as if the user had clicked the chip themselves.
    window.setHomeType('website');

    // re-render subtypes + content on lang change
    const _prevApplyLang = window.applyLang;
    window.applyLang = function(lang) {
      if (_prevApplyLang) _prevApplyLang(lang);
      const activeChip = document.querySelector('#homeChips .home-chip.active');
      const type = activeChip?.dataset.value || '';
      if (window.renderSubtypes) window.renderSubtypes(type);
      if (typeof updateTypeContent === 'function') updateTypeContent(type);
    };


  /* ── cursor trail ── */
    (function () {
      var STORAGE_KEY = 'batnxt_cursor_trail_disabled';
      var canvas = document.getElementById('cursorTrailCanvas');
      if (!canvas || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      if (window.matchMedia('(hover: none)').matches) return;

      var ctx = canvas.getContext('2d');
      var dots = [];
      var lastX = null, lastY = null;
      var running = false;
      var rafId = null;

      function resize() {
        canvas.width = window.innerWidth * devicePixelRatio;
        canvas.height = window.innerHeight * devicePixelRatio;
        canvas.style.width = window.innerWidth + 'px';
        canvas.style.height = window.innerHeight + 'px';
        ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
      }
      resize();
      window.addEventListener('resize', resize);

      function accentColor() {
        return getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#00e89a';
      }

      function onPointerMove(e) {
        var dx = lastX === null ? 0 : e.clientX - lastX;
        var dy = lastY === null ? 0 : e.clientY - lastY;
        var dist = Math.sqrt(dx * dx + dy * dy);
        lastX = e.clientX; lastY = e.clientY;
        if (dist > 4 || dots.length === 0) {
          dots.push({ x: e.clientX, y: e.clientY, life: 1 });
          if (dots.length > 22) dots.shift();
        }
      }

      function tick() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        var color = accentColor();
        for (var i = 0; i < dots.length; i++) {
          var d = dots[i];
          d.life -= 0.045;
          if (d.life <= 0) continue;
          var r = 3.2 * d.life;
          ctx.beginPath();
          ctx.arc(d.x, d.y, r, 0, Math.PI * 2);
          ctx.fillStyle = color;
          ctx.globalAlpha = d.life * 0.35;
          ctx.fill();
        }
        ctx.globalAlpha = 1;
        dots = dots.filter(function (d) { return d.life > 0; });
        rafId = requestAnimationFrame(tick);
      }

      function start() {
        if (running) return;
        running = true;
        lastX = null; lastY = null; dots = [];
        window.addEventListener('pointermove', onPointerMove, { passive: true });
        tick();
      }
      function stop() {
        if (!running) return;
        running = false;
        window.removeEventListener('pointermove', onPointerMove);
        if (rafId) cancelAnimationFrame(rafId);
        rafId = null;
        dots = [];
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }

      window.isCursorTrailEnabled = function () {
        return localStorage.getItem(STORAGE_KEY) !== '1';
      };
      window.setCursorTrailEnabled = function (enabled) {
        localStorage.setItem(STORAGE_KEY, enabled ? '0' : '1');
        if (enabled) start(); else stop();
      };

      if (window.isCursorTrailEnabled()) start();
    })();

  /* ── global drag-and-drop ── */
    /* ── Global drag-and-drop: drop files anywhere on the page ── */
    (function () {
      var overlay = document.getElementById('globalDragOverlay');
      var dragCounter = 0; // track nested dragenter/dragleave pairs

      function hasFiles(e) {
        var dt = e.dataTransfer;
        if (!dt) return false;
        if (dt.types) {
          for (var i = 0; i < dt.types.length; i++) {
            if (dt.types[i] === 'Files') return true;
          }
        }
        return false;
      }

      document.addEventListener('dragenter', function (e) {
        if (!hasFiles(e)) return;
        dragCounter++;
        if (overlay) overlay.classList.add('active');
        e.preventDefault();
      }, false);

      document.addEventListener('dragover', function (e) {
        if (!hasFiles(e)) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
      }, false);

      document.addEventListener('dragleave', function (e) {
        dragCounter--;
        if (dragCounter <= 0) {
          dragCounter = 0;
          if (overlay) overlay.classList.remove('active');
        }
      }, false);

      document.addEventListener('drop', function (e) {
        dragCounter = 0;
        if (overlay) overlay.classList.remove('active');
        if (!hasFiles(e)) return;
        e.preventDefault();

        var files = e.dataTransfer ? Array.from(e.dataTransfer.files) : [];
        if (!files.length) return;

        // Re-use the existing homeFilesSelected logic by synthesising an event-like object
        if (typeof window.homeFilesSelected === 'function') {
          window.homeFilesSelected({ target: { files: files, value: '' } });
        }
      }, false);
    })();

    /* ── Scroll-to-latest button (Home / Workspace / Chat page) ── */
    function isNearBottom(el, threshold) {
      if (threshold === undefined) threshold = 120;
      return el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
    }
    function scrollToBottom(el, smooth) {
      el.scrollTo({ top: el.scrollHeight, behavior: smooth === false ? 'auto' : 'smooth' });
    }
    function wireScrollToLatest(containerEl, buttonEl) {
      if (!containerEl || !buttonEl) return;
      var sync = function () { buttonEl.classList.toggle('show', !isNearBottom(containerEl)); };
      containerEl.addEventListener('scroll', sync, { passive: true });
      // Re-check whenever content grows (new messages), so the button appears
      // for incoming replies while the user is scrolled up, without touching
      // every existing append/scrollTop call site individually.
      new MutationObserver(sync).observe(containerEl, { childList: true, subtree: true });
      buttonEl.addEventListener('click', function () { scrollToBottom(containerEl); });
      sync();
    }

    /* ── Reverse infinite scroll / lazy message windowing ──────────────────
       Both chat surfaces keep their whole history in memory as a single array
       (Home: homeConvHistory from the chat_sessions JSONB; Sidebar: chatHistory
       from localStorage). On open we render only the most recent
       INITIAL_BATCH_PAIRS pairs, then reveal older pairs in MORE_BATCH_PAIRS
       chunks as the user scrolls to the top. A "pair" = one user turn + its
       assistant reply, so batch boundaries are counted by user-role messages.
       This is a render-side optimisation (no extra fetch — the array is already
       loaded); retune by changing the two constants below. */
    var INITIAL_BATCH_PAIRS = 20;
    var MORE_BATCH_PAIRS = 10;
    var homeLazyState = { from: 0, loading: false, observer: null, sentinel: null };
    var chatLazyState = { from: 0, loading: false, observer: null, sentinel: null };

    // Walk backward from `fromIdx` (exclusive) and return the raw-array index at
    // which a batch containing `pairs` user turns begins — or 0 if fewer remain.
    function lazyComputeBatchStart(history, fromIdx, pairs) {
      var count = 0;
      for (var i = fromIdx - 1; i >= 0; i--) {
        if (history[i] && history[i].role === 'user') {
          count++;
          if (count === pairs) return i;
        }
      }
      return 0;
    }

    // Disconnect any observer and remove sentinel/spinner/begin rows left from a
    // previous session, so switching chats can't leave a stale observer firing.
    function lazyTeardown(state, container) {
      if (state.observer) { state.observer.disconnect(); state.observer = null; }
      state.sentinel = null;
      state.from = 0;
      state.loading = false;
      if (container) {
        var stale = container.querySelectorAll('.lazy-sentinel, .lazy-spinner, .lazy-begin');
        for (var i = 0; i < stale.length; i++) stale[i].remove();
      }
    }

    // Initial windowed render + observer wiring. `renderSlice(container, history,
    // start, end)` renders history[start..end) in order using the surface's own
    // append helpers. `pageScroll` picks the scroll root (Home = the scrollable
    // #homeConvMessages container; Sidebar = the page/viewport).
    function lazySetup(cfg) {
      var state = cfg.state, container = cfg.container, history = cfg.getHistory();
      lazyTeardown(state, container);
      var total = history.length;
      var start = lazyComputeBatchStart(history, total, INITIAL_BATCH_PAIRS);
      state.from = start;
      cfg.renderSlice(container, history, start, total);
      if (start <= 0) return; // whole history already shown — no lazy loading needed
      var sentinel = document.createElement('div');
      sentinel.className = 'lazy-sentinel';
      container.insertBefore(sentinel, container.firstChild);
      state.sentinel = sentinel;
      var observer = new IntersectionObserver(function (entries) {
        if (entries[0] && entries[0].isIntersecting) lazyLoadMore(cfg);
      }, { root: cfg.pageScroll ? null : container, rootMargin: '200px 0px 0px 0px', threshold: 0 });
      observer.observe(sentinel);
      state.observer = observer;
    }

    // Prepend the next older batch, preserving the user's scroll position so the
    // viewport doesn't jump. Guarded by state.loading against overlapping loads.
    function lazyLoadMore(cfg) {
      var state = cfg.state, container = cfg.container;
      if (state.loading || state.from <= 0) return;
      state.loading = true;
      var history = cfg.getHistory();
      var pageScroll = cfg.pageScroll;
      var prevHeight = pageScroll ? document.documentElement.scrollHeight : container.scrollHeight;
      var prevScroll = pageScroll ? window.scrollY : container.scrollTop;
      var spinner = document.createElement('div');
      spinner.className = 'lazy-spinner';
      spinner.innerHTML = '<span class="lazy-spinner-ring"></span>';
      container.insertBefore(spinner, state.sentinel ? state.sentinel.nextSibling : container.firstChild);
      requestAnimationFrame(function () {
        var newStart = lazyComputeBatchStart(history, state.from, MORE_BATCH_PAIRS);
        var anchor = spinner.nextSibling; // current oldest message node
        var beforeSet = new Set(Array.prototype.slice.call(container.children));
        cfg.renderSlice(container, history, newStart, state.from);
        // The append helpers add nodes at the bottom; move the freshly-created
        // ones (already in chronological order) up to just above the previous
        // oldest message, keeping the sentinel pinned at the very top.
        var added = Array.prototype.slice.call(container.children).filter(function (n) { return !beforeSet.has(n); });
        for (var i = 0; i < added.length; i++) container.insertBefore(added[i], anchor);
        if (spinner.parentNode) spinner.parentNode.removeChild(spinner);
        state.from = newStart;
        if (pageScroll) {
          window.scrollTo(0, prevScroll + (document.documentElement.scrollHeight - prevHeight));
        } else {
          container.scrollTop = prevScroll + (container.scrollHeight - prevHeight);
        }
        if (state.from <= 0) {
          if (state.observer) { state.observer.disconnect(); state.observer = null; }
          if (state.sentinel && state.sentinel.parentNode) state.sentinel.parentNode.removeChild(state.sentinel);
          state.sentinel = null;
          var begin = document.createElement('div');
          begin.className = 'lazy-begin';
          begin.textContent = BatLang.t('chat.beginning');
          container.insertBefore(begin, container.firstChild);
        }
        state.loading = false;
      });
    }

    // ChatGPT/Claude-style loading skeleton for the initial conversation open:
    // a few pulsing placeholder bubbles (alternating sides, varied widths) shown
    // while the session data is fetched/parsed, then replaced by the real render.
    // Rows are cosmetic only (aria-hidden). Cleared by the caller (innerHTML = '')
    // before lazySetup() paints the actual messages.
    function renderChatSkeleton(container) {
      if (!container) return;
      var rows = [
        { user: false, lines: ['70%', '52%'] },
        { user: true,  lines: ['46%'] },
        { user: false, lines: ['64%', '78%', '40%'] },
        { user: true,  lines: ['38%'] }
      ];
      var html = '<div class="chat-skeleton" aria-hidden="true">';
      for (var r = 0; r < rows.length; r++) {
        html += '<div class="skel-row' + (rows[r].user ? ' user' : '') + '">';
        html += '<div class="skel-avatar"></div><div class="skel-lines">';
        for (var w = 0; w < rows[r].lines.length; w++) {
          html += '<div class="skel-bubble" style="width:' + rows[r].lines[w] + '"></div>';
        }
        html += '</div></div>';
      }
      html += '</div>';
      container.innerHTML = html;
    }

    // Per-surface slice renderers (reuse each surface's existing append helpers).
    function hcmRenderSlice(container, history, start, end) {
      var lastUserPrompt;
      for (var i = start; i < end; i++) {
        var m = history[i];
        // Rebuild the "Thought for Xs" reasoning block that was shown live.
        // secs>0 (even with empty text) restores the honest timing-only chip too.
        if (m.role === 'assistant' && m.think && (m.think.text || m.think.secs)) {
          hcmAppendSavedThinking(m.think.text || '', m.think.secs || 1, container && container.id);
        }
        // Rebuild the finished "Analyzed" terminal card for a restored export
        // reply.
        if (m.role === 'assistant' && m.analyzingSteps) {
          hcmAppendSavedAnalyzingCard('homeConvMessages');
        }
        // Export marker messages render their OWN "✅ ready" lead-in + card
        // via appendExportFileCard below — skip the generic bubble render
        // for them so the ready text doesn't appear twice. This also
        // mirrors the live flow, where appendExportFileCard is called
        // directly and never goes through hcmAppend for this message.
        var isExportMarker = m.role === 'assistant' && m.exportBody;
        if (!isExportMarker) {
          // Clarify replies: reconstruct the same text/card split the live path
          // produced (see homeConvGetReply's rawText→displayText clarify branch)
          // instead of ever rendering the raw <CLARIFY> tag or bare JSON as text —
          // strip the tag if present, or (bare-JSON safety-net path, where the
          // whole content IS the clarify JSON) show no text at all.
          var _renderContent = m.content;
          if (m.role === 'assistant' && m.clarify) {
            _renderContent = /<CLARIFY>[\s\S]*?<\/CLARIFY>/.test(_renderContent || '')
              ? _renderContent.replace(/<CLARIFY>[\s\S]*?<\/CLARIFY>/, '').trim()
              : '';
          }
          if (_renderContent) {
            hcmAppend(m.role, _renderContent, m.role === 'assistant' ? lastUserPrompt : undefined,
              m.role === 'user' ? m.images : undefined, m.role === 'user' ? i : undefined,
              m.role === 'assistant' ? m.msgId : undefined);
          }
        }
        if (m.role === 'user') lastUserPrompt = m.content;
        // Rebuild the interactive clarify card from the persisted data.
        if (m.role === 'assistant' && m.clarify) {
          hcmAppendClarify(m.clarify);
        }
        // Rebuild the exported file card for a restored export reply.
        if (isExportMarker) {
          appendExportFileCard('homeConvMessages', history, m.exportBody, m.exportFormat);
        }
        // Rebuild the clickable preview card for saved generation turns.
        if (m.role === 'assistant' && m.gen && m.gen.html && container) {
          hcmAppendFileCard(container, m.gen.fileName || 'build.html',
            m.gen.label || 'Generated file', m.gen.html, m.gen.type);
        }
      }
    }
    function chatRenderSlice(container, history, start, end) {
      for (var i = start; i < end; i++) {
        appendMsg(history[i].role, history[i].content, null);
      }
    }
    (function () {
      function ready() {
        wireScrollToLatest(document.getElementById('homeConvMessages'), document.getElementById('homeScrollLatestBtn'));
        wireScrollToLatest(document.getElementById('hwMessages'), document.getElementById('hwScrollLatestBtn'));
        // chatMessages now uses page-level scroll — wire the button to the window
        var chatBtn = document.getElementById('chatScrollLatestBtn');
        if (chatBtn) {
          var chatSync = function () {
            var nearBottom = (window.innerHeight + window.scrollY) >= (document.body.scrollHeight - 120);
            chatBtn.classList.toggle('show', !nearBottom);
          };
          window.addEventListener('scroll', chatSync, { passive: true });
          new MutationObserver(chatSync).observe(document.getElementById('chatMessages') || document.body, { childList: true, subtree: true });
          chatBtn.addEventListener('click', function () { window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }); });
          chatSync();
        }
      }
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ready);
      else ready();
    })();

/* ════════════════════════════════════════════════════════════════════
   FEATURE PACK 2.0
   1. Voice Input  2. Collaboration  3. Alfred  4. Multi-Export
   5. QR Preview   6. Drag&Drop      7. Versions 8. Themes  9. Analytics
════════════════════════════════════════════════════════════════════ */

/* ── 1. VOICE INPUT ── */
(function initVoiceInput() {
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  var isRecording = false;
  var recognition = null;

  window.toggleVoiceInput = function () {
    var btn = document.getElementById('homeMicBtn');
    if (!SR) { showToast('Voice input not supported in this browser', 'error'); return; }
    if (isRecording) { if (recognition) recognition.stop(); return; }

    recognition = new SR();
    recognition.lang = window.currentLang === 'ar' ? 'ar-SA' : (window.currentLang === 'tr' ? 'tr-TR' : 'en-US');
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = function () {
      isRecording = true;
      if (btn) btn.classList.add('recording');
      showToast('🎤 Listening\u2026', 'info');
    };
    recognition.onresult = function (e) {
      var transcript = Array.from(e.results).map(function (r) { return r[0].transcript; }).join('');
      var inp = document.getElementById('homeInput');
      if (inp) { inp.value = transcript; inp.dispatchEvent(new Event('input')); }
    };
    recognition.onend = function () {
      isRecording = false;
      if (btn) btn.classList.remove('recording');
    };
    recognition.onerror = function (e) {
      isRecording = false;
      if (btn) btn.classList.remove('recording');
      if (e.error !== 'no-speech') showToast('Voice error: ' + e.error, 'error');
    };
    try { recognition.start(); } catch (e) {}
    if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('voice', 'start');
  };
})();

/* ── 2. REAL-TIME COLLABORATION (BroadcastChannel — same-origin tabs) ── */
(function initCollaboration() {
  try {
    var channel = new BroadcastChannel('batnxt_collab');
    var myId = 'u' + Math.random().toString(36).slice(2, 5).toUpperCase();
    var myColor = ['#00e89a','#3b82f6','#c084fc','#fbbf24','#f87171'][Math.floor(Math.random() * 5)];
    var peers = {};

    function updateCollabUI() {
      var bar = document.getElementById('collabBar');
      var usersEl = document.getElementById('collabUsers');
      if (!bar || !usersEl) return;
      var ids = Object.keys(peers);
      if (ids.length === 0) { bar.classList.remove('active'); return; }
      bar.classList.add('active');
      usersEl.innerHTML = ids.map(function (id) {
        var p = peers[id];
        return '<div class="collab-user-av" style="background:' + p.color + '22;border-color:' + p.color + ';color:' + p.color + ';">' + id + '</div>';
      }).join('');
    }

    channel.onmessage = function (e) {
      var msg = e.data;
      if (!msg || !msg.id || msg.id === myId) return;
      if (msg.type === 'join' || msg.type === 'ping') {
        if (!peers[msg.id]) {
          peers[msg.id] = { color: msg.color };
          updateCollabUI();
          if (msg.type === 'join') {
            showToast('\uD83D\uDC65 ' + msg.id + ' joined the workspace!', 'info');
            channel.postMessage({ type: 'ping', id: myId, color: myColor });
          }
        }
      } else if (msg.type === 'leave') {
        delete peers[msg.id];
        updateCollabUI();
      }
    };

    channel.postMessage({ type: 'join', id: myId, color: myColor });
    window.addEventListener('beforeunload', function () {
      channel.postMessage({ type: 'leave', id: myId });
    });

    window.inviteCollaborator = function () {
      var link = window.location.href;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(link).then(function () {
          showToast('\uD83D\uDCCB Link copied! Open in another tab or share with a teammate.', 'success');
        });
      } else { prompt('Copy this link to collaborate:', link); }
    };

    window.broadcastPreview = function (html, type) {
      channel.postMessage({ type: 'preview_update', id: myId, buildType: type || 'project' });
    };
  } catch (e) { /* BroadcastChannel not available */ }
})();

/* ── 3. ALFRED AGENT MODE ── */
(function initAlfredMode() {
  var ALFRED_STEPS = [
    { icon: '\uD83E\uDDED', label: 'Analyzing requirements & constraints' },
    { icon: '\uD83D\uDDFA\uFE0F', label: 'Planning architecture & data flow' },
    { icon: '\uD83C\uDFA8', label: 'Designing UI layout & visual system' },
    { icon: '\u2699\uFE0F', label: 'Writing component & business logic' },
    { icon: '\uD83D\uDD12', label: 'Security hardening & validation' },
    { icon: '\u2728', label: 'Polishing & final QA pass' },
  ];
  var alfredTimer = null;

  window.showAlfredPanel = function (active) {
    var panel = document.getElementById('alfredPanel');
    if (!panel) return;
    panel.classList.toggle('active', !!active);
    if (active) _runAlfredAnimation();
    else clearInterval(alfredTimer);
  };

  function _runAlfredAnimation() {
    var stepsEl = document.getElementById('alfredSteps');
    if (!stepsEl) return;
    stepsEl.innerHTML = ALFRED_STEPS.map(function (s, i) {
      return '<div class="alfred-step" data-i="' + i + '">' +
        '<span class="alfred-step-icon">' + s.icon + '</span>' +
        '<span class="alfred-step-lbl">' + s.label + '</span>' +
        '<span class="alfred-step-status">waiting</span></div>';
    }).join('');
    clearInterval(alfredTimer);
    var idx = 0;
    function activate(i) {
      stepsEl.querySelectorAll('.alfred-step').forEach(function (el, ni) {
        el.classList.toggle('active', ni === i);
        el.classList.toggle('done', ni < i);
        var st = el.querySelector('.alfred-step-status');
        if (ni < i) st.textContent = 'done \u2713';
        else if (ni === i) st.textContent = 'running\u2026';
        else st.textContent = 'waiting';
      });
    }
    activate(0);
    alfredTimer = setInterval(function () {
      idx++;
      if (idx >= ALFRED_STEPS.length) { clearInterval(alfredTimer); return; }
      activate(idx);
    }, 1800);
  }

  // Wrap runGeneration to activate Alfred panel when Alfred model is selected
  var _origRG_alfred = window.runGeneration;
  if (_origRG_alfred && !window.__alfredHooked) {
    window.__alfredHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      var model = sessionStorage.getItem('batlab_model') || 'BAT 1.2 Core';
      if (model === 'Alfred') window.showAlfredPanel(true);
      var result = await _origRG_alfred(prompt, type, subtype, opts);
      if (model === 'Alfred') { clearInterval(alfredTimer); window.showAlfredPanel(false); }
      return result;
    };
  }
})();

/* ── 4. MULTI-FORMAT EXPORT ── */
window.showExportModal = function () {
  if (!lastHTML) { showToast('Generate something first!', 'info'); return; }
  var overlay = document.getElementById('exportModalOverlay');
  if (overlay) overlay.classList.add('active');
};
window.closeExportModal = function () {
  var overlay = document.getElementById('exportModalOverlay');
  if (overlay) overlay.classList.remove('active');
};
window.exportAs = function (format) {
  if (!lastHTML) return;
  var type = lastType || 'project';
  var ts = Date.now();
  // Serve-time badge (Free tier only) applied once; every export format
  // (html/react/vue/pdf/zip) embeds this same badged document.
  var outHTML = withBatnxtBadge(lastHTML);
  function dl(content, filename, mime) {
    var blob = new Blob([content], { type: mime || 'text/plain' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  }
  if (format === 'html') {
    dl(outHTML, 'batnxt-' + type + '-' + ts + '.html', 'text/html');
    showToast('\u2705 HTML downloaded!', 'success');
  } else if (format === 'react') {
    // Use function replacement to avoid special $ meaning in replacement strings
    var safe = outHTML.replace(/`/g, function() { return '\\`'; }).replace(/\$/g, function() { return '\\$'; });
    var jsx = '// Generated by BatNXT AI\nimport React from \'react\';\n\nconst BatNXTProject = () => (\n  <div dangerouslySetInnerHTML={{ __html: `' + safe + '` }} />\n);\n\nexport default BatNXTProject;\n';
    dl(jsx, 'BatNXTProject.jsx', 'text/javascript');
    showToast('\u2705 React component (.jsx) downloaded!', 'success');
  } else if (format === 'vue') {
    var safev = outHTML.replace(/`/g, function() { return '\\`'; }).replace(/\$/g, function() { return '\\$'; });
    var vue = '<template>\n  <div v-html="html" />\n</template>\n\n<script>\nexport default {\n  name: \'BatNXTProject\',\n  data() { return { html: `' + safev + '` }; }\n};\n<\/script>\n';
    dl(vue, 'BatNXTProject.vue', 'text/plain');
    showToast('\u2705 Vue component downloaded!', 'success');
  } else if (format === 'pdf') {
    var ifr = document.createElement('iframe');
    ifr.style.cssText = 'position:fixed;opacity:0;width:1px;height:1px;top:-9999px;';
    document.body.appendChild(ifr);
    ifr.contentDocument.open();
    ifr.contentDocument.write(outHTML);
    ifr.contentDocument.close();
    setTimeout(function () {
      try { ifr.contentWindow.print(); } catch (e2) {}
      setTimeout(function () { if (ifr.parentNode) ifr.parentNode.removeChild(ifr); }, 3000);
    }, 600);
    showToast('\uD83D\uDDA8\uFE0F Print dialog opened \u2014 save as PDF from there.', 'info');
  } else if (format === 'zip') {
    dl(outHTML, 'batnxt-' + type + '-' + ts + '.html', 'text/html');
    var readme = '# BatNXT Generated Project\n\nType: ' + type + '\nGenerated: ' + new Date().toISOString() + '\n\nOpen the .html file in any browser to view the project.\nMade with BatNXT AI.\n';
    dl(readme, 'README.md', 'text/plain');
    showToast('\u2705 HTML + README downloaded!', 'success');
  }
  window.closeExportModal();
  if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('export', format);
};

/* ── 5. QR CODE MOBILE PREVIEW ── */
window.showQRModal = function () {
  if (!lastHTML) { showToast('Generate something first to get a QR preview!', 'info'); return; }
  var overlay = document.getElementById('qrModalOverlay');
  if (!overlay) return;
  var key = 'batnxt_qr_' + Date.now();
  try { localStorage.setItem(key, lastHTML); } catch (e) {}
  var previewUrl = window.location.origin + window.location.pathname + '?qrPreview=' + encodeURIComponent(key);
  var qrImg = document.getElementById('qrCodeImg');
  if (qrImg) {
    qrImg.style.display = '';
    qrImg.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&qzone=1&data=' + encodeURIComponent(previewUrl);
    qrImg.onerror = function () {
      this.style.display = 'none';
      var fb = document.createElement('div');
      fb.style.cssText = 'width:200px;height:200px;display:flex;align-items:center;justify-content:center;font-size:0.75rem;color:var(--text-muted);text-align:center;padding:16px;border-radius:8px;background:var(--surface2);';
      fb.textContent = 'QR unavailable (offline). Copy the link below.';
      this.parentNode.insertBefore(fb, this.nextSibling);
    };
  }
  var urlEl = document.getElementById('qrPreviewUrl');
  if (urlEl) urlEl.textContent = previewUrl;
  overlay.classList.add('active');
  if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('qr_show', lastType);
};
window.closeQRModal = function () {
  var overlay = document.getElementById('qrModalOverlay');
  if (overlay) overlay.classList.remove('active');
};
window.copyQRUrl = function () {
  var urlEl = document.getElementById('qrPreviewUrl');
  if (!urlEl) return;
  var url = urlEl.textContent;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(function () { showToast('\uD83D\uDCCB Preview link copied!', 'success'); });
  } else { prompt('Copy this URL:', url); }
};
// On load: check for ?qrPreview= and restore the HTML
(function checkQRPreviewParam() {
  try {
    var params = new URLSearchParams(window.location.search);
    var key2 = params.get('qrPreview');
    if (!key2) return;
    var html = localStorage.getItem(decodeURIComponent(key2));
    if (!html) return;
    var attempts = 0;
    var chk = setInterval(function () {
      attempts++;
      if (typeof window.hcmOpenPreview === 'function') {
        clearInterval(chk);
        window.hcmOpenPreview(html, 'project');
        showToast('\uD83D\uDCF1 Mobile preview loaded from QR scan!', 'success');
      } else if (attempts > 40) clearInterval(chk);
    }, 250);
  } catch (e) {}
})();

/* ── 6. DRAG & DROP BUILDER ── */
(function initDragDropBuilder() {
  var ddbActive = false;
  window.toggleDDB = function () {
    ddbActive = !ddbActive;
    var btn = document.getElementById('ddbToggleBtn');
    var banner = document.getElementById('ddbBanner');
    if (btn) btn.classList.toggle('active', ddbActive);
    if (banner) banner.classList.toggle('active', ddbActive);
    if (!ddbActive) { showToast('Element selector off', 'info'); return; }
    showToast('\uD83D\uDDA5\uFE0F Click any element in the preview to edit it with AI', 'info');
    var iframe = document.getElementById('hwPreviewIframe') || document.getElementById('hcmPreviewIframe');
    if (!iframe) return;
    try {
      var doc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document);
      if (!doc || !doc.body) return;
      // Inject hover highlight
      var style = doc.createElement('style');
      style.id = '__ddb_style';
      style.textContent = '*{cursor:pointer!important}*:hover{outline:2px solid rgba(0,232,154,0.85)!important;outline-offset:1px;}';
      doc.head.appendChild(style);
      // Inject click-to-select handler
      var sc = doc.createElement('script');
      sc.id = '__ddb_sc';
      sc.textContent = '(function(){if(window.__ddb)return;window.__ddb=true;document.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();var el=e.target;var tag=el.tagName.toLowerCase();var cls=el.className&&typeof el.className==="string"?el.className.split(" ").filter(Boolean).slice(0,2).map(function(c){return"."+c;}).join(""):"";var txt=(el.innerText||"").trim().slice(0,50);window.parent.postMessage({type:"ddb_select",tag:tag,selector:tag+cls,text:txt},"*");},true);})();';
      doc.body.appendChild(sc);
    } catch (ex) { /* sandboxed iframe — inject blocked */ }
  };
  window.addEventListener('message', function (e) {
    if (!e.data || e.data.type !== 'ddb_select') return;
    var info = e.data;
    var label = info.tag + (info.text ? ' "' + info.text.slice(0, 28) + '"' : '');
    var prompt2 = 'Edit the ' + label + ' element: ';
    var inp = document.getElementById('hwFollowupInput') || document.getElementById('homeInput');
    if (inp) {
      inp.value = prompt2;
      inp.dispatchEvent(new Event('input'));
      inp.focus();
      inp.setSelectionRange(prompt2.length, prompt2.length);
    }
    showToast('\u270F\uFE0F Selected <' + info.selector + '> \u2014 complete the edit request below', 'info');
  });
})();

/* ── 7. VERSION HISTORY ── */
(function initVersionHistory() {
  var VK = 'batnxt_versions_v2';
  var MAX_VER = 12;
  function loadVers() { try { return JSON.parse(localStorage.getItem(VK) || '[]'); } catch (e) { return []; } }
  function saveVers(v) { try { localStorage.setItem(VK, JSON.stringify(v)); } catch (e) {} }

  window.saveVersion = function (label) {
    if (!lastHTML) { showToast('Nothing to save yet \u2014 generate something first.', 'info'); return; }
    var versions = loadVers();
    var ver = { id: 'v' + Date.now(), label: label || ('Snapshot ' + (versions.length + 1)), type: lastType || 'project', ts: Date.now(), html: lastHTML };
    versions.unshift(ver);
    if (versions.length > MAX_VER) versions.pop();
    saveVers(versions);
    showToast('\uD83D\uDCBE Saved: ' + ver.label, 'success');
    if (document.getElementById('versionsModalOverlay') && document.getElementById('versionsModalOverlay').classList.contains('active')) renderVersionsList();
  };
  window.showVersionsModal = function () {
    var overlay = document.getElementById('versionsModalOverlay');
    if (!overlay) return;
    renderVersionsList();
    overlay.classList.add('active');
  };
  window.closeVersionsModal = function () {
    var overlay = document.getElementById('versionsModalOverlay');
    if (overlay) overlay.classList.remove('active');
  };
  function renderVersionsList() {
    var list = document.getElementById('versionsList');
    if (!list) return;
    var versions = loadVers();
    if (versions.length === 0) {
      list.innerHTML = '<div class="versions-empty">No saved versions yet.<br>Click \u201CSave Current\u201D to capture a snapshot.</div>';
      return;
    }
    var icons = { game: '\uD83C\uDFAE', website: '\uD83C\uDF10', tool: '\uD83D\uDEE0', mobile: '\uD83D\uDCF1', project: '\uD83D\uDCC4' };
    list.innerHTML = versions.map(function (v) {
      var icon = icons[v.type] || '\uD83D\uDCC4';
      var date = new Date(v.ts).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      return '<div class="version-item">' +
        '<span class="version-item-icon">' + icon + '</span>' +
        '<div class="version-item-info"><div class="version-item-label">' + escapeHtml(v.label) + '</div>' +
        '<div class="version-item-meta">' + escapeHtml(v.type) + ' \u00B7 ' + date + '</div></div>' +
        '<div class="version-item-actions">' +
        '<button class="version-btn restore" onclick="restoreVersion(\'' + v.id + '\')">Restore</button>' +
        '<button class="version-btn" onclick="deleteVersion(\'' + v.id + '\')">\u2715</button>' +
        '</div></div>';
    }).join('');
  }
  window.restoreVersion = function (id) {
    var ver = loadVers().find(function (v) { return v.id === id; });
    if (!ver) return;
    lastHTML = ver.html; lastType = ver.type;
    var iframe = document.getElementById('hwPreviewIframe');
    if (iframe) iframe.srcdoc = withPreviewShim(lastHTML);
    if (typeof window.hcmOpenPreview === 'function') window.hcmOpenPreview(lastHTML, ver.type);
    var codeView = document.getElementById('hwCodeView');
    if (codeView) codeView.textContent = lastHTML;
    showToast('\u23EA Restored: ' + ver.label, 'success');
    window.closeVersionsModal();
  };
  window.deleteVersion = function (id) {
    saveVers(loadVers().filter(function (v) { return v.id !== id; }));
    renderVersionsList();
  };
  // Auto-save after successful generation
  var _origRG_ver = window.runGeneration;
  if (_origRG_ver && !window.__versionsHooked) {
    window.__versionsHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      var prevHTML = lastHTML;
      var result = await _origRG_ver(prompt, type, subtype, opts);
      if (lastHTML && lastHTML !== prevHTML) {
        var versions = loadVers();
        var label2 = 'Auto \u00B7 ' + (type || 'build') + ' \u2014 ' + (prompt || '').slice(0, 38);
        versions.unshift({ id: 'v' + Date.now(), label: label2, type: type || 'project', ts: Date.now(), html: lastHTML });
        if (versions.length > MAX_VER) versions.pop();
        saveVers(versions);
      }
      return result;
    };
  }
})();

/* ── 8. CUSTOM THEMES & DESIGN SYSTEM ── */
(function initCustomThemes() {
  var PALETTES = {
    default: { a: '#00e89a', ag: 'rgba(0,232,154,0.35)',   ad: 'rgba(0,232,154,0.1)'   },
    ocean:   { a: '#38bdf8', ag: 'rgba(56,189,248,0.35)',  ad: 'rgba(56,189,248,0.1)'  },
    purple:  { a: '#c084fc', ag: 'rgba(192,132,252,0.35)', ad: 'rgba(192,132,252,0.1)' },
    fire:    { a: '#fb923c', ag: 'rgba(251,146,60,0.35)',  ad: 'rgba(251,146,60,0.1)'  },
    rose:    { a: '#fb7185', ag: 'rgba(251,113,133,0.35)', ad: 'rgba(251,113,133,0.1)' },
    gold:    { a: '#fbbf24', ag: 'rgba(251,191,36,0.35)',  ad: 'rgba(251,191,36,0.1)'  },
  };
  function setPalette(p) {
    document.documentElement.style.setProperty('--accent', p.a);
    document.documentElement.style.setProperty('--accent-glow', p.ag);
    document.documentElement.style.setProperty('--accent-dim', p.ad);
  }
  window.applyTheme = function (name) {
    var p = PALETTES[name];
    if (!p) return;
    setPalette(p);
    localStorage.setItem('batnxt_theme', name);
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.toggle('active', btn.dataset.theme === name); });
    showToast('\uD83C\uDFA8 Theme: ' + name, 'success');
  };
  window.applyCustomAccent = function (hex) {
    if (!hex || hex.length < 7) return;
    var r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
    setPalette({ a: hex, ag: 'rgba('+r+','+g+','+b+',0.35)', ad: 'rgba('+r+','+g+','+b+',0.1)' });
    localStorage.setItem('batnxt_theme', 'custom');
    localStorage.setItem('batnxt_custom_accent', hex);
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.remove('active'); });
  };
  window._selectedDesignSystem = '';
  window.getDesignSystemNote = function () {
    var ds = localStorage.getItem('batnxt_design_system') || '';
    var notes = { material:'Use Material Design 3 principles: elevation, ripple, rounded corners.', ant:'Follow Ant Design: 8px grid, blue primary (#1677ff), clear hierarchy.', fluent:'Apply Microsoft Fluent 2: neutral backgrounds, subtle shadows, smooth motion.', ios:'Follow Apple HIG: SF Pro typography, iOS 17 components, blur backgrounds.', bootstrap:'Use Bootstrap 5: 12-column grid, btn/card/badge components, utility spacing.' };
    return notes[ds] || '';
  };
  // Hook showSettingsModal to sync preset states
  var _origSM = window.showSettingsModal;
  window.showSettingsModal = function () {
    if (_origSM) _origSM();
    var saved = localStorage.getItem('batnxt_theme') || 'default';
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.toggle('active', btn.dataset.theme === saved); });
    var ci = document.getElementById('customAccentInput');
    if (ci) { var sc2 = localStorage.getItem('batnxt_custom_accent'); if (sc2) ci.value = sc2; }
    var dsSel = document.getElementById('designSystemSelect');
    if (dsSel) dsSel.value = localStorage.getItem('batnxt_design_system') || '';
  };
  // Save design system on change
  var dsSel2 = document.getElementById('designSystemSelect');
  if (dsSel2) dsSel2.addEventListener('change', function () { localStorage.setItem('batnxt_design_system', this.value); showToast('\u2705 Design system: ' + (this.value || 'none'), 'success'); });
  // Restore saved theme on load
  (function () {
    var saved = localStorage.getItem('batnxt_theme');
    if (!saved || saved === 'default') return;
    if (PALETTES[saved]) { setPalette(PALETTES[saved]); return; }
    if (saved === 'custom') { var c = localStorage.getItem('batnxt_custom_accent'); if (c) window.applyCustomAccent(c); }
  })();
})();

/* ── 9. ANALYTICS DASHBOARD ── */
(function initAnalytics() {
  var AK = 'batnxt_analytics_v2';
  function loadA() { try { return JSON.parse(localStorage.getItem(AK) || '{}'); } catch (e) { return {}; } }
  function saveA(d) { try { localStorage.setItem(AK, JSON.stringify(d)); } catch (e) {} }

  window.trackAnalyticsEvent = function (type, value) {
    var d = loadA();
    d.firstSeen = d.firstSeen || Date.now();
    d.lastSeen = Date.now();
    if (type === 'generation') {
      d.totalGenerations = (d.totalGenerations || 0) + 1;
      d.byType = d.byType || {};
      d.byType[value] = (d.byType[value] || 0) + 1;
      var model = sessionStorage.getItem('batlab_model') || 'BAT 1.2 Core';
      d.byModel = d.byModel || {};
      d.byModel[model] = (d.byModel[model] || 0) + 1;
    } else if (type === 'export') {
      d.totalExports = (d.totalExports || 0) + 1;
    } else if (type === 'voice') {
      d.totalVoice = (d.totalVoice || 0) + 1;
    } else if (type === 'qr_show') {
      d.totalQR = (d.totalQR || 0) + 1;
    }
    saveA(d);
  };

  window.showAnalyticsModal = function () {
    var d = loadA();
    var overlay = document.getElementById('analyticsOverlay');
    if (!overlay) return;
    function setText(id, v) { var el = document.getElementById(id); if (el) el.textContent = v; }
    setText('analyticsTotal', d.totalGenerations || 0);
    setText('analyticsExports', d.totalExports || 0);
    setText('analyticsVoice', d.totalVoice || 0);
    var days = d.firstSeen ? Math.max(1, Math.ceil((Date.now() - d.firstSeen) / 86400000)) : 0;
    setText('analyticsDays', days);
    var typesEl = document.getElementById('analyticsTypes');
    if (typesEl) {
      var byType = d.byType || {};
      var total2 = Math.max(1, d.totalGenerations || 1);
      typesEl.innerHTML = [{ t:'game',i:'\uD83C\uDFAE' },{ t:'website',i:'\uD83C\uDF10' },{ t:'tool',i:'\uD83D\uDEE0' },{ t:'mobile',i:'\uD83D\uDCF1' }].map(function (r) {
        var cnt = byType[r.t] || 0;
        var pct = Math.round((cnt / total2) * 100);
        return '<div class="analytics-bar-row"><div class="analytics-bar-lbl">' + r.i + ' ' + r.t + '</div><div class="analytics-bar-track"><div class="analytics-bar-fill" style="width:' + pct + '%"></div></div><div class="analytics-bar-val">' + cnt + '</div></div>';
      }).join('');
    }
    var topModelEl = document.getElementById('analyticsTopModel');
    if (topModelEl) {
      var byModel = d.byModel || {};
      var topModel = Object.keys(byModel).sort(function (a, b) { return byModel[b] - byModel[a]; })[0] || '\u2014';
      topModelEl.textContent = topModel + (byModel[topModel] ? ' (' + byModel[topModel] + ' builds)' : '');
    }
    overlay.classList.add('active');
  };
  window.closeAnalyticsModal = function () {
    var overlay = document.getElementById('analyticsOverlay');
    if (overlay) overlay.classList.remove('active');
  };
  // Hook generation for analytics
  var _origRG_anal = window.runGeneration;
  if (_origRG_anal && !window.__analyticsHooked) {
    window.__analyticsHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      var result = await _origRG_anal(prompt, type, subtype, opts);
      if (lastHTML) trackAnalyticsEvent('generation', type);
      return result;
    };
  }
  trackAnalyticsEvent('session', 'open');
})();

/* ── spShowTab: ensure themes tab works ── */
(function patchSpShowTab() {
  var _orig = window.spShowTab;
  window.spShowTab = function (tab, btn) {
    if (_orig) _orig(tab, btn);
    if (tab === 'themes') {
      var saved = localStorage.getItem('batnxt_theme') || 'default';
      document.querySelectorAll('.sp-theme-btn').forEach(function (b) { b.classList.toggle('active', b.dataset.theme === saved); });
      var ci = document.getElementById('customAccentInput');
      if (ci) { var sc3 = localStorage.getItem('batnxt_custom_accent'); if (sc3) ci.value = sc3; }
      var cts = document.getElementById('cursorTrailSelect');
      if (cts && window.isCursorTrailEnabled) cts.value = window.isCursorTrailEnabled() ? 'enabled' : 'disabled';
    }
  };
})();

/* ── 5. QR CODE MOBILE PREVIEW ── */
window.showQRModal = function () {
  if (!lastHTML) { showToast('Generate something first to get a QR preview!', 'info'); return; }
  var overlay = document.getElementById('qrModalOverlay');
  if (!overlay) return;
  var key = 'batnxt_qr_' + Date.now();
  try { localStorage.setItem(key, lastHTML); } catch (e) {}
  var previewUrl = window.location.origin + window.location.pathname + '?qrPreview=' + encodeURIComponent(key);
  var qrImg = document.getElementById('qrCodeImg');
  if (qrImg) {
    qrImg.style.display = '';
    qrImg.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&qzone=1&data=' + encodeURIComponent(previewUrl);
    qrImg.onerror = function () {
      this.style.display = 'none';
      var fb = document.createElement('div');
      fb.style.cssText = 'width:200px;height:200px;display:flex;align-items:center;justify-content:center;font-size:0.75rem;color:var(--text-muted);text-align:center;padding:16px;border-radius:8px;background:var(--surface2);';
      fb.textContent = 'QR unavailable (offline). Copy the link below.';
      this.parentNode.insertBefore(fb, this.nextSibling);
    };
  }
  var urlEl = document.getElementById('qrPreviewUrl');
  if (urlEl) urlEl.textContent = previewUrl;
  overlay.classList.add('active');
  if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('qr_show', lastType);
};
window.closeQRModal = function () {
  var overlay = document.getElementById('qrModalOverlay');
  if (overlay) overlay.classList.remove('active');
};
window.copyQRUrl = function () {
  var urlEl = document.getElementById('qrPreviewUrl');
  if (!urlEl) return;
  var url = urlEl.textContent;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(function () { showToast('\uD83D\uDCCB Preview link copied!', 'success'); });
  } else { prompt('Copy this URL:', url); }
};
// On load: check for ?qrPreview= and restore the HTML
(function checkQRPreviewParam() {
  try {
    var params = new URLSearchParams(window.location.search);
    var key2 = params.get('qrPreview');
    if (!key2) return;
    var html = localStorage.getItem(decodeURIComponent(key2));
    if (!html) return;
    var attempts = 0;
    var chk = setInterval(function () {
      attempts++;
      if (typeof window.hcmOpenPreview === 'function') {
        clearInterval(chk);
        window.hcmOpenPreview(html, 'project');
        showToast('\uD83D\uDCF1 Mobile preview loaded from QR scan!', 'success');
      } else if (attempts > 40) clearInterval(chk);
    }, 250);
  } catch (e) {}
})();

/* ── 6. DRAG & DROP BUILDER ── */
(function initDragDropBuilder() {
  var ddbActive = false;
  window.toggleDDB = function () {
    ddbActive = !ddbActive;
    var btn = document.getElementById('ddbToggleBtn');
    var banner = document.getElementById('ddbBanner');
    if (btn) btn.classList.toggle('active', ddbActive);
    if (banner) banner.classList.toggle('active', ddbActive);
    if (!ddbActive) { showToast('Element selector off', 'info'); return; }
    showToast('\uD83D\uDDA5\uFE0F Click any element in the preview to edit it with AI', 'info');
    var iframe = document.getElementById('hwPreviewIframe') || document.getElementById('hcmPreviewIframe');
    if (!iframe) return;
    try {
      var doc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document);
      if (!doc || !doc.body) return;
      // Inject hover highlight
      var style = doc.createElement('style');
      style.id = '__ddb_style';
      style.textContent = '*{cursor:pointer!important}*:hover{outline:2px solid rgba(0,232,154,0.85)!important;outline-offset:1px;}';
      doc.head.appendChild(style);
      // Inject click-to-select handler
      var sc = doc.createElement('script');
      sc.id = '__ddb_sc';
      sc.textContent = '(function(){if(window.__ddb)return;window.__ddb=true;document.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();var el=e.target;var tag=el.tagName.toLowerCase();var cls=el.className&&typeof el.className==="string"?el.className.split(" ").filter(Boolean).slice(0,2).map(function(c){return"."+c;}).join(""):"";var txt=(el.innerText||"").trim().slice(0,50);window.parent.postMessage({type:"ddb_select",tag:tag,selector:tag+cls,text:txt},"*");},true);})();';
      doc.body.appendChild(sc);
    } catch (ex) { /* sandboxed iframe — inject blocked */ }
  };
  window.addEventListener('message', function (e) {
    if (!e.data || e.data.type !== 'ddb_select') return;
    var info = e.data;
    var label = info.tag + (info.text ? ' "' + info.text.slice(0, 28) + '"' : '');
    var prompt2 = 'Edit the ' + label + ' element: ';
    var inp = document.getElementById('hwFollowupInput') || document.getElementById('homeInput');
    if (inp) {
      inp.value = prompt2;
      inp.dispatchEvent(new Event('input'));
      inp.focus();
      inp.setSelectionRange(prompt2.length, prompt2.length);
    }
    showToast('\u270F\uFE0F Selected <' + info.selector + '> \u2014 complete the edit request below', 'info');
  });
})();

/* ── 7. VERSION HISTORY ── */
(function initVersionHistory() {
  var VK = 'batnxt_versions_v2';
  var MAX_VER = 12;
  function loadVers() { try { return JSON.parse(localStorage.getItem(VK) || '[]'); } catch (e) { return []; } }
  function saveVers(v) { try { localStorage.setItem(VK, JSON.stringify(v)); } catch (e) {} }

  window.saveVersion = function (label) {
    if (!lastHTML) { showToast('Nothing to save yet \u2014 generate something first.', 'info'); return; }
    var versions = loadVers();
    var ver = { id: 'v' + Date.now(), label: label || ('Snapshot ' + (versions.length + 1)), type: lastType || 'project', ts: Date.now(), html: lastHTML };
    versions.unshift(ver);
    if (versions.length > MAX_VER) versions.pop();
    saveVers(versions);
    showToast('\uD83D\uDCBE Saved: ' + ver.label, 'success');
    if (document.getElementById('versionsModalOverlay') && document.getElementById('versionsModalOverlay').classList.contains('active')) renderVersionsList();
  };
  window.showVersionsModal = function () {
    var overlay = document.getElementById('versionsModalOverlay');
    if (!overlay) return;
    renderVersionsList();
    overlay.classList.add('active');
  };
  window.closeVersionsModal = function () {
    var overlay = document.getElementById('versionsModalOverlay');
    if (overlay) overlay.classList.remove('active');
  };
  function renderVersionsList() {
    var list = document.getElementById('versionsList');
    if (!list) return;
    var versions = loadVers();
    if (versions.length === 0) {
      list.innerHTML = '<div class="versions-empty">No saved versions yet.<br>Click \u201CSave Current\u201D to capture a snapshot.</div>';
      return;
    }
    var icons = { game: '\uD83C\uDFAE', website: '\uD83C\uDF10', tool: '\uD83D\uDEE0', mobile: '\uD83D\uDCF1', project: '\uD83D\uDCC4' };
    list.innerHTML = versions.map(function (v) {
      var icon = icons[v.type] || '\uD83D\uDCC4';
      var date = new Date(v.ts).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      return '<div class="version-item">' +
        '<span class="version-item-icon">' + icon + '</span>' +
        '<div class="version-item-info"><div class="version-item-label">' + escapeHtml(v.label) + '</div>' +
        '<div class="version-item-meta">' + escapeHtml(v.type) + ' \u00B7 ' + date + '</div></div>' +
        '<div class="version-item-actions">' +
        '<button class="version-btn restore" onclick="restoreVersion(\'' + v.id + '\')">Restore</button>' +
        '<button class="version-btn" onclick="deleteVersion(\'' + v.id + '\')">\u2715</button>' +
        '</div></div>';
    }).join('');
  }
  window.restoreVersion = function (id) {
    var ver = loadVers().find(function (v) { return v.id === id; });
    if (!ver) return;
    lastHTML = ver.html; lastType = ver.type;
    var iframe = document.getElementById('hwPreviewIframe');
    if (iframe) iframe.srcdoc = withPreviewShim(lastHTML);
    if (typeof window.hcmOpenPreview === 'function') window.hcmOpenPreview(lastHTML, ver.type);
    var codeView = document.getElementById('hwCodeView');
    if (codeView) codeView.textContent = lastHTML;
    showToast('\u23EA Restored: ' + ver.label, 'success');
    window.closeVersionsModal();
  };
  window.deleteVersion = function (id) {
    saveVers(loadVers().filter(function (v) { return v.id !== id; }));
    renderVersionsList();
  };
  // Auto-save after successful generation
  var _origRG_ver = window.runGeneration;
  if (_origRG_ver && !window.__versionsHooked) {
    window.__versionsHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      var prevHTML = lastHTML;
      var result = await _origRG_ver(prompt, type, subtype, opts);
      if (lastHTML && lastHTML !== prevHTML) {
        var versions = loadVers();
        var label2 = 'Auto \u00B7 ' + (type || 'build') + ' \u2014 ' + (prompt || '').slice(0, 38);
        versions.unshift({ id: 'v' + Date.now(), label: label2, type: type || 'project', ts: Date.now(), html: lastHTML });
        if (versions.length > MAX_VER) versions.pop();
        saveVers(versions);
      }
      return result;
    };
  }
})();

/* ── 8. CUSTOM THEMES & DESIGN SYSTEM ── */
(function initCustomThemes() {
  var PALETTES = {
    default: { a: '#00e89a', ag: 'rgba(0,232,154,0.35)',   ad: 'rgba(0,232,154,0.1)'   },
    ocean:   { a: '#38bdf8', ag: 'rgba(56,189,248,0.35)',  ad: 'rgba(56,189,248,0.1)'  },
    purple:  { a: '#c084fc', ag: 'rgba(192,132,252,0.35)', ad: 'rgba(192,132,252,0.1)' },
    fire:    { a: '#fb923c', ag: 'rgba(251,146,60,0.35)',  ad: 'rgba(251,146,60,0.1)'  },
    rose:    { a: '#fb7185', ag: 'rgba(251,113,133,0.35)', ad: 'rgba(251,113,133,0.1)' },
    gold:    { a: '#fbbf24', ag: 'rgba(251,191,36,0.35)',  ad: 'rgba(251,191,36,0.1)'  },
  };
  function setPalette(p) {
    document.documentElement.style.setProperty('--accent', p.a);
    document.documentElement.style.setProperty('--accent-glow', p.ag);
    document.documentElement.style.setProperty('--accent-dim', p.ad);
  }
  window.applyTheme = function (name) {
    var p = PALETTES[name];
    if (!p) return;
    setPalette(p);
    localStorage.setItem('batnxt_theme', name);
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.toggle('active', btn.dataset.theme === name); });
    showToast('\uD83C\uDFA8 Theme: ' + name, 'success');
  };
  window.applyCustomAccent = function (hex) {
    if (!hex || hex.length < 7) return;
    var r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
    setPalette({ a: hex, ag: 'rgba('+r+','+g+','+b+',0.35)', ad: 'rgba('+r+','+g+','+b+',0.1)' });
    localStorage.setItem('batnxt_theme', 'custom');
    localStorage.setItem('batnxt_custom_accent', hex);
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.remove('active'); });
  };
  window._selectedDesignSystem = '';
  window.getDesignSystemNote = function () {
    var ds = localStorage.getItem('batnxt_design_system') || '';
    var notes = { material:'Use Material Design 3 principles: elevation, ripple, rounded corners.', ant:'Follow Ant Design: 8px grid, blue primary (#1677ff), clear hierarchy.', fluent:'Apply Microsoft Fluent 2: neutral backgrounds, subtle shadows, smooth motion.', ios:'Follow Apple HIG: SF Pro typography, iOS 17 components, blur backgrounds.', bootstrap:'Use Bootstrap 5: 12-column grid, btn/card/badge components, utility spacing.' };
    return notes[ds] || '';
  };
  // Hook showSettingsModal to sync preset states
  var _origSM = window.showSettingsModal;
  window.showSettingsModal = function () {
    if (_origSM) _origSM();
    var saved = localStorage.getItem('batnxt_theme') || 'default';
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.toggle('active', btn.dataset.theme === saved); });
    var ci = document.getElementById('customAccentInput');
    if (ci) { var sc2 = localStorage.getItem('batnxt_custom_accent'); if (sc2) ci.value = sc2; }
    var dsSel = document.getElementById('designSystemSelect');
    if (dsSel) dsSel.value = localStorage.getItem('batnxt_design_system') || '';
  };
  // Save design system on change
  var dsSel2 = document.getElementById('designSystemSelect');
  if (dsSel2) dsSel2.addEventListener('change', function () { localStorage.setItem('batnxt_design_system', this.value); showToast('\u2705 Design system: ' + (this.value || 'none'), 'success'); });
  // Restore saved theme on load
  (function () {
    var saved = localStorage.getItem('batnxt_theme');
    if (!saved || saved === 'default') return;
    if (PALETTES[saved]) { setPalette(PALETTES[saved]); return; }
    if (saved === 'custom') { var c = localStorage.getItem('batnxt_custom_accent'); if (c) window.applyCustomAccent(c); }
  })();
})();

/* ── 9. ANALYTICS DASHBOARD ── */
(function initAnalytics() {
  var AK = 'batnxt_analytics_v2';
  function loadA() { try { return JSON.parse(localStorage.getItem(AK) || '{}'); } catch (e) { return {}; } }
  function saveA(d) { try { localStorage.setItem(AK, JSON.stringify(d)); } catch (e) {} }

  window.trackAnalyticsEvent = function (type, value) {
    var d = loadA();
    d.firstSeen = d.firstSeen || Date.now();
    d.lastSeen = Date.now();
    if (type === 'generation') {
      d.totalGenerations = (d.totalGenerations || 0) + 1;
      d.byType = d.byType || {};
      d.byType[value] = (d.byType[value] || 0) + 1;
      var model = sessionStorage.getItem('batlab_model') || 'BAT 1.2 Core';
      d.byModel = d.byModel || {};
      d.byModel[model] = (d.byModel[model] || 0) + 1;
    } else if (type === 'export') {
      d.totalExports = (d.totalExports || 0) + 1;
    } else if (type === 'voice') {
      d.totalVoice = (d.totalVoice || 0) + 1;
    } else if (type === 'qr_show') {
      d.totalQR = (d.totalQR || 0) + 1;
    }
    saveA(d);
  };

  window.showAnalyticsModal = function () {
    var d = loadA();
    var overlay = document.getElementById('analyticsOverlay');
    if (!overlay) return;
    function setText(id, v) { var el = document.getElementById(id); if (el) el.textContent = v; }
    setText('analyticsTotal', d.totalGenerations || 0);
    setText('analyticsExports', d.totalExports || 0);
    setText('analyticsVoice', d.totalVoice || 0);
    var days = d.firstSeen ? Math.max(1, Math.ceil((Date.now() - d.firstSeen) / 86400000)) : 0;
    setText('analyticsDays', days);
    var typesEl = document.getElementById('analyticsTypes');
    if (typesEl) {
      var byType = d.byType || {};
      var total2 = Math.max(1, d.totalGenerations || 1);
      typesEl.innerHTML = [{ t:'game',i:'\uD83C\uDFAE' },{ t:'website',i:'\uD83C\uDF10' },{ t:'tool',i:'\uD83D\uDEE0' },{ t:'mobile',i:'\uD83D\uDCF1' }].map(function (r) {
        var cnt = byType[r.t] || 0;
        var pct = Math.round((cnt / total2) * 100);
        return '<div class="analytics-bar-row"><div class="analytics-bar-lbl">' + r.i + ' ' + r.t + '</div><div class="analytics-bar-track"><div class="analytics-bar-fill" style="width:' + pct + '%"></div></div><div class="analytics-bar-val">' + cnt + '</div></div>';
      }).join('');
    }
    var topModelEl = document.getElementById('analyticsTopModel');
    if (topModelEl) {
      var byModel = d.byModel || {};
      var topModel = Object.keys(byModel).sort(function (a, b) { return byModel[b] - byModel[a]; })[0] || '\u2014';
      topModelEl.textContent = topModel + (byModel[topModel] ? ' (' + byModel[topModel] + ' builds)' : '');
    }
    overlay.classList.add('active');
  };
  window.closeAnalyticsModal = function () {
    var overlay = document.getElementById('analyticsOverlay');
    if (overlay) overlay.classList.remove('active');
  };
  // Hook generation for analytics
  var _origRG_anal = window.runGeneration;
  if (_origRG_anal && !window.__analyticsHooked) {
    window.__analyticsHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      var result = await _origRG_anal(prompt, type, subtype, opts);
      if (lastHTML) trackAnalyticsEvent('generation', type);
      return result;
    };
  }
  trackAnalyticsEvent('session', 'open');
})();

/* ── spShowTab: ensure themes tab works ── */
(function patchSpShowTab() {
  var _orig = window.spShowTab;
  window.spShowTab = function (tab, btn) {
    if (_orig) _orig(tab, btn);
    if (tab === 'themes') {
      var saved = localStorage.getItem('batnxt_theme') || 'default';
      document.querySelectorAll('.sp-theme-btn').forEach(function (b) { b.classList.toggle('active', b.dataset.theme === saved); });
      var ci = document.getElementById('customAccentInput');
      if (ci) { var sc3 = localStorage.getItem('batnxt_custom_accent'); if (sc3) ci.value = sc3; }
      var cts = document.getElementById('cursorTrailSelect');
      if (cts && window.isCursorTrailEnabled) cts.value = window.isCursorTrailEnabled() ? 'enabled' : 'disabled';
    }
  };
})();

/* ── 5. QR CODE MOBILE PREVIEW ── */
window.showQRModal = function () {
  if (!lastHTML) { showToast('Generate something first to get a QR preview!', 'info'); return; }
  var overlay = document.getElementById('qrModalOverlay');
  if (!overlay) return;
  var key = 'batnxt_qr_' + Date.now();
  try { localStorage.setItem(key, lastHTML); } catch (e) {}
  var previewUrl = window.location.origin + window.location.pathname + '?qrPreview=' + encodeURIComponent(key);
  var qrImg = document.getElementById('qrCodeImg');
  if (qrImg) {
    qrImg.style.display = '';
    qrImg.src = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&qzone=1&data=' + encodeURIComponent(previewUrl);
    qrImg.onerror = function () {
      this.style.display = 'none';
      var fb = document.createElement('div');
      fb.style.cssText = 'width:200px;height:200px;display:flex;align-items:center;justify-content:center;font-size:0.75rem;color:var(--text-muted);text-align:center;padding:16px;border-radius:8px;background:var(--surface2);';
      fb.textContent = 'QR unavailable (offline). Copy the link below.';
      this.parentNode.insertBefore(fb, this.nextSibling);
    };
  }
  var urlEl = document.getElementById('qrPreviewUrl');
  if (urlEl) urlEl.textContent = previewUrl;
  overlay.classList.add('active');
  if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('qr_show', lastType);
};
window.closeQRModal = function () {
  var overlay = document.getElementById('qrModalOverlay');
  if (overlay) overlay.classList.remove('active');
};
window.copyQRUrl = function () {
  var urlEl = document.getElementById('qrPreviewUrl');
  if (!urlEl) return;
  var url = urlEl.textContent;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(url).then(function () { showToast('\uD83D\uDCCB Preview link copied!', 'success'); });
  } else { prompt('Copy this URL:', url); }
};
// On load: check for ?qrPreview= and restore the HTML
(function checkQRPreviewParam() {
  try {
    var params = new URLSearchParams(window.location.search);
    var key2 = params.get('qrPreview');
    if (!key2) return;
    var html = localStorage.getItem(decodeURIComponent(key2));
    if (!html) return;
    var attempts = 0;
    var chk = setInterval(function () {
      attempts++;
      if (typeof window.hcmOpenPreview === 'function') {
        clearInterval(chk);
        window.hcmOpenPreview(html, 'project');
        showToast('\uD83D\uDCF1 Mobile preview loaded from QR scan!', 'success');
      } else if (attempts > 40) clearInterval(chk);
    }, 250);
  } catch (e) {}
})();

/* ── 6. DRAG & DROP BUILDER ── */
(function initDragDropBuilder() {
  var ddbActive = false;
  window.toggleDDB = function () {
    ddbActive = !ddbActive;
    var btn = document.getElementById('ddbToggleBtn');
    var banner = document.getElementById('ddbBanner');
    if (btn) btn.classList.toggle('active', ddbActive);
    if (banner) banner.classList.toggle('active', ddbActive);
    if (!ddbActive) { showToast('Element selector off', 'info'); return; }
    showToast('\uD83D\uDDA5\uFE0F Click any element in the preview to edit it with AI', 'info');
    var iframe = document.getElementById('hwPreviewIframe') || document.getElementById('hcmPreviewIframe');
    if (!iframe) return;
    try {
      var doc = iframe.contentDocument || (iframe.contentWindow && iframe.contentWindow.document);
      if (!doc || !doc.body) return;
      // Inject hover highlight
      var style = doc.createElement('style');
      style.id = '__ddb_style';
      style.textContent = '*{cursor:pointer!important}*:hover{outline:2px solid rgba(0,232,154,0.85)!important;outline-offset:1px;}';
      doc.head.appendChild(style);
      // Inject click-to-select handler
      var sc = doc.createElement('script');
      sc.id = '__ddb_sc';
      sc.textContent = '(function(){if(window.__ddb)return;window.__ddb=true;document.addEventListener("click",function(e){e.preventDefault();e.stopPropagation();var el=e.target;var tag=el.tagName.toLowerCase();var cls=el.className&&typeof el.className==="string"?el.className.split(" ").filter(Boolean).slice(0,2).map(function(c){return"."+c;}).join(""):"";var txt=(el.innerText||"").trim().slice(0,50);window.parent.postMessage({type:"ddb_select",tag:tag,selector:tag+cls,text:txt},"*");},true);})();';
      doc.body.appendChild(sc);
    } catch (ex) { /* sandboxed iframe — inject blocked */ }
  };
  window.addEventListener('message', function (e) {
    if (!e.data || e.data.type !== 'ddb_select') return;
    var info = e.data;
    var label = info.tag + (info.text ? ' "' + info.text.slice(0, 28) + '"' : '');
    var prompt2 = 'Edit the ' + label + ' element: ';
    var inp = document.getElementById('hwFollowupInput') || document.getElementById('homeInput');
    if (inp) {
      inp.value = prompt2;
      inp.dispatchEvent(new Event('input'));
      inp.focus();
      inp.setSelectionRange(prompt2.length, prompt2.length);
    }
    showToast('\u270F\uFE0F Selected <' + info.selector + '> \u2014 complete the edit request below', 'info');
  });
})();

/* ── 7. VERSION HISTORY ── */
(function initVersionHistory() {
  var VK = 'batnxt_versions_v2';
  var MAX_VER = 12;
  function loadVers() { try { return JSON.parse(localStorage.getItem(VK) || '[]'); } catch (e) { return []; } }
  function saveVers(v) { try { localStorage.setItem(VK, JSON.stringify(v)); } catch (e) {} }

  window.saveVersion = function (label) {
    if (!lastHTML) { showToast('Nothing to save yet \u2014 generate something first.', 'info'); return; }
    var versions = loadVers();
    var ver = { id: 'v' + Date.now(), label: label || ('Snapshot ' + (versions.length + 1)), type: lastType || 'project', ts: Date.now(), html: lastHTML };
    versions.unshift(ver);
    if (versions.length > MAX_VER) versions.pop();
    saveVers(versions);
    showToast('\uD83D\uDCBE Saved: ' + ver.label, 'success');
    if (document.getElementById('versionsModalOverlay') && document.getElementById('versionsModalOverlay').classList.contains('active')) renderVersionsList();
  };
  window.showVersionsModal = function () {
    var overlay = document.getElementById('versionsModalOverlay');
    if (!overlay) return;
    renderVersionsList();
    overlay.classList.add('active');
  };
  window.closeVersionsModal = function () {
    var overlay = document.getElementById('versionsModalOverlay');
    if (overlay) overlay.classList.remove('active');
  };
  function renderVersionsList() {
    var list = document.getElementById('versionsList');
    if (!list) return;
    var versions = loadVers();
    if (versions.length === 0) {
      list.innerHTML = '<div class="versions-empty">No saved versions yet.<br>Click \u201CSave Current\u201D to capture a snapshot.</div>';
      return;
    }
    var icons = { game: '\uD83C\uDFAE', website: '\uD83C\uDF10', tool: '\uD83D\uDEE0', mobile: '\uD83D\uDCF1', project: '\uD83D\uDCC4' };
    list.innerHTML = versions.map(function (v) {
      var icon = icons[v.type] || '\uD83D\uDCC4';
      var date = new Date(v.ts).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      return '<div class="version-item">' +
        '<span class="version-item-icon">' + icon + '</span>' +
        '<div class="version-item-info"><div class="version-item-label">' + escapeHtml(v.label) + '</div>' +
        '<div class="version-item-meta">' + escapeHtml(v.type) + ' \u00B7 ' + date + '</div></div>' +
        '<div class="version-item-actions">' +
        '<button class="version-btn restore" onclick="restoreVersion(\'' + v.id + '\')">Restore</button>' +
        '<button class="version-btn" onclick="deleteVersion(\'' + v.id + '\')">\u2715</button>' +
        '</div></div>';
    }).join('');
  }
  window.restoreVersion = function (id) {
    var ver = loadVers().find(function (v) { return v.id === id; });
    if (!ver) return;
    lastHTML = ver.html; lastType = ver.type;
    var iframe = document.getElementById('hwPreviewIframe');
    if (iframe) iframe.srcdoc = withPreviewShim(lastHTML);
    if (typeof window.hcmOpenPreview === 'function') window.hcmOpenPreview(lastHTML, ver.type);
    var codeView = document.getElementById('hwCodeView');
    if (codeView) codeView.textContent = lastHTML;
    showToast('\u23EA Restored: ' + ver.label, 'success');
    window.closeVersionsModal();
  };
  window.deleteVersion = function (id) {
    saveVers(loadVers().filter(function (v) { return v.id !== id; }));
    renderVersionsList();
  };
  // Auto-save after successful generation
  var _origRG_ver = window.runGeneration;
  if (_origRG_ver && !window.__versionsHooked) {
    window.__versionsHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      var prevHTML = lastHTML;
      var result = await _origRG_ver(prompt, type, subtype, opts);
      if (lastHTML && lastHTML !== prevHTML) {
        var versions = loadVers();
        var label2 = 'Auto \u00B7 ' + (type || 'build') + ' \u2014 ' + (prompt || '').slice(0, 38);
        versions.unshift({ id: 'v' + Date.now(), label: label2, type: type || 'project', ts: Date.now(), html: lastHTML });
        if (versions.length > MAX_VER) versions.pop();
        saveVers(versions);
      }
      return result;
    };
  }
})();

/* ── 8. CUSTOM THEMES & DESIGN SYSTEM ── */
(function initCustomThemes() {
  var PALETTES = {
    default: { a: '#00e89a', ag: 'rgba(0,232,154,0.35)',   ad: 'rgba(0,232,154,0.1)'   },
    ocean:   { a: '#38bdf8', ag: 'rgba(56,189,248,0.35)',  ad: 'rgba(56,189,248,0.1)'  },
    purple:  { a: '#c084fc', ag: 'rgba(192,132,252,0.35)', ad: 'rgba(192,132,252,0.1)' },
    fire:    { a: '#fb923c', ag: 'rgba(251,146,60,0.35)',  ad: 'rgba(251,146,60,0.1)'  },
    rose:    { a: '#fb7185', ag: 'rgba(251,113,133,0.35)', ad: 'rgba(251,113,133,0.1)' },
    gold:    { a: '#fbbf24', ag: 'rgba(251,191,36,0.35)',  ad: 'rgba(251,191,36,0.1)'  },
  };
  function setPalette(p) {
    document.documentElement.style.setProperty('--accent', p.a);
    document.documentElement.style.setProperty('--accent-glow', p.ag);
    document.documentElement.style.setProperty('--accent-dim', p.ad);
  }
  window.applyTheme = function (name) {
    var p = PALETTES[name];
    if (!p) return;
    setPalette(p);
    localStorage.setItem('batnxt_theme', name);
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.toggle('active', btn.dataset.theme === name); });
    showToast('\uD83C\uDFA8 Theme: ' + name, 'success');
  };
  window.applyCustomAccent = function (hex) {
    if (!hex || hex.length < 7) return;
    var r = parseInt(hex.slice(1,3),16), g = parseInt(hex.slice(3,5),16), b = parseInt(hex.slice(5,7),16);
    setPalette({ a: hex, ag: 'rgba('+r+','+g+','+b+',0.35)', ad: 'rgba('+r+','+g+','+b+',0.1)' });
    localStorage.setItem('batnxt_theme', 'custom');
    localStorage.setItem('batnxt_custom_accent', hex);
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.remove('active'); });
  };
  window._selectedDesignSystem = '';
  window.getDesignSystemNote = function () {
    var ds = localStorage.getItem('batnxt_design_system') || '';
    var notes = { material:'Use Material Design 3 principles: elevation, ripple, rounded corners.', ant:'Follow Ant Design: 8px grid, blue primary (#1677ff), clear hierarchy.', fluent:'Apply Microsoft Fluent 2: neutral backgrounds, subtle shadows, smooth motion.', ios:'Follow Apple HIG: SF Pro typography, iOS 17 components, blur backgrounds.', bootstrap:'Use Bootstrap 5: 12-column grid, btn/card/badge components, utility spacing.' };
    return notes[ds] || '';
  };
  // Hook showSettingsModal to sync preset states
  var _origSM = window.showSettingsModal;
  window.showSettingsModal = function () {
    if (_origSM) _origSM();
    var saved = localStorage.getItem('batnxt_theme') || 'default';
    document.querySelectorAll('.sp-theme-btn').forEach(function (btn) { btn.classList.toggle('active', btn.dataset.theme === saved); });
    var ci = document.getElementById('customAccentInput');
    if (ci) { var sc2 = localStorage.getItem('batnxt_custom_accent'); if (sc2) ci.value = sc2; }
    var dsSel = document.getElementById('designSystemSelect');
    if (dsSel) dsSel.value = localStorage.getItem('batnxt_design_system') || '';
  };
  // Save design system on change
  var dsSel2 = document.getElementById('designSystemSelect');
  if (dsSel2) dsSel2.addEventListener('change', function () { localStorage.setItem('batnxt_design_system', this.value); showToast('\u2705 Design system: ' + (this.value || 'none'), 'success'); });
  // Restore saved theme on load
  (function () {
    var saved = localStorage.getItem('batnxt_theme');
    if (!saved || saved === 'default') return;
    if (PALETTES[saved]) { setPalette(PALETTES[saved]); return; }
    if (saved === 'custom') { var c = localStorage.getItem('batnxt_custom_accent'); if (c) window.applyCustomAccent(c); }
  })();
})();

/* ── 9. ANALYTICS DASHBOARD ── */
(function initAnalytics() {
  var AK = 'batnxt_analytics_v2';
  function loadA() { try { return JSON.parse(localStorage.getItem(AK) || '{}'); } catch (e) { return {}; } }
  function saveA(d) { try { localStorage.setItem(AK, JSON.stringify(d)); } catch (e) {} }

  window.trackAnalyticsEvent = function (type, value) {
    var d = loadA();
    d.firstSeen = d.firstSeen || Date.now();
    d.lastSeen = Date.now();
    if (type === 'generation') {
      d.totalGenerations = (d.totalGenerations || 0) + 1;
      d.byType = d.byType || {};
      d.byType[value] = (d.byType[value] || 0) + 1;
      var model = sessionStorage.getItem('batlab_model') || 'BAT 1.2 Core';
      d.byModel = d.byModel || {};
      d.byModel[model] = (d.byModel[model] || 0) + 1;
    } else if (type === 'export') {
      d.totalExports = (d.totalExports || 0) + 1;
    } else if (type === 'voice') {
      d.totalVoice = (d.totalVoice || 0) + 1;
    } else if (type === 'qr_show') {
      d.totalQR = (d.totalQR || 0) + 1;
    }
    saveA(d);
  };

  window.showAnalyticsModal = function () {
    var d = loadA();
    var overlay = document.getElementById('analyticsOverlay');
    if (!overlay) return;
    function setText(id, v) { var el = document.getElementById(id); if (el) el.textContent = v; }
    setText('analyticsTotal', d.totalGenerations || 0);
    setText('analyticsExports', d.totalExports || 0);
    setText('analyticsVoice', d.totalVoice || 0);
    var days = d.firstSeen ? Math.max(1, Math.ceil((Date.now() - d.firstSeen) / 86400000)) : 0;
    setText('analyticsDays', days);
    var typesEl = document.getElementById('analyticsTypes');
    if (typesEl) {
      var byType = d.byType || {};
      var total2 = Math.max(1, d.totalGenerations || 1);
      typesEl.innerHTML = [{ t:'game',i:'\uD83C\uDFAE' },{ t:'website',i:'\uD83C\uDF10' },{ t:'tool',i:'\uD83D\uDEE0' },{ t:'mobile',i:'\uD83D\uDCF1' }].map(function (r) {
        var cnt = byType[r.t] || 0;
        var pct = Math.round((cnt / total2) * 100);
        return '<div class="analytics-bar-row"><div class="analytics-bar-lbl">' + r.i + ' ' + r.t + '</div><div class="analytics-bar-track"><div class="analytics-bar-fill" style="width:' + pct + '%"></div></div><div class="analytics-bar-val">' + cnt + '</div></div>';
      }).join('');
    }
    var topModelEl = document.getElementById('analyticsTopModel');
    if (topModelEl) {
      var byModel = d.byModel || {};
      var topModel = Object.keys(byModel).sort(function (a, b) { return byModel[b] - byModel[a]; })[0] || '\u2014';
      topModelEl.textContent = topModel + (byModel[topModel] ? ' (' + byModel[topModel] + ' builds)' : '');
    }
    overlay.classList.add('active');
  };
  window.closeAnalyticsModal = function () {
    var overlay = document.getElementById('analyticsOverlay');
    if (overlay) overlay.classList.remove('active');
  };
  // Hook generation for analytics
  var _origRG_anal = window.runGeneration;
  if (_origRG_anal && !window.__analyticsHooked) {
    window.__analyticsHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      var result = await _origRG_anal(prompt, type, subtype, opts);
      if (lastHTML) trackAnalyticsEvent('generation', type);
      return result;
    };
  }
  trackAnalyticsEvent('session', 'open');
})();

/* ── spShowTab: ensure themes tab works ── */
(function patchSpShowTab() {
  var _orig = window.spShowTab;
  window.spShowTab = function (tab, btn) {
    if (_orig) _orig(tab, btn);
    if (tab === 'themes') {
      var saved = localStorage.getItem('batnxt_theme') || 'default';
      document.querySelectorAll('.sp-theme-btn').forEach(function (b) { b.classList.toggle('active', b.dataset.theme === saved); });
      var ci = document.getElementById('customAccentInput');
      if (ci) { var sc3 = localStorage.getItem('batnxt_custom_accent'); if (sc3) ci.value = sc3; }
      var cts = document.getElementById('cursorTrailSelect');
      if (cts && window.isCursorTrailEnabled) cts.value = window.isCursorTrailEnabled() ? 'enabled' : 'disabled';
    }
  };
})();

/* ── Chats view (full list, search + bulk selection) ──
   Uses its own fetch (chatsViewSessions), separate from the sidebar's
   capped-at-20 homeChatSessions cache, so the full history is browsable here. */
async function loadChatsViewSessions() {
  if (!currentUser) { chatsViewSessions = []; renderChatsList(); return; }
  try {
    const { data, error } = await supabase.from('chat_sessions')
      .select('id, title, updated_at, is_pinned, is_read')
      .eq('user_id', currentUser.id)
      .order('updated_at', { ascending: false });
    if (error) throw error;
    chatsViewSessions = (data || []).map(d => ({
      id: d.id, title: d.title,
      updatedAt: d.updated_at ? new Date(d.updated_at).getTime() : Date.now(),
      isPinned: !!d.is_pinned, isRead: d.is_read !== false
    }));
  } catch(e) { console.error('Failed to load chats view sessions:', e); chatsViewSessions = []; }
  renderChatsList();
}

window.searchChatsView = function(query) {
  chatsSearchQuery = (query || '').toLowerCase().trim();
  renderChatsList();
};

window.enterChatsSelectionMode = function(initialId) {
  chatsSelectionMode = true;
  chatsSelectedIds = new Set(initialId ? [initialId] : []);
  renderChatsList();
};
window.toggleChatsSelected = function(id, checked) {
  if (checked) chatsSelectedIds.add(id); else chatsSelectedIds.delete(id);
  renderChatsList();
};
window.selectAllChats = function() {
  chatsViewSessions.forEach(s => chatsSelectedIds.add(s.id));
  renderChatsList();
};
window.cancelChatsSelection = function() {
  chatsSelectionMode = false; chatsSelectedIds.clear();
  renderChatsList();
};
window.deleteSelectedChats = async function() {
  const ids = Array.from(chatsSelectedIds);
  if (!ids.length || !await window.showConfirmDialog(`Delete ${ids.length} conversation(s)?`, 'This cannot be undone.', 'Delete')) return;
  try { await supabase.from('chat_sessions').delete().in('id', ids); }
  catch(e) { console.error('Failed to delete selected chats:', e); }
  homeChatSessions = homeChatSessions.filter(s => !ids.includes(s.id));
  if (ids.includes(homeConvSessionId)) { homeConvSessionId = null; homeConvHistory = []; homeConvActive = false; }
  renderHomeChatHistory();
  chatsSelectionMode = false; chatsSelectedIds.clear();
  await loadChatsViewSessions();
};

function renderChatsList() {
  const list = document.getElementById('chatsList');
  const empty = document.getElementById('chatsEmpty');
  const toolbar = document.getElementById('chatsSelectToolbar');
  const header = document.getElementById('chatsHeaderDefault');
  if (!list || !empty) return;
  if (toolbar) toolbar.style.display = chatsSelectionMode ? 'flex' : 'none';
  if (header) header.style.display = chatsSelectionMode ? 'none' : 'flex';
  if (chatsSelectionMode) {
    const countEl = document.getElementById('chatsSelectedCount');
    if (countEl) countEl.textContent = chatsSelectedIds.size + ' selected';
  }
  const filtered = chatsViewSessions.filter(s => !chatsSearchQuery || (s.title || '').toLowerCase().includes(chatsSearchQuery));
  if (filtered.length === 0) { empty.style.display = 'block'; list.innerHTML = ''; return; }
  empty.style.display = 'none';
  list.innerHTML = filtered.map(s => {
    const title = escapeHtml(s.title || 'Untitled');
    const checked = chatsSelectedIds.has(s.id) ? 'checked' : '';
    const showUnread = s.isRead === false;
    return `<div class="sidebar-history-item${s.isPinned ? ' pinned-chat' : ''}">
      ${chatsSelectionMode ? `<input type="checkbox" class="chats-row-checkbox" ${checked} onchange="toggleChatsSelected('${s.id}', this.checked)">` : ''}
      <button class="shi-main" onclick="loadHomeChatSession('${s.id}')">
        <span class="shi-title">${s.isPinned ? '📌 ' : ''}${title}</span>
        ${showUnread ? '<span class="shi-unread-dot" title="Unread"></span>' : ''}
      </button>
      <div class="shi-actions">
        <button class="shi-dots-btn" onclick="event.stopPropagation();showHistoryMenu(event,'${s.id}','chatsview')" title="More options">⋮</button>
      </div>
    </div>`;
  }).join('');
}

/* ── Library view (grid of successfully-analyzed image attachments) ──
   Metadata is read directly via supabase-js (RLS owner-only SELECT, same
   pattern as Chats/chat_sessions above). Image bytes are fetched one-by-one,
   authenticated, through the gateway's GET /library/image/:id route (see
   worker/gateway.js) since the R2 bucket itself is not browser-accessible. */
async function fetchLibraryImageBlobUrl(id) {
  const token = await getAccessToken();
  if (!token) return null;
  try {
    const res = await fetch(GATEWAY_URL + '/library/image/' + id, {
      headers: { Authorization: 'Bearer ' + token },
    });
    if (!res.ok) return null;
    return URL.createObjectURL(await res.blob());
  } catch (e) {
    return null;
  }
}

window.openLibraryPreview = function (url) {
  const overlay = document.getElementById('libraryPreviewOverlay');
  const img = document.getElementById('libraryPreviewImg');
  if (!overlay || !img) return;
  img.src = url;
  overlay.classList.add('active');
};
window.closeLibraryPreview = function () {
  const overlay = document.getElementById('libraryPreviewOverlay');
  if (overlay) overlay.classList.remove('active');
};

/* ── Library view: paginated, lazy-loaded gallery with Grid/List modes ──
   Rows are read directly via supabase-js (RLS owner-only SELECT) in pages of
   LIB_PAGE_INITIAL then LIB_PAGE_MORE per bottom-scroll. Each page's image
   bytes are fetched through the authenticated GET /library/image/:id route,
   parallel-capped at LIB_BLOB_CONCURRENCY, with pulsing skeletons swapped for
   real thumbnails as each blob resolves. Search/filter reset the query (they
   run server-side against the whole library, not just the loaded page) — a
   `seq` counter fences stale in-flight loads after a reset. Note: server-side
   name search matches `file_name` only, so older rows (file_name NULL, shown
   with a synthesized display name) never surface in text search — by design. */
var LIB_PAGE_INITIAL = 20;
var LIB_PAGE_MORE = 10;
var LIB_BLOB_CONCURRENCY = 6;
var libState = {
  view: 'grid',    // 'grid' | 'list'
  filter: 'all',   // 'all' | 'images'
  search: '',
  rows: [],        // accumulated row metadata (+ _node/_url/_failed/_loading)
  offset: 0,
  loading: false,
  done: false,
  observer: null,
  sentinel: null,
  seq: 0,          // bumped on every reset to fence stale async loads
};
var _libSearchTimer = null;

function libFormatBytes(n) {
  if (n == null || isNaN(n)) return '—';
  if (n < 1024) return n + ' B';
  if (n < 1048576) return Math.round(n / 1024) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}
function libRelDate(ts) {
  var locale = document.documentElement.getAttribute('lang') || 'en';
  try { return new Date(ts).toLocaleDateString(locale, { day: 'numeric', month: 'short', year: 'numeric' }); }
  catch (e) { return new Date(ts).toLocaleDateString(); }
}
function libExtFromMime(ct) {
  switch ((ct || '').toLowerCase()) {
    case 'image/png': return 'png';
    case 'image/jpeg': case 'image/jpg': return 'jpg';
    case 'image/webp': return 'webp';
    case 'image/gif': return 'gif';
    default: return '';
  }
}
function libDisplayName(row) {
  if (row.file_name && String(row.file_name).trim()) return String(row.file_name);
  var ext = libExtFromMime(row.content_type);
  var stamp = '';
  try { stamp = new Date(row.created_at).toLocaleDateString('en-CA'); } catch (e) {}
  return 'Image ' + stamp + (ext ? '.' + ext : '');
}
function libSanitizeSearch(s) {
  // Drop PostgREST-significant chars so the ilike filter can't be broken/injected.
  return (s || '').replace(/[%,()]/g, ' ').trim();
}

/* Fire `worker` over `items` with at most `limit` in flight at once. */
function runCapped(items, limit, worker) {
  return new Promise(function (resolve) {
    var idx = 0, active = 0, done = 0, n = items.length;
    if (n === 0) { resolve(); return; }
    function pump() {
      while (active < limit && idx < n) {
        var it = items[idx++];
        active++;
        Promise.resolve(worker(it)).catch(function () {}).then(function () {
          active--; done++;
          if (done >= n) resolve(); else pump();
        });
      }
    }
    pump();
  });
}

/* ── node builders ── */
function libMakeGridSkel() {
  var d = document.createElement('div');
  d.className = 'lib-skel-tile';
  return d;
}
function libMakeGridImg(row) {
  var img = document.createElement('img');
  img.src = row._url;
  img.loading = 'lazy';
  img.alt = libDisplayName(row);
  img.onclick = function () { openLibraryPreview(row._url); };
  return img;
}
function libMakeListHeader() {
  var h = document.createElement('div');
  h.className = 'lib-list-headrow';
  var n = document.createElement('span'); n.textContent = BatLang.t('sp.library.colName') || 'Name';
  var m = document.createElement('span'); m.className = 'lib-col-modified'; m.textContent = BatLang.t('sp.library.colModified') || 'Modified';
  var s = document.createElement('span'); s.textContent = BatLang.t('sp.library.colSize') || 'Size';
  h.appendChild(n); h.appendChild(m); h.appendChild(s);
  return h;
}
function libMakeListSkelRow() {
  var row = document.createElement('div');
  row.className = 'lib-row';
  var name = document.createElement('div');
  name.className = 'lib-row-name';
  var thumb = document.createElement('div');
  thumb.className = 'lib-row-thumb lib-skel-thumb';
  var bar = document.createElement('div'); bar.className = 'lib-skel-bar'; bar.style.width = '60%';
  name.appendChild(thumb); name.appendChild(bar);
  var mod = document.createElement('div'); mod.className = 'lib-skel-bar lib-col-modified'; mod.style.width = '70%';
  var size = document.createElement('div'); size.className = 'lib-skel-bar'; size.style.width = '50%';
  row.appendChild(name); row.appendChild(mod); row.appendChild(size);
  return row;
}
function libMakeListRow(row) {
  var el = document.createElement('div');
  el.className = 'lib-row';
  var name = document.createElement('div');
  name.className = 'lib-row-name';
  var thumb = document.createElement('img');
  thumb.className = 'lib-row-thumb';
  if (!row._url) thumb.classList.add('lib-skel-thumb'); else thumb.src = row._url;
  var fname = document.createElement('div');
  fname.className = 'lib-row-fname';
  fname.textContent = libDisplayName(row);
  fname.title = libDisplayName(row);
  name.appendChild(thumb); name.appendChild(fname);
  var mod = document.createElement('div'); mod.className = 'lib-row-meta lib-col-modified'; mod.textContent = libRelDate(row.created_at);
  var size = document.createElement('div'); size.className = 'lib-row-meta'; size.textContent = libFormatBytes(row.size_bytes);
  el.appendChild(name); el.appendChild(mod); el.appendChild(size);
  if (row._url) el.onclick = function () { openLibraryPreview(row._url); };
  return el;
}

/* Swap a row's skeleton for its resolved image, in whichever view is current. */
function libApplyRowImage(row) {
  if (!row._url || !row._node) return;
  if (libState.view === 'grid') {
    var img = libMakeGridImg(row);
    if (row._node.parentNode) row._node.parentNode.replaceChild(img, row._node);
    row._node = img;
  } else {
    var thumb = row._node.querySelector('.lib-row-thumb');
    if (thumb) { thumb.src = row._url; thumb.classList.remove('lib-skel-thumb'); }
    row._node.onclick = function () { openLibraryPreview(row._url); };
  }
}

function libResolveRows(rows) {
  return runCapped(rows, LIB_BLOB_CONCURRENCY, async function (row) {
    if (row._url) { libApplyRowImage(row); return; }
    if (row._loading || row._failed) return;
    row._loading = true;
    var mySeq = libState.seq;
    var url = await fetchLibraryImageBlobUrl(row.id);
    row._loading = false;
    if (mySeq !== libState.seq) return; // reset happened mid-fetch — drop it
    if (!url) { row._failed = true; return; }
    row._url = url;
    libApplyRowImage(row);
  });
}

function libApplyViewVisibility() {
  var grid = document.getElementById('libraryGrid');
  var list = document.getElementById('libraryList');
  if (grid) grid.style.display = libState.view === 'grid' ? 'grid' : 'none';
  if (list) list.style.display = libState.view === 'list' ? 'flex' : 'none';
}

function libRenderInitialSkeleton() {
  var grid = document.getElementById('libraryGrid');
  var list = document.getElementById('libraryList');
  var empty = document.getElementById('libraryEmpty');
  if (empty) empty.style.display = 'none';
  libApplyViewVisibility();
  var n = 12, i;
  if (libState.view === 'grid') {
    if (grid) { grid.innerHTML = ''; for (i = 0; i < n; i++) grid.appendChild(libMakeGridSkel()); }
  } else if (list) {
    list.innerHTML = '';
    list.appendChild(libMakeListHeader());
    for (i = 0; i < n; i++) list.appendChild(libMakeListSkelRow());
  }
}

function libAppendRows(rows) {
  var grid = document.getElementById('libraryGrid');
  var list = document.getElementById('libraryList');
  var toResolve = [];
  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    var node = libState.view === 'grid' ? libMakeGridSkel() : libMakeListRow(row);
    row._node = node;
    if (libState.view === 'grid' && grid) grid.appendChild(node);
    else if (list) list.appendChild(node);
    if (row._url) libApplyRowImage(row); else toResolve.push(row);
  }
  libResolveRows(toResolve);
}

/* Re-render the active view from already-loaded rows (used by the Grid/List
   toggle — no requery; cached blob URLs render instantly, the rest re-skeleton
   and re-resolve). */
function libRebuildFromRows() {
  var grid = document.getElementById('libraryGrid');
  var list = document.getElementById('libraryList');
  libApplyViewVisibility();
  var rows = libState.rows, toResolve = [], i;
  if (libState.view === 'grid') {
    if (!grid) return;
    grid.innerHTML = '';
    for (i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (r._url) { r._node = libMakeGridImg(r); grid.appendChild(r._node); }
      else { r._node = libMakeGridSkel(); grid.appendChild(r._node); toResolve.push(r); }
    }
  } else {
    if (!list) return;
    list.innerHTML = '';
    list.appendChild(libMakeListHeader());
    for (i = 0; i < rows.length; i++) {
      var row = rows[i];
      row._node = libMakeListRow(row);
      list.appendChild(row._node);
      if (!row._url) toResolve.push(row);
    }
  }
  libResolveRows(toResolve);
}

function libTeardownObserver() {
  if (libState.observer) { libState.observer.disconnect(); libState.observer = null; }
  if (libState.sentinel && libState.sentinel.parentNode) libState.sentinel.parentNode.removeChild(libState.sentinel);
  libState.sentinel = null;
}
function libEnsureSentinel() {
  if (libState.done || libState.sentinel) return;
  var view = document.getElementById('libraryView');
  if (!view) return;
  var s = document.createElement('div');
  s.className = 'lib-loadmore';
  s.id = 'libSentinel';
  s.innerHTML = '<span class="lazy-spinner-ring"></span>';
  view.appendChild(s);
  libState.sentinel = s;
  // root:null (viewport) is robust whether the window or an inner ancestor
  // scrolls — same choice as the sidebar chat lazy-load.
  libState.observer = new IntersectionObserver(function (entries) {
    if (entries[0] && entries[0].isIntersecting) libLoadPage(false);
  }, { root: null, rootMargin: '0px 0px 300px 0px', threshold: 0 });
  libState.observer.observe(s);
}

async function libLoadPage(isInitial) {
  if (libState.loading || libState.done || !currentUser) return;
  libState.loading = true;
  var mySeq = libState.seq;
  var limit = isInitial ? LIB_PAGE_INITIAL : LIB_PAGE_MORE;
  var grid = document.getElementById('libraryGrid');
  var list = document.getElementById('libraryList');
  var empty = document.getElementById('libraryEmpty');

  // Append bottom skeletons for a "load more" page (initial skeletons are
  // already on screen from libRenderInitialSkeleton).
  var moreSkels = [];
  if (!isInitial) {
    for (var k = 0; k < limit; k++) {
      var sk = libState.view === 'grid' ? libMakeGridSkel() : libMakeListSkelRow();
      moreSkels.push(sk);
      if (libState.view === 'grid' && grid) grid.appendChild(sk);
      else if (list) list.appendChild(sk);
    }
  }

  var q = supabase
    .from('library_images')
    .select('id,created_at,content_type,size_bytes,file_name')
    .eq('user_id', currentUser.id)
    .order('created_at', { ascending: false })
    .range(libState.offset, libState.offset + limit - 1);
  if (libState.filter === 'images') q = q.like('content_type', 'image/%');
  var term = libSanitizeSearch(libState.search);
  if (term) q = q.ilike('file_name', '%' + term + '%');

  var res = await q;
  if (mySeq !== libState.seq) return; // reset raced ahead — abandon this load

  for (var j = 0; j < moreSkels.length; j++) {
    if (moreSkels[j].parentNode) moreSkels[j].parentNode.removeChild(moreSkels[j]);
  }

  var data = res && res.data;
  if (isInitial) {
    if (grid) grid.innerHTML = '';
    if (list) list.innerHTML = '';
    libState.rows = [];
  }

  if (!data || data.length === 0) {
    if (isInitial) {
      if (empty) empty.style.display = 'block';
      if (grid) grid.style.display = 'none';
      if (list) list.style.display = 'none';
    }
    libState.done = true;
    libTeardownObserver();
    libState.loading = false;
    return;
  }

  if (empty) empty.style.display = 'none';
  libApplyViewVisibility();
  if (isInitial && libState.view === 'list' && list) list.appendChild(libMakeListHeader());

  libState.rows = libState.rows.concat(data);
  libAppendRows(data);
  libState.offset += data.length;

  if (data.length < limit) { libState.done = true; libTeardownObserver(); }
  else libEnsureSentinel();
  libState.loading = false;
}

/* Reset the query context (search text / filter tab changed) and reload from
   page 0 — search & filter both apply server-side across the whole library. */
function libApplyQueryReset(opts) {
  if (opts.search !== undefined) libState.search = opts.search;
  if (opts.filter !== undefined) libState.filter = opts.filter;
  libState.rows = [];
  libState.offset = 0;
  libState.done = false;
  libState.loading = false;
  libState.seq++;
  libTeardownObserver();
  libRenderInitialSkeleton();
  libLoadPage(true);
}

window.setLibraryView = function (v) {
  if (v !== 'grid' && v !== 'list') return;
  if (libState.view === v) return;
  libState.view = v;
  try { localStorage.setItem('batnxt_library_view', v); } catch (e) {}
  var g = document.getElementById('libViewGridBtn'), l = document.getElementById('libViewListBtn');
  if (g) g.classList.toggle('active', v === 'grid');
  if (l) l.classList.toggle('active', v === 'list');
  libRebuildFromRows();
};
window.setLibraryFilter = function (f) {
  if (f !== 'all' && f !== 'images') return;
  if (libState.filter === f) return;
  var tabs = document.querySelectorAll('#libraryView .lib-tab[data-filter]');
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-filter') === f);
  libApplyQueryReset({ filter: f });
};
window.searchLibraryView = function (v) {
  if (_libSearchTimer) clearTimeout(_libSearchTimer);
  _libSearchTimer = setTimeout(function () { libApplyQueryReset({ search: v }); }, 250);
};

async function renderLibrary() {
  var grid = document.getElementById('libraryGrid');
  if (!grid || !currentUser) return;
  var pv = 'grid';
  try { pv = localStorage.getItem('batnxt_library_view') || 'grid'; } catch (e) {}
  libState.view = pv === 'list' ? 'list' : 'grid';
  libState.filter = 'all';
  libState.search = '';
  libState.rows = [];
  libState.offset = 0;
  libState.loading = false;
  libState.done = false;
  libState.seq++;
  libTeardownObserver();

  var si = document.getElementById('librarySearchInput'); if (si) si.value = '';
  var g = document.getElementById('libViewGridBtn'), l = document.getElementById('libViewListBtn');
  if (g) g.classList.toggle('active', libState.view === 'grid');
  if (l) l.classList.toggle('active', libState.view === 'list');
  var tabs = document.querySelectorAll('#libraryView .lib-tab[data-filter]');
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-filter') === libState.filter);

  libRenderInitialSkeleton();
  await libLoadPage(true);
}
window.renderLibrary = renderLibrary;

/* ── Marketing History (My Marketing Analyses) ──────────────────────────
   Mirrors the Library architecture 1:1 (see libState/libLoadPage above) but
   queries `marketing_analyses` instead of `library_images`: no blob
   resolution step (there's nothing to lazy-load — cards render straight from
   the row), server-side search matches `title` only via ilike, and the
   filter tabs map directly onto the `category` column (`all` skips the
   .eq entirely). A `seq` counter fences stale in-flight loads after a
   reset, exactly like the Library implementation. */
var MKT_HIST_PAGE_INITIAL = 10;
var MKT_HIST_PAGE_MORE = 10;
var mktHistoryState = {
  filter: 'all',   // 'all' | one of MKT_CATEGORY_VALUES
  search: '',
  rows: [],        // accumulated marketing_analyses rows (raw, incl. `messages`)
  offset: 0,
  loading: false,
  done: false,
  loadMoreBtn: null,
  seq: 0,
};
var _mktHistSearchTimer = null;

/* ── Recent Analyses strip ──
   Quick-access shortcut on the "New Analysis" panel: shows the user's most
   recent saved marketing_analyses rows so they don't have to open the full
   History sub-view for recent items. Reuses mktHistoryOpen(id) verbatim —
   does NOT duplicate its reopen logic — by merging the fetched rows into
   mktHistoryState.rows (the array mktHistoryOpen reads from), the same way
   the History tab's own pagination does. */
var MKT_RECENT_STRIP_LIMIT = 5;

/* ── History tab count badge ──
   mktHistoryTotalCount caches the total row count for the History tab badge
   (e.g. "History (24)"). null = not yet loaded (badge stays hidden to avoid
   a "(0)" flash). Fetched once via a head:true/count:'exact' query (no row
   data transferred) and then updated optimistically on new saves — see
   mktHistoryCountLoad()/mktHistoryCountBump() below. */
var mktHistoryTotalCount = null;

async function mktHistoryCountLoad() {
  if (mktHistoryTotalCount !== null || !currentUser) return;
  let res;
  try {
    res = await supabase
      .from('marketing_analyses')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', currentUser.id);
  } catch (e) {
    console.error('Failed to load marketing history count:', e);
    return;
  }
  if (typeof res.count !== 'number') return;
  mktHistoryTotalCount = res.count;
  mktHistoryCountRender();
}
window.mktHistoryCountLoad = mktHistoryCountLoad;

function mktHistoryCountRender() {
  const badge = document.getElementById('marketingHistoryCount');
  if (!badge || mktHistoryTotalCount === null) return;
  badge.textContent = '(' + mktHistoryTotalCount + ')';
  badge.style.display = '';
}

// Optimistic +1 on a newly-created analysis (no delete path exists for
// marketing_analyses, so no decrement case is needed).
function mktHistoryCountBump() {
  if (mktHistoryTotalCount === null) return;
  mktHistoryTotalCount++;
  mktHistoryCountRender();
}

async function mktRecentStripLoad() {
  const strip = document.getElementById('marketingRecentStrip');
  const row = document.getElementById('marketingRecentRow');
  if (!strip || !row || !currentUser) return;

  let res;
  try {
    res = await supabase
      .from('marketing_analyses')
      .select('id,title,created_at,updated_at,source_url,domain,scores,competition,growth_potential,category,messages')
      .eq('user_id', currentUser.id)
      .order('updated_at', { ascending: false })
      .limit(MKT_RECENT_STRIP_LIMIT);
  } catch (e) {
    console.error('Failed to load recent marketing analyses:', e);
    return;
  }

  const data = res && res.data;
  if (!data || !data.length) { strip.style.display = 'none'; row.innerHTML = ''; mktLastAnalysisRender(null); return; }

  // Merge into mktHistoryState.rows (dedup by id) so mktHistoryOpen(id) can
  // find these rows even if the History tab has never been opened yet.
  data.forEach(function (r) {
    if (!mktHistoryState.rows.some(function (existing) { return existing.id === r.id; })) {
      mktHistoryState.rows.push(r);
    }
  });

  row.innerHTML = '';
  data.forEach(function (r) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'mkt-recent-card';
    const title = r.title || (BatLang.t('marketing.newTitle') || 'Marketing Analysis');
    card.title = title;
    card.onclick = function () { window.mktHistoryOpen(r.id); };

    const titleEl = document.createElement('div');
    titleEl.className = 'mkt-recent-title';
    titleEl.textContent = title;
    card.appendChild(titleEl);

    const dateEl = document.createElement('div');
    dateEl.className = 'mkt-recent-date';
    dateEl.textContent = libRelDate(r.updated_at || r.created_at);
    card.appendChild(dateEl);

    const seoScore = r.scores && typeof r.scores.seo === 'number' ? Math.max(0, Math.min(100, Math.round(r.scores.seo))) : null;
    if (seoScore !== null || r.category) {
      const chips = document.createElement('div');
      chips.className = 'mkt-recent-chips';
      if (seoScore !== null) {
        const chip = document.createElement('span');
        chip.className = 'mkt-hist-chip';
        const dot = document.createElement('span');
        dot.className = 'mkt-hist-chip-dot';
        dot.style.background = marketingScoreColor(seoScore);
        chip.appendChild(dot);
        const seoMeta = MARKETING_SCORE_AXES.seo;
        chip.appendChild(document.createTextNode((BatLang.t(seoMeta.labelKey) || seoMeta.fallback) + ' ' + seoScore));
        chips.appendChild(chip);
      }
      if (r.category) {
        const catChip = document.createElement('span');
        catChip.className = 'mkt-hist-chip';
        catChip.textContent = r.category;
        chips.appendChild(catChip);
      }
      card.appendChild(chips);
    }

    row.appendChild(card);
  });
  strip.style.display = 'flex';

  // data[0] is the most recently updated row (query is ordered desc).
  mktLastAnalysisRender(data[0]);
}
window.mktRecentStripLoad = mktRecentStripLoad;

// Last-analysis mini dashboard strip — quick-glance summary of the user's
// most recent saved analysis, shown at the top of the New Analysis composer.
// Sourced from mktRecentStripLoad's already-fetched data (no new query).
function mktLastAnalysisRender(row) {
  const strip = document.getElementById('marketingLastAnalysisStrip');
  const titleEl = document.getElementById('marketingLastAnalysisTitle');
  const domainEl = document.getElementById('marketingLastAnalysisDomain');
  const chipsEl = document.getElementById('marketingLastAnalysisChips');
  if (!strip || !titleEl || !domainEl || !chipsEl) return;

  if (!row) { strip.style.display = 'none'; return; }

  const title = row.title || (BatLang.t('marketing.newTitle') || 'Marketing Analysis');
  titleEl.textContent = title;
  strip.title = title;
  strip.onclick = function () { window.mktHistoryOpen(row.id); };

  if (row.domain) { domainEl.textContent = row.domain; domainEl.style.display = ''; }
  else { domainEl.style.display = 'none'; }

  chipsEl.innerHTML = '';
  const seoScore = row.scores && typeof row.scores.seo === 'number' ? Math.max(0, Math.min(100, Math.round(row.scores.seo))) : null;
  if (seoScore !== null) {
    const chip = document.createElement('span');
    chip.className = 'mkt-hist-chip';
    const dot = document.createElement('span');
    dot.className = 'mkt-hist-chip-dot';
    dot.style.background = marketingScoreColor(seoScore);
    chip.appendChild(dot);
    const seoMeta = MARKETING_SCORE_AXES.seo;
    chip.appendChild(document.createTextNode((BatLang.t(seoMeta.labelKey) || seoMeta.fallback) + ' ' + seoScore));
    chipsEl.appendChild(chip);
  }
  if (row.competition && MKT_LEVEL_VALUES.indexOf(row.competition) !== -1) {
    const levelKey = 'marketing.level' + row.competition;
    const levelLabel = (typeof BatLang !== 'undefined' && BatLang.t(levelKey)) || row.competition;
    const compChip = document.createElement('span');
    compChip.className = 'mkt-hist-chip';
    compChip.textContent = ((typeof BatLang !== 'undefined' && BatLang.t('marketing.competitionLabel')) || 'Competition') + ': ' + levelLabel;
    chipsEl.appendChild(compChip);
  }

  strip.style.display = 'flex';
}
window.mktLastAnalysisRender = mktLastAnalysisRender;

// Lightweight client-side Analytics view — one Supabase fetch (RLS already
// scopes to currentUser.id, same pattern as mktRecentStripLoad above), then
// plain-JS aggregation. No charting library, no new backend route.
let mktAnalyticsCache = null;
async function mktAnalyticsLoad() {
  if (!currentUser) return [];
  let res;
  try {
    res = await supabase
      .from('marketing_analyses')
      .select('id,scores,category,created_at')
      .eq('user_id', currentUser.id)
      .order('created_at', { ascending: false })
      .limit(1000);
  } catch (e) {
    console.error('Failed to load marketing analytics:', e);
    return [];
  }
  mktAnalyticsCache = (res && res.data) || [];
  return mktAnalyticsCache;
}

async function renderMktAnalytics() {
  const empty = document.getElementById('marketingAnalyticsEmpty');
  const body = document.getElementById('marketingAnalyticsBody');
  const grid = document.getElementById('marketingAnalyticsGrid');
  const catsWrap = document.getElementById('marketingAnalyticsCats');
  if (!empty || !body || !grid || !catsWrap) return;

  const rows = await mktAnalyticsLoad();
  if (!rows.length) {
    empty.style.display = 'block';
    body.style.display = 'none';
    return;
  }
  empty.style.display = 'none';
  body.style.display = 'flex';

  // Stat tiles: total + one average per score axis actually present in at
  // least one saved row (older rows without newer axes just don't count
  // toward that axis's average — no tile is shown if zero rows have it).
  grid.innerHTML = '';
  const totalTile = document.createElement('div');
  totalTile.className = 'mkt-analytics-stat';
  totalTile.innerHTML = '<div class="mkt-analytics-stat-value">' + rows.length + '</div><div class="mkt-analytics-stat-label">' +
    (BatLang.t('marketing.analyticsTotal') || 'Total analyses') + '</div>';
  grid.appendChild(totalTile);

  const axisSums = {};
  const axisCounts = {};
  const overallSums = [];
  rows.forEach(function (r) {
    const scores = r.scores || {};
    const present = Object.keys(MARKETING_SCORE_AXES).filter(function (a) { return typeof scores[a] === 'number'; });
    present.forEach(function (a) {
      axisSums[a] = (axisSums[a] || 0) + scores[a];
      axisCounts[a] = (axisCounts[a] || 0) + 1;
    });
    if (present.length) overallSums.push(present.reduce(function (sum, a) { return sum + scores[a]; }, 0) / present.length);
  });

  Object.keys(MARKETING_SCORE_AXES).forEach(function (axis) {
    if (!axisCounts[axis]) return;
    const meta = MARKETING_SCORE_AXES[axis];
    const avg = Math.round(axisSums[axis] / axisCounts[axis]);
    const tile = document.createElement('div');
    tile.className = 'mkt-analytics-stat';
    const label = BatLang.t('marketing.analyticsAvgPrefix') || 'Avg';
    tile.innerHTML = '<div class="mkt-analytics-stat-value" style="color:' + marketingScoreColor(avg) + '">' + avg + '</div><div class="mkt-analytics-stat-label">' +
      label + ' ' + (BatLang.t(meta.labelKey) || meta.fallback) + '</div>';
    grid.appendChild(tile);
  });

  if (overallSums.length) {
    const avgOverall = Math.round(overallSums.reduce(function (s, v) { return s + v; }, 0) / overallSums.length);
    const tile = document.createElement('div');
    tile.className = 'mkt-analytics-stat';
    tile.innerHTML = '<div class="mkt-analytics-stat-value" style="color:' + marketingScoreColor(avgOverall) + '">' + avgOverall + '</div><div class="mkt-analytics-stat-label">' +
      (BatLang.t('marketing.analyticsAvgOverall') || 'Avg Overall Score') + '</div>';
    grid.appendChild(tile);
  }

  // Category breakdown: simple counts, sorted descending, rendered as plain
  // CSS width-percentage bars (no charting library).
  const catCounts = {};
  rows.forEach(function (r) {
    const cat = r.category || (BatLang.t('marketing.categoryUncategorized') || 'Uncategorized');
    catCounts[cat] = (catCounts[cat] || 0) + 1;
  });
  const catEntries = Object.keys(catCounts).map(function (cat) { return { cat: cat, count: catCounts[cat] }; })
    .sort(function (a, b) { return b.count - a.count; });
  const maxCount = catEntries.length ? catEntries[0].count : 1;

  const mostUsedTile = document.createElement('div');
  mostUsedTile.className = 'mkt-analytics-stat';
  mostUsedTile.innerHTML = '<div class="mkt-analytics-stat-value">' + (catEntries[0] ? catEntries[0].cat : '—') + '</div><div class="mkt-analytics-stat-label">' +
    (BatLang.t('marketing.analyticsMostUsedCategory') || 'Most-used category') + '</div>';
  grid.appendChild(mostUsedTile);

  catsWrap.innerHTML = '';
  catEntries.forEach(function (entry) {
    const row = document.createElement('div');
    row.className = 'mkt-analytics-cat-row';
    const pct = Math.round((entry.count / maxCount) * 100);
    row.innerHTML = '<div class="mkt-analytics-cat-head"><span>' + entry.cat + '</span><span>' + entry.count + '</span></div>' +
      '<div class="mkt-analytics-bar-track"><div class="mkt-analytics-bar" style="width:' + pct + '%;"></div></div>';
    catsWrap.appendChild(row);
  });
}
window.renderMktAnalytics = renderMktAnalytics;

function mktHistSanitizeSearch(s) {
  return (s || '').replace(/[%,()]/g, ' ').trim();
}

// Strips a (possibly absent) <MKT_SCORES>...</MKT_SCORES> tag out of a
// stored raw assistant message, mirroring the exact parse/fallback chain
// used at send-time (see sendMarketingMessage()) — used both for the
// History card's plain-text preview and for mktHistoryOpen()'s replay, so
// the raw JSON tag is never shown to the user in either place.
function mktStripScoresTag(rawText) {
  const text = rawText || '';
  let displayText = text;
  let mktScores = null;
  const scoresMatch = text.match(/<MKT_SCORES>([\s\S]*?)<\/MKT_SCORES>/);
  if (scoresMatch) {
    const rawTag = scoresMatch[1].trim();
    try { mktScores = JSON.parse(rawTag); }
    catch (e) {
      try { mktScores = JSON.parse(stripJsonCodeFences(rawTag)); }
      catch (e2) { mktScores = null; }
    }
    displayText = displayText.replace(/<MKT_SCORES>[\s\S]*?<\/MKT_SCORES>/, '').trim();
  } else {
    mktScores = detectBareMktScoresJson(displayText);
    if (mktScores) displayText = '';
  }
  return { displayText: displayText, mktScores: mktScores };
}

// Plain-text preview for the non-structured card layout — last assistant
// reply's prose (tag stripped) if there is one, else the first user turn.
function mktHistPreviewText(row) {
  const msgs = (row && row.messages) || [];
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i].role === 'assistant') {
      const stripped = mktStripScoresTag(msgs[i].content).displayText;
      if (stripped) return stripped;
    }
  }
  const firstUser = msgs.find(function (m) { return m.role === 'user'; });
  return (firstUser && firstUser.content) || '';
}

function mktHistMakeCardSkel() {
  const card = document.createElement('div');
  card.className = 'mkt-hist-card mkt-hist-card-skel';
  const l1 = document.createElement('div'); l1.className = 'mkt-hist-skel-line'; l1.style.width = '55%';
  const l2 = document.createElement('div'); l2.className = 'mkt-hist-skel-line'; l2.style.width = '90%';
  const l3 = document.createElement('div'); l3.className = 'mkt-hist-skel-line'; l3.style.width = '40%';
  card.appendChild(l1); card.appendChild(l2); card.appendChild(l3);
  return card;
}

// One card per saved analysis — two layouts gated on whether `scores` is
// present: structured rows show mini score/level chips (reusing the
// MKT_SCORES widget's color language via marketingScoreColor); everything
// else falls back to a plain two-line text preview.
function mktHistMakeCard(row) {
  const card = document.createElement('div');
  card.className = 'mkt-hist-card';
  card.onclick = function () { window.mktHistoryOpen(row.id); };

  const top = document.createElement('div');
  top.className = 'mkt-hist-card-top';
  const title = document.createElement('div');
  title.className = 'mkt-hist-title';
  title.textContent = row.title || (BatLang.t('marketing.newTitle') || 'Marketing Analysis');
  title.title = title.textContent;
  const date = document.createElement('div');
  date.className = 'mkt-hist-date';
  date.textContent = libRelDate(row.updated_at || row.created_at);
  top.appendChild(title); top.appendChild(date);
  card.appendChild(top);

  if (row.domain) {
    const domain = document.createElement('div');
    domain.className = 'mkt-hist-domain';
    domain.textContent = row.domain;
    card.appendChild(domain);
  }

  if (row.scores && typeof row.scores === 'object') {
    const chips = document.createElement('div');
    chips.className = 'mkt-hist-chips';
    Object.keys(MARKETING_SCORE_AXES).forEach(function (axis) {
      if (typeof row.scores[axis] !== 'number') return;
      const meta = MARKETING_SCORE_AXES[axis];
      const v = Math.max(0, Math.min(100, Math.round(row.scores[axis])));
      const chip = document.createElement('span');
      chip.className = 'mkt-hist-chip';
      const dot = document.createElement('span');
      dot.className = 'mkt-hist-chip-dot';
      dot.style.background = marketingScoreColor(v);
      chip.appendChild(dot);
      chip.appendChild(document.createTextNode((BatLang.t(meta.labelKey) || meta.fallback) + ' ' + v));
      chips.appendChild(chip);
    });
    if (row.category) {
      const catChip = document.createElement('span');
      catChip.className = 'mkt-hist-chip';
      catChip.textContent = row.category;
      chips.appendChild(catChip);
    }
    card.appendChild(chips);
  } else {
    const preview = document.createElement('div');
    preview.className = 'mkt-hist-preview';
    preview.textContent = mktHistPreviewText(row);
    card.appendChild(preview);
  }

  return card;
}

function mktHistoryTeardownLoadMore() {
  const wrap = document.getElementById('mktHistLoadMoreWrap');
  if (wrap && wrap.parentNode) wrap.parentNode.removeChild(wrap);
  mktHistoryState.loadMoreBtn = null;
}
function mktHistoryEnsureLoadMoreButton() {
  if (mktHistoryState.done) return;
  const existingWrap = document.getElementById('mktHistLoadMoreWrap');
  if (existingWrap) {
    // Already on screen (e.g. re-enabling after a page finished loading).
    if (mktHistoryState.loadMoreBtn) {
      mktHistoryState.loadMoreBtn.disabled = false;
      mktHistoryState.loadMoreBtn.textContent = BatLang.t('marketing.loadMore') || 'Load more';
    }
    return;
  }
  const list = document.getElementById('marketingHistoryList');
  if (!list) return;
  const wrap = document.createElement('div');
  wrap.className = 'lib-loadmore';
  wrap.id = 'mktHistLoadMoreWrap';
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'btn-solid btn-sm';
  btn.textContent = BatLang.t('marketing.loadMore') || 'Load more';
  btn.onclick = function () {
    btn.disabled = true;
    btn.textContent = BatLang.t('marketing.loading') || 'Loading…';
    mktHistoryLoadPage(false);
  };
  wrap.appendChild(btn);
  list.parentNode.appendChild(wrap);
  mktHistoryState.loadMoreBtn = btn;
}

async function mktHistoryLoadPage(isInitial) {
  if (mktHistoryState.loading || mktHistoryState.done || !currentUser) return;
  mktHistoryState.loading = true;
  const mySeq = mktHistoryState.seq;
  const limit = isInitial ? MKT_HIST_PAGE_INITIAL : MKT_HIST_PAGE_MORE;
  const list = document.getElementById('marketingHistoryList');
  const empty = document.getElementById('marketingHistoryEmpty');

  const moreSkels = [];
  if (!isInitial && list) {
    for (let k = 0; k < limit; k++) {
      const sk = mktHistMakeCardSkel();
      moreSkels.push(sk);
      list.appendChild(sk);
    }
  }

  let q = supabase
    .from('marketing_analyses')
    .select('id,title,created_at,updated_at,source_url,domain,scores,competition,growth_potential,category,messages')
    .eq('user_id', currentUser.id)
    .order('updated_at', { ascending: false })
    .range(mktHistoryState.offset, mktHistoryState.offset + limit - 1);
  if (mktHistoryState.filter !== 'all') q = q.eq('category', mktHistoryState.filter);
  const term = mktHistSanitizeSearch(mktHistoryState.search);
  if (term) q = q.ilike('title', '%' + term + '%');

  const res = await q;
  if (mySeq !== mktHistoryState.seq) return;

  for (let j = 0; j < moreSkels.length; j++) {
    if (moreSkels[j].parentNode) moreSkels[j].parentNode.removeChild(moreSkels[j]);
  }

  const data = res && res.data;
  if (isInitial && list) { list.innerHTML = ''; mktHistoryState.rows = []; }

  if (!data || data.length === 0) {
    if (isInitial && empty) empty.style.display = 'block';
    mktHistoryState.done = true;
    mktHistoryTeardownLoadMore();
    mktHistoryState.loading = false;
    return;
  }

  if (empty) empty.style.display = 'none';
  mktHistoryState.rows = mktHistoryState.rows.concat(data);
  if (list) data.forEach(function (row) { list.appendChild(mktHistMakeCard(row)); });
  mktHistoryState.offset += data.length;

  if (data.length < limit) { mktHistoryState.done = true; mktHistoryTeardownLoadMore(); }
  else mktHistoryEnsureLoadMoreButton();
  mktHistoryState.loading = false;
}

function mktHistoryApplyQueryReset(opts) {
  if (opts.search !== undefined) mktHistoryState.search = opts.search;
  if (opts.filter !== undefined) mktHistoryState.filter = opts.filter;
  mktHistoryState.rows = [];
  mktHistoryState.offset = 0;
  mktHistoryState.done = false;
  mktHistoryState.loading = false;
  mktHistoryState.seq++;
  mktHistoryTeardownLoadMore();
  const list = document.getElementById('marketingHistoryList');
  const empty = document.getElementById('marketingHistoryEmpty');
  if (empty) empty.style.display = 'none';
  if (list) {
    list.innerHTML = '';
    for (let i = 0; i < MKT_HIST_PAGE_INITIAL; i++) list.appendChild(mktHistMakeCardSkel());
  }
  mktHistoryLoadPage(true);
}

window.setMktHistoryFilter = function (f) {
  if (mktHistoryState.filter === f) return;
  const tabs = document.querySelectorAll('#marketingHistoryTabs .lib-tab[data-filter]');
  for (let i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-filter') === f);
  mktHistoryApplyQueryReset({ filter: f });
};
window.searchMktHistory = function (v) {
  if (_mktHistSearchTimer) clearTimeout(_mktHistSearchTimer);
  _mktHistSearchTimer = setTimeout(function () { mktHistoryApplyQueryReset({ search: v }); }, 250);
};

async function renderMktHistory() {
  const list = document.getElementById('marketingHistoryList');
  if (!list || !currentUser) return;
  mktHistoryState.filter = 'all';
  mktHistoryState.search = '';
  mktHistoryState.rows = [];
  mktHistoryState.offset = 0;
  mktHistoryState.loading = false;
  mktHistoryState.done = false;
  mktHistoryState.seq++;
  mktHistoryTeardownLoadMore();

  const si = document.getElementById('marketingHistorySearchInput'); if (si) si.value = '';
  const tabs = document.querySelectorAll('#marketingHistoryTabs .lib-tab[data-filter]');
  for (let i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-filter') === mktHistoryState.filter);

  const empty = document.getElementById('marketingHistoryEmpty');
  if (empty) empty.style.display = 'none';
  list.innerHTML = '';
  for (let i = 0; i < MKT_HIST_PAGE_INITIAL; i++) list.appendChild(mktHistMakeCardSkel());

  await mktHistoryLoadPage(true);
}
window.renderMktHistory = renderMktHistory;

// Reopens a saved analysis in the "New Analysis" panel so a follow-up
// message updates the SAME row instead of creating a new one. Reads the
// row straight out of the already-fetched mktHistoryState.rows (no second
// Supabase round-trip) — a stale click (row scrolled out / list reset
// mid-click) is simply a no-op. Each stored assistant turn has its raw
// <MKT_SCORES> tag stripped before replay (mirrors the send-time display
// path exactly — see mktStripScoresTag above) so the JSON tag never leaks
// into the reopened thread, and the scores widget is re-appended only for
// the most recent assistant turn that actually carried one.
// Rebuilds #marketingMessages from scratch against the current
// marketingHistory (already-baked content — no re-extraction). Each stored
// assistant turn has its raw <MKT_SCORES> tag stripped for display (see
// mktStripScoresTag above), with the scores widget re-appended only for the
// most recent assistant turn that actually carried one. User messages get
// their true array index (for the Copy/Edit/Regenerate hover row). Used by
// mktHistoryOpen (reopening a saved analysis). (Edit/Regenerate no longer
// truncate/rebuild — they append a fresh turn via sendMarketingMessage.)
function marketingRenderHistory() {
  const messages = document.getElementById('marketingMessages');
  if (messages) messages.innerHTML = '';

  let lastScores = null, lastRecommendations = null;
  marketingHistory.forEach(function (m, i) {
    if (m.role === 'assistant') {
      // Rebuild the "Thought for Xs" reasoning block that was shown live, ahead
      // of its text bubble (mirrors Home's hcmRenderSlice). secs>0 with empty
      // text restores the honest timing-only chip too.
      if (m.think && (m.think.text || m.think.secs)) {
        hcmAppendSavedThinking(m.think.text || '', m.think.secs || 1, 'marketingMessages');
      }
      // Rebuild the finished "Analyzed" terminal card for a restored export
      // reply, ahead of its text bubble (same ordering as Home's
      // hcmRenderSlice — Part C persistence fix).
      if (m.analyzingSteps) {
        hcmAppendSavedAnalyzingCard('marketingMessages');
      }
      const stripped = mktStripScoresTag(m.content);
      // Export marker messages render their OWN "✅ ready" lead-in + card
      // via appendExportFileCard below — skip the generic bubble render so
      // the ready text doesn't appear twice (mirrors the live flow, where
      // appendExportFileCard is called directly, never through marketingAppend).
      if (!m.exportBody) {
        marketingAppend('assistant', stripped.displayText, undefined, undefined, m.msgId);
      }
      if (stripped.mktScores && stripped.mktScores.scores) {
        lastScores = stripped.mktScores.scores;
        lastRecommendations = stripped.mktScores.recommendations || [];
      } else {
        lastScores = null; lastRecommendations = null;
      }
      // Rebuild the interactive exported file card for a restored export
      // reply (the card's body/format are persisted inline on the message).
      if (m.exportBody) {
        appendExportFileCard('marketingMessages', marketingHistory, m.exportBody, m.exportFormat);
      }
    } else {
      // Legacy rows saved before displayCaption/attachments existed simply
      // don't have those fields — fall back to today's raw-content behavior
      // for them (no migration, no breakage), while fixed-format rows show
      // only the typed caption + a (static, non-interactive) file card.
      const caption = m.displayCaption != null ? m.displayCaption : m.content;
      marketingAppend(m.role, caption, m.attachments, i);
    }
  });
  if (lastScores) appendMarketingScoresWidget(lastScores, lastRecommendations);
}

window.mktHistoryOpen = async function (id) {
  const row = mktHistoryState.rows.find(function (r) { return r.id === id; });
  if (!row) return; // stale click guard

  marketingHistory = (row.messages || []).slice();
  marketingAnalysisId = row.id;
  marketingAnalysisTitle = row.title || null;
  marketingAttachedFiles = [];
  marketingRenderAttachedFileChips();

  const input = document.getElementById('marketingInput');
  if (input) input.value = '';
  const urlInput = document.getElementById('marketingUrlInput');
  if (urlInput) urlInput.value = '';

  await loadStarredSetForSession('marketing', row.id);
  if (marketingAnalysisId !== row.id) return; // a different analysis was opened meanwhile

  marketingRenderHistory();

  window.showMarketingSubview('new');
};

// ── Starred view (list of all starred messages, across Home + Marketing) ──
// Mirrors the Marketing History architecture 1:1 (see mktHistoryState/
// mktHistoryLoadPage above) but queries `starred_messages` instead, with a
// `source` filter tab (all/home/marketing) in place of the category tabs,
// and a stripped-down card (title + snippet + relative date + unstar
// button) since starred_messages rows are themselves just a denormalized
// snapshot, not the full saved object like a marketing_analyses row.
var STARRED_PAGE_INITIAL = 10;
var STARRED_PAGE_MORE = 10;
var starredState = {
  filter: 'all',   // 'all' | 'home' | 'marketing'
  search: '',
  rows: [],
  offset: 0,
  loading: false,
  done: false,
  loadMoreBtn: null,
  seq: 0,
};
var _starredSearchTimer = null;

function starredMakeCardSkel() {
  const card = document.createElement('div');
  card.className = 'mkt-hist-card mkt-hist-card-skel';
  const l1 = document.createElement('div'); l1.className = 'mkt-hist-skel-line'; l1.style.width = '55%';
  const l2 = document.createElement('div'); l2.className = 'mkt-hist-skel-line'; l2.style.width = '90%';
  const l3 = document.createElement('div'); l3.className = 'mkt-hist-skel-line'; l3.style.width = '40%';
  card.appendChild(l1); card.appendChild(l2); card.appendChild(l3);
  return card;
}

// Scrolls to and briefly highlights a message already rendered in the
// current view (Home or Marketing) after opening its source conversation.
// A message outside the currently-rendered lazy-load window (older Home
// history that hasn't been scrolled into yet) simply won't be found — the
// conversation still opens correctly, it just isn't auto-scrolled to.
function starredScrollToMsg(msgId) {
  if (!msgId) return;
  setTimeout(function () {
    const el = document.querySelector('.hcm-msg[data-msg-id="' + msgId.replace(/"/g, '') + '"]');
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.classList.add('hcm-msg-flash');
    setTimeout(function () { el.classList.remove('hcm-msg-flash'); }, 1600);
  }, 300);
}

// Opens the parent conversation/analysis for a starred row and scrolls to
// the starred message itself. Both surfaces' own open helpers only look in
// their already-fetched in-memory lists (homeChatSessions is capped to the
// 20 most-recently-updated sessions; mktHistoryState.rows only has whatever
// the History tab has paged through) — a starred message from further back
// falls through both, so each branch below fetches that one row directly
// from Supabase (RLS-scoped) as a fallback and merges it in before opening.
async function starredOpenSource(row) {
  if (row.source === 'home') {
    let session = homeChatSessions.find(function (s) { return s.id === row.session_id; });
    if (!session) {
      let res;
      try {
        res = await supabase.from('chat_sessions')
          .select('id, title, messages, updated_at, is_pinned, is_read')
          .eq('user_id', currentUser.id)
          .eq('id', row.session_id)
          .single();
      } catch (e) {
        console.error('Failed to load conversation for starred message:', e);
        return;
      }
      if (!res || res.error || !res.data) return; // parent conversation was deleted
      session = {
        id: res.data.id,
        title: res.data.title,
        messages: res.data.messages || [],
        updatedAt: res.data.updated_at ? new Date(res.data.updated_at).getTime() : Date.now(),
        isPinned: !!res.data.is_pinned,
        isRead: res.data.is_read !== false
      };
      homeChatSessions.push(session);
    }
    await window.loadHomeChatSession(row.session_id);
    starredScrollToMsg(row.msg_id);
  } else {
    let mRow = mktHistoryState.rows.find(function (r) { return r.id === row.session_id; });
    if (!mRow) {
      let res;
      try {
        res = await supabase.from('marketing_analyses')
          .select('id,title,created_at,updated_at,source_url,domain,scores,competition,growth_potential,category,messages')
          .eq('user_id', currentUser.id)
          .eq('id', row.session_id)
          .single();
      } catch (e) {
        console.error('Failed to load marketing analysis for starred message:', e);
        return;
      }
      if (!res || res.error || !res.data) return; // parent analysis was deleted
      mRow = res.data;
      mktHistoryState.rows.push(mRow);
    }
    showView('marketing');
    await window.mktHistoryOpen(row.session_id);
    starredScrollToMsg(row.msg_id);
  }
}

// One card per starred_messages row — title + relative date on top, a
// short content snippet below, and an unstar button that deletes the row
// from Supabase and removes the card on click.
function starredMakeCard(row) {
  const card = document.createElement('div');
  card.className = 'mkt-hist-card';
  card.onclick = function () { starredOpenSource(row); };

  const top = document.createElement('div');
  top.className = 'mkt-hist-card-top';
  const title = document.createElement('div');
  title.className = 'mkt-hist-title';
  title.textContent = row.title || (row.source === 'marketing'
    ? (BatLang.t('marketing.newTitle') || 'Marketing Analysis')
    : (BatLang.t('sp.starred.untitledChat') || 'Chat'));
  title.title = title.textContent;
  const date = document.createElement('div');
  date.className = 'mkt-hist-date';
  date.textContent = libRelDate(row.created_at);
  top.appendChild(title); top.appendChild(date);
  card.appendChild(top);

  if (row.content_snippet) {
    const preview = document.createElement('div');
    preview.className = 'mkt-hist-preview';
    preview.textContent = row.content_snippet;
    card.appendChild(preview);
  }

  const chips = document.createElement('div');
  chips.className = 'mkt-hist-chips';
  const sourceChip = document.createElement('span');
  sourceChip.className = 'mkt-hist-chip';
  sourceChip.textContent = row.source === 'marketing'
    ? (BatLang.t('sp.starred.tabMarketing') || 'Marketing')
    : (BatLang.t('sp.starred.tabChat') || 'Chat');
  chips.appendChild(sourceChip);
  card.appendChild(chips);

  const unstarBtn = document.createElement('button');
  unstarBtn.type = 'button';
  unstarBtn.className = 'hcm-reaction-btn hcm-star-btn active mkt-hist-unstar-btn';
  unstarBtn.innerHTML = _starSvg;
  unstarBtn.setAttribute('aria-label', BatLang.t('chat.starBtn') || 'Unstar message');
  unstarBtn.title = BatLang.t('chat.starBtn') || 'Unstar message';
  unstarBtn.addEventListener('click', async function (ev) {
    ev.stopPropagation();
    unstarBtn.disabled = true;
    try {
      const res = await supabase.from('starred_messages').delete()
        .eq('user_id', currentUser.id).eq('source', row.source)
        .eq('session_id', row.session_id).eq('msg_id', row.msg_id);
      if (res.error) throw res.error;
    } catch (e) {
      console.error('Failed to unstar message:', e);
      unstarBtn.disabled = false;
      return;
    }
    // Keep the in-memory starred-set cache (used by the source
    // conversation's own star buttons) consistent with this removal.
    if (_starredMsgIdSets[row.source]) _starredMsgIdSets[row.source].delete(row.msg_id);
    starredState.rows = starredState.rows.filter(function (r) { return r !== row; });
    if (card.parentNode) card.parentNode.removeChild(card);
    if (!starredState.rows.length) {
      const empty = document.getElementById('starredEmpty');
      if (empty) empty.style.display = 'block';
    }
  });
  card.appendChild(unstarBtn);

  return card;
}

function starredTeardownLoadMore() {
  const wrap = document.getElementById('starredLoadMoreWrap');
  if (wrap && wrap.parentNode) wrap.parentNode.removeChild(wrap);
  starredState.loadMoreBtn = null;
}
function starredEnsureLoadMoreButton() {
  if (starredState.done) return;
  const existingWrap = document.getElementById('starredLoadMoreWrap');
  if (existingWrap) {
    if (starredState.loadMoreBtn) {
      starredState.loadMoreBtn.disabled = false;
      starredState.loadMoreBtn.textContent = BatLang.t('marketing.loadMore') || 'Load more';
    }
    return;
  }
  const list = document.getElementById('starredList');
  if (!list) return;
  const wrap = document.createElement('div');
  wrap.className = 'lib-loadmore';
  wrap.id = 'starredLoadMoreWrap';
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'btn-solid btn-sm';
  btn.textContent = BatLang.t('marketing.loadMore') || 'Load more';
  btn.onclick = function () {
    btn.disabled = true;
    btn.textContent = BatLang.t('marketing.loading') || 'Loading…';
    starredLoadPage(false);
  };
  wrap.appendChild(btn);
  list.parentNode.appendChild(wrap);
  starredState.loadMoreBtn = btn;
}

async function starredLoadPage(isInitial) {
  if (starredState.loading || starredState.done || !currentUser) return;
  starredState.loading = true;
  const mySeq = starredState.seq;
  const limit = isInitial ? STARRED_PAGE_INITIAL : STARRED_PAGE_MORE;
  const list = document.getElementById('starredList');
  const empty = document.getElementById('starredEmpty');

  const moreSkels = [];
  if (!isInitial && list) {
    for (let k = 0; k < limit; k++) {
      const sk = starredMakeCardSkel();
      moreSkels.push(sk);
      list.appendChild(sk);
    }
  }

  let q = supabase
    .from('starred_messages')
    .select('id,source,session_id,msg_id,role,content_snippet,title,created_at')
    .eq('user_id', currentUser.id)
    .order('created_at', { ascending: false })
    .range(starredState.offset, starredState.offset + limit - 1);
  if (starredState.filter !== 'all') q = q.eq('source', starredState.filter);
  const term = mktHistSanitizeSearch(starredState.search);
  if (term) q = q.or('title.ilike.%' + term + '%,content_snippet.ilike.%' + term + '%');

  const res = await q;
  if (mySeq !== starredState.seq) return;

  for (let j = 0; j < moreSkels.length; j++) {
    if (moreSkels[j].parentNode) moreSkels[j].parentNode.removeChild(moreSkels[j]);
  }

  const data = res && res.data;
  if (isInitial && list) { list.innerHTML = ''; starredState.rows = []; }

  if (!data || data.length === 0) {
    if (isInitial && empty) empty.style.display = 'block';
    starredState.done = true;
    starredTeardownLoadMore();
    starredState.loading = false;
    return;
  }

  if (empty) empty.style.display = 'none';
  starredState.rows = starredState.rows.concat(data);
  if (list) data.forEach(function (row) { list.appendChild(starredMakeCard(row)); });
  starredState.offset += data.length;

  if (data.length < limit) { starredState.done = true; starredTeardownLoadMore(); }
  else starredEnsureLoadMoreButton();
  starredState.loading = false;
}

function starredApplyQueryReset(opts) {
  if (opts.search !== undefined) starredState.search = opts.search;
  if (opts.filter !== undefined) starredState.filter = opts.filter;
  starredState.rows = [];
  starredState.offset = 0;
  starredState.done = false;
  starredState.loading = false;
  starredState.seq++;
  starredTeardownLoadMore();
  const list = document.getElementById('starredList');
  const empty = document.getElementById('starredEmpty');
  if (empty) empty.style.display = 'none';
  if (list) {
    list.innerHTML = '';
    for (let i = 0; i < STARRED_PAGE_INITIAL; i++) list.appendChild(starredMakeCardSkel());
  }
  starredLoadPage(true);
}

window.setStarredFilter = function (f) {
  if (starredState.filter === f) return;
  const tabs = document.querySelectorAll('#starredTabs .lib-tab[data-filter]');
  for (let i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-filter') === f);
  starredApplyQueryReset({ filter: f });
};
window.searchStarred = function (v) {
  if (_starredSearchTimer) clearTimeout(_starredSearchTimer);
  _starredSearchTimer = setTimeout(function () { starredApplyQueryReset({ search: v }); }, 250);
};

async function renderStarred() {
  const list = document.getElementById('starredList');
  if (!list || !currentUser) return;
  starredState.filter = 'all';
  starredState.search = '';
  starredState.rows = [];
  starredState.offset = 0;
  starredState.loading = false;
  starredState.done = false;
  starredState.seq++;
  starredTeardownLoadMore();

  const si = document.getElementById('starredSearchInput'); if (si) si.value = '';
  const tabs = document.querySelectorAll('#starredTabs .lib-tab[data-filter]');
  for (let i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-filter') === starredState.filter);

  const empty = document.getElementById('starredEmpty');
  if (empty) empty.style.display = 'none';
  list.innerHTML = '';
  for (let i = 0; i < STARRED_PAGE_INITIAL; i++) list.appendChild(starredMakeCardSkel());

  await starredLoadPage(true);
}
window.renderStarred = renderStarred;

/* Swaps a user bubble's rendered content for an inline edit textarea
   (Edit & Resend). Cancel restores the original bubble HTML; Save commits
   the edit via marketingCommitEdit. Pre-fills with the lightweight display
   caption (not the full extracted/baked content sent to the model) — NOTE:
   if the original message had file/URL attachments, editing and resending
   goes out as plain text only; attachments aren't restored into the edit
   box (a known limitation, flagged separately). */
function marketingStartEditUserMessage(index, div, bubble) {
  if (marketingBusy) return;
  const entry = marketingHistory[index];
  if (!entry || entry.role !== 'user') return;
  const originalHTML = bubble.innerHTML;
  const prefill = entry.displayCaption != null ? entry.displayCaption : entry.content;

  bubble.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.className = 'hcm-edit-wrap';
  const ta = document.createElement('textarea');
  ta.className = 'hcm-edit-textarea';
  ta.value = prefill || '';
  const actions = document.createElement('div');
  actions.className = 'hcm-edit-actions';
  const cancelBtn = document.createElement('button');
  cancelBtn.type = 'button';
  cancelBtn.className = 'hcm-edit-btn';
  cancelBtn.textContent = BatLang.t('chat.cancelBtn') || 'Cancel';
  cancelBtn.addEventListener('click', function () { bubble.innerHTML = originalHTML; });
  const saveBtn = document.createElement('button');
  saveBtn.type = 'button';
  saveBtn.className = 'hcm-edit-btn primary';
  saveBtn.textContent = BatLang.t('chat.saveResendBtn') || 'Save & resend';
  saveBtn.addEventListener('click', function () {
    const newText = ta.value.trim();
    if (!newText) return;
    bubble.innerHTML = originalHTML; // leave the original message untouched
    marketingCommitEdit(newText);
  });
  actions.appendChild(cancelBtn);
  actions.appendChild(saveBtn);
  wrap.appendChild(ta);
  wrap.appendChild(actions);
  bubble.appendChild(wrap);
  ta.focus();
  ta.setSelectionRange(ta.value.length, ta.value.length);
}

/* Commits a Marketing Edit & Resend (append-only): sends the edited text as
   a brand-new user turn at the END of the conversation, exactly as a normal
   user send would — sendMarketingMessage() reads #marketingInput directly,
   so the edited text is set there and the same entry point is invoked.
   Nothing existing is truncated, removed, or replaced. */
function marketingCommitEdit(newText) {
  if (marketingBusy) return;
  const input = document.getElementById('marketingInput');
  if (input) { input.value = newText; input.dispatchEvent(new Event('input')); }
  window.sendMarketingMessage();
}

/* Regenerate (append-only): resends the original user text as a brand-new
   user turn at the END of the conversation, exactly as a normal user send
   would (via #marketingInput + sendMarketingMessage) — which handles
   extraction, structured-mode detection, thinking bubble and reply on its
   own. Nothing existing is touched, removed, or replaced. Uses the
   lightweight display caption (attachments aren't re-restored — same known
   plain-text limitation as Edit). */
function marketingRegenerateUserMessage(index) {
  if (marketingBusy) return;
  const entry = marketingHistory[index];
  if (!entry || entry.role !== 'user') return;
  const text = entry.displayCaption != null ? entry.displayCaption : entry.content;
  const input = document.getElementById('marketingInput');
  if (input) { input.value = text; input.dispatchEvent(new Event('input')); }
  window.sendMarketingMessage();
}

// Toggles the Marketing view between its "New Analysis" composer and the
// "History" browse panel (a sub-view of the Marketing tool, not a new
// sidebar entry) — mirrors the .lib-tab active-state convention used by
// the Library grid/list view toggle.
window.showMarketingSubview = function (subview) {
  const tabs = document.querySelectorAll('#marketingSubviewTabs .lib-tab[data-subview]');
  for (let i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].getAttribute('data-subview') === subview);
  const newPanel = document.getElementById('marketingNewPanel');
  const histPanel = document.getElementById('marketingHistoryPanel');
  const analyticsPanel = document.getElementById('marketingAnalyticsPanel');
  if (newPanel) newPanel.style.display = subview === 'new' ? 'flex' : 'none';
  if (histPanel) histPanel.style.display = subview === 'history' ? 'flex' : 'none';
  if (analyticsPanel) analyticsPanel.style.display = subview === 'analytics' ? 'flex' : 'none';
  if (subview === 'history') renderMktHistory();
  if (subview === 'new') mktRecentStripLoad();
  if (subview === 'analytics') renderMktAnalytics();
};

/* ══════════════════════════════════════════════════════════════
   FEATURE PACK: AI Suggestions · One-Click Fix · Real ZIP ·
   Next.js Export · GitHub Push · Keyboard Shortcuts
   ══════════════════════════════════════════════════════════════ */
(function featurePackCore() {

  /* ── track the last generation error so "Fix Automatically" has context ── */
  window.__lastGenError = '';
  var _origRG_fix = window.runGeneration;
  if (_origRG_fix && !window.__fixHooked) {
    window.__fixHooked = true;
    window.runGeneration = async function (prompt, type, subtype, opts) {
      try {
        var result = await _origRG_fix(prompt, type, subtype, opts);
        window.__lastGenError = '';
        return result;
      } catch (err) {
        window.__lastGenError = (err && err.message) ? err.message : 'unknown_error';
        throw err;
      }
    };
  }

  /* ── 1. AI SUGGESTIONS — one click, reuses the iterative-edit (baseHTML) path ── */
  var SUGGESTIONS = {
    seo: 'Improve this page\'s SEO: add/complete <title>, meta description, Open Graph tags, one clear <h1>, descriptive alt text on every image, semantic HTML5 landmarks, and a canonical link. Do not change the visual design.',
    ui: 'Improve the overall UI: refine spacing, alignment, visual hierarchy, color contrast and typography so it looks more polished and professional. Keep all existing functionality and content exactly the same.',
    dark: 'Add a proper dark mode: switch the color palette to a well-contrasted dark theme (dark backgrounds, light text, adjusted accent colors) while keeping the same layout and functionality.',
    animate: 'Add tasteful, lightweight CSS animations and micro-interactions: fade/slide-ins on scroll or load, smooth hover/focus transitions on buttons and cards. Keep them subtle and do not affect performance or layout.',
    mobile: 'Optimize this page for mobile: fix any overflow, tighten spacing and font sizes for small screens, make sure buttons/tap targets are at least 44px, and verify the layout reflows cleanly at 375px width.'
  };
  window.aiSuggestApply = function (kind) {
    if (!lastHTML) { showToast('Generate something first!', 'info'); return; }
    var prompt = SUGGESTIONS[kind];
    if (!prompt) return;
    document.querySelectorAll('.hw-sugg-btn').forEach(function (b) { b.disabled = true; });
    window.runGeneration(prompt, lastType || 'website', lastSubtype, { baseHTML: lastHTML })
      .catch(function () {})
      .finally(function () {
        document.querySelectorAll('.hw-sugg-btn').forEach(function (b) { b.disabled = false; });
      });
  };

  /* ── 2. ONE-CLICK FIX — retries the same edit but explicitly tells the model to fix the failure ── */
  window.aiOneClickFix = function () {
    if (!lastAttempt) { showToast('Nothing to fix yet.', 'info'); return; }
    var base = lastHTML || (lastAttempt.opts && lastAttempt.opts.baseHTML) || '';
    var errNote = window.__lastGenError ? (' The last attempt failed with: ' + window.__lastGenError + '.') : '';
    var fixPrompt = 'The previous generation failed or produced broken output.' + errNote +
      ' Please fix it and return a complete, working, self-contained HTML file. Original request: ' + (lastAttempt.prompt || '');
    var opts = base ? { baseHTML: base } : (lastAttempt.opts || {});
    window.runGeneration(fixPrompt, lastAttempt.type || 'website', lastAttempt.subtype, opts);
  };

  /* ── 3. REAL ZIP + NEXT.JS EXPORT — wraps existing exportAs, adds new formats ── */
  var _origExportAs = window.exportAs;
  window.exportAs = function (format) {
    if (!lastHTML) { return _origExportAs && _origExportAs(format); }
    var type = lastType || 'project';
    var ts = Date.now();
    // Serve-time badge (Free tier only) — nextjs/zip are handled here; other
    // formats delegate to _origExportAs, which badges independently.
    var outHTML = withBatnxtBadge(lastHTML);

    function dl(content, filename, mime) {
      var blob = new Blob([content], { type: mime || 'text/plain' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url; a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
    }

    if (format === 'nextjs') {
      var safeNext = outHTML.replace(/`/g, '\\`').replace(/\$/g, '\\$');
      var page = "// app/page.jsx — drop into a Next.js 13+ App Router project\n" +
        "'use client';\nimport { useEffect, useRef } from 'react';\n\n" +
        "const MARKUP = `" + safeNext + "`;\n\n" +
        "export default function Page() {\n" +
        "  const ref = useRef(null);\n" +
        "  useEffect(() => {\n" +
        "    if (!ref.current) return;\n" +
        "    // Re-run inline <script> tags, since dangerouslySetInnerHTML does not execute them.\n" +
        "    ref.current.querySelectorAll('script').forEach((old) => {\n" +
        "      const s = document.createElement('script');\n" +
        "      if (old.src) s.src = old.src; else s.textContent = old.textContent;\n" +
        "      old.replaceWith(s);\n" +
        "    });\n" +
        "  }, []);\n" +
        "  return <div ref={ref} dangerouslySetInnerHTML={{ __html: MARKUP }} />;\n" +
        "}\n";
      dl(page, 'page.jsx', 'text/javascript');
      showToast('✅ Next.js page.jsx downloaded!', 'success');
      window.closeExportModal();
      if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('export', 'nextjs');
      return;
    }

    if (format === 'zip') {
      if (typeof JSZip === 'undefined') {
        showToast('ZIP library failed to load — check your connection.', 'error');
        return;
      }
      var zip = new JSZip();
      zip.file('index.html', outHTML);
      zip.file('README.md',
        '# BatNXT Generated Project\n\nType: ' + type + '\nGenerated: ' + new Date().toISOString() +
        '\n\nOpen index.html in any browser, or run a static server:\n\n```\nnpx serve .\n```\n\nMade with BatNXT AI.\n');
      zip.file('package.json', JSON.stringify({
        name: 'batnxt-' + type + '-' + ts,
        version: '1.0.0',
        private: true,
        scripts: { start: 'npx serve .' }
      }, null, 2));
      zip.generateAsync({ type: 'blob' }).then(function (blob) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = 'batnxt-' + type + '-' + ts + '.zip';
        document.body.appendChild(a); a.click(); a.remove();
        URL.revokeObjectURL(url);
        showToast('✅ ZIP project downloaded!', 'success');
      }).catch(function () {
        showToast('Could not build ZIP file.', 'error');
      });
      window.closeExportModal();
      if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('export', 'zip');
      return;
    }

    return _origExportAs(format);
  };

  /* ── 4. GITHUB PUSH — uses the GitHub Contents API directly from the browser ── */
  window.showGithubPushModal = function () {
    if (!lastHTML) { showToast('Generate something first!', 'info'); return; }
    window.closeExportModal();
    var overlay = document.getElementById('githubPushOverlay');
    if (overlay) overlay.classList.add('active');
  };
  window.closeGithubPushModal = function () {
    var overlay = document.getElementById('githubPushOverlay');
    if (overlay) overlay.classList.remove('active');
  };

  async function ghApi(url, token, opts) {
    opts = opts || {};
    var res = await fetch('https://api.github.com' + url, Object.assign({
      headers: {
        Authorization: 'Bearer ' + token,
        Accept: 'application/vnd.github+json',
        'Content-Type': 'application/json'
      }
    }, opts));
    return res;
  }

  window.doGithubPush = async function () {
    var token = (document.getElementById('ghTokenInput') || {}).value || '';
    var repoField = (document.getElementById('ghRepoInput') || {}).value || '';
    var priv = !!(document.getElementById('ghPrivateCheck') || {}).checked;
    var statusEl = document.getElementById('ghPushStatus');
    var btn = document.getElementById('ghPushBtn');
    function setStatus(msg) { if (statusEl) statusEl.textContent = msg; }

    if (!token) { setStatus('⚠️ Enter your GitHub token first.'); return; }
    if (!repoField.includes('/')) { setStatus('⚠️ Use the format owner/repo-name.'); return; }
    if (!lastHTML) { setStatus('⚠️ Nothing generated yet.'); return; }

    var parts = repoField.split('/');
    var owner = parts[0], repo = parts.slice(1).join('/');
    if (btn) btn.disabled = true;
    setStatus('Checking repository...');

    try {
      var repoRes = await ghApi('/repos/' + owner + '/' + repo, token);
      if (repoRes.status === 404) {
        setStatus('Repo not found — creating it...');
        var createRes = await ghApi('/user/repos', token, {
          method: 'POST',
          body: JSON.stringify({ name: repo, private: priv, auto_init: true, description: 'Generated with BatNXT AI' })
        });
        if (!createRes.ok) {
          var cErr = await createRes.json().catch(function () { return {}; });
          throw new Error(cErr.message || 'Could not create repository');
        }
        setStatus('Repository created. Uploading files...');
        await new Promise(function (r) { setTimeout(r, 1200); }); // let GitHub finish init
      } else if (!repoRes.ok) {
        var vErr = await repoRes.json().catch(function () { return {}; });
        throw new Error(vErr.message || 'Could not access repository');
      } else {
        setStatus('Repository found. Uploading files...');
      }

      async function putFile(path, content, message) {
        var getRes = await ghApi('/repos/' + owner + '/' + repo + '/contents/' + path, token);
        var sha = null;
        if (getRes.ok) { var existing = await getRes.json(); sha = existing.sha; }
        var body = {
          message: message,
          content: btoa(unescape(encodeURIComponent(content)))
        };
        if (sha) body.sha = sha;
        var putRes = await ghApi('/repos/' + owner + '/' + repo + '/contents/' + path, token, {
          method: 'PUT',
          body: JSON.stringify(body)
        });
        if (!putRes.ok) {
          var pErr = await putRes.json().catch(function () { return {}; });
          throw new Error(pErr.message || ('Failed to upload ' + path));
        }
      }

      await putFile('index.html', lastHTML, 'Update index.html via BatNXT AI');
      var readme = '# ' + repo + '\n\nGenerated with [BatNXT AI](https://batnxt.ai).\n\nOpen `index.html` in any browser, or deploy the folder to any static host (GitHub Pages, Netlify, Vercel, Cloudflare Pages).\n';
      await putFile('README.md', readme, 'Add README via BatNXT AI');

      setStatus('✅ Pushed successfully!');
      showToast('✅ Pushed to github.com/' + owner + '/' + repo, 'success');
      if (typeof window.trackAnalyticsEvent === 'function') window.trackAnalyticsEvent('export', 'github');
    } catch (err) {
      setStatus('❌ ' + (err.message || 'Push failed.'));
      showToast('GitHub push failed: ' + (err.message || 'unknown error'), 'error');
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  /* ── 5. KEYBOARD SHORTCUTS ── */
  window.showShortcutsModal = function () {
    var o = document.getElementById('shortcutsOverlay');
    if (o) o.classList.add('active');
  };
  window.closeShortcutsModal = function () {
    var o = document.getElementById('shortcutsOverlay');
    if (o) o.classList.remove('active');
  };

  document.addEventListener('keydown', function (e) {
    var typingInField = e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable);
    var ctrl = e.ctrlKey || e.metaKey;

    if (ctrl && !e.shiftKey && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      var promptBox = document.getElementById('hwFollowupInput') ||
        document.getElementById('homePromptInput') ||
        document.querySelector('textarea');
      if (promptBox) promptBox.focus();
      return;
    }
    if (ctrl && !e.shiftKey && e.key === '/') {
      e.preventDefault();
      window.showShortcutsModal();
      return;
    }
    if (ctrl && e.key === 'Enter') {
      e.preventDefault();
      if (typeof window.hwFollowupSend === 'function') window.hwFollowupSend();
      return;
    }
    if (ctrl && !e.shiftKey && e.key.toLowerCase() === 'e') {
      if (typingInField) return;
      e.preventDefault();
      if (typeof window.toggleDDB === 'function') window.toggleDDB();
      return;
    }
    if (ctrl && e.shiftKey && e.key.toLowerCase() === 'e') {
      e.preventDefault();
      if (typeof window.showExportModal === 'function') window.showExportModal();
      return;
    }
    if (e.key === 'Escape') {
      window.closeShortcutsModal();
      if (typeof window.closeGithubPushModal === 'function') window.closeGithubPushModal();
      batmanClose();
    }
  });

  /* ── /batman MODE ────────────────────────────────────────────────────── */
  var _batActiveFeats = new Set();
  var _batSourceInput = null;

  var BAT_FEAT_PROMPTS = {
    deepsearch: '[DEEP SEARCH ENABLED: Cross-reference multiple real-world sources, cite evidence, and verify facts thoroughly]',
    turbo:      '[TURBO MODE: Maximize response quality, depth, and completeness with no compromises]',
    memory:     '[MEMORY BOOST: Recall and utilize full conversation context with high precision]',
    precision:  '[PRECISION ANALYSIS: Provide ultra-detailed, step-by-step structured reasoning]',
    creative:   '[CREATIVE UNLEASH: Generate bold, unconventional, high-impact ideas without limits]',
    code:       '[CODE EXPERT: Respond as a senior software engineer — review, refactor, debug, and explain at an expert level]',
  };

  window.batmanCheckInput = function batmanCheckInput(inputEl) {
    var val = inputEl.value;
    var panel = document.getElementById('batmanPanel');
    if (!panel) return;
    if (/^\s*\/batman/i.test(val)) {
      _batSourceInput = inputEl;
      panel.classList.add('active');
    } else {
      panel.classList.remove('active');
    }
  }

  window.batmanClose = function () {
    var panel = document.getElementById('batmanPanel');
    if (panel) panel.classList.remove('active');
  };

  window.batmanToggle = function (btn) {
    var feat = btn.dataset.feat;
    if (!feat) return;
    if (_batActiveFeats.has(feat)) {
      _batActiveFeats.delete(feat);
      btn.classList.remove('active-feat');
    } else {
      _batActiveFeats.add(feat);
      btn.classList.add('active-feat');
    }
    var countEl = document.getElementById('batActiveCount');
    if (countEl) countEl.textContent = _batActiveFeats.size;
  };

  window.batmanApply = function () {
    var panel = document.getElementById('batmanPanel');
    if (!panel) return;

    // Build the modifier prefix from all active features
    var prefix = '';
    _batActiveFeats.forEach(function (feat) {
      if (BAT_FEAT_PROMPTS[feat]) prefix += BAT_FEAT_PROMPTS[feat] + ' ';
    });
    prefix = prefix.trim();

    // Determine which input field to use
    var inp = _batSourceInput ||
              document.getElementById('chatInput') ||
              document.getElementById('homeInput');

    if (inp) {
      // Strip the /batman trigger text (including any leading spaces), keep anything typed after it
      var rawVal = inp.value || '';
      var afterCmd = rawVal.replace(/^\s*\/batman\s*/i, '').trim();
      // Compose final message
      var finalMsg = prefix ? (prefix + (afterCmd ? ' ' + afterCmd : '')) : afterCmd;
      inp.value = finalMsg;
      inp.dispatchEvent(new Event('input'));
    }

    // Close panel and reset
    panel.classList.remove('active');
    panel.querySelectorAll('.bat-feat-btn').forEach(function (b) { b.classList.remove('active-feat'); });
    _batActiveFeats.clear();
    var countEl = document.getElementById('batActiveCount');
    if (countEl) countEl.textContent = '0';
    _batSourceInput = null;

    // Fire the send action
    if (inp && inp.id === 'chatInput') {
      if (typeof sendChatMessage === 'function') sendChatMessage();
    } else {
      if (typeof window.homeGoGenerate === 'function') window.homeGoGenerate();
    }
  };

  /* ── Slash-command autocomplete for homeInput ──────────────────────────
     Type /  →  dropdown of available model shortcuts.
     Type /ba → filtered list (batman …).
     Pick one → inserts /commandname + switches the model.
     If a recognized /command is in the text → word is highlighted via mirror.
     Unrecognized partial → no color, just dropdown filtering.
  ─────────────────────────────────────────────────────────────────────── */
  (function initSlashCommands() {
    var SLASH_COMMANDS = [
      { name: 'batman',  model: 'BAT 1.2',       desc: 'Deep thinking · best all-round',        tier: 'pro'  },
      { name: 'flash',   model: 'BAT 1.2 Flash', desc: 'Faster, lighter builds',                 tier: 'free' },
      { name: 'alfred',  model: 'Alfred',         desc: 'Alfred Ultra · elite agent mode',        tier: 'pro'  },
    ];

    function init() {
      var inp = document.getElementById('homeInput');
      var drop = document.getElementById('slashCmdDrop');
      var mirror = document.getElementById('homeInputMirror');
      if (!inp || !drop || !mirror) return;

      var activeIdx = -1;
      var currentMatches = [];

      /* Sync mirror's font metrics to match the textarea exactly (resolves
         any font-size/weight differences introduced by media queries). */
      function syncMirrorStyle() {
        var cs = window.getComputedStyle(inp);
        ['fontFamily','fontSize','fontWeight','lineHeight',
         'letterSpacing','wordSpacing','textTransform'].forEach(function(p) {
          mirror.style[p] = cs[p];
        });
      }
      syncMirrorStyle();
      // Re-sync on resize (viewport changes can trigger media query switches)
      window.addEventListener('resize', syncMirrorStyle);

      /* ── helpers ── */
      function escHtml(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      }

      /* Extract the /word immediately before the cursor, or null */
      function getSlashWord(text, cursor) {
        var before = text.slice(0, cursor);
        var m = before.match(/\/(\w*)$/);
        return m ? m : null; // [fullMatch, group1]
      }

      /* Build dropdown HTML for a list of matching commands */
      function renderDrop(matches) {
        activeIdx = -1;
        currentMatches = matches;
        if (!matches.length) { drop.style.display = 'none'; return; }

        var html = '<div class="slash-cmd-header">Models</div>';
        html += matches.map(function(cmd, i) {
          var tierCls = 'sci-tier sci-tier-' + cmd.tier;
          var tierLabel = cmd.tier === 'free' ? 'FREE' : cmd.tier === 'pro' ? 'PRO' : 'MAX';
          return '<button type="button" class="slash-cmd-item" role="option" data-idx="' + i + '">' +
            '<span class="sci-slash">/</span>' +
            '<span class="sci-name">' + escHtml(cmd.name) + '</span>' +
            '<span class="' + tierCls + '">' + tierLabel + '</span>' +
            '<span class="sci-desc">' + escHtml(cmd.desc) + '</span>' +
          '</button>';
        }).join('');

        drop.innerHTML = html;
        drop.style.display = 'block';

        drop.querySelectorAll('.slash-cmd-item').forEach(function(btn) {
          btn.addEventListener('mousedown', function(e) {
            e.preventDefault(); // don't blur textarea
            applyCmd(currentMatches[parseInt(btn.dataset.idx, 10)]);
          });
        });
      }

      function setActiveRow(idx) {
        activeIdx = Math.max(0, Math.min(idx, currentMatches.length - 1));
        drop.querySelectorAll('.slash-cmd-item').forEach(function(b, i) {
          b.classList.toggle('active', i === activeIdx);
        });
        var active = drop.querySelector('.slash-cmd-item.active');
        if (active) active.scrollIntoView({ block: 'nearest' });
      }

      /* Replace the /query in the textarea with /cmdname + space, then switch model */
      function applyCmd(cmd) {
        if (!cmd) return;
        var cursor = inp.selectionStart;
        var text = inp.value;
        var m = text.slice(0, cursor).match(/\/(\w*)$/);
        if (!m) return;
        var start = cursor - m[0].length;
        var inserted = '/' + cmd.name + ' ';
        inp.value = text.slice(0, start) + inserted + text.slice(cursor);
        var newCursor = start + inserted.length;
        inp.setSelectionRange(newCursor, newCursor);
        drop.style.display = 'none';
        inp.dispatchEvent(new Event('input'));
        // Switch model
        try {
          var optEl = document.querySelector('.home-model-opt[data-model="' + cmd.model + '"]');
          if (typeof window.selectModel === 'function') window.selectModel(cmd.model, optEl || null);
        } catch(e) {}
        inp.focus();
      }

      /* Mirror overlay: color recognized /commands, keep textarea text invisible */
      function updateMirror(text) {
        if (!text) { mirror.innerHTML = ''; inp.classList.remove('hsc-active'); return; }

        // Build a regex of all known command names for exact match
        var names = SLASH_COMMANDS.map(function(c){ return c.name; }).join('|');
        var re = new RegExp('/(' + names + ')(?=\\s|$)', 'g');

        if (!re.test(text)) {
          mirror.innerHTML = '';
          inp.classList.remove('hsc-active');
          return;
        }
        re.lastIndex = 0;

        // Rebuild HTML: escape everything, wrap matching /commands in .hsc
        var escaped = escHtml(text);
        // We need to apply the regex on the escaped string; since command names
        // are alphanumeric the escape doesn't change them.
        var highlighted = escaped.replace(re, '<span class="hsc">/$1</span>');
        // zero-width space keeps height correct when text ends with a match
        mirror.innerHTML = highlighted + '\u200B';
        inp.classList.add('hsc-active');
      }

      /* ── Event listeners ── */
      inp.addEventListener('input', function() {
        var text = inp.value;
        var cursor = inp.selectionStart;
        updateMirror(text);

        var m = getSlashWord(text, cursor);
        if (!m) { drop.style.display = 'none'; return; }

        var query = m[1].toLowerCase();
        var matches = SLASH_COMMANDS.filter(function(c) {
          return c.name.startsWith(query);
        });
        renderDrop(matches);
      });

      inp.addEventListener('keydown', function(e) {
        if (drop.style.display === 'none') return;
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          setActiveRow(activeIdx < 0 ? 0 : activeIdx + 1);
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          setActiveRow(activeIdx <= 0 ? 0 : activeIdx - 1);
        } else if (e.key === 'Enter' && activeIdx >= 0) {
          e.preventDefault();
          e.stopPropagation();
          applyCmd(currentMatches[activeIdx]);
        } else if (e.key === 'Escape') {
          drop.style.display = 'none';
          activeIdx = -1;
        } else if (e.key === 'Tab' && activeIdx >= 0) {
          e.preventDefault();
          applyCmd(currentMatches[activeIdx]);
        }
      });

      inp.addEventListener('click', function() {
        // Re-evaluate on click in case cursor moved into a / word
        inp.dispatchEvent(new Event('input'));
      });

      /* Keep mirror scroll position in sync when textarea overflows max-height */
      inp.addEventListener('scroll', function() {
        mirror.scrollTop = inp.scrollTop;
      });

      inp.addEventListener('blur', function() {
        // Small delay so mousedown on a drop item fires first
        setTimeout(function() {
          if (drop.style.display !== 'none') drop.style.display = 'none';
        }, 180);
      });
    }

    // Run after DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  })();

  /* ── Wheel-scroll delegation for hcm-active home view ──────────────────
     Allows scrolling the conversation by wheeling anywhere inside the
     .home-view#homeView.hcm-active — not just when the cursor is over
     the messages container itself.
  ─────────────────────────────────────────────────────────────────────── */
  (function initHomeScrollDelegate() {
    function setup() {
      var homeView = document.getElementById('homeView');
      if (!homeView) return;

      homeView.addEventListener('wheel', function(e) {
        // Only active in chat mode
        if (!homeView.classList.contains('hcm-active')) return;

        var msgs = document.getElementById('homeConvMessages');
        if (!msgs) return;

        // Walk up from the event target: if any element between target and
        // homeView has its own scrollable overflow (and is NOT msgs itself),
        // let that element handle the wheel event naturally.
        var el = e.target;
        while (el && el !== homeView) {
          if (el !== msgs) {
            var style = window.getComputedStyle(el);
            var ov = style.overflowY;
            if ((ov === 'auto' || ov === 'scroll') && el.scrollHeight > el.clientHeight) {
              var goingDown = e.deltaY > 0;
              var atBottom = el.scrollTop >= el.scrollHeight - el.clientHeight - 1;
              var atTop = el.scrollTop <= 0;
              // Only intercept if child can't scroll further in that direction
              if ((goingDown && !atBottom) || (!goingDown && !atTop)) return;
            }
          }
          el = el.parentElement;
        }

        // Forward to conversation messages
        e.preventDefault();
        msgs.scrollBy({ top: e.deltaY, behavior: 'auto' });
      }, { passive: false });
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setup);
    } else {
      setup();
    }
  })();

  /* ── Share Chat Modal ───────────────────────────────────────────────── */
  var _scmSelection = 'private';
  // Set to { id, share_token } when the open conversation already has an
  // active row in conversation_shares — lets the modal offer "Stop sharing"
  // and reuse the existing link instead of minting a new one every time.
  var _scmActiveShare = null;

  window.openShareChatModal = async function openShareChatModal() {
    var modal = document.getElementById('shareChatModal');
    if (!modal) return;
    _scmActiveShare = null;
    _scmSelection = 'private';
    scmSelect('private');
    var copied = document.getElementById('scmCopied');
    if (copied) copied.classList.remove('show');
    var btn = document.getElementById('scmCreateBtn');
    if (btn) { btn.textContent = 'Create share link'; btn.disabled = false; }
    var stopBtn = document.getElementById('scmStopBtn');
    if (stopBtn) stopBtn.style.display = 'none';
    modal.style.display = 'flex';
    document.addEventListener('keydown', _scmKeyHandler);

    // If this conversation already has an active public share, reflect
    // that in the modal (public option selected + Stop Sharing shown)
    // instead of defaulting to "Keep private". Fails silently (stays on
    // the private default) if the session isn't saved yet, the user is
    // signed out, or the migration in db/schema_conversation_sharing.sql
    // hasn't been applied yet.
    if (typeof homeConvSessionId !== 'undefined' && homeConvSessionId && currentUser) {
      try {
        var res = await supabase.from('conversation_shares')
          .select('id, share_token')
          .eq('session_id', homeConvSessionId)
          .eq('is_active', true)
          .maybeSingle();
        if (res && res.data && modal.style.display !== 'none') {
          _scmActiveShare = res.data;
          _scmSelection = 'public';
          scmSelect('public');
          if (btn) btn.textContent = 'Copy link';
        }
      } catch (e) { /* ignore — modal stays in default private state */ }
    }
  };

  window.closeShareChatModal = function closeShareChatModal() {
    var modal = document.getElementById('shareChatModal');
    if (modal) modal.style.display = 'none';
    document.removeEventListener('keydown', _scmKeyHandler);
  };

  function _scmKeyHandler(e) {
    if (e.key === 'Escape') window.closeShareChatModal();
  }

  window.scmSelect = function scmSelect(choice) {
    _scmSelection = choice;
    var optPriv = document.getElementById('scmOptPrivate');
    var optPub  = document.getElementById('scmOptPublic');
    if (optPriv) optPriv.classList.toggle('selected', choice === 'private');
    if (optPub)  optPub.classList.toggle('selected',  choice === 'public');
    var stopBtn = document.getElementById('scmStopBtn');
    if (stopBtn) stopBtn.style.display = (_scmActiveShare && choice === 'public') ? '' : 'none';
  };

  function scmCopyUrl(shareUrl, btn, copied) {
    try {
      navigator.clipboard.writeText(shareUrl).then(function() {
        btn.disabled = false;
        btn.textContent = 'Copy link';
        if (copied) copied.classList.add('show');
        setTimeout(function() { if (copied) copied.classList.remove('show'); }, 1800);
      }).catch(function() {
        btn.disabled = false;
        btn.textContent = shareUrl;
      });
    } catch (err) {
      btn.disabled = false;
      btn.textContent = shareUrl;
    }
  }

  window.scmCreateLink = async function scmCreateLink() {
    var btn = document.getElementById('scmCreateBtn');
    var copied = document.getElementById('scmCopied');
    if (!btn) return;

    if (_scmSelection === 'private') {
      // Nothing to share — just close. This does NOT revoke an existing
      // public link; use the dedicated "Stop sharing" button for that.
      window.closeShareChatModal();
      return;
    }

    if (!homeConvSessionId || !currentUser) {
      btn.textContent = 'Start chatting first';
      setTimeout(function() { btn.textContent = 'Create share link'; }, 1800);
      return;
    }

    // A live link already exists for this conversation — just copy it
    // again rather than minting a second, redundant share row.
    if (_scmActiveShare) {
      scmCopyUrl(window.location.origin + '/share/' + _scmActiveShare.share_token, btn, copied);
      return;
    }

    btn.disabled = true;
    btn.textContent = 'Creating link…';

    try {
      var token = (window.crypto && crypto.randomUUID)
        ? crypto.randomUUID().replace(/-/g, '')
        : (Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2));
      var res = await supabase.from('conversation_shares')
        .insert({ session_id: homeConvSessionId, user_id: currentUser.id, share_token: token })
        .select('id, share_token')
        .single();
      if (res.error || !res.data) throw res.error || new Error('Insert failed');
      _scmActiveShare = res.data;
      var stopBtn = document.getElementById('scmStopBtn');
      if (stopBtn) stopBtn.style.display = '';
      scmCopyUrl(window.location.origin + '/share/' + res.data.share_token, btn, copied);
    } catch (err) {
      console.error('Failed to create share link:', err);
      btn.disabled = false;
      btn.textContent = 'Could not create link — try again';
      setTimeout(function() { btn.textContent = 'Create share link'; }, 2200);
    }
  };

  /* Revokes the active share for the open conversation (soft-delete:
     is_active=false + revoked_at), so the link stops resolving on
     share.html but the row is kept for an audit trail. */
  window.scmStopSharing = async function scmStopSharing() {
    if (!_scmActiveShare) return;
    var stopBtn = document.getElementById('scmStopBtn');
    var btn = document.getElementById('scmCreateBtn');
    var copied = document.getElementById('scmCopied');
    if (stopBtn) { stopBtn.disabled = true; stopBtn.textContent = 'Stopping…'; }
    try {
      await supabase.from('conversation_shares')
        .update({ is_active: false, revoked_at: new Date().toISOString() })
        .eq('id', _scmActiveShare.id);
    } catch (e) {
      console.error('Failed to stop sharing:', e);
    }
    _scmActiveShare = null;
    if (copied) copied.classList.remove('show');
    if (stopBtn) { stopBtn.disabled = false; stopBtn.textContent = 'Stop sharing'; stopBtn.style.display = 'none'; }
    if (btn) { btn.disabled = false; btn.textContent = 'Create share link'; }
    _scmSelection = 'private';
    scmSelect('private');
  };

  // Close modal when clicking the backdrop
  (function() {
    function setupShareBackdrop() {
      var modal = document.getElementById('shareChatModal');
      if (!modal) return;
      modal.addEventListener('click', function(e) {
        if (e.target === modal) window.closeShareChatModal();
      });
    }
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setupShareBackdrop);
    } else {
      setupShareBackdrop();
    }
  })();

})();