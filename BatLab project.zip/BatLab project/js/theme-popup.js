/* Theme picker popup removed — the site now defaults to dark theme for
   every visitor (see the no-flash theme script in each page's <head>).
   This file is intentionally left as a no-op so existing <script src>
   references don't 404. */
