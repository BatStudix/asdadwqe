/* ── Site-wide, one-time theme picker popup ──
   Shows a Dark/Light choice to every visitor (logged in or not) the very
   first time they land on any BatNXT page. The choice is stored in
   localStorage (`batlab_theme` + `batlab_theme_picked`) and can be changed
   later from Settings. Never shows again once a choice has been made. */
(function () {
  "use strict";

  try {
    if (localStorage.getItem("batlab_theme_picked")) return;
  } catch (e) {
    return;
  }

  function inject() {
    if (document.getElementById("themePickOverlay")) return;

    var lang = "en";
    try {
      lang = localStorage.getItem("batlab_lang") || "en";
    } catch (e) {}
    var isAr = lang === "ar";
    var dir = isAr ? "rtl" : "ltr";

    var text = isAr
      ? {
          title: "اختر مظهرك المفضل",
          sub: "يمكنك تغيير هذا لاحقاً من الإعدادات.",
          dark: "داكن",
          light: "فاتح"
        }
      : {
          title: "Choose your look",
          sub: "You can change this later from Settings.",
          dark: "Dark",
          light: "Light"
        };

    var overlay = document.createElement("div");
    overlay.id = "themePickOverlay";
    overlay.setAttribute("dir", dir);
    overlay.style.cssText =
      "position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;" +
      "background:rgba(4,6,12,0.72);" +
      "padding:20px;font-family:'Poppins',sans-serif;";

    var card = document.createElement("div");
    card.style.cssText =
      "width:100%;max-width:380px;background:#0f1420;border:1px solid #1a2235;border-radius:16px;" +
      "padding:28px 24px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.45);";

    var title = document.createElement("h2");
    title.textContent = text.title;
    title.style.cssText = "margin:0 0 8px;color:#eef2f7;font-size:1.15rem;font-weight:800;";

    var sub = document.createElement("p");
    sub.textContent = text.sub;
    sub.style.cssText = "margin:0 0 20px;color:#aab3c2;font-size:0.85rem;line-height:1.5;";

    var picker = document.createElement("div");
    picker.style.cssText = "display:flex;gap:10px;";

    function makeOption(key, label, iconSvg) {
      var opt = document.createElement("button");
      opt.type = "button";
      opt.style.cssText =
        "flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;" +
        "background:#151b2b;border:1px solid #1a2235;border-radius:12px;padding:18px 10px;" +
        "color:#aab3c2;font-family:'Poppins',sans-serif;font-weight:700;font-size:0.85rem;" +
        "cursor:pointer;transition:border-color .15s,background .15s,color .15s;";
      opt.innerHTML = iconSvg + '<span style="margin-top:2px;">' + label + "</span>";
      opt.addEventListener("mouseenter", function () {
        opt.style.borderColor = "rgba(0,232,154,0.4)";
      });
      opt.addEventListener("mouseleave", function () {
        opt.style.borderColor = "#1a2235";
      });
      opt.addEventListener("click", function () {
        choose(key);
      });
      return opt;
    }

    var darkIcon =
      '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
    var lightIcon =
      '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';

    picker.appendChild(makeOption("dark", text.dark, darkIcon));
    picker.appendChild(makeOption("light", text.light, lightIcon));

    card.appendChild(title);
    card.appendChild(sub);
    card.appendChild(picker);
    overlay.appendChild(card);
    document.body.appendChild(overlay);
  }

  function choose(t) {
    try {
      localStorage.setItem("batlab_theme", t);
      localStorage.setItem("batlab_theme_picked", "1");
    } catch (e) {}
    location.reload();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", inject);
  } else {
    inject();
  }
})();
