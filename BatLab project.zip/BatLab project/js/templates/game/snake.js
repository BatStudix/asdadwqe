/* ── Snake template: grid-based movement, growing tail, wall/self collision,
   optional wrap-around, powerups, sound, and localStorage high score.
   Layout/CSS/game-loop are static and hand-authored — only colors, controls,
   difficulty, and feature flags come from the AI plan. ── */

import { escapeHtml, safeColor, filterFeatures } from '../helpers.js';

const ALLOWED_FEATURES = ['highscore', 'walls', 'powerups', 'sound'];
const SPEED_MS = { easy: 180, normal: 130, hard: 90 };

export function renderSnake(plan) {
  const style = (plan && plan.style) || {};
  const player = (plan && plan.player) || {};
  const enemy = (plan && plan.enemy) || {};
  const theme = style.theme === 'light' ? 'light' : 'dark';
  const colors = (style && style.colors) || {};
  const background = safeColor(colors.background, theme === 'light' ? '#f7f7fb' : '#0d0d14');
  const primary = safeColor(colors.primary, '#00cec9');
  const snakeColor = safeColor(player.color, primary);
  const foodColor = safeColor(enemy.color, '#fd79a8');
  const difficulty = ['easy', 'normal', 'hard'].includes(plan && plan.difficulty) ? plan.difficulty : 'normal';
  const controls = ['arrows', 'wasd', 'touch'].includes(plan && plan.controls) ? plan.controls : 'arrows';
  const features = filterFeatures(plan && plan.features, ALLOWED_FEATURES);
  const hasHighscore = features.includes('highscore');
  const hasWalls = features.includes('walls');
  const hasPowerups = features.includes('powerups');
  const hasSound = features.includes('sound');
  const speedMs = SPEED_MS[difficulty];
  const title = escapeHtml((plan && plan.content && plan.content.brand) || 'Snake');

  return '<!DOCTYPE html>\n' +
'<html lang="en">\n' +
'<head>\n' +
'<meta charset="UTF-8">\n' +
'<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">\n' +
'<title>' + title + '</title>\n' +
'<style>\n' +
'*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}\n' +
'html,body{height:100%;overflow:hidden}\n' +
'body{background:' + background + ';color:#f5f5fa;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:16px}\n' +
'.sn-hud{display:flex;gap:24px;font-size:1rem;font-weight:600}\n' +
'.sn-hud span{opacity:.55;font-weight:500;margin-right:6px}\n' +
'#snCanvas{background:#000;border-radius:12px;border:1px solid #22222e;max-width:94vw;max-height:60vh;touch-action:none}\n' +
'.sn-overlay{position:fixed;inset:0;background:rgba(0,0,0,.72);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;text-align:center;padding:24px;backdrop-filter:blur(4px)}\n' +
'.sn-overlay h1{font-size:2rem;font-weight:800}\n' +
'.sn-overlay p{opacity:.75;max-width:320px}\n' +
'.sn-btn{padding:13px 30px;border-radius:10px;border:none;background:' + snakeColor + ';color:#0d0d14;font-weight:700;font-size:1rem;cursor:pointer}\n' +
'.sn-dpad{display:grid;grid-template-columns:56px 56px 56px;grid-template-rows:56px 56px 56px;gap:6px;margin-top:4px}\n' +
'.sn-dpad button{border-radius:10px;border:1px solid #2a2a3a;background:#15151f;color:#fff;font-size:1.2rem;touch-action:none}\n' +
'.sn-dpad button:active{background:' + snakeColor + ';color:#0d0d14}\n' +
'.sn-hidden{display:none !important}\n' +
'</style>\n' +
'</head>\n' +
'<body>\n' +
'<div class="sn-hud"><div><span>Score</span><b id="snScore">0</b></div>' + (hasHighscore ? '<div><span>Best</span><b id="snBest">0</b></div>' : '') + '</div>\n' +
'<canvas id="snCanvas" width="400" height="400"></canvas>\n' +
(controls === 'touch' ?
'<div class="sn-dpad" id="snDpad">' +
  '<span></span><button data-dir="up">\u2191</button><span></span>' +
  '<button data-dir="left">\u2190</button><span></span><button data-dir="right">\u2192</button>' +
  '<span></span><button data-dir="down">\u2193</button><span></span>' +
'</div>\n' : '') +
'<div class="sn-overlay" id="snStart"><h1>' + title + '</h1><p>Use arrow keys or WASD to move' + (controls === 'touch' ? ', or the on-screen controls' : '') + '. Eat the food, avoid ' + (hasWalls ? 'yourself' : 'the walls and yourself') + '.</p><button class="sn-btn" id="snStartBtn">Start Game</button></div>\n' +
'<div class="sn-overlay sn-hidden" id="snOver"><h1>Game Over</h1><p id="snFinalScore"></p><button class="sn-btn" id="snRestartBtn">Play Again</button></div>\n' +
'<script>\n' +
'(function(){\n' +
'var canvas=document.getElementById("snCanvas");var ctx=canvas.getContext("2d");\n' +
'var GRID=20,CELLS=canvas.width/GRID;\n' +
'var snakeColor="' + snakeColor + '",foodColor="' + foodColor + '",powerColor="#ffd93d";\n' +
'var hasWalls=' + hasWalls + ',hasPowerups=' + hasPowerups + ',hasSound=' + hasSound + ',hasHighscore=' + hasHighscore + ';\n' +
'var speedMs=' + speedMs + ';\n' +
'var scoreEl=document.getElementById("snScore");\n' +
(hasHighscore ? 'var bestEl=document.getElementById("snBest");var best=parseInt(localStorage.getItem("sn_best")||"0",10);bestEl.textContent=best;\n' : '') +
'var startOverlay=document.getElementById("snStart"),overOverlay=document.getElementById("snOver");\n' +
'var snake,dir,nextDir,food,power,score,loopId,running=false;\n' +
'function beep(freq,dur){if(!hasSound)return;try{var ac=window._snAc||(window._snAc=new (window.AudioContext||window.webkitAudioContext)());var o=ac.createOscillator();var g=ac.createGain();o.connect(g);g.connect(ac.destination);o.frequency.value=freq;g.gain.value=.05;o.start();g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+dur);o.stop(ac.currentTime+dur);}catch(e){}}\n' +
'function randCell(){return {x:Math.floor(Math.random()*CELLS),y:Math.floor(Math.random()*CELLS)};}\n' +
'function placeFood(){var p;do{p=randCell();}while(snake.some(function(s){return s.x===p.x&&s.y===p.y;}));food=p;}\n' +
'function placePower(){if(!hasPowerups){power=null;return;}if(Math.random()<0.15){var p;do{p=randCell();}while(snake.some(function(s){return s.x===p.x&&s.y===p.y;})||(food&&food.x===p.x&&food.y===p.y));power=p;}else{power=null;}}\n' +
'function reset(){snake=[{x:Math.floor(CELLS/2),y:Math.floor(CELLS/2)}];dir={x:1,y:0};nextDir=dir;score=0;scoreEl.textContent="0";placeFood();power=null;}\n' +
'function gameOver(){running=false;clearInterval(loopId);beep(110,.3);\n' +
(hasHighscore ? 'if(score>best){best=score;localStorage.setItem("sn_best",String(best));bestEl.textContent=best;}\n' : '') +
'document.getElementById("snFinalScore").textContent="Score: "+score;overOverlay.classList.remove("sn-hidden");}\n' +
'function step(){\n' +
'dir=nextDir;var head={x:snake[0].x+dir.x,y:snake[0].y+dir.y};\n' +
'if(hasWalls){head.x=(head.x+CELLS)%CELLS;head.y=(head.y+CELLS)%CELLS;}\n' +
'else if(head.x<0||head.y<0||head.x>=CELLS||head.y>=CELLS){gameOver();return;}\n' +
'if(snake.some(function(s){return s.x===head.x&&s.y===head.y;})){gameOver();return;}\n' +
'snake.unshift(head);\n' +
'if(food&&head.x===food.x&&head.y===food.y){score+=10;scoreEl.textContent=score;beep(660,.08);placeFood();placePower();}\n' +
'else if(power&&head.x===power.x&&head.y===power.y){score+=30;scoreEl.textContent=score;beep(880,.12);power=null;}\n' +
'else{snake.pop();}\n' +
'draw();\n' +
'}\n' +
'function draw(){\n' +
'ctx.fillStyle="#000";ctx.fillRect(0,0,canvas.width,canvas.height);\n' +
'ctx.fillStyle=foodColor;if(food)ctx.fillRect(food.x*GRID+2,food.y*GRID+2,GRID-4,GRID-4);\n' +
'if(power){ctx.fillStyle=powerColor;ctx.beginPath();ctx.arc(power.x*GRID+GRID/2,power.y*GRID+GRID/2,GRID/2-2,0,Math.PI*2);ctx.fill();}\n' +
'ctx.fillStyle=snakeColor;\n' +
'snake.forEach(function(s,i){var pad=i===0?1:2;ctx.fillRect(s.x*GRID+pad,s.y*GRID+pad,GRID-pad*2,GRID-pad*2);});\n' +
'}\n' +
'function setDir(x,y){if(dir.x===-x&&dir.y===-y)return;nextDir={x:x,y:y};}\n' +
'document.addEventListener("keydown",function(e){\n' +
'var k=e.key.toLowerCase();\n' +
'if(["arrowup","w"].includes(k))setDir(0,-1);\n' +
'else if(["arrowdown","s"].includes(k))setDir(0,1);\n' +
'else if(["arrowleft","a"].includes(k))setDir(-1,0);\n' +
'else if(["arrowright","d"].includes(k))setDir(1,0);\n' +
'else return;\n' +
'e.preventDefault();\n' +
'});\n' +
'var dpad=document.getElementById("snDpad");\n' +
'if(dpad){dpad.querySelectorAll("button").forEach(function(b){b.addEventListener("touchstart",function(e){e.preventDefault();handleDpad(b.dataset.dir);});b.addEventListener("click",function(){handleDpad(b.dataset.dir);});});}\n' +
'function handleDpad(d){if(d==="up")setDir(0,-1);else if(d==="down")setDir(0,1);else if(d==="left")setDir(-1,0);else if(d==="right")setDir(1,0);}\n' +
'var touchStartX=0,touchStartY=0;\n' +
'canvas.addEventListener("touchstart",function(e){var t=e.touches[0];touchStartX=t.clientX;touchStartY=t.clientY;},{passive:true});\n' +
'canvas.addEventListener("touchend",function(e){var t=e.changedTouches[0];var dx=t.clientX-touchStartX,dy=t.clientY-touchStartY;if(Math.abs(dx)>Math.abs(dy)){setDir(dx>0?1:-1,0);}else{setDir(0,dy>0?1:-1);}},{passive:true});\n' +
'function start(){reset();running=true;startOverlay.classList.add("sn-hidden");overOverlay.classList.add("sn-hidden");draw();clearInterval(loopId);loopId=setInterval(step,speedMs);}\n' +
'document.getElementById("snStartBtn").addEventListener("click",start);\n' +
'document.getElementById("snRestartBtn").addEventListener("click",start);\n' +
'})();\n' +
'</script>\n' +
'</body>\n' +
'</html>';
}
