/* ── Space-shooter template: requestAnimationFrame loop, player ship,
   bullets, enemy waves, AABB collision. Layout/CSS/game-loop are static and
   hand-authored — only colors, controls, difficulty, and feature flags come
   from the AI plan. ── */

import { escapeHtml, safeColor, filterFeatures } from '../helpers.js';

const ALLOWED_FEATURES = ['highscore', 'levels', 'powerups', 'sound'];
const DIFFICULTY = {
  easy:   { enemySpeed: 1.1, spawnMs: 950, enemySpeedMul: 1 },
  normal: { enemySpeed: 1.6, spawnMs: 700, enemySpeedMul: 1 },
  hard:   { enemySpeed: 2.2, spawnMs: 500, enemySpeedMul: 1 }
};

export function renderSpaceShooter(plan) {
  const style = (plan && plan.style) || {};
  const player = (plan && plan.player) || {};
  const enemy = (plan && plan.enemy) || {};
  const weapons = (plan && plan.weapons) || {};
  const theme = style.theme === 'light' ? 'light' : 'dark';
  const colors = (style && style.colors) || {};
  const background = safeColor(colors.background, theme === 'light' ? '#f7f7fb' : '#0d0d14');
  const primary = safeColor(colors.primary, '#00cec9');
  const playerColor = safeColor(player.color, primary);
  const enemyColor = safeColor(enemy.color, '#fd79a8');
  const weaponType = weapons.type === 'laser' ? 'laser' : 'bullet';
  const difficulty = ['easy', 'normal', 'hard'].includes(plan && plan.difficulty) ? plan.difficulty : 'normal';
  const diff = DIFFICULTY[difficulty];
  const controls = ['arrows', 'wasd', 'touch'].includes(plan && plan.controls) ? plan.controls : 'arrows';
  const features = filterFeatures(plan && plan.features, ALLOWED_FEATURES);
  const hasHighscore = features.includes('highscore');
  const hasLevels = features.includes('levels');
  const hasPowerups = features.includes('powerups');
  const hasSound = features.includes('sound');
  const title = escapeHtml((plan && plan.content && plan.content.brand) || 'Space Shooter');

  return '<!DOCTYPE html>\n' +
'<html lang="en">\n' +
'<head>\n' +
'<meta charset="UTF-8">\n' +
'<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">\n' +
'<title>' + title + '</title>\n' +
'<style>\n' +
'*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}\n' +
'html,body{height:100%;overflow:hidden}\n' +
'body{background:' + background + ';color:#f5f5fa;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:16px}\n' +
'.ss-hud{display:flex;gap:24px;font-size:1rem;font-weight:600}\n' +
'.ss-hud span{opacity:.55;font-weight:500;margin-right:6px}\n' +
'#ssCanvas{background:#000;border-radius:12px;border:1px solid #22222e;max-width:94vw;max-height:64vh;touch-action:none}\n' +
'.ss-overlay{position:fixed;inset:0;background:rgba(0,0,0,.72);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;text-align:center;padding:24px;backdrop-filter:blur(4px)}\n' +
'.ss-overlay h1{font-size:2rem;font-weight:800}\n' +
'.ss-overlay p{opacity:.75;max-width:340px}\n' +
'.ss-btn{padding:13px 30px;border-radius:10px;border:none;background:' + playerColor + ';color:#0d0d14;font-weight:700;font-size:1rem;cursor:pointer}\n' +
'.ss-touch{display:flex;gap:14px;margin-top:4px}\n' +
'.ss-touch button{width:64px;height:56px;border-radius:10px;border:1px solid #2a2a3a;background:#15151f;color:#fff;font-size:1.2rem;touch-action:none}\n' +
'.ss-touch button:active{background:' + playerColor + ';color:#0d0d14}\n' +
'.ss-fire{background:' + enemyColor + '22 !important}\n' +
'.ss-hidden{display:none !important}\n' +
'</style>\n' +
'</head>\n' +
'<body>\n' +
'<div class="ss-hud"><div><span>Score</span><b id="ssScore">0</b></div><div><span>Lives</span><b id="ssLives">3</b></div>' +
(hasLevels ? '<div><span>Level</span><b id="ssLevel">1</b></div>' : '') +
(hasHighscore ? '<div><span>Best</span><b id="ssBest">0</b></div>' : '') +
'</div>\n' +
'<canvas id="ssCanvas" width="420" height="520"></canvas>\n' +
(controls === 'touch' ?
'<div class="ss-touch" id="ssTouch">' +
  '<button data-act="left">\u2190</button><button data-act="right">\u2192</button><button data-act="fire" class="ss-fire">\u25CF</button>' +
'</div>\n' : '') +
'<div class="ss-overlay" id="ssStart"><h1>' + title + '</h1><p>Move with arrow keys or WASD' + (controls === 'touch' ? ', or the on-screen controls' : '') + '. Press Space to fire. Destroy enemies before they reach you.</p><button class="ss-btn" id="ssStartBtn">Start Game</button></div>\n' +
'<div class="ss-overlay ss-hidden" id="ssOver"><h1>Game Over</h1><p id="ssFinalScore"></p><button class="ss-btn" id="ssRestartBtn">Play Again</button></div>\n' +
'<script>\n' +
'(function(){\n' +
'var canvas=document.getElementById("ssCanvas");var ctx=canvas.getContext("2d");\n' +
'var W=canvas.width,H=canvas.height;\n' +
'var playerColor="' + playerColor + '",enemyColor="' + enemyColor + '",powerColor="#ffd93d",weaponType="' + weaponType + '";\n' +
'var hasLevels=' + hasLevels + ',hasPowerups=' + hasPowerups + ',hasSound=' + hasSound + ',hasHighscore=' + hasHighscore + ';\n' +
'var enemySpeed=' + diff.enemySpeed + ',spawnMs=' + diff.spawnMs + ',enemyCount=' + (Math.max(1, Math.min(8, parseInt(enemy.count, 10) || 3))) + ';\n' +
'var playerSpeedBase=' + (Math.max(0.5, Math.min(3, Number(player.speed) || 1))) + ' * 4.2;\n' +
'var scoreEl=document.getElementById("ssScore"),livesEl=document.getElementById("ssLives");\n' +
(hasLevels ? 'var levelEl=document.getElementById("ssLevel");\n' : '') +
(hasHighscore ? 'var bestEl=document.getElementById("ssBest");var best=parseInt(localStorage.getItem("ss_best")||"0",10);bestEl.textContent=best;\n' : '') +
'var startOverlay=document.getElementById("ssStart"),overOverlay=document.getElementById("ssOver");\n' +
'var player,bullets,enemies,powerups,score,lives,level,spawnTimer,rapidFireUntil,running=false,lastTime=0,lastSpawn=0,keys={};\n' +
'function beep(freq,dur){if(!hasSound)return;try{var ac=window._ssAc||(window._ssAc=new (window.AudioContext||window.webkitAudioContext)());var o=ac.createOscillator();var g=ac.createGain();o.connect(g);g.connect(ac.destination);o.frequency.value=freq;g.gain.value=.05;o.start();g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+dur);o.stop(ac.currentTime+dur);}catch(e){}}\n' +
'function reset(){player={x:W/2-16,y:H-56,w:32,h:28,cooldown:0};bullets=[];enemies=[];powerups=[];score=0;lives=3;level=1;spawnTimer=0;rapidFireUntil=0;\n' +
'scoreEl.textContent="0";livesEl.textContent="3";' + (hasLevels ? 'levelEl.textContent="1";' : '') + '}\n' +
'function rectHit(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}\n' +
'function spawnEnemy(){var w=28,h=24;var x=Math.random()*(W-w);enemies.push({x:x,y:-h,w:w,h:h,speed:enemySpeed*(hasLevels?(1+(level-1)*0.15):1)});}\n' +
'function spawnPowerup(){if(!hasPowerups)return;if(Math.random()<0.4){var w=20;powerups.push({x:Math.random()*(W-w),y:-20,w:w,h:20,speed:2.2});}}\n' +
'function fire(){if(player.cooldown>0)return;var rapid=Date.now()<rapidFireUntil;player.cooldown=rapid?90:220;\n' +
'if(weaponType==="laser")bullets.push({x:player.x+player.w/2-2,y:player.y-4,w:4,h:18,speed:9});\n' +
'else bullets.push({x:player.x+player.w/2-3,y:player.y-4,w:6,h:10,speed:8});\n' +
'beep(880,.05);}\n' +
'function gameOver(){running=false;beep(110,.35);\n' +
(hasHighscore ? 'if(score>best){best=score;localStorage.setItem("ss_best",String(best));bestEl.textContent=best;}\n' : '') +
'document.getElementById("ssFinalScore").textContent="Score: "+score;overOverlay.classList.remove("ss-hidden");}\n' +
'function update(dt){\n' +
'var speed=playerSpeedBase;\n' +
'if(keys.left)player.x-=speed;if(keys.right)player.x+=speed;\n' +
'player.x=Math.max(0,Math.min(W-player.w,player.x));\n' +
'if(keys.fire)fire();\n' +
'if(player.cooldown>0)player.cooldown-=dt;\n' +
'bullets.forEach(function(b){b.y-=b.speed;});bullets=bullets.filter(function(b){return b.y+b.h>0;});\n' +
'spawnTimer+=dt;var curSpawn=spawnMs/(hasLevels?(1+(level-1)*0.12):1);\n' +
'if(spawnTimer>curSpawn){spawnTimer=0;spawnEnemy();spawnPowerup();}\n' +
'enemies.forEach(function(e){e.y+=e.speed;});\n' +
'enemies=enemies.filter(function(e){\n' +
'if(e.y>H){lives--;livesEl.textContent=lives;if(lives<=0)gameOver();return false;}\n' +
'return true;\n' +
'});\n' +
'powerups.forEach(function(p){p.y+=p.speed;});\n' +
'powerups=powerups.filter(function(p){\n' +
'if(rectHit(p,player)){rapidFireUntil=Date.now()+5000;beep(1200,.15);return false;}\n' +
'return p.y<H+20;\n' +
'});\n' +
'for(var i=enemies.length-1;i>=0;i--){\n' +
'for(var j=bullets.length-1;j>=0;j--){\n' +
'if(rectHit(enemies[i],bullets[j])){\n' +
'enemies.splice(i,1);bullets.splice(j,1);score+=10;scoreEl.textContent=score;beep(660,.08);\n' +
'if(hasLevels&&score>0&&score%150===0){level++;levelEl.textContent=level;}\n' +
'break;\n' +
'}\n' +
'}\n' +
'}\n' +
'for(var k=enemies.length-1;k>=0;k--){\n' +
'if(rectHit(enemies[k],player)){enemies.splice(k,1);lives--;livesEl.textContent=lives;beep(150,.2);if(lives<=0){gameOver();return;}}\n' +
'}\n' +
'}\n' +
'function drawShip(x,y,w,h,color){ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(x+w/2,y);ctx.lineTo(x+w,y+h);ctx.lineTo(x,y+h);ctx.closePath();ctx.fill();}\n' +
'function draw(){\n' +
'ctx.fillStyle="#000";ctx.fillRect(0,0,W,H);\n' +
'drawShip(player.x,player.y,player.w,player.h,playerColor);\n' +
'ctx.fillStyle="#fff";bullets.forEach(function(b){ctx.fillRect(b.x,b.y,b.w,b.h);});\n' +
'enemies.forEach(function(e){ctx.fillStyle=enemyColor;ctx.fillRect(e.x,e.y,e.w,e.h);});\n' +
'ctx.fillStyle=powerColor;powerups.forEach(function(p){ctx.beginPath();ctx.arc(p.x+p.w/2,p.y+p.h/2,p.w/2,0,Math.PI*2);ctx.fill();});\n' +
'}\n' +
'function loop(t){\n' +
'if(!running)return;\n' +
'var dt=lastTime?t-lastTime:16;lastTime=t;\n' +
'update(dt);draw();\n' +
'requestAnimationFrame(loop);\n' +
'}\n' +
'document.addEventListener("keydown",function(e){\n' +
'var k=e.key.toLowerCase();\n' +
'if(["arrowleft","a"].includes(k))keys.left=true;\n' +
'else if(["arrowright","d"].includes(k))keys.right=true;\n' +
'else if(k===" "||k==="spacebar"){keys.fire=true;e.preventDefault();}\n' +
'});\n' +
'document.addEventListener("keyup",function(e){\n' +
'var k=e.key.toLowerCase();\n' +
'if(["arrowleft","a"].includes(k))keys.left=false;\n' +
'else if(["arrowright","d"].includes(k))keys.right=false;\n' +
'else if(k===" "||k==="spacebar")keys.fire=false;\n' +
'});\n' +
'var touch=document.getElementById("ssTouch");\n' +
'if(touch){touch.querySelectorAll("button").forEach(function(b){\n' +
'var act=b.dataset.act;\n' +
'b.addEventListener("touchstart",function(e){e.preventDefault();keys[act]=true;});\n' +
'b.addEventListener("touchend",function(e){e.preventDefault();keys[act]=false;});\n' +
'b.addEventListener("mousedown",function(){keys[act]=true;});\n' +
'b.addEventListener("mouseup",function(){keys[act]=false;});\n' +
'});}\n' +
'function start(){reset();running=true;lastTime=0;startOverlay.classList.add("ss-hidden");overOverlay.classList.add("ss-hidden");requestAnimationFrame(loop);}\n' +
'document.getElementById("ssStartBtn").addEventListener("click",start);\n' +
'document.getElementById("ssRestartBtn").addEventListener("click",start);\n' +
'})();\n' +
'</script>\n' +
'</body>\n' +
'</html>';
}
