/* ── Template pipeline orchestrator: Planner (fast AI JSON-plan call) →
   Template Engine (pure render(plan) → html). Returns null on ANY failure
   or no-match so the caller can silently fall back to the existing
   single-shot generation path — nothing here ever throws. ── */

import { runPlanner, validatePlan } from './planner.js';
import { resolveTemplate } from './registry.js';
import { tinyDelay } from './helpers.js';

export const TEMPLATE_STAGE_LABELS = {
  en: ['Analyzing idea…', 'Selecting template…', 'Building structure…', 'Customizing design…', 'Adding features…', 'Ready!'],
  ar: ['جارٍ تحليل الفكرة…', 'جارٍ اختيار القالب…', 'جارٍ بناء الهيكل…', 'جارٍ تخصيص التصميم…', 'جارٍ إضافة الميزات…', 'جاهز!']
};

export async function tryTemplatePipeline(prompt, type, subtype, opts) {
  const options = opts || {};
  const onStage = typeof options.onStage === 'function' ? options.onStage : function () {};

  if (type !== 'website' && type !== 'game') return null;

  try {
    onStage(0);
    const rawText = await runPlanner(prompt, type);
    if (!rawText) return null;

    onStage(1);
    const plan = validatePlan(type, rawText);
    if (!plan || plan.template === 'none') return null;

    const renderFn = resolveTemplate(type, plan.template);
    if (!renderFn) return null;

    onStage(2);
    await tinyDelay(150);

    onStage(3);
    await tinyDelay(150);

    onStage(4);
    let html;
    try {
      html = renderFn(plan);
    } catch (e) {
      return null;
    }
    if (!html || typeof html !== 'string') return null;

    onStage(5);
    return html;
  } catch (e) {
    return null;
  }
}
