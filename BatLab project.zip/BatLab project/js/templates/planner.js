/* ── Planner: turns a user prompt into a small JSON spec instead of a full
   HTML file. Reuses the existing generic /chat worker (no redeploy needed) —
   same request/response contract already used by runPreGenAnalysis() and the
   home-chat assistant elsewhere in the app. ── */

import { templateKeys } from './registry.js';

const CHAT_WORKER_URL = 'https://weathered-rain-34fa.mustafathth123.workers.dev/chat';

export const PLANNER_SYSTEM = {
  website:
    'You are a fast website-planning module. Do NOT write any HTML, CSS, or code. ' +
    'Given a user\'s request, output ONLY a single <PLAN>...</PLAN> tag wrapping one JSON object ' +
    '(no markdown fences, no explanation, nothing outside the tag) describing which prebuilt template ' +
    'best fits the request and how to customize it.\n\n' +
    'Available templates:\n' +
    '- "landing-page": a marketing/SaaS/product/app landing page with hero, features, and optional ' +
    'testimonials, pricing, gallery, and a contact form.\n' +
    '- "portfolio": a personal/freelancer portfolio with about, projects, and optional skills and contact.\n\n' +
    'If neither template is a genuinely good fit (e.g. e-commerce store with cart/checkout, blog, ' +
    'dashboard, multi-page site, or anything requiring custom logic), set "template" to "none" — ' +
    'do not force a bad fit.\n\n' +
    'JSON shape:\n' +
    '{\n' +
    '  "type": "website",\n' +
    '  "template": "landing-page" | "portfolio" | "none",\n' +
    '  "style": { "theme": "dark" | "light", "colors": { "primary": "#hex", "secondary": "#hex", "accent": "#hex", "background": "#hex" }, "layout": "centered" | "wide" },\n' +
    '  "content": { "brand": "...", "headline": "...", "subheadline": "...", "ctaText": "..." },\n' +
    '  "features": ["testimonials", "pricing", "gallery", "contact-form"]\n' +
    '}\n' +
    'For "portfolio", use content fields { "brand", "headline" (name), "subheadline" (title/role), "ctaText" } ' +
    'and features from ["skills", "contact"].\n\n' +
    'All text content must be in English using Latin characters only. Output nothing but the <PLAN> tag.',
  game:
    'You are a fast game-planning module. Do NOT write any HTML, CSS, or game code. ' +
    'Given a user\'s request, output ONLY a single <PLAN>...</PLAN> tag wrapping one JSON object ' +
    '(no markdown fences, no explanation, nothing outside the tag) describing which prebuilt game ' +
    'template best fits the request and how to configure it.\n\n' +
    'Available templates:\n' +
    '- "snake": classic grid-based snake game (player moves and grows, avoids walls/self, eats food).\n' +
    '- "space-shooter": top-down arcade shooter (player ship shoots waves of enemies).\n\n' +
    'If neither template is a genuinely good fit (e.g. platformer, tower defense, racing, puzzle, or ' +
    'anything requiring custom mechanics), set "template" to "none" — do not force a bad fit.\n\n' +
    'JSON shape:\n' +
    '{\n' +
    '  "type": "game",\n' +
    '  "template": "snake" | "space-shooter" | "none",\n' +
    '  "player": { "shape": "square" | "circle" | "triangle", "color": "#hex", "speed": 1 },\n' +
    '  "enemy": { "shape": "square" | "circle" | "triangle", "color": "#hex", "count": 3, "speed": 1 },\n' +
    '  "controls": "arrows" | "wasd" | "touch",\n' +
    '  "weapons": { "enabled": false, "type": "bullet" | "laser" | null },\n' +
    '  "difficulty": "easy" | "normal" | "hard",\n' +
    '  "style": { "theme": "dark" | "light", "colors": { "primary": "#hex", "background": "#hex" } },\n' +
    '  "features": ["highscore", "sound"]\n' +
    '}\n' +
    'For "snake": enemy.color is used as the food color, other enemy fields are ignored; features from ' +
    '["highscore", "walls", "powerups", "sound"]. For "space-shooter": features from ' +
    '["highscore", "levels", "powerups", "sound"].\n\n' +
    'All text content must be in English using Latin characters only. Output nothing but the <PLAN> tag.'
};

// POSTs to the existing generic chat worker and returns the raw assistant
// text, or null on any network/HTTP failure (caller treats null as "fall
// back to the old pipeline").
export async function runPlanner(prompt, type) {
  const system = PLANNER_SYSTEM[type];
  if (!system) return null;
  try {
    const res = await fetch(CHAT_WORKER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ system, messages: [{ role: 'user', content: prompt }] })
    });
    if (!res.ok) return null;
    const data = await res.json();
    const text = data.content?.[0]?.text || data.reply || data.text || '';
    return text || null;
  } catch (e) {
    return null;
  }
}

function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

// Structural/type validation only — per-field defaulting happens inside each
// template renderer (defaults differ per template). Returns the parsed plan
// object on success (plan.template may legitimately be "none"), or null if
// the plan is unusable and the caller should fall back to the old pipeline.
export function validatePlan(type, rawText) {
  if (!rawText || typeof rawText !== 'string') return null;
  const match = rawText.match(/<PLAN>([\s\S]*?)<\/PLAN>/);
  if (!match) return null;

  let plan;
  try {
    plan = JSON.parse(match[1].trim());
  } catch (e) {
    return null;
  }

  if (!isPlainObject(plan)) return null;
  if (plan.type !== type) return null;

  const keys = templateKeys(type);
  if (typeof plan.template !== 'string' || (plan.template !== 'none' && keys.indexOf(plan.template) === -1)) {
    return null;
  }

  const objectFields = type === 'website'
    ? ['style', 'content']
    : ['style', 'player', 'enemy', 'weapons'];
  for (const field of objectFields) {
    if (plan[field] !== undefined && !isPlainObject(plan[field])) return null;
  }
  if (isPlainObject(plan.style) && plan.style.colors !== undefined && !isPlainObject(plan.style.colors)) {
    return null;
  }
  if (plan.features !== undefined && !Array.isArray(plan.features)) return null;

  return plan;
}
