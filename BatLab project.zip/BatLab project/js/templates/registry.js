/* ── Template registry: the single extension point. Adding a new template
   later is just: write a renderX(plan) file + add one line below. ── */

import { renderLandingPage } from './website/landing-page.js';
import { renderPortfolio } from './website/portfolio.js';
import { renderSnake } from './game/snake.js';
import { renderSpaceShooter } from './game/space-shooter.js';

export const TEMPLATE_REGISTRY = {
  website: {
    'landing-page': renderLandingPage,
    'portfolio': renderPortfolio
  },
  game: {
    'snake': renderSnake,
    'space-shooter': renderSpaceShooter
  }
};

export function resolveTemplate(type, key) {
  const group = TEMPLATE_REGISTRY[type];
  if (!group) return null;
  const fn = group[key];
  return typeof fn === 'function' ? fn : null;
}

export function templateKeys(type) {
  const group = TEMPLATE_REGISTRY[type];
  return group ? Object.keys(group) : [];
}
