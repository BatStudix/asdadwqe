/* ── Portfolio template: hero (name/title) + about + projects + optional
   skills/contact. Layout/CSS is static and hand-authored — only text,
   colors, and section presence come from the AI plan. ── */

import { escapeHtml, cssVarBlock, joinSections, filterFeatures } from '../helpers.js';

const ALLOWED_FEATURES = ['skills', 'contact'];

const DEFAULT_COLORS_DARK = { primary: '#00cec9', secondary: '#6c5ce7', accent: '#fd79a8', background: '#0d0d14' };
const DEFAULT_COLORS_LIGHT = { primary: '#00b894', secondary: '#6c5ce7', accent: '#e17055', background: '#f7f7fb' };

export function renderPortfolio(plan) {
  const style = (plan && plan.style) || {};
  const content = (plan && plan.content) || {};
  const theme = style.theme === 'light' ? 'light' : 'dark';
  const layout = style.layout === 'wide' ? 'wide' : 'centered';
  const colorDefaults = theme === 'light' ? DEFAULT_COLORS_LIGHT : DEFAULT_COLORS_DARK;
  const features = filterFeatures(plan && plan.features, ALLOWED_FEATURES);

  const brand = escapeHtml(content.brand || 'Portfolio');
  const name = escapeHtml(content.headline || 'Jordan Doe');
  const role = escapeHtml(content.subheadline || 'Designer & Developer');
  const ctaText = escapeHtml(content.ctaText || 'View my work');
  const initial = escapeHtml((content.headline || 'J').trim().charAt(0).toUpperCase() || 'J');

  const navLinks = joinSections([
    [true, '<a href="#about">About</a>'],
    [true, '<a href="#projects">Projects</a>'],
    [features.includes('skills'), '<a href="#skills">Skills</a>'],
    [features.includes('contact'), '<a href="#contact">Contact</a>']
  ]);

  const navbar =
    '<header class="pf-nav"><div class="pf-container pf-nav-inner">' +
      '<span class="pf-brand">' + brand + '</span>' +
      '<nav class="pf-nav-links">' + navLinks + '</nav>' +
    '</div></header>';

  const hero =
    '<section class="pf-hero"><div class="pf-container pf-hero-inner">' +
      '<div class="pf-avatar">' + initial + '</div>' +
      '<h1>' + name + '</h1>' +
      '<p class="pf-role">' + role + '</p>' +
      '<a class="pf-btn pf-btn-primary" href="#projects">' + ctaText + '</a>' +
    '</div></section>';

  const about =
    '<section id="about" class="pf-about"><div class="pf-container">' +
      '<h2 class="pf-section-title">About</h2>' +
      '<p class="pf-about-text">' +
        'I\u2019m ' + name + ', a ' + role.toLowerCase() + ' focused on building clean, functional, and ' +
        'thoughtful work. I care about the details and enjoy turning ideas into polished, real things.' +
      '</p>' +
    '</div></section>';

  const projectData = [
    ['Project One', 'A short description of this project and the problem it solves.'],
    ['Project Two', 'A short description of this project and the problem it solves.'],
    ['Project Three', 'A short description of this project and the problem it solves.']
  ];
  const projects =
    '<section id="projects" class="pf-projects"><div class="pf-container">' +
      '<h2 class="pf-section-title">Projects</h2>' +
      '<div class="pf-project-grid">' +
        projectData.map(function (p, i) {
          return '<div class="pf-project-card">' +
            '<div class="pf-project-thumb" style="background:linear-gradient(135deg,var(--primary),var(--secondary));opacity:' + (0.55 + i * 0.15) + '"></div>' +
            '<h3>' + escapeHtml(p[0]) + '</h3><p>' + escapeHtml(p[1]) + '</p>' +
          '</div>';
        }).join('') +
      '</div>' +
    '</div></section>';

  const skillsList = ['Design', 'Development', 'Strategy', 'Branding', 'Collaboration', 'Problem Solving'];
  const skills = features.includes('skills')
    ? '<section id="skills" class="pf-skills"><div class="pf-container">' +
        '<h2 class="pf-section-title">Skills</h2>' +
        '<div class="pf-skills-list">' +
          skillsList.map(function (s) { return '<span class="pf-skill-chip">' + escapeHtml(s) + '</span>'; }).join('') +
        '</div>' +
      '</div></section>'
    : '';

  const contact = features.includes('contact')
    ? '<section id="contact" class="pf-contact"><div class="pf-container pf-contact-inner">' +
        '<h2 class="pf-section-title">Get in touch</h2>' +
        '<p class="pf-contact-text">Have a project in mind or just want to say hi? I\u2019d love to hear from you.</p>' +
        '<form class="pf-form" onsubmit="event.preventDefault();this.querySelector(\'.pf-form-status\').textContent=\'Thanks — I\\u2019ll get back to you soon.\';this.reset();">' +
          '<input type="text" placeholder="Your name" required>' +
          '<input type="email" placeholder="Your email" required>' +
          '<textarea placeholder="Your message" rows="4" required></textarea>' +
          '<button type="submit" class="pf-btn pf-btn-primary">Send message</button>' +
          '<p class="pf-form-status"></p>' +
        '</form>' +
      '</div></section>'
    : '';

  const footer =
    '<footer class="pf-footer"><div class="pf-container pf-footer-inner">' +
      '<span>&copy; ' + new Date().getFullYear() + ' ' + name + '. All rights reserved.</span>' +
    '</div></footer>';

  const body = joinSections([
    [true, navbar],
    [true, hero],
    [true, about],
    [true, projects],
    [true, skills],
    [true, contact],
    [true, footer]
  ]);

  const vars = cssVarBlock(style.colors, colorDefaults);
  const maxWidth = layout === 'wide' ? '1100px' : '840px';

  return '<!DOCTYPE html>\n' +
'<html lang="en" data-theme="' + theme + '">\n' +
'<head>\n' +
'<meta charset="UTF-8">\n' +
'<meta name="viewport" content="width=device-width, initial-scale=1.0">\n' +
'<title>' + brand + '</title>\n' +
'<style>\n' +
vars + '\n' +
'*{box-sizing:border-box;margin:0;padding:0}\n' +
'html{scroll-behavior:smooth}\n' +
'body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:var(--background);color:' + (theme === 'light' ? '#1a1a24' : '#f5f5fa') + ';line-height:1.6}\n' +
'.pf-container{max-width:' + maxWidth + ';margin:0 auto;padding:0 24px}\n' +
'.pf-nav{position:sticky;top:0;z-index:10;backdrop-filter:blur(10px);background:' + (theme === 'light' ? 'rgba(247,247,251,.85)' : 'rgba(13,13,20,.85)') + ';border-bottom:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#1e1e2a') + '}\n' +
'.pf-nav-inner{display:flex;align-items:center;justify-content:space-between;padding:16px 24px}\n' +
'.pf-brand{font-weight:700}\n' +
'.pf-nav-links{display:flex;gap:20px;font-size:.9rem}\n' +
'.pf-nav-links a{color:inherit;text-decoration:none;opacity:.8}\n' +
'.pf-nav-links a:hover{opacity:1}\n' +
'.pf-btn{display:inline-block;padding:11px 22px;border-radius:8px;font-size:.9rem;font-weight:600;text-decoration:none;border:none;cursor:pointer;transition:transform .15s ease}\n' +
'.pf-btn:hover{transform:translateY(-1px)}\n' +
'.pf-btn-primary{background:var(--primary);color:#fff}\n' +
'.pf-hero{padding:96px 24px 72px;text-align:center}\n' +
'.pf-avatar{width:88px;height:88px;border-radius:50%;margin:0 auto 24px;display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:800;color:#fff;background:linear-gradient(135deg,var(--primary),var(--secondary))}\n' +
'.pf-hero h1{font-size:clamp(2rem,4.5vw,2.8rem);font-weight:800;margin-bottom:8px;letter-spacing:-.02em}\n' +
'.pf-role{opacity:.7;font-size:1.05rem;margin-bottom:28px}\n' +
'.pf-section-title{font-size:1.7rem;font-weight:700;margin-bottom:28px;letter-spacing:-.01em}\n' +
'.pf-about{padding:64px 0}\n' +
'.pf-about-text{opacity:.8;max-width:640px;font-size:1.02rem}\n' +
'.pf-projects{padding:64px 0;background:' + (theme === 'light' ? '#fff' : '#12121a') + '}\n' +
'.pf-project-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:22px}\n' +
'.pf-project-card{border-radius:14px;overflow:hidden;background:' + (theme === 'light' ? '#f7f7fb' : '#15151f') + ';border:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#22222e') + '}\n' +
'.pf-project-thumb{aspect-ratio:16/10}\n' +
'.pf-project-card h3{margin:16px 16px 6px;font-size:1.05rem}\n' +
'.pf-project-card p{margin:0 16px 18px;opacity:.7;font-size:.9rem}\n' +
'.pf-skills{padding:64px 0}\n' +
'.pf-skills-list{display:flex;flex-wrap:wrap;gap:10px}\n' +
'.pf-skill-chip{padding:9px 16px;border-radius:99px;font-size:.85rem;background:' + (theme === 'light' ? '#fff' : '#15151f') + ';border:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#22222e') + '}\n' +
'.pf-contact{padding:64px 0;background:' + (theme === 'light' ? '#fff' : '#12121a') + '}\n' +
'.pf-contact-inner{max-width:480px}\n' +
'.pf-contact-text{opacity:.75;margin-bottom:22px}\n' +
'.pf-form{display:flex;flex-direction:column;gap:12px}\n' +
'.pf-form input,.pf-form textarea{padding:12px 14px;border-radius:8px;border:1px solid ' + (theme === 'light' ? '#d6d6e2' : '#2a2a3a') + ';background:' + (theme === 'light' ? '#f7f7fb' : '#0d0d14') + ';color:inherit;font:inherit;resize:vertical}\n' +
'.pf-form-status{font-size:.85rem;opacity:.75;min-height:1.2em}\n' +
'.pf-footer{padding:28px 24px;text-align:center;font-size:.85rem;opacity:.6;border-top:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#1e1e2a') + '}\n' +
'@media(max-width:640px){.pf-nav-links{display:none}}\n' +
'</style>\n' +
'</head>\n' +
'<body>\n' +
body + '\n' +
'</body>\n' +
'</html>';
}
