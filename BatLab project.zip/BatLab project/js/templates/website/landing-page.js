/* ── Landing-page template: hero + features + optional testimonials/
   pricing/gallery/contact-form. Layout/CSS is static and hand-authored —
   only text, colors, and section presence come from the AI plan. ── */

import { escapeHtml, cssVarBlock, joinSections, filterFeatures } from '../helpers.js';

const ALLOWED_FEATURES = ['testimonials', 'pricing', 'gallery', 'contact-form'];

const DEFAULT_COLORS_DARK = { primary: '#6c5ce7', secondary: '#00cec9', accent: '#fd79a8', background: '#0d0d14' };
const DEFAULT_COLORS_LIGHT = { primary: '#6c5ce7', secondary: '#00b894', accent: '#e17055', background: '#f7f7fb' };

export function renderLandingPage(plan) {
  const style = (plan && plan.style) || {};
  const content = (plan && plan.content) || {};
  const theme = style.theme === 'light' ? 'light' : 'dark';
  const layout = style.layout === 'wide' ? 'wide' : 'centered';
  const colorDefaults = theme === 'light' ? DEFAULT_COLORS_LIGHT : DEFAULT_COLORS_DARK;
  const features = filterFeatures(plan && plan.features, ALLOWED_FEATURES);

  const brand = escapeHtml(content.brand || 'Brand');
  const headline = escapeHtml(content.headline || 'Build something amazing');
  const subheadline = escapeHtml(content.subheadline || 'A short, clear description of what you offer and why it matters.');
  const ctaText = escapeHtml(content.ctaText || 'Get Started');

  const navLinks = joinSections([
    [true, '<a href="#features">Features</a>'],
    [features.includes('testimonials'), '<a href="#testimonials">Testimonials</a>'],
    [features.includes('pricing'), '<a href="#pricing">Pricing</a>'],
    [features.includes('gallery'), '<a href="#gallery">Gallery</a>'],
    [features.includes('contact-form'), '<a href="#contact">Contact</a>']
  ]);

  const navbar =
    '<header class="lp-nav"><div class="lp-container lp-nav-inner">' +
      '<span class="lp-brand">' + brand + '</span>' +
      '<nav class="lp-nav-links">' + navLinks + '</nav>' +
      '<a class="lp-btn lp-btn-primary lp-nav-cta" href="#cta">' + ctaText + '</a>' +
    '</div></header>';

  const hero =
    '<section class="lp-hero"><div class="lp-container lp-hero-inner">' +
      '<h1>' + headline + '</h1>' +
      '<p class="lp-hero-sub">' + subheadline + '</p>' +
      '<div class="lp-hero-actions">' +
        '<a class="lp-btn lp-btn-primary" href="#cta">' + ctaText + '</a>' +
        '<a class="lp-btn lp-btn-ghost" href="#features">Learn more</a>' +
      '</div>' +
    '</div></section>';

  const featureCards = [
    ['Fast', 'Built for speed from the ground up, so nothing gets in your way.'],
    ['Reliable', 'Dependable performance you can count on, every single time.'],
    ['Simple', 'A clean, focused experience without unnecessary complexity.'],
    ['Flexible', 'Adapts to how you work instead of forcing you to adapt.']
  ];
  const featuresSection =
    '<section id="features" class="lp-features"><div class="lp-container">' +
      '<h2 class="lp-section-title">Why choose ' + brand + '</h2>' +
      '<div class="lp-feature-grid">' +
        featureCards.map(function (f) {
          return '<div class="lp-feature-card"><h3>' + escapeHtml(f[0]) + '</h3><p>' + escapeHtml(f[1]) + '</p></div>';
        }).join('') +
      '</div>' +
    '</div></section>';

  const testimonialsSection = features.includes('testimonials')
    ? '<section id="testimonials" class="lp-testimonials"><div class="lp-container">' +
        '<h2 class="lp-section-title">What people are saying</h2>' +
        '<div class="lp-testimonial-grid">' +
          [
            ['This completely changed how our team works. Couldn\u2019t imagine going back.', 'Alex Rivera'],
            ['Simple, fast, and it just works. Exactly what we needed.', 'Jordan Lee'],
            ['The best decision we made this year, hands down.', 'Sam Chen']
          ].map(function (t) {
            return '<blockquote class="lp-testimonial"><p>\u201C' + escapeHtml(t[0]) + '\u201D</p><cite>' + escapeHtml(t[1]) + '</cite></blockquote>';
          }).join('') +
        '</div>' +
      '</div></section>'
    : '';

  const pricingSection = features.includes('pricing')
    ? '<section id="pricing" class="lp-pricing"><div class="lp-container">' +
        '<h2 class="lp-section-title">Simple pricing</h2>' +
        '<div class="lp-pricing-grid">' +
          [
            ['Starter', '$0', ['1 project', 'Community support']],
            ['Pro', '$19/mo', ['Unlimited projects', 'Priority support', 'Advanced features']],
            ['Team', '$49/mo', ['Everything in Pro', 'Team collaboration', 'Admin controls']]
          ].map(function (p, i) {
            return '<div class="lp-price-card' + (i === 1 ? ' lp-price-featured' : '') + '">' +
              '<h3>' + escapeHtml(p[0]) + '</h3><div class="lp-price">' + escapeHtml(p[1]) + '</div>' +
              '<ul>' + p[2].map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul>' +
              '<a class="lp-btn lp-btn-primary" href="#cta">Choose ' + escapeHtml(p[0]) + '</a>' +
            '</div>';
          }).join('') +
        '</div>' +
      '</div></section>'
    : '';

  const gallerySection = features.includes('gallery')
    ? '<section id="gallery" class="lp-gallery"><div class="lp-container">' +
        '<h2 class="lp-section-title">Gallery</h2>' +
        '<div class="lp-gallery-grid">' +
          [1, 2, 3, 4, 5, 6].map(function (n) {
            return '<div class="lp-gallery-item" style="background:linear-gradient(135deg,var(--primary),var(--secondary));opacity:' + (0.55 + n * 0.06) + '"></div>';
          }).join('') +
        '</div>' +
      '</div></section>'
    : '';

  const contactSection = features.includes('contact-form')
    ? '<section id="contact" class="lp-contact"><div class="lp-container lp-contact-inner">' +
        '<h2 class="lp-section-title">Get in touch</h2>' +
        '<form class="lp-form" onsubmit="event.preventDefault();this.querySelector(\'.lp-form-status\').textContent=\'Thanks — we\\u2019ll be in touch soon.\';this.reset();">' +
          '<input type="text" placeholder="Your name" required>' +
          '<input type="email" placeholder="Your email" required>' +
          '<textarea placeholder="Your message" rows="4" required></textarea>' +
          '<button type="submit" class="lp-btn lp-btn-primary">Send message</button>' +
          '<p class="lp-form-status"></p>' +
        '</form>' +
      '</div></section>'
    : '';

  const ctaSection =
    '<section id="cta" class="lp-cta"><div class="lp-container lp-cta-inner">' +
      '<h2>Ready to get started?</h2>' +
      '<p>' + subheadline + '</p>' +
      '<a class="lp-btn lp-btn-primary" href="#top">' + ctaText + '</a>' +
    '</div></section>';

  const footer =
    '<footer class="lp-footer"><div class="lp-container lp-footer-inner">' +
      '<span>&copy; ' + new Date().getFullYear() + ' ' + brand + '. All rights reserved.</span>' +
    '</div></footer>';

  const body = joinSections([
    [true, navbar],
    [true, hero],
    [true, featuresSection],
    [true, testimonialsSection],
    [true, pricingSection],
    [true, gallerySection],
    [true, contactSection],
    [true, ctaSection],
    [true, footer]
  ]);

  const vars = cssVarBlock(style.colors, colorDefaults);
  const maxWidth = layout === 'wide' ? '1200px' : '960px';

  return '<!DOCTYPE html>\n' +
'<html lang="en" data-theme="' + theme + '">\n' +
'<head>\n' +
'<meta charset="UTF-8">\n' +
'<meta name="viewport" content="width=device-width, initial-scale=1.0">\n' +
'<title>' + brand + '</title>\n' +
'<style>\n' +
vars + '\n' +
'*{box-sizing:border-box;margin:0;padding:0}\n' +
'html{scroll-behavior:smooth}\n' +
'body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:var(--background);color:' + (theme === 'light' ? '#1a1a24' : '#f5f5fa') + ';line-height:1.6}\n' +
'.lp-container{max-width:' + maxWidth + ';margin:0 auto;padding:0 24px}\n' +
'.lp-nav{position:sticky;top:0;z-index:10;backdrop-filter:blur(10px);background:' + (theme === 'light' ? 'rgba(247,247,251,.85)' : 'rgba(13,13,20,.85)') + ';border-bottom:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#1e1e2a') + '}\n' +
'.lp-nav-inner{display:flex;align-items:center;justify-content:space-between;padding:16px 24px;gap:16px}\n' +
'.lp-brand{font-weight:700;font-size:1.15rem}\n' +
'.lp-nav-links{display:flex;gap:20px;font-size:.9rem}\n' +
'.lp-nav-links a{color:inherit;text-decoration:none;opacity:.8}\n' +
'.lp-nav-links a:hover{opacity:1}\n' +
'.lp-btn{display:inline-block;padding:11px 22px;border-radius:8px;font-size:.9rem;font-weight:600;text-decoration:none;border:none;cursor:pointer;transition:transform .15s ease,opacity .15s ease}\n' +
'.lp-btn:hover{transform:translateY(-1px)}\n' +
'.lp-btn-primary{background:var(--primary);color:#fff}\n' +
'.lp-btn-ghost{background:transparent;color:inherit;border:1px solid ' + (theme === 'light' ? '#d6d6e2' : '#2a2a3a') + '}\n' +
'.lp-hero{padding:96px 24px 80px;text-align:center;background:radial-gradient(circle at 50% 0%,color-mix(in srgb,var(--primary) 22%,transparent),transparent 60%)}\n' +
'.lp-hero h1{font-size:clamp(2.2rem,5vw,3.4rem);font-weight:800;max-width:820px;margin:0 auto 20px;letter-spacing:-.02em}\n' +
'.lp-hero-sub{font-size:1.15rem;opacity:.75;max-width:600px;margin:0 auto 32px}\n' +
'.lp-hero-actions{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}\n' +
'.lp-section-title{font-size:2rem;font-weight:700;text-align:center;margin-bottom:40px;letter-spacing:-.01em}\n' +
'.lp-features{padding:80px 0}\n' +
'.lp-feature-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px}\n' +
'.lp-feature-card{padding:28px;border-radius:14px;background:' + (theme === 'light' ? '#fff' : '#15151f') + ';border:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#22222e') + '}\n' +
'.lp-feature-card h3{margin-bottom:10px;color:var(--primary)}\n' +
'.lp-feature-card p{opacity:.75;font-size:.95rem}\n' +
'.lp-testimonials{padding:80px 0;background:' + (theme === 'light' ? '#fff' : '#12121a') + '}\n' +
'.lp-testimonial-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px}\n' +
'.lp-testimonial{padding:24px;border-radius:14px;background:' + (theme === 'light' ? '#f7f7fb' : '#15151f') + ';border:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#22222e') + '}\n' +
'.lp-testimonial p{font-style:italic;opacity:.85;margin-bottom:12px}\n' +
'.lp-testimonial cite{font-weight:600;font-size:.85rem;opacity:.7}\n' +
'.lp-pricing{padding:80px 0}\n' +
'.lp-pricing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px;align-items:stretch}\n' +
'.lp-price-card{padding:32px 24px;border-radius:14px;background:' + (theme === 'light' ? '#fff' : '#15151f') + ';border:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#22222e') + ';display:flex;flex-direction:column;gap:14px}\n' +
'.lp-price-featured{border-color:var(--primary);box-shadow:0 0 0 1px var(--primary)}\n' +
'.lp-price{font-size:1.8rem;font-weight:800;color:var(--primary)}\n' +
'.lp-price-card ul{list-style:none;opacity:.8;font-size:.9rem;display:flex;flex-direction:column;gap:8px;flex:1}\n' +
'.lp-price-card li::before{content:"\\2713  ";color:var(--secondary)}\n' +
'.lp-gallery{padding:80px 0}\n' +
'.lp-gallery-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px}\n' +
'.lp-gallery-item{aspect-ratio:1;border-radius:14px}\n' +
'.lp-contact{padding:80px 0;background:' + (theme === 'light' ? '#fff' : '#12121a') + '}\n' +
'.lp-contact-inner{max-width:520px}\n' +
'.lp-form{display:flex;flex-direction:column;gap:12px}\n' +
'.lp-form input,.lp-form textarea{padding:12px 14px;border-radius:8px;border:1px solid ' + (theme === 'light' ? '#d6d6e2' : '#2a2a3a') + ';background:' + (theme === 'light' ? '#f7f7fb' : '#0d0d14') + ';color:inherit;font:inherit;resize:vertical}\n' +
'.lp-form-status{font-size:.85rem;opacity:.75;min-height:1.2em}\n' +
'.lp-cta{padding:90px 24px;text-align:center}\n' +
'.lp-cta-inner{display:flex;flex-direction:column;align-items:center;gap:18px}\n' +
'.lp-cta h2{font-size:2rem;font-weight:700}\n' +
'.lp-cta p{opacity:.75;max-width:480px}\n' +
'.lp-footer{padding:28px 24px;text-align:center;font-size:.85rem;opacity:.6;border-top:1px solid ' + (theme === 'light' ? '#e6e6ee' : '#1e1e2a') + '}\n' +
'@media(max-width:640px){.lp-nav-links{display:none}}\n' +
'</style>\n' +
'</head>\n' +
'<body id="top">\n' +
body + '\n' +
'</body>\n' +
'</html>';
}
