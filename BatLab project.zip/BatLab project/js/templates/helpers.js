/* ── Shared helpers for the Planner → Template Engine pipeline ──
   Pure, dependency-free utilities used by every template renderer. */

export function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const HEX_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

// Returns `color` if it's a valid hex string, otherwise `fallback`.
export function safeColor(color, fallback) {
  return typeof color === 'string' && HEX_RE.test(color.trim()) ? color.trim() : fallback;
}

// Builds a `:root{--name:value;...}` CSS block from a {name: value} map,
// skipping invalid hex colors (falling back per-key) so a template never
// breaks from a single bad AI-supplied value.
export function cssVarBlock(colors, defaults) {
  const c = colors && typeof colors === 'object' ? colors : {};
  const d = defaults || {};
  const keys = Object.keys(d);
  const decls = keys.map(function (k) {
    return '--' + k + ':' + safeColor(c[k], d[k]) + ';';
  });
  return ':root{' + decls.join('') + '}';
}

// Joins [condition, htmlString] pairs, keeping only truthy sections, in order.
export function joinSections(pairs) {
  return pairs
    .filter(function (pair) { return pair && pair[0] && typeof pair[1] === 'string'; })
    .map(function (pair) { return pair[1]; })
    .join('\n');
}

// Cosmetic-only delay used to pace the stage widget so quick plans don't
// flash through all 6 labels instantly.
export function tinyDelay(ms) {
  return new Promise(function (resolve) { setTimeout(resolve, ms); });
}

// Keeps only allow-listed feature names, silently dropping anything unknown.
export function filterFeatures(features, allowed) {
  if (!Array.isArray(features)) return [];
  const allowSet = new Set(allowed);
  return features.filter(function (f) { return typeof f === 'string' && allowSet.has(f); });
}
